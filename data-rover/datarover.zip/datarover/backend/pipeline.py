"""
Pipeline engine — chains Extract, Transform, and Load steps into a single
scheduled (or on-demand) job.  Reuses downloader / uploader workers and
delegates persistence to config.py.
"""

import threading
import time
import uuid
import datetime
import traceback

import config
import downloader
import uploader

# ---------------------------------------------------------------------------
# In-memory run tracking  (completed runs are also persisted to config.json)
# ---------------------------------------------------------------------------
_pipeline_runs = {}

# ---------------------------------------------------------------------------
# APScheduler (lazy-initialized)
# ---------------------------------------------------------------------------
_scheduler = None


def init_scheduler():
    """Create and start the APScheduler BackgroundScheduler, registering
    all enabled pipelines that have a schedule configured."""
    global _scheduler
    try:
        from apscheduler.schedulers.background import BackgroundScheduler
        from apscheduler.triggers.cron import CronTrigger
        from apscheduler.triggers.date import DateTrigger
    except ImportError:
        print("[pipeline] APScheduler not installed — scheduling disabled")
        return

    _scheduler = BackgroundScheduler(daemon=True)
    _scheduler.start()

    for p in config.get_pipelines():
        if p.get("enabled", True):
            _sync_schedule(p)

    print(f"[pipeline] Scheduler started — {len(_scheduler.get_jobs())} job(s) registered")


def shutdown_scheduler():
    global _scheduler
    if _scheduler:
        _scheduler.shutdown(wait=False)
        _scheduler = None


def _sync_schedule(pipeline):
    """Add or update the APScheduler job for *pipeline*."""
    if _scheduler is None:
        return
    from apscheduler.triggers.cron import CronTrigger
    from apscheduler.triggers.date import DateTrigger

    job_id = f"pipeline_{pipeline['id']}"

    # Remove existing job if any
    existing = _scheduler.get_job(job_id)
    if existing:
        _scheduler.remove_job(job_id)

    schedule = pipeline.get("schedule", {})
    stype = schedule.get("type", "none")
    tz = schedule.get("timezone", "UTC")

    if not pipeline.get("enabled", True) or stype == "none":
        return

    if stype == "recurring" and schedule.get("cron"):
        cron_parts = schedule["cron"].split()
        if len(cron_parts) == 5:
            trigger = CronTrigger(
                minute=cron_parts[0], hour=cron_parts[1],
                day=cron_parts[2], month=cron_parts[3],
                day_of_week=cron_parts[4], timezone=tz,
            )
            _scheduler.add_job(
                _scheduled_run, trigger, args=[pipeline["id"]],
                id=job_id, replace_existing=True,
            )

    elif stype == "once" and schedule.get("runAt"):
        try:
            run_dt = datetime.datetime.fromisoformat(schedule["runAt"])
            trigger = DateTrigger(run_date=run_dt, timezone=tz)
            _scheduler.add_job(
                _scheduled_run, trigger, args=[pipeline["id"]],
                id=job_id, replace_existing=True,
            )
        except Exception:
            pass


def _remove_schedule(pipeline_id):
    if _scheduler is None:
        return
    job_id = f"pipeline_{pipeline_id}"
    if _scheduler.get_job(job_id):
        _scheduler.remove_job(job_id)


def _scheduled_run(pipeline_id):
    """Called by APScheduler when a trigger fires."""
    run_pipeline(pipeline_id)


def get_scheduled_jobs():
    """Return list of scheduled jobs with next run times."""
    if _scheduler is None:
        return []
    result = []
    for job in _scheduler.get_jobs():
        result.append({
            "id": job.id,
            "pipelineId": job.id.replace("pipeline_", ""),
            "nextRunTime": job.next_run_time.isoformat() if job.next_run_time else None,
        })
    return result


# ---------------------------------------------------------------------------
# CRUD  (thin wrappers around config helpers)
# ---------------------------------------------------------------------------

def get_all_pipelines():
    return config.get_pipelines()


def get_pipeline(pipeline_id):
    return config.get_pipeline(pipeline_id)


def save_pipeline(pipeline):
    saved = config.upsert_pipeline(pipeline)
    _sync_schedule(saved)
    return saved


def delete_pipeline_by_id(pipeline_id):
    _remove_schedule(pipeline_id)
    config.delete_pipeline(pipeline_id)


# ---------------------------------------------------------------------------
# Execution engine
# ---------------------------------------------------------------------------

def run_pipeline(pipeline_id):
    """Kick off a pipeline run in a background thread.  Returns run_id."""
    pipeline = config.get_pipeline(pipeline_id)
    if not pipeline:
        raise ValueError(f"Pipeline {pipeline_id} not found")

    run_id = str(uuid.uuid4())[:8]
    run = {
        "runId": run_id,
        "pipelineId": pipeline_id,
        "pipelineName": pipeline.get("name", ""),
        "startedAt": datetime.datetime.now().isoformat(),
        "finishedAt": None,
        "status": "running",
        "stepResults": [],
        "running": True,
        "type": "Pipeline",
    }
    _pipeline_runs[run_id] = run

    t = threading.Thread(
        target=_execute_pipeline,
        args=(run_id, pipeline),
        daemon=True,
    )
    t.start()
    return run_id


def get_run(run_id):
    return _pipeline_runs.get(run_id)


def get_all_runs():
    return list(_pipeline_runs.values())


def _execute_pipeline(run_id, pipeline):
    """Sequentially execute each step of the pipeline."""
    run = _pipeline_runs[run_id]
    steps = pipeline.get("steps", [])

    # Find the extract step (if any) so transform can inherit its DB context
    extract_step = next((s for s in steps if s.get("type") == "extract"), None)

    try:
        for step in steps:
            step_id = step.get("id", "?")
            step_type = step.get("type", "")
            step_result = {"stepId": step_id, "type": step_type, "status": "running", "message": ""}
            run["stepResults"].append(step_result)

            try:
                if step_type == "extract":
                    _run_extract_step(step, step_result)
                elif step_type == "transform":
                    _run_transform_step(step, step_result, extract_step)
                elif step_type == "load":
                    _run_load_step(step, step_result)
                else:
                    step_result["status"] = "error"
                    step_result["message"] = f"Unknown step type: {step_type}"
                    run["status"] = "error"
                    break

                if step_result["status"] == "error":
                    run["status"] = "error"
                    break

            except Exception as e:
                traceback.print_exc()
                step_result["status"] = "error"
                step_result["message"] = str(e)
                run["status"] = "error"
                break

        if run["status"] == "running":
            run["status"] = "complete"

    except Exception as e:
        traceback.print_exc()
        run["status"] = "error"
    finally:
        run["finishedAt"] = datetime.datetime.now().isoformat()
        run["running"] = False
        _persist_run(pipeline["id"], run)


def _build_source_info(step, source_type="salesforce"):
    """Build source_info metadata dict for table comments."""
    if source_type == "database":
        src_name = ""
        try:
            c = config.get_database(step.get("sourceDbConnectionId", ""))
            if c:
                src_name = c.get("name", "")
        except Exception:
            pass
        return {"type": "Database", "connection": src_name, "database": step.get("sourceDatabase", "")}
    else:
        sf_name = ""
        try:
            c = config.get_salesforce(step.get("sfConnectionId") or step.get("sourceConnectionId", ""))
            if c:
                sf_name = c.get("name", "")
        except Exception:
            pass
        return {"type": "Salesforce", "connection": sf_name, "object": ", ".join(step.get("objects", []))}


def _run_extract_step(step, result):
    """Extract data into DB — from SF objects or from a database via SQL."""
    source_type = step.get("sourceType", "salesforce")

    if source_type == "database":
        # DB-to-DB extract via SQL query
        source_info = _build_source_info(step, "database")
        job_id = downloader.start_sql_import_job(
            source_db_conn_id=step["sourceDbConnectionId"],
            target_db_conn_id=step["dbConnectionId"],
            sql=step["sql"],
            table_name=step["tableName"],
            source_database=step.get("sourceDatabase"),
            target_database=step.get("targetDatabase"),
            source_info=source_info,
        )
        result["subJobId"] = job_id
        _wait_for_job(job_id, "download")
        status = downloader.get_status(job_id)
        if status and status.get("status") == "error":
            result["status"] = "error"
            result["message"] = status.get("message", "Extract failed")
        else:
            result["status"] = "complete"
            result["message"] = status.get("message", "Extract complete")
    else:
        # SF extract (original path)
        objects = step.get("objects", [])
        table_names = step.get("tableNames", {})
        import_modes = step.get("importModes", {})
        sf_conn_id = step.get("sfConnectionId") or step.get("sourceConnectionId", "")
        source_info = _build_source_info(step, "salesforce")
        job_id = downloader.start_job(
            sf_conn_id=sf_conn_id,
            db_conn_id=step["dbConnectionId"],
            object_names=objects,
            table_names=table_names if table_names else None,
            target_database=step.get("targetDatabase"),
            source_info=source_info,
            import_modes=import_modes if import_modes else None,
        )
        result["subJobId"] = job_id
        _wait_for_job(job_id, "download")
        status = downloader.get_status(job_id)
        # Check per-object statuses
        errors = {k: v for k, v in (status.get("errors") or {}).items() if v}
        if errors:
            result["status"] = "error"
            result["message"] = "; ".join(f"{k}: {v}" for k, v in errors.items())
        else:
            result["status"] = "complete"
            result["message"] = f"Extracted {', '.join(objects)}"


def _run_transform_step(step, result, extract_step=None):
    """Run a SQL transform (DB-to-DB copy via SQL).
    Inherits DB connection/database from extract step when not set explicitly."""
    # Fall back to extract step's DB connection and database
    source_db = step.get("sourceDbConnectionId") or (extract_step or {}).get("dbConnectionId", "")
    target_db = step.get("targetDbConnectionId") or (extract_step or {}).get("dbConnectionId", "")
    source_database = step.get("sourceDatabase") or (extract_step or {}).get("targetDatabase", "")
    target_database = step.get("targetDatabase") or (extract_step or {}).get("targetDatabase", "")

    src_name = ""
    try:
        c = config.get_database(source_db)
        if c:
            src_name = c.get("name", "")
    except Exception:
        pass
    source_info = {"type": "Database", "connection": src_name, "database": source_database}

    job_id = downloader.start_sql_import_job(
        source_db_conn_id=source_db,
        target_db_conn_id=target_db,
        sql=step["sql"],
        table_name=step["tableName"],
        source_database=source_database,
        target_database=target_database,
        source_info=source_info,
    )
    result["subJobId"] = job_id
    _wait_for_job(job_id, "download")
    status = downloader.get_status(job_id)
    if status and status.get("status") == "error":
        result["status"] = "error"
        result["message"] = status.get("message", "Transform failed")
    else:
        result["status"] = "complete"
        result["message"] = status.get("message", "Transform complete")


def _run_load_step(step, result):
    """Upload data from DB table to SF."""
    job_id = uploader.start_job(
        sf_conn_id=step["sfConnectionId"],
        db_conn_id=step["dbConnectionId"],
        table_name=step["tableName"],
        object_name=step["objectName"],
        operation=step.get("operation", "insert"),
        column_mapping=step.get("columnMapping", {}),
        external_id_field=step.get("externalIdField"),
    )
    result["subJobId"] = job_id
    _wait_for_job(job_id, "upload")
    status = uploader.get_status(job_id)
    if status and status.get("error_count", 0) > 0:
        result["status"] = "error"
        result["message"] = f"{status.get('success_count', 0)} succeeded, {status['error_count']} failed"
    elif status and status.get("status") == "error":
        result["status"] = "error"
        result["message"] = status.get("message", "Upload failed")
    else:
        result["status"] = "complete"
        result["message"] = f"Loaded {status.get('success_count', 0)} records"


def _wait_for_job(job_id, job_type):
    """Poll until a sub-job finishes."""
    getter = downloader.get_status if job_type == "download" else uploader.get_status
    while True:
        status = getter(job_id)
        if status is None or not status.get("running", False):
            return
        time.sleep(2)


def _persist_run(pipeline_id, run):
    """Save the completed run summary into the pipeline's lastRuns (cap at 10)
    and also persist to the jobs table for history."""
    try:
        pipeline = config.get_pipeline(pipeline_id)
        if not pipeline:
            return
        last_runs = pipeline.get("lastRuns", [])
        summary = {
            "runId": run["runId"],
            "startedAt": run["startedAt"],
            "finishedAt": run["finishedAt"],
            "status": run["status"],
            "stepResults": run["stepResults"],
        }
        last_runs.insert(0, summary)
        pipeline["lastRuns"] = last_runs[:10]
        config.upsert_pipeline(pipeline)
    except Exception:
        traceback.print_exc()
    # Persist to jobs table
    try:
        import store
        store.save_job({**run, "id": run["runId"]})
    except Exception:
        traceback.print_exc()
