"""CLI command parser and dispatcher for the embedded terminal.

Parses text commands and routes them to existing backend functions.
"""

import config
import salesforce_client
import db_client
import downloader
import uploader
import attachment_handler
import quick_loader
import pipeline
import store
import time
import threading

# Cache for object/table lists (per connection, with TTL)
_cache = {}
_cache_lock = threading.Lock()
_CACHE_TTL = 60  # seconds

COMMANDS = [
    "help", "connections", "use", "objects", "databases", "tables",
    "describe", "count", "query", "sql", "preview", "extract", "load",
    "jobs", "job", "clear",
]

HELP_TEXT = """Available commands:

  help                          Show this help message
  connections                   List all connections
  use sf <name>                 Set active Salesforce connection
  use db <name>                 Set active database connection
  use database <name>           Set active database within connection
  objects                       List Salesforce objects
  databases                     List databases in active DB connection
  tables [database]             List database tables
  describe <object|table>       Show fields/columns
  count <object|table>          Get record count
  query <SOQL or SQL>           Execute a query
  sql <SQL statement>           Execute SQL against database (DDL/DML)
  load <table> <object> [op]   Load DB table to Salesforce (op: update/insert/upsert/delete)
  preview <object|table>        Show sample rows
  extract <object> [object...]  Extract SF objects to database
  jobs                          List recent jobs
  job <id|#|last>               Show job status (by ID, row #, or 'last')
  clear                         Clear terminal"""


def _get_cached(key):
    with _cache_lock:
        entry = _cache.get(key)
        if entry and (time.time() - entry["ts"]) < _CACHE_TTL:
            return entry["data"]
    return None


def _set_cached(key, data):
    with _cache_lock:
        _cache[key] = {"data": data, "ts": time.time()}


def _find_sf_conn(name):
    """Find a Salesforce connection by name (case-insensitive)."""
    data = config.get_all()
    for c in data.get("salesforce_connections", []):
        if c.get("name", "").lower() == name.lower():
            return c
        if c.get("id") == name:
            return c
    return None


def _find_db_conn(name):
    """Find a database connection by name (case-insensitive)."""
    data = config.get_all()
    for c in data.get("database_connections", []):
        if c.get("name", "").lower() == name.lower():
            return c
        if c.get("id") == name:
            return c
    return None


def _get_sf_conn(context):
    conn_id = context.get("sfConnectionId")
    if not conn_id:
        return None
    return config.get_salesforce(conn_id)


def _get_db_conn(context):
    conn_id = context.get("dbConnectionId")
    if not conn_id:
        return None
    return config.get_database(conn_id)


def _text(output):
    return {"output": output, "type": "text"}


def _error(output):
    return {"output": output, "type": "error"}


def _table(columns, rows):
    return {"output": "", "type": "table", "columns": columns, "rows": rows}


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------

def _cmd_help(args, context):
    return _text(HELP_TEXT)


def _cmd_connections(args, context):
    data = config.get_all()
    lines = []
    sf = data.get("salesforce_connections", [])
    db = data.get("database_connections", [])
    if sf:
        lines.append("Salesforce Connections:")
        for c in sf:
            lines.append(f"  {c.get('name', '?')}  (id: {c.get('id', '?')})")
    if db:
        lines.append("Database Connections:")
        for c in db:
            db_type = c.get("dbType", "postgres")
            lines.append(f"  {c.get('name', '?')}  [{db_type}]  (id: {c.get('id', '?')})")
    if not sf and not db:
        lines.append("No connections configured.")
    return _text("\n".join(lines))


def _cmd_use(args, context):
    if len(args) < 2:
        return _error("Usage: use sf <name>  |  use db <name>  |  use database <name>")
    conn_type = args[0].lower()
    name = " ".join(args[1:])
    if conn_type == "sf":
        conn = _find_sf_conn(name)
        if not conn:
            return _error(f"Salesforce connection '{name}' not found")
        return {
            "output": f"Active Salesforce connection: {conn['name']}",
            "type": "text",
            "setConnection": {"type": "sf", "id": conn["id"]},
        }
    elif conn_type == "db":
        conn = _find_db_conn(name)
        if not conn:
            return _error(f"Database connection '{name}' not found")
        return {
            "output": f"Active database connection: {conn['name']} [{conn.get('dbType', 'postgres')}]",
            "type": "text",
            "setConnection": {"type": "db", "id": conn["id"]},
        }
    elif conn_type == "database":
        # Set active database within the current DB connection
        return {
            "output": f"Active database: {name}",
            "type": "text",
            "setDatabase": name,
        }
    else:
        return _error("Usage: use sf <name>  |  use db <name>  |  use database <name>")


def _cmd_objects(args, context):
    conn = _get_sf_conn(context)
    if not conn:
        return _error("No active Salesforce connection. Use: use sf <name>")
    cache_key = f"objects:{conn['id']}"
    cached = _get_cached(cache_key)
    if cached:
        objects = cached
    else:
        sf = salesforce_client.connect(conn)
        objects = salesforce_client.list_objects_fast(sf)
        _set_cached(cache_key, objects)
    columns = ["API Name", "Label"]
    rows = [{"API Name": o["apiName"], "Label": o["name"]} for o in objects]
    return _table(columns, rows)


def _cmd_databases(args, context):
    conn = _get_db_conn(context)
    if not conn:
        return _error("No active database connection. Use: use db <name>")
    db_type = conn.get("dbType", "")
    is_duckdb = db_type == "duckdb"
    is_athena = db_type == "athena"
    is_mysql = db_type == "mysql"
    if is_duckdb:
        import os as _os
        filepath = _os.path.expanduser(conn.get("filepath", "~/sfdc-loader/duckdb"))
        _os.makedirs(filepath, exist_ok=True)
        databases = sorted([f[:-7] for f in _os.listdir(filepath) if f.endswith(".duckdb")])
        if not databases:
            databases = ["default"]
    elif is_athena or is_mysql:
        db = db_client.get_connection(conn)
        cur = db.cursor()
        cur.execute("SHOW DATABASES")
        databases = [row[0] for row in cur.fetchall()]
        cur.close()
        db.close()
    else:
        # PostgreSQL / Redshift
        db = db_client.get_connection(conn)
        cur = db.cursor()
        cur.execute("SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname")
        databases = [row[0] for row in cur.fetchall()]
        cur.close()
        db.close()
    current = context.get("database") or conn.get("database", "")
    columns = ["Database"]
    rows = [{"Database": (f"{d}  (active)" if d == current else d)} for d in databases]
    return {**_table(columns, rows), "output": f"{conn.get('name', '?')} [{db_type or 'postgres'}] — {len(databases)} databases"}


def _cmd_tables(args, context):
    conn = _get_db_conn(context)
    if not conn:
        return _error("No active database connection. Use: use db <name>")
    database = args[0] if args else context.get("database") or conn.get("database")
    conn_with_db = {**conn}
    if database:
        conn_with_db["database"] = database
    db_type = conn.get("dbType", "")
    is_duckdb = db_type == "duckdb"
    is_athena = db_type == "athena"
    is_mysql = db_type == "mysql"
    db = db_client.get_connection(conn_with_db)
    cur = db.cursor()
    if is_duckdb:
        cur.execute("SHOW TABLES")
    elif is_athena or is_mysql:
        cur.execute("SHOW TABLES")
    else:
        cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public' ORDER BY table_name")
    tables = [row[0] for row in cur.fetchall()]
    cur.close()
    db.close()
    columns = ["Table Name"]
    rows = [{"Table Name": t} for t in tables]
    db_name = database or conn.get("database", "default")
    if not rows:
        return _text(f"No tables found in database '{db_name}'.")
    return {**_table(columns, rows), "output": f"Database: {db_name} ({len(tables)} tables)"}


def _cmd_describe(args, context):
    if not args:
        return _error("Usage: describe <object|table>")
    name = args[0]
    # Try Salesforce first if connection is active
    sf_conn = _get_sf_conn(context)
    if sf_conn:
        try:
            sf = salesforce_client.connect(sf_conn)
            desc = getattr(sf, name).describe()
            columns = ["Field", "Label", "Type", "Length", "Required", "Createable"]
            rows = []
            for f in desc["fields"]:
                rows.append({
                    "Field": f["name"],
                    "Label": f.get("label", ""),
                    "Type": f["type"],
                    "Length": str(f.get("length", "")),
                    "Required": "Yes" if (not f.get("nillable", True) and not f.get("defaultedOnCreate", False)) else "",
                    "Createable": "Yes" if f.get("createable") else "",
                })
            label = desc.get("label", name)
            return {**_table(columns, rows), "output": f"{label} ({name}) \u2014 {len(rows)} fields"}
        except Exception:
            pass  # Fall through to DB
    # Try database
    db_conn = _get_db_conn(context)
    if db_conn:
        try:
            db_type = db_conn.get("dbType", "")
            is_duckdb = db_type == "duckdb"
            is_mysql = db_type == "mysql"
            is_athena = db_type == "athena"
            database = context.get("database") or db_conn.get("database")
            conn_with_db = {**db_conn}
            if database:
                conn_with_db["database"] = database
            db = db_client.get_connection(conn_with_db)
            cur = db.cursor()
            if is_duckdb:
                cur.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = ? ORDER BY ordinal_position", (name,))
            elif is_mysql:
                cur.execute(f"SHOW COLUMNS FROM `{name}`")
            elif is_athena:
                cur.execute(f"DESCRIBE {name}")
            else:
                cur.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_schema = 'public' AND table_name = %s ORDER BY ordinal_position", (name,))
            if is_mysql:
                columns = ["Column", "Type"]
                rows = [{"Column": r[0], "Type": r[1]} for r in cur.fetchall()]
            elif is_athena:
                columns = ["Column", "Type"]
                rows = []
                for r in cur.fetchall():
                    parts = [p.strip() for p in r[0].split("\t") if p.strip()]
                    if len(parts) >= 2 and not parts[0].startswith("#"):
                        rows.append({"Column": parts[0], "Type": parts[1]})
            else:
                columns = ["Column", "Type"]
                rows = [{"Column": r[0], "Type": r[1]} for r in cur.fetchall()]
            cur.close()
            db.close()
            if rows:
                return {**_table(columns, rows), "output": f"Table: {name} \u2014 {len(rows)} columns"}
        except Exception:
            pass
    if not sf_conn and not db_conn:
        return _error("No active connection. Use: use sf <name>  or  use db <name>")
    return _error(f"'{name}' not found as a Salesforce object or database table.")


def _cmd_count(args, context):
    if not args:
        return _error("Usage: count <object|table>")
    name = args[0]
    sf_conn = _get_sf_conn(context)
    if sf_conn:
        try:
            sf = salesforce_client.connect(sf_conn)
            result = sf.query(f"SELECT COUNT() FROM {name}")
            count = result.get("totalSize", 0)
            return _text(f"{name}: {count:,} records")
        except Exception:
            pass
    db_conn = _get_db_conn(context)
    if db_conn:
        try:
            database = context.get("database") or db_conn.get("database")
            conn_with_db = {**db_conn}
            if database:
                conn_with_db["database"] = database
            db_type = db_conn.get("dbType", "")
            is_mysql = db_type == "mysql"
            is_athena = db_type == "athena"
            quote = '`' if is_mysql else ('' if is_athena else '"')
            db = db_client.get_connection(conn_with_db)
            cur = db.cursor()
            cur.execute(f'SELECT COUNT(*) FROM {quote}{name}{quote}')
            count = cur.fetchone()[0]
            cur.close()
            db.close()
            return _text(f"{name}: {count:,} rows")
        except Exception:
            pass
    if not sf_conn and not db_conn:
        return _error("No active connection. Use: use sf <name>  or  use db <name>")
    return _error(f"'{name}' not found.")


def _cmd_query(args, context):
    if not args:
        return _error("Usage: query <SOQL or SQL statement>")
    query_str = " ".join(args)
    # Detect SOQL vs SQL: SOQL uses FROM <ObjectName> (capitalized, no schema)
    is_soql = query_str.upper().lstrip().startswith("SELECT") and _looks_like_soql(query_str)
    if is_soql:
        sf_conn = _get_sf_conn(context)
        if not sf_conn:
            return _error("No active Salesforce connection. Use: use sf <name>")
        sf = salesforce_client.connect(sf_conn)
        result = sf.query_all(query_str)
        records = result.get("records", [])
        total = result.get("totalSize", 0)
        if not records:
            return _text(f"No records returned. (totalSize: {total})")
        raw_columns = [k for k in records[0].keys() if k != "attributes"]
        # Flatten relationship fields
        columns = []
        for col in raw_columns:
            sample = records[0].get(col)
            if isinstance(sample, dict) and "attributes" in sample:
                sub_keys = [k for k in sample.keys() if k != "attributes"]
                for sk in sub_keys:
                    columns.append(f"{col}.{sk}")
            else:
                columns.append(col)
        rows = []
        for rec in records:
            row = {}
            for col in raw_columns:
                val = rec.get(col)
                if isinstance(val, dict) and "attributes" in val:
                    sub_keys = [k for k in val.keys() if k != "attributes"]
                    for sk in sub_keys:
                        sv = val.get(sk)
                        row[f"{col}.{sk}"] = str(sv) if sv is not None else None
                else:
                    row[col] = str(val) if val is not None else None
            rows.append(row)
        output = f"{len(rows)} of {total} records"
        return {**_table(columns, rows), "output": output}
    else:
        db_conn = _get_db_conn(context)
        if not db_conn:
            return _error("No active database connection. Use: use db <name>")
        database = context.get("database") or db_conn.get("database")
        conn_with_db = {**db_conn}
        if database:
            conn_with_db["database"] = database
        db = db_client.get_connection(conn_with_db)
        cur = db.cursor()
        cur.execute(query_str)
        if cur.description:
            columns = [desc[0] for desc in cur.description]
            raw_rows = cur.fetchall()
            rows = []
            for row in raw_rows:
                rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
            result = {**_table(columns, rows), "output": f"{len(rows)} rows"}
        else:
            db.commit()
            result = _text(f"{cur.rowcount} row(s) affected")
        cur.close()
        db.close()
        return result


def _looks_like_soql(query_str):
    """Heuristic: if FROM target has no dot/schema, likely SOQL."""
    upper = query_str.upper()
    idx = upper.find("FROM")
    if idx < 0:
        return False
    after_from = query_str[idx + 4:].strip().split()[0] if query_str[idx + 4:].strip() else ""
    # SOQL objects don't have dots (unless relationship query) or quotes
    if '"' in after_from or "." in after_from:
        return False
    # SOQL objects typically start with uppercase
    return after_from[:1].isupper() if after_from else False


def _cmd_preview(args, context):
    if not args:
        return _error("Usage: preview <object|table>")
    name = args[0]
    sf_conn = _get_sf_conn(context)
    if sf_conn:
        try:
            sf = salesforce_client.connect(sf_conn)
            desc = getattr(sf, name).describe()
            field_names = [f["name"] for f in desc["fields"] if f.get("type") != "address"][:15]
            if not field_names:
                field_names = ["Id"]
            soql = f"SELECT {', '.join(field_names)} FROM {name} LIMIT 10"
            result = sf.query(soql)
            rows = []
            for rec in result.get("records", []):
                row = {k: (str(v) if v is not None else None) for k, v in rec.items() if k != "attributes"}
                rows.append(row)
            return {**_table(field_names, rows), "output": f"Preview: {name} ({len(rows)} rows)"}
        except Exception:
            pass
    db_conn = _get_db_conn(context)
    if db_conn:
        try:
            database = context.get("database") or db_conn.get("database")
            conn_with_db = {**db_conn}
            if database:
                conn_with_db["database"] = database
            db_type = db_conn.get("dbType", "")
            is_mysql = db_type == "mysql"
            is_athena = db_type == "athena"
            quote = '`' if is_mysql else ('' if is_athena else '"')
            db = db_client.get_connection(conn_with_db)
            cur = db.cursor()
            cur.execute(f'SELECT * FROM {quote}{name}{quote} LIMIT 25')
            columns = [desc[0] for desc in cur.description]
            rows = []
            for row in cur.fetchall():
                rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
            cur.close()
            db.close()
            return {**_table(columns, rows), "output": f"Preview: {name} ({len(rows)} rows)"}
        except Exception:
            pass
    if not sf_conn and not db_conn:
        return _error("No active connection. Use: use sf <name>  or  use db <name>")
    return _error(f"'{name}' not found.")


def _cmd_extract(args, context):
    if not args:
        return _error("Usage: extract <object> [object2 ...]")
    sf_conn = _get_sf_conn(context)
    db_conn = _get_db_conn(context)
    if not sf_conn:
        return _error("No active Salesforce connection. Use: use sf <name>")
    if not db_conn:
        return _error("No active database connection. Use: use db <name>")
    objects = args
    target_database = context.get("database") or db_conn.get("database")
    job_id = downloader.start_job(
        sf_conn["id"], db_conn["id"], objects,
        target_database=target_database,
    )
    return _text(f"Extract started. Job ID: {job_id}\nObjects: {', '.join(objects)}\nUse 'job {job_id}' to check status.")


def _cmd_sql(args, context):
    if not args:
        return _error("Usage: sql <SQL statement>")
    sql_str = " ".join(args)
    db_conn = _get_db_conn(context)
    if not db_conn:
        return _error("No active database connection. Use: use db <name>")
    database = context.get("database") or db_conn.get("database")
    conn_with_db = {**db_conn}
    if database:
        conn_with_db["database"] = database
    db = db_client.get_connection(conn_with_db)
    cur = db.cursor()
    # Support multiple statements separated by semicolons
    statements = [s.strip() for s in sql_str.split(";") if s.strip()]
    last_result = None
    total_affected = 0
    for stmt in statements:
        cur.execute(stmt)
        if cur.description:
            columns = [desc[0] for desc in cur.description]
            raw_rows = cur.fetchall()
            rows = []
            for row in raw_rows:
                rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
            last_result = {**_table(columns, rows), "output": f"{len(rows)} rows"}
        else:
            db.commit()
            total_affected += cur.rowcount if cur.rowcount >= 0 else 0
    cur.close()
    db.close()
    if last_result:
        return last_result
    return _text(f"OK. {total_affected} row(s) affected. ({len(statements)} statement(s))")


def _cmd_load(args, context):
    if not args:
        return _error("Usage: load <postgres_table> <sf_object> [operation]\n  operation: update (default), insert, upsert, delete")
    if len(args) < 2:
        return _error("Usage: load <postgres_table> <sf_object> [operation]")
    table_name = args[0]
    object_name = args[1]
    operation = args[2].lower() if len(args) > 2 else "update"
    if operation not in ("insert", "update", "upsert", "delete"):
        return _error(f"Unknown operation '{operation}'. Use: insert, update, upsert, delete")
    sf_conn = _get_sf_conn(context)
    db_conn = _get_db_conn(context)
    if not sf_conn:
        return _error("No active Salesforce connection. Use: use sf <name>")
    if not db_conn:
        return _error("No active database connection. Use: use db <name>")
    database = context.get("database") or db_conn.get("database")
    external_id_field = None
    # Check for --extid flag
    if len(args) > 3 and args[3] == "--extid" and len(args) > 4:
        external_id_field = args[4]
    job_id = uploader.start_job(
        sf_conn["id"], db_conn["id"], table_name, object_name, operation,
        column_mapping={},
        external_id_field=external_id_field,
        source_database=database,
    )
    return _text(f"Load started. Job ID: {job_id}\n  {table_name} → {object_name} ({operation})\nUse 'job {job_id}' to check status.")


_last_jobs_list = []  # cached ordered list of job IDs from last `jobs` command


def _get_all_jobs_sorted():
    """Gather all jobs from all sources, sorted most recent first."""
    in_memory = {}
    for j in downloader._jobs.values():
        in_memory[j["id"]] = {**j, "jobType": "import"}
    for j in uploader._jobs.values():
        entry = {k: v for k, v in j.items() if k != "record_results"}
        entry["jobType"] = "upload"
        in_memory[j["id"]] = entry
    for j in attachment_handler._jobs.values():
        entry = {k: v for k, v in j.items() if k != "file_results"}
        entry["jobType"] = "attachment"
        in_memory[j["id"]] = entry
    for j in quick_loader._jobs.values():
        entry = {k: v for k, v in j.items() if k != "record_results"}
        entry["jobType"] = "quick_load"
        in_memory[j["id"]] = entry
    for j in pipeline.get_all_runs():
        in_memory[j["runId"]] = {**j, "jobType": "pipeline"}
    for j in store.get_jobs():
        job_id = j.get("id") or j.get("runId", "")
        if job_id not in in_memory:
            in_memory[job_id] = j
    jobs = list(in_memory.values())
    jobs.sort(key=lambda j: j.get("startedAt", j.get("startTime", "")), reverse=True)
    return jobs


def _cmd_jobs(args, context):
    global _last_jobs_list
    jobs = _get_all_jobs_sorted()
    if not jobs:
        return _text("No jobs found.")
    # Cache job IDs for `job 1`, `job 2`, `job last` lookups
    _last_jobs_list = [j.get("id") or j.get("runId", "") for j in jobs]
    columns = ["#", "ID", "Type", "Status", "Object/Table", "Started"]
    rows = []
    for idx, j in enumerate(jobs[:20], 1):
        jid = j.get("id") or j.get("runId", "")
        jtype = j.get("jobType", "?")
        running = j.get("running", False)
        status = "running" if running else (j.get("status", "done"))
        obj = j.get("object", j.get("objects", j.get("pipelineName", "")))
        if isinstance(obj, list):
            obj = ", ".join(obj)
        started = j.get("startedAt", j.get("startTime", ""))
        rows.append({"#": str(idx), "ID": str(jid)[:12], "Type": jtype, "Status": status, "Object/Table": str(obj), "Started": str(started)[:19]})
    return {**_table(columns, rows), "output": f"{len(jobs)} total jobs (showing latest {len(rows)}). Use 'job <#>' or 'job last' to view details."}


def _cmd_job(args, context):
    global _last_jobs_list
    if not args:
        return _error("Usage: job <id|#|last>")
    job_id = args[0]
    # Support "job last" and "job 1", "job 2", etc.
    if job_id.lower() == "last":
        if not _last_jobs_list:
            jobs = _get_all_jobs_sorted()
            if not jobs:
                return _error("No jobs found.")
            _last_jobs_list = [j.get("id") or j.get("runId", "") for j in jobs]
        job_id = _last_jobs_list[0]
    elif job_id.isdigit():
        idx = int(job_id)
        if not _last_jobs_list:
            jobs = _get_all_jobs_sorted()
            if not jobs:
                return _error("No jobs found.")
            _last_jobs_list = [j.get("id") or j.get("runId", "") for j in jobs]
        if idx < 1 or idx > len(_last_jobs_list):
            return _error(f"Job #{idx} not found. Run 'jobs' to see available jobs (1-{len(_last_jobs_list)}).")
        job_id = _last_jobs_list[idx - 1]
    # Check in-memory jobs first
    for store_dict in [downloader._jobs, uploader._jobs, attachment_handler._jobs, quick_loader._jobs]:
        if job_id in store_dict:
            j = store_dict[job_id]
            lines = [f"Job: {job_id}"]
            lines.append(f"  Type: {j.get('jobType', '?')}")
            lines.append(f"  Running: {j.get('running', False)}")
            lines.append(f"  Object: {j.get('object', j.get('objects', '?'))}")
            if j.get("totalRecords"):
                lines.append(f"  Total Records: {j['totalRecords']:,}")
            if j.get("processedRecords"):
                lines.append(f"  Processed: {j['processedRecords']:,}")
            if j.get("errors"):
                lines.append(f"  Errors: {j['errors']}")
            if j.get("status"):
                lines.append(f"  Status: {j['status']}")
            return _text("\n".join(lines))
    # Check persisted jobs
    persisted = store.get_jobs()
    for j in persisted:
        jid = j.get("id") or j.get("runId", "")
        if jid == job_id or str(jid).startswith(job_id):
            lines = [f"Job: {jid}"]
            for k, v in j.items():
                if k not in ("id", "runId", "record_results", "file_results"):
                    lines.append(f"  {k}: {v}")
            return _text("\n".join(lines))
    return _error(f"Job '{job_id}' not found.")


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------

_DISPATCH = {
    "help": _cmd_help,
    "connections": _cmd_connections,
    "use": _cmd_use,
    "objects": _cmd_objects,
    "databases": _cmd_databases,
    "tables": _cmd_tables,
    "describe": _cmd_describe,
    "count": _cmd_count,
    "query": _cmd_query,
    "sql": _cmd_sql,
    "preview": _cmd_preview,
    "extract": _cmd_extract,
    "load": _cmd_load,
    "jobs": _cmd_jobs,
    "job": _cmd_job,
}


def execute(command_str, context):
    """Parse and execute a CLI command. Returns a dict with output, type, etc."""
    parts = command_str.strip().split(None, 1)
    if not parts:
        return _text("")
    cmd = parts[0].lower()
    # For 'query', pass the entire rest as-is (preserve spacing)
    if cmd == "query":
        args = [parts[1]] if len(parts) > 1 else []
    elif cmd == "use":
        # Split 'use sf Name' into ['sf', 'Name']
        rest = parts[1] if len(parts) > 1 else ""
        args = rest.split(None, 1)  # max 2 parts: type + name
    else:
        args = parts[1].split() if len(parts) > 1 else []
    handler = _DISPATCH.get(cmd)
    if not handler:
        return _error(f"Unknown command: {cmd}\nType 'help' for available commands.")
    return handler(args, context)


def get_completions(partial, context):
    """Return tab-completion suggestions for the given partial input."""
    parts = partial.strip().split()
    if not parts or (len(parts) == 1 and not partial.endswith(" ")):
        # Complete command name
        prefix = parts[0].lower() if parts else ""
        return [c for c in COMMANDS if c.startswith(prefix)]
    cmd = parts[0].lower()
    if cmd == "use":
        if len(parts) == 1 or (len(parts) == 2 and not partial.endswith(" ")):
            prefix = parts[1].lower() if len(parts) > 1 else ""
            return [t for t in ["sf", "db"] if t.startswith(prefix)]
        if len(parts) >= 2:
            conn_type = parts[1].lower()
            name_prefix = (" ".join(parts[2:])).lower() if len(parts) > 2 else ""
            data = config.get_all()
            if conn_type == "sf":
                return [c["name"] for c in data.get("salesforce_connections", []) if c.get("name", "").lower().startswith(name_prefix)]
            elif conn_type == "db":
                return [c["name"] for c in data.get("database_connections", []) if c.get("name", "").lower().startswith(name_prefix)]
    if cmd in ("describe", "count", "preview", "extract"):
        prefix = parts[1].lower() if len(parts) > 1 and not partial.endswith(" ") else ""
        if partial.endswith(" ") and len(parts) > 1:
            prefix = ""
        suggestions = []
        # SF objects
        sf_conn = _get_sf_conn(context)
        if sf_conn:
            cache_key = f"objects:{sf_conn['id']}"
            objects = _get_cached(cache_key)
            if objects:
                suggestions.extend([o["apiName"] for o in objects if o["apiName"].lower().startswith(prefix)])
        # DB tables
        db_conn = _get_db_conn(context)
        if db_conn:
            cache_key = f"tables:{db_conn['id']}"
            tables = _get_cached(cache_key)
            if tables:
                suggestions.extend([t for t in tables if t.lower().startswith(prefix)])
        return suggestions
    return []
