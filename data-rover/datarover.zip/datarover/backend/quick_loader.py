"""Quick Load: File → SQLite → Salesforce upload pipeline.

Parses CSV/XLSX files into an in-memory SQLite database, allows SQL
transformations, then uploads to Salesforce using the existing bulk API.
"""

import csv
import io
import os
import sqlite3
import threading
import time
import traceback
import uuid
import datetime

import salesforce_client
import config
import store

# ── Session store ────────────────────────────────────────────────────

_sessions = {}  # session_id → { "db": sqlite3.Connection, "created": float, "columns": [...] }
_jobs = {}      # job_id → upload status dict


def cancel_job(job_id):
    job = _jobs.get(job_id)
    if not job:
        return False
    if job.get("running"):
        job["_cancel"] = True
        return True
    return False


SESSION_TTL = 30 * 60  # 30 minutes


def _cleanup_expired():
    """Remove sessions older than SESSION_TTL."""
    now = time.time()
    expired = [sid for sid, s in _sessions.items() if now - s["created"] > SESSION_TTL]
    for sid in expired:
        try:
            _sessions[sid]["db"].close()
        except Exception:
            pass
        del _sessions[sid]


# ── File parsing ─────────────────────────────────────────────────────

def _parse_csv(content_bytes):
    """Parse CSV bytes into (columns, rows) where rows is list of tuples."""
    text = content_bytes.decode("utf-8-sig")
    reader = csv.reader(io.StringIO(text))
    header = next(reader, None)
    if not header:
        raise ValueError("CSV file has no header row")
    columns = [col.strip() for col in header]
    rows = [tuple(row) for row in reader if any(cell.strip() for cell in row)]
    return columns, rows


def _parse_xlsx(content_bytes):
    """Parse XLSX bytes into (columns, rows) using openpyxl."""
    import openpyxl
    wb = openpyxl.load_workbook(io.BytesIO(content_bytes), read_only=True, data_only=True)
    ws = wb.active
    rows_iter = ws.iter_rows(values_only=True)
    header = next(rows_iter, None)
    if not header:
        raise ValueError("Excel file has no header row")
    columns = [str(col).strip() if col is not None else f"col_{i}" for i, col in enumerate(header)]
    rows = []
    for row in rows_iter:
        if any(cell is not None for cell in row):
            rows.append(tuple(
                str(cell) if cell is not None else None
                for cell in row
            ))
    wb.close()
    return columns, rows


# ── Session management ───────────────────────────────────────────────

def create_session(filename, content_bytes, file_type):
    """Parse file and load into in-memory SQLite. Returns session info."""
    _cleanup_expired()

    if file_type == "xlsx":
        columns, rows = _parse_xlsx(content_bytes)
    else:
        columns, rows = _parse_csv(content_bytes)

    # Sanitize column names for SQLite (replace spaces, special chars)
    safe_columns = []
    for col in columns:
        safe = col.replace(" ", "_").replace("-", "_").replace(".", "_")
        # Remove any remaining non-alphanumeric chars (except underscore)
        safe = "".join(c for c in safe if c.isalnum() or c == "_")
        if not safe:
            safe = f"col_{len(safe_columns)}"
        safe_columns.append(safe)

    session_id = str(uuid.uuid4())[:8]
    db = sqlite3.connect(":memory:", check_same_thread=False)
    db.row_factory = sqlite3.Row

    # Create table
    col_defs = ", ".join(f'"{c}" TEXT' for c in safe_columns)
    db.execute(f'CREATE TABLE data ({col_defs})')

    # Insert rows
    if rows:
        placeholders = ", ".join("?" * len(safe_columns))
        db.executemany(f'INSERT INTO data VALUES ({placeholders})', rows)
    db.commit()

    _sessions[session_id] = {
        "db": db,
        "created": time.time(),
        "columns": safe_columns,
        "original_columns": columns,
        "filename": filename,
    }

    # Return preview
    preview = _get_preview_data(session_id, limit=25)
    return {
        "sessionId": session_id,
        "filename": filename,
        "columns": safe_columns,
        "originalColumns": columns,
        "rowCount": len(rows),
        "preview": preview,
    }


def run_query(session_id, sql):
    """Execute SQL against the session's SQLite database."""
    session = _sessions.get(session_id)
    if not session:
        raise ValueError("Session not found or expired")

    db = session["db"]
    sql = sql.strip()
    if not sql:
        raise ValueError("No SQL provided")

    cursor = db.execute(sql)

    # If it's a SELECT, return results
    if cursor.description:
        columns = [desc[0] for desc in cursor.description]
        rows = []
        for row in cursor.fetchall():
            rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
        return {"columns": columns, "rows": rows, "rowCount": len(rows)}
    else:
        db.commit()
        # After DML, refresh the column list from the data table
        try:
            cur2 = db.execute("SELECT * FROM data LIMIT 0")
            session["columns"] = [desc[0] for desc in cur2.description]
        except Exception:
            pass
        return {"columns": [], "rows": [], "rowCount": cursor.rowcount, "message": f"{cursor.rowcount} row(s) affected"}


def get_preview(session_id, limit=25):
    """Return current state of the data table."""
    session = _sessions.get(session_id)
    if not session:
        raise ValueError("Session not found or expired")
    return _get_preview_data(session_id, limit)


def _get_preview_data(session_id, limit=25):
    """Internal: fetch preview rows from the data table."""
    session = _sessions[session_id]
    db = session["db"]
    try:
        cursor = db.execute(f"SELECT * FROM data LIMIT {limit}")
        columns = [desc[0] for desc in cursor.description]
        rows = []
        for row in cursor.fetchall():
            rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
        # Get total count
        count_cursor = db.execute("SELECT COUNT(*) FROM data")
        total = count_cursor.fetchone()[0]
        return {"columns": columns, "rows": rows, "totalRows": total}
    except Exception as e:
        return {"columns": [], "rows": [], "totalRows": 0, "error": str(e)}


# ── Salesforce upload ────────────────────────────────────────────────

def start_upload(session_id, sf_conn_id, object_name, operation, column_mapping, external_id_field=None):
    """Start a background upload from SQLite session to Salesforce."""
    session = _sessions.get(session_id)
    if not session:
        raise ValueError("Session not found or expired")

    job_id = str(uuid.uuid4())[:8]
    sf_name = ""
    try:
        sf_conn = config.get_salesforce(sf_conn_id)
        if sf_conn:
            sf_name = sf_conn.get("name", "")
    except Exception:
        pass

    _jobs[job_id] = {
        "id": job_id,
        "type": "Quick Load",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "total_records": 0,
        "success_count": 0,
        "error_count": 0,
        "errors": [],
        "record_results": [],
        "object_name": object_name,
        "source_name": session.get("filename", "file"),
        "target_name": sf_name,
    }

    t = threading.Thread(
        target=_run_upload,
        args=(job_id, session_id, sf_conn_id, object_name, operation, column_mapping, external_id_field),
        daemon=True,
    )
    t.start()
    return job_id


def _do_bulk_op(sf, object_name, operation, records, external_id_field):
    """Execute a single bulk API operation."""
    if operation == "insert":
        return salesforce_client.bulk_insert(sf, object_name, records)
    elif operation == "update":
        return salesforce_client.bulk_update(sf, object_name, records)
    elif operation == "upsert":
        return salesforce_client.bulk_upsert(sf, object_name, records, external_id_field)
    elif operation == "delete":
        return salesforce_client.bulk_delete(sf, object_name, records)
    else:
        raise ValueError(f"Unknown operation: {operation}")


def _run_upload(job_id, session_id, sf_conn_id, object_name, operation, column_mapping, external_id_field):
    """Background thread: read SQLite data and upload to SF in batches."""
    job = _jobs[job_id]
    try:
        session = _sessions.get(session_id)
        if not session:
            raise ValueError("Session expired")

        sf_conn = config.get_salesforce(sf_conn_id)
        sf = salesforce_client.connect(sf_conn)

        # Read all rows from SQLite
        job["status"] = "reading"
        job["progress"] = 5
        db = session["db"]
        cursor = db.execute("SELECT * FROM data")
        db_columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()

        total = len(rows)
        job["total_records"] = total
        job["progress"] = 20

        if total == 0:
            job["status"] = "complete"
            job["progress"] = 100
            return

        # Build SF records using column mapping
        job["status"] = "uploading"
        all_success = 0
        all_errors = 0
        all_error_details = []
        all_record_results = []

        batch_sz = 200
        try:
            batch_sz = config.get_bulk_settings().get("sfUploadBatchSize", 200)
        except Exception:
            pass

        for batch_start in range(0, total, batch_sz):
            batch_rows = rows[batch_start:batch_start + batch_sz]
            records = []
            for row in batch_rows:
                row_dict = dict(zip(db_columns, row))
                sf_record = {}
                for src_col, sf_field in column_mapping.items():
                    if sf_field and sf_field != "__skip__":
                        val = row_dict.get(src_col)
                        sf_record[sf_field] = val
                records.append(sf_record)

            # Execute bulk operation (with session refresh on expiry)
            try:
                result = _do_bulk_op(sf, object_name, operation, records, external_id_field)
            except Exception as e:
                if "InvalidSessionId" in str(e) or "INVALID_SESSION_ID" in str(e):
                    job["status"] = "refreshing session"
                    sf_conn = config.get_salesforce(sf_conn_id)
                    sf = salesforce_client.connect(sf_conn)
                    result = _do_bulk_op(sf, object_name, operation, records, external_id_field)
                else:
                    raise

            # Collect results
            batch_record_results = result.get("record_results", [])
            for rr in batch_record_results:
                rr["row"] = rr["row"] + batch_start

            all_success += result["success_count"]
            all_errors += result["error_count"]
            all_error_details.extend(result["errors"])
            all_record_results.extend(batch_record_results)

            # Update progress (20% → 100%)
            processed = min(batch_start + batch_sz, total)
            job["progress"] = 20 + int((processed / total) * 80)
            job["success_count"] = all_success
            job["error_count"] = all_errors
            job["errors"] = all_error_details[:50]
            job["record_results"] = all_record_results

        job["status"] = "complete"
        job["progress"] = 100

    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["errors"] = [str(e)]
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass


def get_upload_status(job_id):
    """Return upload job status (without record_results for polling)."""
    job = _jobs.get(job_id)
    if not job:
        return None
    resp = {k: v for k, v in job.items() if k != "record_results"}
    resp["has_record_results"] = len(job.get("record_results", [])) > 0
    return resp


def get_upload_results(job_id):
    """Return per-record results for a completed job."""
    job = _jobs.get(job_id)
    if not job:
        return None
    return job.get("record_results", [])


def cleanup_session(session_id):
    """Close SQLite connection and remove session."""
    session = _sessions.pop(session_id, None)
    if session:
        try:
            session["db"].close()
        except Exception:
            pass
