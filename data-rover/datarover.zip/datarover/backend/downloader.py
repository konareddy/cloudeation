import threading
import uuid
import traceback
import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import salesforce_client
import db_client
import config
import store

_jobs = {}


def _resolve_db(conn_id):
    """Look up DB connection name and database for display."""
    try:
        c = config.get_database(conn_id)
        if c:
            return c.get("name", ""), c.get("database", "")
    except Exception:
        pass
    return "", ""


def _resolve_sf(conn_id):
    """Look up SF connection name for display."""
    try:
        c = config.get_salesforce(conn_id)
        if c:
            return c.get("name", "")
    except Exception:
        pass
    return ""


def start_job(sf_conn_id, db_conn_id, object_names, table_names=None, target_database=None, source_info=None, import_modes=None, pk_chunk_sizes=None):
    job_id = str(uuid.uuid4())[:8]
    statuses = {name: "pending" for name in object_names}
    progress = {name: 0 for name in object_names}
    errors = {name: "" for name in object_names}
    tgt_name, tgt_db = _resolve_db(db_conn_id)
    src_name = _resolve_sf(sf_conn_id)
    _jobs[job_id] = {
        "id": job_id,
        "type": "SF Extract",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "statuses": statuses,
        "progress": progress,
        "errors": errors,
        "table_name": ", ".join(table_names.get(n, n) for n in object_names) if table_names else ", ".join(object_names),
        "source_name": src_name,
        "source_object": ", ".join(object_names),
        "target_conn_id": db_conn_id,
        "target_name": tgt_name,
        "target_database": target_database or tgt_db,
    }
    t = threading.Thread(
        target=_run_job,
        args=(job_id, sf_conn_id, db_conn_id, object_names, table_names or {}, target_database, source_info, import_modes or {}, pk_chunk_sizes or {}),
        daemon=True,
    )
    t.start()
    return job_id


def get_status(job_id):
    return _jobs.get(job_id)


def cancel_job(job_id):
    """Request cancellation of a running job."""
    job = _jobs.get(job_id)
    if not job:
        return False
    if job.get("running"):
        job["_cancel"] = True
        return True
    return False


def start_soql_import_job(sf_conn_id, db_conn_id, soql, table_name, target_database=None, source_info=None):
    job_id = str(uuid.uuid4())[:8]
    tgt_name, tgt_db = _resolve_db(db_conn_id)
    src_name = _resolve_sf(sf_conn_id)
    source_object = ""
    if source_info and isinstance(source_info, dict):
        source_object = source_info.get("object", "")
    _jobs[job_id] = {
        "id": job_id,
        "type": "SOQL Import",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "message": "Starting SOQL import...",
        "table_name": table_name,
        "record_count": 0,
        "source_name": src_name,
        "source_object": source_object,
        "target_conn_id": db_conn_id,
        "target_name": tgt_name,
        "target_database": target_database or tgt_db,
    }
    t = threading.Thread(
        target=_run_soql_import,
        args=(job_id, sf_conn_id, db_conn_id, soql, table_name, target_database, source_info),
        daemon=True,
    )
    t.start()
    return job_id


def _run_soql_import(job_id, sf_conn_id, db_conn_id, soql, table_name, target_database=None, source_info=None):
    job = _jobs[job_id]
    try:
        sf_conn = config.get_salesforce(sf_conn_id)
        db_conn = config.get_database(db_conn_id)
        sf = salesforce_client.connect(sf_conn)
        pg = db_client.get_connection(db_conn, database=target_database)

        job["status"] = "querying"
        job["progress"] = 10
        job["message"] = "Executing SOQL query..."

        columns, records, total = salesforce_client.fetch_records_by_soql(sf, soql)

        job["progress"] = 50
        job["message"] = f"Fetched {len(records)} records"
        job["record_count"] = len(records)

        if not records or not columns:
            job["status"] = "complete"
            job["progress"] = 100
            job["message"] = "No records returned"
            return

        # Build field_meta from columns (all TEXT type since we don't have SF metadata)
        field_meta = [{"name": col, "type": "string"} for col in columns]

        job["status"] = "creating_table"
        job["progress"] = 60
        job["message"] = f"Creating table {table_name}..."

        table = db_client.create_table(pg, table_name, field_meta, raw_table_name=True)

        job["status"] = "inserting"
        job["progress"] = 70
        job["message"] = "Inserting records..."

        def _insert_progress(done, total):
            job["progress"] = 70 + int(25 * done / max(total, 1))
            job["message"] = f"Inserting records... {done:,}/{total:,}"

        inserted = db_client.insert_records(pg, table, field_meta, records, progress_callback=_insert_progress)

        if source_info:
            import json, datetime
            source_info["imported_at"] = datetime.datetime.now().isoformat()
            source_info["records"] = inserted
            db_client.set_table_comment(pg, table_name, json.dumps(source_info))

        job["status"] = "complete"
        job["progress"] = 100
        job["message"] = f"Imported {inserted:,} records into {table_name}"

        pg.close()
    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["message"] = str(e)
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass


def start_sql_import_job(source_db_conn_id, target_db_conn_id, sql, table_name, source_database=None, target_database=None, source_info=None):
    job_id = str(uuid.uuid4())[:8]
    # Derive a more specific type label from the source connection
    _type_label = "SQL Import"
    src_name = ""
    try:
        src_conn = config.get_database(source_db_conn_id)
        if src_conn:
            db_type = (src_conn.get("dbType") or "").lower()
            label_map = {"athena": "Athena Import", "mysql": "MySQL Import", "redshift": "Redshift Import", "postgresql": "PostgreSQL Import"}
            _type_label = label_map.get(db_type, "SQL Import")
            src_name = src_conn.get("name", "")
    except Exception:
        pass
    tgt_name, tgt_db = _resolve_db(target_db_conn_id)
    source_object = ""
    if source_info and isinstance(source_info, dict):
        source_object = source_info.get("object", "")
    _jobs[job_id] = {
        "id": job_id,
        "type": _type_label,
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "message": "Starting SQL import...",
        "table_name": table_name,
        "record_count": 0,
        "source_name": src_name,
        "source_database": source_database or "",
        "source_object": source_object,
        "target_conn_id": target_db_conn_id,
        "target_name": tgt_name,
        "target_database": target_database or tgt_db,
    }
    t = threading.Thread(
        target=_run_sql_import,
        args=(job_id, source_db_conn_id, target_db_conn_id, sql, table_name, source_database, target_database, source_info),
        daemon=True,
    )
    t.start()
    return job_id


def _run_sql_import(job_id, source_db_conn_id, target_db_conn_id, sql, table_name, source_database=None, target_database=None, source_info=None):
    job = _jobs[job_id]
    try:
        source_conn = config.get_database(source_db_conn_id)
        target_conn = config.get_database(target_db_conn_id)

        job["status"] = "querying"
        job["progress"] = 10
        job["message"] = "Executing SQL query on source..."

        source_db = db_client.get_connection(source_conn, database=source_database)
        cur = source_db.cursor()
        cur.execute(sql)

        if not cur.description:
            job["status"] = "error"
            job["message"] = "Query did not return any data"
            return

        columns = [desc[0] for desc in cur.description]
        records = []
        for row in cur.fetchall():
            rec = {}
            for col, val in zip(columns, row):
                rec[col] = str(val) if val is not None else None
            records.append(rec)

        cur.close()
        source_db.close()

        job["progress"] = 50
        job["message"] = f"Fetched {len(records)} records"
        job["record_count"] = len(records)

        if not records:
            job["status"] = "complete"
            job["progress"] = 100
            job["message"] = "No records returned"
            return

        field_meta = [{"name": col, "type": "string"} for col in columns]

        job["status"] = "creating_table"
        job["progress"] = 60
        job["message"] = f"Creating table {table_name}..."

        target_db = db_client.get_connection(target_conn, database=target_database)
        table = db_client.create_table(target_db, table_name, field_meta, raw_table_name=True)

        job["status"] = "inserting"
        job["progress"] = 70
        job["message"] = "Inserting records..."

        def _insert_progress(done, total):
            job["progress"] = 70 + int(25 * done / max(total, 1))
            job["message"] = f"Inserting records... {done:,}/{total:,}"

        inserted = db_client.insert_records(target_db, table, field_meta, records, progress_callback=_insert_progress)

        if source_info:
            import json, datetime
            source_info["imported_at"] = datetime.datetime.now().isoformat()
            source_info["records"] = inserted
            db_client.set_table_comment(target_db, table_name, json.dumps(source_info))

        job["status"] = "complete"
        job["progress"] = 100
        job["message"] = f"Imported {inserted:,} records into {table_name}"

        target_db.close()
    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["message"] = str(e)
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass


def start_csv_import_job(target_db_conn_id, table_name, columns, records, source_info=None):
    job_id = str(uuid.uuid4())[:8]
    tgt_name, tgt_db = _resolve_db(target_db_conn_id)
    _jobs[job_id] = {
        "id": job_id,
        "type": "CSV Import",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "message": "Starting CSV import...",
        "table_name": table_name,
        "record_count": len(records),
        "target_conn_id": target_db_conn_id,
        "target_name": tgt_name,
        "target_database": tgt_db,
    }
    t = threading.Thread(
        target=_run_csv_import,
        args=(job_id, target_db_conn_id, table_name, columns, records, source_info),
        daemon=True,
    )
    t.start()
    return job_id


def _run_csv_import(job_id, target_db_conn_id, table_name, columns, records, source_info=None):
    job = _jobs[job_id]
    try:
        target_conn = config.get_database(target_db_conn_id)

        field_meta = [{"name": col, "type": "string"} for col in columns]

        job["status"] = "creating_table"
        job["progress"] = 20
        job["message"] = f"Creating table {table_name}..."

        target_db = db_client.get_connection(target_conn)
        table = db_client.create_table(target_db, table_name, field_meta, raw_table_name=True)

        job["status"] = "inserting"
        job["progress"] = 40
        job["message"] = f"Inserting {len(records)} records..."

        def _insert_progress(done, total):
            job["progress"] = 40 + int(55 * done / max(total, 1))
            job["message"] = f"Inserting records... {done:,}/{total:,}"

        inserted = db_client.insert_records(target_db, table, field_meta, records, progress_callback=_insert_progress)

        if source_info:
            import json, datetime
            source_info["imported_at"] = datetime.datetime.now().isoformat()
            source_info["records"] = inserted
            db_client.set_table_comment(target_db, table_name, json.dumps(source_info))

        job["status"] = "complete"
        job["progress"] = 100
        job["message"] = f"Imported {inserted:,} records into {table_name}"

        target_db.close()
    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["message"] = str(e)
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass


def _get_last_modified(pg, table):
    """Get the max SystemModstamp from an existing table for delta extraction."""
    try:
        cur = pg.cursor()
        # Try systemmodstamp first (lowercase, as we store columns lowercase)
        cur.execute(f'SELECT MAX("systemmodstamp") FROM "{table}"')
        row = cur.fetchone()
        cur.close()
        if row and row[0]:
            val = row[0]
            # Convert to ISO string if it's a datetime object
            if hasattr(val, 'isoformat'):
                return val.isoformat() + 'Z'
            return str(val)
    except Exception:
        try:
            pg.rollback()
        except Exception:
            pass
    return None


def _extract_single_object(obj_name, sf_conn_id, db_conn_id, target_database, table_names, import_modes, source_info, job, pk_chunk_sizes=None):
    """Extract a single SF object — streams records page-by-page to minimize memory."""
    sf_conn = config.get_salesforce(sf_conn_id)
    db_conn = config.get_database(db_conn_id)
    sf = salesforce_client.connect(sf_conn)
    pg = db_client.get_connection(db_conn, database=target_database)

    try:
        job["statuses"][obj_name] = "downloading"
        job["progress"][obj_name] = 5

        # Phase 1: Metadata only (describe + count)
        field_meta, total, use_bulk = salesforce_client.prepare_extract(sf, obj_name)
        job["progress"][obj_name] = 10
        job["messages"] = job.get("messages", {})
        job["messages"][obj_name] = f"Described {obj_name}: {total:,} records"

        # Phase 2: Create table or reuse existing
        mode = import_modes.get(obj_name, "full")
        custom_table = table_names.get(obj_name)
        # Resolve the actual target table name consistently
        if custom_table:
            table = custom_table
        else:
            table = obj_name.lower()

        where_clause = None
        if mode == "delta":
            if db_client.table_exists(pg, table):
                # Get last modified timestamp for incremental query
                last_mod = _get_last_modified(pg, table)
                if last_mod:
                    where_clause = f"SystemModstamp > {last_mod}"
                    # Get count of delta records
                    try:
                        count_result = sf.query(f"SELECT COUNT() FROM {obj_name} WHERE SystemModstamp > {last_mod}")
                        total = count_result.get("totalSize", 0)
                    except Exception:
                        pass
                    job["messages"][obj_name] = f"Delta: {total:,} records modified since last extract"
            else:
                # Table doesn't exist yet — create it (first-time delta = full load)
                db_client.create_table(pg, table, field_meta, raw_table_name=True)
        else:
            # Full refresh: always DROP and recreate
            db_client.create_table(pg, table, field_meta, raw_table_name=True)
        job["progress"][obj_name] = 15

        if mode == "delta" and total == 0 and where_clause:
            job["progress"][obj_name] = 100
            job["messages"][obj_name] = "No new/modified records since last extract"
            job["statuses"][obj_name] = "complete"
            return

        # Phase 3: Stream records from SF → DB page by page
        total_inserted = 0

        def _on_batch(records_batch, _name=obj_name):
            if job.get("_cancel"):
                raise InterruptedError("Job cancelled")
            nonlocal total_inserted
            total_inserted += db_client.insert_records(pg, table, field_meta, records_batch)
            job["messages"] = job.get("messages", {})
            if total > 0:
                pct = 15 + int(80 * total_inserted / total)
                job["progress"][_name] = min(pct, 95)
            job["messages"][_name] = f"Inserted {total_inserted:,} / {total:,} records"

        def _on_progress(phase, detail, fetched_count, _name=obj_name):
            job["messages"] = job.get("messages", {})
            if phase == "bulk_started":
                job["messages"][_name] = detail

        # Use per-object PK chunk size if specified
        obj_chunk_size = (pk_chunk_sizes or {}).get(obj_name)
        salesforce_client.stream_records(sf, obj_name, field_meta, use_bulk, _on_batch, _on_progress, pk_chunk_size=obj_chunk_size, where_clause=where_clause)
        job["progress"][obj_name] = 100

        if source_info:
            import json, datetime as _dt
            si = {**source_info, "object": obj_name, "imported_at": _dt.datetime.now().isoformat(), "records": total_inserted}
            db_client.set_table_comment(pg, custom_table or table, json.dumps(si))

        job["statuses"][obj_name] = "complete"
    except Exception as e:
        traceback.print_exc()
        job["statuses"][obj_name] = "error"
        job["progress"][obj_name] = 0
        job["errors"][obj_name] = str(e)
    finally:
        try:
            pg.close()
        except Exception:
            pass


def _run_job(job_id, sf_conn_id, db_conn_id, object_names, table_names=None, target_database=None, source_info=None, import_modes=None, pk_chunk_sizes=None):
    table_names = table_names or {}
    import_modes = import_modes or {}
    pk_chunk_sizes = pk_chunk_sizes or {}
    job = _jobs[job_id]
    max_workers = config.get_bulk_settings().get("parallelWorkers", 2)
    try:
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            futures = {
                pool.submit(
                    _extract_single_object,
                    obj_name, sf_conn_id, db_conn_id, target_database,
                    table_names, import_modes, source_info, job, pk_chunk_sizes,
                ): obj_name
                for obj_name in object_names
            }
            for future in as_completed(futures):
                if job.get("_cancel"):
                    for f in futures:
                        f.cancel()
                    break
                obj_name = futures[future]
                try:
                    future.result()
                except Exception as e:
                    traceback.print_exc()
                    job["statuses"][obj_name] = "error"
                    job["errors"][obj_name] = str(e)
    except Exception as e:
        traceback.print_exc()
        for obj_name in object_names:
            if job["statuses"][obj_name] in ("pending", "downloading"):
                job["statuses"][obj_name] = "error"
    finally:
        if job.get("_cancel"):
            job["status"] = "cancelled"
            for obj_name in object_names:
                if job["statuses"][obj_name] in ("pending", "downloading"):
                    job["statuses"][obj_name] = "cancelled"
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass
