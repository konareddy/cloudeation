import threading
import uuid
import traceback
import datetime
import os
import re
import csv
import base64
import requests
import salesforce_client
import config
import store

_jobs = {}

DEFAULT_BASE_DIR = os.path.join(os.path.expanduser("~"), "sfdc-loader", "attachments")


def _get_timeout():
    try:
        return config.get_bulk_settings().get("requestTimeout", 300)
    except Exception:
        return 300


def _sanitize_filename(name):
    """Strip invalid chars, truncate to 200 characters."""
    if not name:
        return "unnamed"
    # Remove characters invalid in most filesystems
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name)
    name = name.strip('. ')
    if not name:
        return "unnamed"
    return name[:200]


def _format_bytes(n):
    """Human-readable size string."""
    if n < 1024:
        return f"{n} B"
    elif n < 1024 * 1024:
        return f"{n / 1024:.1f} KB"
    elif n < 1024 * 1024 * 1024:
        return f"{n / (1024 * 1024):.1f} MB"
    else:
        return f"{n / (1024 * 1024 * 1024):.1f} GB"


def _resolve_sf(conn_id):
    """Look up SF connection name for display."""
    try:
        c = config.get_salesforce(conn_id)
        if c:
            return c.get("name", "")
    except Exception:
        pass
    return ""


def _download_file_binary(sf, url):
    """Streaming GET with Bearer token. Returns a response object for streaming."""
    full_url = f"https://{sf.sf_instance}{url}"
    headers = {"Authorization": f"Bearer {sf.session_id}"}
    resp = requests.get(full_url, headers=headers, stream=True, timeout=_get_timeout())
    resp.raise_for_status()
    return resp


def _sf_rest_post(sf, path, payload):
    """POST JSON with Bearer token to SF REST API."""
    full_url = sf.base_url + path
    headers = {
        "Authorization": f"Bearer {sf.session_id}",
        "Content-Type": "application/json",
    }
    resp = requests.post(full_url, json=payload, headers=headers, timeout=_get_timeout())
    return resp


def _is_session_expired(e):
    """Check if an exception indicates an expired session."""
    msg = str(e)
    return "InvalidSessionId" in msg or "INVALID_SESSION_ID" in msg or "Invalid session id" in msg or "401" in msg


def _refresh_sf(sf_conn_id):
    """Re-read config and reconnect to SF."""
    sf_conn = config.get_salesforce(sf_conn_id)
    return salesforce_client.connect(sf_conn)


def get_status(job_id):
    return _jobs.get(job_id)


def cancel_job(job_id):
    """Request cancellation of a running job."""
    job = _jobs.get(job_id)
    if not job:
        return False
    if job.get("running"):
        job["_cancel"] = True
        return True
    return False


# ---------------------------------------------------------------------------
# Download
# ---------------------------------------------------------------------------

def start_download_job(sf_conn_id, object_type, where_clause=None, output_dir=None):
    job_id = str(uuid.uuid4())[:8]
    src_name = _resolve_sf(sf_conn_id)
    if not output_dir:
        output_dir = os.path.join(DEFAULT_BASE_DIR, job_id)

    _jobs[job_id] = {
        "id": job_id,
        "type": "File Download",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "message": "Starting file download...",
        "object_type": object_type,
        "source_name": src_name,
        "output_dir": output_dir,
        "total_files": 0,
        "completed_files": 0,
        "total_bytes": 0,
        "downloaded_bytes": 0,
        "errors": [],
        "file_results": [],
    }
    t = threading.Thread(
        target=_run_download_job,
        args=(job_id, sf_conn_id, object_type, where_clause, output_dir),
        daemon=True,
    )
    t.start()
    return job_id


def _run_download_job(job_id, sf_conn_id, object_type, where_clause, output_dir):
    job = _jobs[job_id]
    try:
        sf_conn = config.get_salesforce(sf_conn_id)
        sf = salesforce_client.connect(sf_conn)

        job["status"] = "querying"
        job["progress"] = 5
        job["message"] = "Querying file metadata..."

        # Build SOQL
        if object_type == "ContentVersion":
            soql = (
                "SELECT Id, ContentDocumentId, Title, FileExtension, ContentSize, FileType "
                "FROM ContentVersion WHERE IsLatest = true"
            )
            if where_clause and where_clause.strip():
                soql += f" AND ({where_clause.strip()})"
        else:
            # Attachment
            soql = "SELECT Id, ParentId, Name, ContentType, BodyLength FROM Attachment"
            if where_clause and where_clause.strip():
                soql += f" WHERE {where_clause.strip()}"

        result = sf.query_all(soql)
        records = result.get("records", [])

        total_files = len(records)
        job["total_files"] = total_files
        job["progress"] = 10
        job["message"] = f"Found {total_files} file(s)"

        if total_files == 0:
            job["status"] = "complete"
            job["progress"] = 100
            job["message"] = "No files found"
            return

        # Calculate total bytes
        total_bytes = 0
        for rec in records:
            if object_type == "ContentVersion":
                total_bytes += rec.get("ContentSize") or 0
            else:
                total_bytes += rec.get("BodyLength") or 0
        job["total_bytes"] = total_bytes

        # Create output directory
        os.makedirs(output_dir, exist_ok=True)

        # API version from sf object
        api_ver = sf.sf_version

        # Download each file
        for i, rec in enumerate(records):
            if job.get("_cancel"):
                job["status"] = "cancelled"
                job["message"] = f"Cancelled after {job['completed_files']} of {total_files} files"
                return

            rec_id = rec["Id"]
            try:
                if object_type == "ContentVersion":
                    name = rec.get("Title") or "untitled"
                    ext = rec.get("FileExtension") or ""
                    if ext and not name.lower().endswith(f".{ext.lower()}"):
                        name = f"{name}.{ext}"
                    content_type = rec.get("FileType") or ""
                    size = rec.get("ContentSize") or 0
                    parent_id = rec.get("ContentDocumentId") or ""
                    download_path = f"/services/data/v{api_ver}/sobjects/ContentVersion/{rec_id}/VersionData"
                else:
                    name = rec.get("Name") or "untitled"
                    content_type = rec.get("ContentType") or ""
                    size = rec.get("BodyLength") or 0
                    parent_id = rec.get("ParentId") or ""
                    download_path = f"/services/data/v{api_ver}/sobjects/Attachment/{rec_id}/Body"

                safe_name = _sanitize_filename(name)
                filename = f"{rec_id}_{safe_name}"
                filepath = os.path.join(output_dir, filename)

                job["message"] = f"Downloading {i + 1}/{total_files}: {safe_name}"

                # Streaming download with retry on session expiry
                try:
                    resp = _download_file_binary(sf, download_path)
                except Exception as e:
                    if _is_session_expired(e):
                        job["message"] = f"Refreshing session, retrying {safe_name}..."
                        sf = _refresh_sf(sf_conn_id)
                        resp = _download_file_binary(sf, download_path)
                    else:
                        raise

                file_bytes = 0
                with open(filepath, "wb") as f:
                    for chunk in resp.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            file_bytes += len(chunk)
                            job["downloaded_bytes"] += len(chunk)

                job["completed_files"] = i + 1
                # Progress: 10-90% for downloads, 90-100% for metadata
                job["progress"] = 10 + int((i + 1) / total_files * 80)

                job["file_results"].append({
                    "id": rec_id,
                    "parent_id": parent_id,
                    "name": name,
                    "content_type": content_type,
                    "size": file_bytes,
                    "file_path": filepath,
                    "success": True,
                    "error": "",
                })

            except Exception as e:
                job["completed_files"] = i + 1
                job["progress"] = 10 + int((i + 1) / total_files * 80)
                err_msg = str(e)
                job["errors"].append({"file": name if 'name' in dir() else rec_id, "error": err_msg})
                job["file_results"].append({
                    "id": rec_id,
                    "parent_id": parent_id if 'parent_id' in dir() else "",
                    "name": name if 'name' in dir() else rec_id,
                    "content_type": "",
                    "size": 0,
                    "file_path": "",
                    "success": False,
                    "error": err_msg,
                })

        # Write metadata.csv
        job["status"] = "writing_metadata"
        job["progress"] = 92
        job["message"] = "Writing metadata.csv..."

        csv_path = os.path.join(output_dir, "metadata.csv")
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["Id", "ParentId", "Name", "ContentType", "Size", "FilePath"])
            for fr in job["file_results"]:
                if fr["success"]:
                    writer.writerow([
                        fr["id"], fr["parent_id"], fr["name"],
                        fr["content_type"], fr["size"], os.path.basename(fr["file_path"]),
                    ])

        success_count = sum(1 for fr in job["file_results"] if fr["success"])
        error_count = sum(1 for fr in job["file_results"] if not fr["success"])
        job["status"] = "complete"
        job["progress"] = 100
        job["message"] = f"Downloaded {success_count} file(s) ({_format_bytes(job['downloaded_bytes'])})"
        if error_count:
            job["message"] += f", {error_count} error(s)"

    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["message"] = str(e)
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Upload
# ---------------------------------------------------------------------------

def start_upload_job(sf_conn_id, object_type, source_dir, default_parent_id=None, link_to_record_id=None):
    job_id = str(uuid.uuid4())[:8]
    src_name = _resolve_sf(sf_conn_id)

    _jobs[job_id] = {
        "id": job_id,
        "type": "File Upload",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "message": "Starting file upload...",
        "object_type": object_type,
        "target_name": src_name,
        "source_dir": source_dir,
        "total_files": 0,
        "completed_files": 0,
        "success_count": 0,
        "error_count": 0,
        "total_bytes": 0,
        "uploaded_bytes": 0,
        "errors": [],
        "file_results": [],
    }
    t = threading.Thread(
        target=_run_upload_job,
        args=(job_id, sf_conn_id, object_type, source_dir, default_parent_id, link_to_record_id),
        daemon=True,
    )
    t.start()
    return job_id


def _run_upload_job(job_id, sf_conn_id, object_type, source_dir, default_parent_id, link_to_record_id):
    job = _jobs[job_id]
    try:
        sf_conn = config.get_salesforce(sf_conn_id)
        sf = salesforce_client.connect(sf_conn)

        job["status"] = "scanning"
        job["progress"] = 5
        job["message"] = "Scanning source directory..."

        skip_files = {"metadata.csv", "upload_results.csv"}
        files = []
        for fname in sorted(os.listdir(source_dir)):
            fpath = os.path.join(source_dir, fname)
            if os.path.isfile(fpath) and fname.lower() not in skip_files:
                files.append((fname, fpath))

        total_files = len(files)
        job["total_files"] = total_files
        total_bytes = sum(os.path.getsize(fp) for _, fp in files)
        job["total_bytes"] = total_bytes
        job["progress"] = 10
        job["message"] = f"Found {total_files} file(s) to upload"

        if total_files == 0:
            job["status"] = "complete"
            job["progress"] = 100
            job["message"] = "No files to upload"
            return

        # Load metadata.csv if present (for ParentId / Name / ContentType mappings)
        metadata_map = {}  # keyed by filename
        meta_csv = os.path.join(source_dir, "metadata.csv")
        if os.path.isfile(meta_csv):
            try:
                with open(meta_csv, "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        file_path_col = row.get("FilePath", "")
                        if file_path_col:
                            metadata_map[file_path_col] = row
            except Exception:
                pass

        job["status"] = "uploading"

        for i, (fname, fpath) in enumerate(files):
            if job.get("_cancel"):
                job["status"] = "cancelled"
                job["message"] = f"Cancelled after {job['completed_files']} of {total_files} files"
                return

            try:
                file_size = os.path.getsize(fpath)
                meta = metadata_map.get(fname, {})

                # Read and base64 encode
                with open(fpath, "rb") as f:
                    file_data = f.read()
                b64_data = base64.b64encode(file_data).decode("ascii")

                job["message"] = f"Uploading {i + 1}/{total_files}: {fname}"

                if object_type == "ContentVersion":
                    original_name = meta.get("Name", fname)
                    payload = {
                        "Title": os.path.splitext(original_name)[0],
                        "PathOnClient": original_name,
                        "VersionData": b64_data,
                    }
                    api_path = "/sobjects/ContentVersion"
                else:
                    # Attachment
                    parent_id = meta.get("ParentId", "") or default_parent_id or ""
                    if not parent_id:
                        raise ValueError(f"No ParentId for file {fname}. Provide a default ParentId or include metadata.csv.")
                    original_name = meta.get("Name", fname)
                    content_type = meta.get("ContentType", "application/octet-stream")
                    payload = {
                        "ParentId": parent_id,
                        "Name": original_name,
                        "Body": b64_data,
                        "ContentType": content_type,
                    }
                    api_path = "/sobjects/Attachment"

                # POST with retry on session expiry
                try:
                    resp = _sf_rest_post(sf, api_path, payload)
                except Exception as e:
                    if _is_session_expired(e):
                        sf = _refresh_sf(sf_conn_id)
                        resp = _sf_rest_post(sf, api_path, payload)
                    else:
                        raise

                resp_body = resp.json()

                if resp.status_code in (200, 201) and resp_body.get("success", resp_body.get("id")):
                    sf_id = resp_body.get("id", "")

                    # Optionally create ContentDocumentLink
                    if object_type == "ContentVersion" and link_to_record_id and sf_id:
                        try:
                            # Need to get ContentDocumentId from the new ContentVersion
                            cv_result = sf.query(f"SELECT ContentDocumentId FROM ContentVersion WHERE Id = '{sf_id}'")
                            cv_records = cv_result.get("records", [])
                            if cv_records:
                                doc_id = cv_records[0]["ContentDocumentId"]
                                link_payload = {
                                    "ContentDocumentId": doc_id,
                                    "LinkedEntityId": link_to_record_id,
                                    "ShareType": "V",
                                }
                                _sf_rest_post(sf, "/sobjects/ContentDocumentLink", link_payload)
                        except Exception:
                            pass  # Non-fatal

                    job["success_count"] += 1
                    job["uploaded_bytes"] += file_size
                    job["file_results"].append({
                        "file": fname,
                        "sf_id": sf_id,
                        "success": True,
                        "error": "",
                    })
                else:
                    # Error from SF
                    errors = resp_body if isinstance(resp_body, list) else [resp_body]
                    err_msg = "; ".join(
                        e.get("message", str(e)) for e in errors
                    )
                    raise Exception(err_msg)

            except Exception as e:
                err_msg = str(e)
                job["error_count"] += 1
                job["errors"].append({"file": fname, "error": err_msg})
                job["file_results"].append({
                    "file": fname,
                    "sf_id": "",
                    "success": False,
                    "error": err_msg,
                })

            job["completed_files"] = i + 1
            job["progress"] = 10 + int((i + 1) / total_files * 85)

        # Write upload_results.csv
        job["status"] = "writing_results"
        job["progress"] = 97
        job["message"] = "Writing upload_results.csv..."

        results_path = os.path.join(source_dir, "upload_results.csv")
        with open(results_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["File", "SalesforceId", "Success", "Error"])
            for fr in job["file_results"]:
                writer.writerow([fr["file"], fr["sf_id"], fr["success"], fr["error"]])

        job["status"] = "complete"
        job["progress"] = 100
        job["message"] = f"Uploaded {job['success_count']} file(s) ({_format_bytes(job['uploaded_bytes'])})"
        if job["error_count"]:
            job["message"] += f", {job['error_count']} error(s)"

    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["message"] = str(e)
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

def list_download_folders():
    """List directories under the base attachments dir with file counts and sizes."""
    folders = []
    if not os.path.isdir(DEFAULT_BASE_DIR):
        return folders
    for entry in sorted(os.listdir(DEFAULT_BASE_DIR), reverse=True):
        dir_path = os.path.join(DEFAULT_BASE_DIR, entry)
        if not os.path.isdir(dir_path):
            continue
        file_count = 0
        total_size = 0
        has_metadata = False
        for fname in os.listdir(dir_path):
            fpath = os.path.join(dir_path, fname)
            if os.path.isfile(fpath):
                if fname == "metadata.csv":
                    has_metadata = True
                else:
                    file_count += 1
                    total_size += os.path.getsize(fpath)
        folders.append({
            "name": entry,
            "path": dir_path,
            "file_count": file_count,
            "total_size": total_size,
            "total_size_display": _format_bytes(total_size),
            "has_metadata": has_metadata,
        })
    return folders


def count_files(sf_conn_id, object_type, where_clause=None):
    """Preview count of files matching a query."""
    sf_conn = config.get_salesforce(sf_conn_id)
    sf = salesforce_client.connect(sf_conn)
    if object_type == "ContentVersion":
        soql = "SELECT COUNT() FROM ContentVersion WHERE IsLatest = true"
        if where_clause and where_clause.strip():
            soql += f" AND ({where_clause.strip()})"
    else:
        soql = "SELECT COUNT() FROM Attachment"
        if where_clause and where_clause.strip():
            soql += f" WHERE {where_clause.strip()}"
    result = sf.query(soql)
    return result.get("totalSize", 0)
