"""Script runner for Data Rover — executes multi-step command scripts sequentially.

Parses a script text into steps, runs each through cli_handler.execute(),
and waits for async jobs (extract/load) to complete before proceeding.
"""

import uuid
import time
import datetime
import threading

import cli_handler
import downloader
import uploader

# In-memory store of script runs
_script_runs = {}

# Command keywords that start a new step
_COMMAND_KEYWORDS = {
    "extract", "load", "sql", "query", "use", "connections",
    "objects", "databases", "tables", "describe", "count", "preview",
}


def parse_script(script_text):
    """Parse script text into a list of command strings.

    Rules:
    - Lines starting with # or -- are comments (skipped)
    - Blank lines are separators
    - A line starting with a known command keyword starts a new step
    - Continuation lines (indented or not starting with a keyword) are joined to current step
    """
    steps = []
    current = []

    for raw_line in script_text.splitlines():
        line = raw_line.strip()

        # Skip empty lines — they end current step
        if not line:
            if current:
                steps.append(" ".join(current))
                current = []
            continue

        # Skip comments
        if line.startswith("#") or line.startswith("--"):
            continue

        # Check if this line starts a new command
        first_word = line.split()[0].lower() if line.split() else ""
        if first_word in _COMMAND_KEYWORDS:
            # Save previous step
            if current:
                steps.append(" ".join(current))
                current = []
            current.append(line)
        else:
            # Continuation of current step
            if current:
                current.append(line)
            else:
                # Orphan line — treat as new step
                current.append(line)

    # Don't forget the last step
    if current:
        steps.append(" ".join(current))

    return steps


def _format_extract_progress(status):
    """Format extract job status into readable progress text."""
    lines = []
    progress = status.get("progress", 0)
    lines.append(f"Progress: {progress}%")
    # Per-object breakdown
    objects = status.get("objects", {})
    if objects:
        for obj_name, obj_info in objects.items():
            if isinstance(obj_info, dict):
                obj_status = obj_info.get("status", "pending")
                obj_records = obj_info.get("processedRecords", 0)
                obj_total = obj_info.get("totalRecords", 0)
                if obj_total:
                    lines.append(f"  {obj_name}: {obj_records:,}/{obj_total:,} records ({obj_status})")
                elif obj_records:
                    lines.append(f"  {obj_name}: {obj_records:,} records ({obj_status})")
                else:
                    lines.append(f"  {obj_name}: {obj_status}")
    total = status.get("processedRecords", 0)
    if total:
        lines.append(f"Total: {total:,} records")
    return "\n".join(lines)


def _format_load_progress(status):
    """Format load job status into readable progress text."""
    lines = []
    progress = status.get("progress", 0)
    total = status.get("total_records", 0)
    success = status.get("success_count", 0)
    errors = status.get("error_count", 0)
    st = status.get("status", "running")
    lines.append(f"Progress: {progress}%  |  Status: {st}")
    if total:
        lines.append(f"Total: {total:,}  |  Success: {success:,}  |  Errors: {errors:,}")
    error_list = status.get("errors", [])
    if error_list:
        for err in error_list[:5]:
            lines.append(f"  ❌ {err}")
    return "\n".join(lines)


def _wait_for_extract_job(job_id, step_info, timeout=1800):
    """Wait for a downloader job to finish, updating step_info with live progress."""
    start = time.time()
    while time.time() - start < timeout:
        status = downloader.get_status(job_id)
        if status:
            step_info["output"] = _format_extract_progress(status)
            if not status.get("running", True):
                return status
        time.sleep(2)
    return {"status": "timeout", "running": False}


def _wait_for_load_job(job_id, step_info, timeout=1800):
    """Wait for an uploader job to finish, updating step_info with live progress."""
    start = time.time()
    while time.time() - start < timeout:
        status = uploader.get_status(job_id)
        if status:
            step_info["output"] = _format_load_progress(status)
            if not status.get("running", True):
                return status
        time.sleep(2)
    return {"status": "timeout", "running": False}


def _extract_job_id_from_output(output_text):
    """Extract job ID from cli output like 'Extract started. Job ID: abc123'."""
    if "Job ID:" in output_text:
        parts = output_text.split("Job ID:")
        if len(parts) > 1:
            return parts[1].strip().split()[0].strip()
    return None


def _execute_script(run_id, steps, context):
    """Execute script steps sequentially in background thread."""
    run = _script_runs[run_id]
    run["status"] = "running"
    run["startedAt"] = datetime.datetime.now().isoformat()

    for i, cmd in enumerate(steps):
        step_info = {
            "stepNum": i + 1,
            "command": cmd,
            "status": "running",
            "output": "",
            "startedAt": datetime.datetime.now().isoformat(),
            "finishedAt": None,
            "error": None,
        }
        run["steps"][i] = step_info
        run["currentStep"] = i + 1

        try:
            result = cli_handler.execute(cmd, context)

            # Handle connection switching (use sf/db/database)
            if result.get("setConnection"):
                sc = result["setConnection"]
                if sc["type"] == "sf":
                    context["sfConnectionId"] = sc["id"]
                elif sc["type"] == "db":
                    context["dbConnectionId"] = sc["id"]
            if result.get("setDatabase"):
                context["database"] = result["setDatabase"]

            step_info["output"] = result.get("output", "")

            if result.get("type") == "error":
                step_info["status"] = "error"
                step_info["error"] = result.get("output", "Unknown error")
                step_info["finishedAt"] = datetime.datetime.now().isoformat()
                run["status"] = "error"
                run["finishedAt"] = datetime.datetime.now().isoformat()
                run["error"] = f"Step {i + 1} failed: {step_info['error']}"
                return

            # If this was an extract or load command, wait for the async job
            cmd_lower = cmd.strip().split()[0].lower()
            job_id = _extract_job_id_from_output(result.get("output", ""))

            if cmd_lower == "extract" and job_id:
                step_info["status"] = "waiting"
                step_info["jobId"] = job_id
                status = _wait_for_extract_job(job_id, step_info)
                if status.get("status") == "timeout":
                    step_info["status"] = "error"
                    step_info["error"] = "Extract timed out after 30 minutes"
                    step_info["finishedAt"] = datetime.datetime.now().isoformat()
                    run["status"] = "error"
                    run["finishedAt"] = datetime.datetime.now().isoformat()
                    return
                elif status.get("status") == "error" or status.get("errors"):
                    errors = status.get("errors", [])
                    step_info["status"] = "error"
                    step_info["error"] = f"Extract failed: {errors[:3]}" if errors else "Extract failed"
                    step_info["output"] = _format_extract_progress(status)
                    step_info["finishedAt"] = datetime.datetime.now().isoformat()
                    run["status"] = "error"
                    run["finishedAt"] = datetime.datetime.now().isoformat()
                    return
                step_info["output"] = _format_extract_progress(status) + "\n✅ Extract complete."

            elif cmd_lower == "load" and job_id:
                step_info["status"] = "waiting"
                step_info["jobId"] = job_id
                status = _wait_for_load_job(job_id, step_info)
                if status.get("status") == "timeout":
                    step_info["status"] = "error"
                    step_info["error"] = "Load timed out after 30 minutes"
                    step_info["finishedAt"] = datetime.datetime.now().isoformat()
                    run["status"] = "error"
                    run["finishedAt"] = datetime.datetime.now().isoformat()
                    return
                elif status.get("error_count", 0) > 0:
                    step_info["status"] = "warning"
                    step_info["output"] = _format_load_progress(status) + "\n⚠️ Load complete with errors."
                elif status.get("status") == "error":
                    step_info["status"] = "error"
                    step_info["error"] = status.get("message", "Load failed")
                    step_info["output"] = _format_load_progress(status)
                    step_info["finishedAt"] = datetime.datetime.now().isoformat()
                    run["status"] = "error"
                    run["finishedAt"] = datetime.datetime.now().isoformat()
                    return
                else:
                    step_info["output"] = _format_load_progress(status) + "\n✅ Load complete."

            step_info["status"] = step_info.get("status", "complete") if step_info["status"] in ("warning",) else "complete"
            step_info["finishedAt"] = datetime.datetime.now().isoformat()

        except Exception as e:
            step_info["status"] = "error"
            step_info["error"] = str(e)
            step_info["finishedAt"] = datetime.datetime.now().isoformat()
            run["status"] = "error"
            run["finishedAt"] = datetime.datetime.now().isoformat()
            run["error"] = f"Step {i + 1} exception: {str(e)}"
            return

    run["status"] = "complete"
    run["finishedAt"] = datetime.datetime.now().isoformat()


def run_script(script_text, context):
    """Parse and execute a script. Returns run_id for status tracking."""
    steps = parse_script(script_text)
    if not steps:
        return None, "Script is empty — no commands found."

    run_id = str(uuid.uuid4())[:8]
    _script_runs[run_id] = {
        "runId": run_id,
        "status": "starting",
        "totalSteps": len(steps),
        "currentStep": 0,
        "steps": [{
            "stepNum": i + 1,
            "command": cmd,
            "status": "pending",
            "output": "",
            "startedAt": None,
            "finishedAt": None,
            "error": None,
        } for i, cmd in enumerate(steps)],
        "startedAt": None,
        "finishedAt": None,
        "error": None,
    }

    # Make a copy of context so script can modify it (use commands)
    ctx_copy = dict(context)

    t = threading.Thread(
        target=_execute_script,
        args=(run_id, steps, ctx_copy),
        daemon=True,
    )
    t.start()

    return run_id, None


def get_run(run_id):
    """Get status of a script run."""
    return _script_runs.get(run_id)


def get_all_runs():
    """Get all script runs."""
    return list(_script_runs.values())
