"""Multi-round staged seeder using DuckDB for local staging.

Phase 1 (Extract): Download records for each selected object, then iteratively
                    resolve parent references across multiple rounds.
Phase 2 (Load):    Insert into target org with ID remapping (old ID -> new ID).

Objects-based flow:
  1. User selects objects, fields, WHERE conditions, sample sizes
  2. Extract: download each object's records to DuckDB, then resolve
     missing parent references in additional rounds
  3. User reviews staged data
  4. Insert into target in topological order, remapping IDs
"""

import datetime
import json
import os
import re
import threading
import traceback
import uuid

import duckdb

import salesforce_client
import store

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
_STAGING_DIR = os.path.join(store.DATA_DIR, "staging")
_ID_CHUNK = 150
_MAX_FIELDS_PER_QUERY = 200

_SYSTEM_FIELDS = {
    "Id", "IsDeleted", "CreatedDate", "CreatedById",
    "LastModifiedDate", "LastModifiedById", "SystemModstamp",
    "LastActivityDate", "LastViewedDate", "LastReferencedDate",
    "attributes",
}

# Objects we don't chase when resolving parent references
_SKIP_PARENT_OBJECTS = {
    "User", "RecordType", "BusinessHours", "Organization", "Profile",
    "UserRole", "Group", "DandBCompany", "BusinessProcess", "ListView",
}

# ---------------------------------------------------------------------------
_jobs = {}
_lock = threading.Lock()


# ---------------------------------------------------------------------------
# DuckDB staging
# ---------------------------------------------------------------------------
class _StagingDB:
    def __init__(self, path):
        self.db = duckdb.connect(path)
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS records (
                object_name VARCHAR, sf_id VARCHAR, data VARCHAR,
                round_num INTEGER,
                PRIMARY KEY (object_name, sf_id)
            )
        """)
        self.db.execute("""
            CREATE TABLE IF NOT EXISTS id_map (
                old_id VARCHAR PRIMARY KEY, new_id VARCHAR, object_name VARCHAR
            )
        """)

    def put(self, obj, sf_id, record, rnd):
        self.db.execute(
            "INSERT OR REPLACE INTO records VALUES (?, ?, ?, ?)",
            [obj, sf_id, json.dumps(record, default=str), rnd],
        )

    def get_records(self, obj):
        rows = self.db.execute(
            "SELECT sf_id, data FROM records WHERE object_name = ?", [obj]
        ).fetchall()
        return [(r[0], json.loads(r[1])) for r in rows]

    def all_ids(self):
        return {r[0] for r in self.db.execute("SELECT sf_id FROM records").fetchall()}

    def count(self, obj):
        return self.db.execute(
            "SELECT COUNT(*) FROM records WHERE object_name = ?", [obj]
        ).fetchone()[0]

    def objects(self):
        return [r[0] for r in self.db.execute(
            "SELECT DISTINCT object_name FROM records"
        ).fetchall()]

    def map_id(self, old_id, new_id, obj):
        self.db.execute("INSERT OR REPLACE INTO id_map VALUES (?, ?, ?)",
                        [old_id, new_id, obj])

    def new_id(self, old_id):
        row = self.db.execute(
            "SELECT new_id FROM id_map WHERE old_id = ?", [old_id]
        ).fetchone()
        return row[0] if row else None

    def close(self):
        try:
            self.db.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ensure_dir(job_id):
    d = os.path.join(_STAGING_DIR, job_id)
    os.makedirs(d, exist_ok=True)
    return d


def _describe_fields(sf, obj):
    """Return (field_names_incl_Id, ref_field_map, relationship_names).

    relationship_names: {fieldName: relationshipName}
      e.g. {"AccountId": "Account", "BRE_OperationUnit__c": "BRE_OperationUnit__r"}
    """
    desc = getattr(sf, obj).describe()
    names = ["Id"]
    refs = {}
    rel_names = {}
    for f in desc["fields"]:
        if f["name"] == "Id":
            continue
        if f.get("createable"):
            names.append(f["name"])
            if f.get("type") == "reference" and f.get("referenceTo"):
                refs[f["name"]] = list(f["referenceTo"])
                if f.get("relationshipName"):
                    rel_names[f["name"]] = f["relationshipName"]
    return names, refs, rel_names


def _describe_fields_full(sf, obj):
    """Return full field metadata for validation: {fieldName: {required, type, referenceTo, label}}."""
    desc = getattr(sf, obj).describe()
    fields = {}
    for f in desc["fields"]:
        if f["name"] == "Id":
            continue
        if f.get("createable"):
            required = not f.get("nillable", True) and not f.get("defaultedOnCreate", False)
            fields[f["name"]] = {
                "required": required,
                "type": f.get("type"),
                "label": f.get("label", f["name"]),
                "referenceTo": list(f.get("referenceTo") or []),
            }
    return fields


def _chunked_soql(sf, template, ids):
    out = []
    ids = list(ids)
    for i in range(0, len(ids), _ID_CHUNK):
        chunk = ids[i:i + _ID_CHUNK]
        ids_str = ",".join("'%s'" % x for x in chunk)
        soql = template.replace("{IDS}", ids_str)
        try:
            res = sf.query_all(soql)
            out.extend(res.get("records", []))
        except Exception as e:
            print(f"[staged] chunk error: {e}", flush=True)
    return out


def _topo_sort(objects, dep_map):
    ordered, visited, stack = [], set(), set()
    def visit(n):
        if n in visited or n in stack:
            return
        stack.add(n)
        for d in dep_map.get(n, []):
            visit(d)
        stack.discard(n)
        visited.add(n)
        ordered.append(n)
    for o in objects:
        visit(o)
    return ordered


# ---------------------------------------------------------------------------
# Extract (Phase 1) — objects-based
# ---------------------------------------------------------------------------

def start_extract(source_conn_id, objects_config, dependencies, max_rounds=5):
    """
    Begin multi-round extraction.

    objects_config: list of {name, sampleSize, fields, where, recordTypes}
    dependencies:   {objName: [{object, field}]} — lookup deps
    max_rounds:     how many rounds to chase parent references
    Returns: job_id
    """
    job_id = str(uuid.uuid4())[:8]
    job = {
        "id": job_id,
        "type": "staged_seed",
        "phase": "extracting",
        "status": "running",
        "running": True,
        "started_at": datetime.datetime.now().isoformat(),
        "source_conn_id": source_conn_id,
        "objects_config": objects_config,
        "dependencies": dependencies,
        "max_rounds": max_rounds,
        "rounds": [],
        "objects": {},
        "error": None,
    }
    with _lock:
        _jobs[job_id] = job
    threading.Thread(target=_run_extract, args=(job_id,), daemon=True).start()
    return job_id


def _run_extract(job_id):
    job = _jobs[job_id]
    try:
        conn = store.get_salesforce(job["source_conn_id"])
        sf = salesforce_client.connect(conn)

        stg = _StagingDB(os.path.join(_ensure_dir(job_id), "staging.duckdb"))
        job["_stg"] = stg

        obj_configs = {o["name"]: o for o in job["objects_config"]}
        dependencies = job["dependencies"]
        descs = {}  # obj -> {names, refs}

        def ensure_desc(obj):
            if obj not in descs:
                n, r, rn = _describe_fields(sf, obj)
                descs[obj] = {"names": n, "refs": r, "rel_names": rn}
            return descs[obj]

        # ── Round 1: Fetch each object independently ─────────────
        # Always do standalone queries first. References are resolved
        # in rounds 2+ so we get complete, connected data.
        _log(job, 1, "Fetching selected objects", "running")
        round1_total = 0

        for obj_name, cfg in obj_configs.items():
            sample_size = cfg.get("sampleSize", 100)
            where = cfg.get("where", "")
            rt_config = cfg.get("recordTypes")

            desc = ensure_desc(obj_name)
            if cfg.get("fields") and len(cfg["fields"]) > 0:
                fields = ["Id"] + [f for f in cfg["fields"] if f != "Id"]
            else:
                fields = desc["names"]
            # Ensure required/key fields are at the front so they don't get
            # cut off by _MAX_FIELDS_PER_QUERY.  Name is always critical.
            priority = {"Name", "FirstName", "LastName", "Subject"}
            front = [f for f in fields if f in priority and f != "Id"]
            rest = [f for f in fields if f not in priority and f != "Id"]
            fields = ["Id"] + front + rest
            field_list = ", ".join(fields[:_MAX_FIELDS_PER_QUERY])

            conditions = []
            if where:
                conditions.append(f"({where})")
            if rt_config:
                rt_ids = [rt["id"] for rt in rt_config]
                if rt_ids:
                    ids_str = ",".join("'%s'" % r for r in rt_ids)
                    conditions.append(f"RecordTypeId IN ({ids_str})")

            where_clause = " AND ".join(conditions) if conditions else ""
            soql = f"SELECT {field_list} FROM {obj_name}"
            if where_clause:
                soql += f" WHERE {where_clause}"
            soql += f" LIMIT {sample_size}"

            try:
                result = sf.query_all(soql)
                recs = result.get("records", [])
                for r in recs:
                    stg.put(obj_name, r["Id"], r, 1)
                job["objects"][obj_name] = {"count": len(recs)}
                round1_total += len(recs)
                print(f"[staged] R1 {obj_name}: {len(recs)}", flush=True)
            except Exception as e:
                print(f"[staged] R1 error {obj_name}: {e}", flush=True)
                job["objects"][obj_name] = {"count": 0, "error": str(e)}

        _finish_round(job, round1_total)

        # ── Rounds 2..N: Resolve missing parent references ───────
        selected_set = set(obj_configs.keys())

        for rnd in range(2, job["max_rounds"] + 2):
            all_ids = stg.all_ids()
            missing = {}  # obj -> set(ids)

            for obj_name in stg.objects():
                desc = ensure_desc(obj_name)
                for _, rec in stg.get_records(obj_name):
                    for fname, ref_objs in desc["refs"].items():
                        val = rec.get(fname)
                        if not val or val in all_ids:
                            continue
                        for ro in ref_objs:
                            if ro in _SKIP_PARENT_OBJECTS:
                                continue
                            # Only chase refs to objects the user selected
                            if ro in selected_set:
                                missing.setdefault(ro, set()).add(val)

            if not missing:
                print(f"[staged] R{rnd}: no missing refs — done", flush=True)
                break

            desc_str = ", ".join(f"{o}({len(v)})" for o, v in missing.items())
            _log(job, rnd, f"Resolving parents: {desc_str}", "running")
            total = 0
            for obj, needed in missing.items():
                try:
                    d = ensure_desc(obj)
                    priority = {"Name", "FirstName", "LastName", "Subject"}
                    front = [f for f in d["names"] if f in priority and f != "Id"]
                    rest = [f for f in d["names"] if f not in priority and f != "Id"]
                    ordered = ["Id"] + front + rest
                    flds = ", ".join(ordered[:_MAX_FIELDS_PER_QUERY])
                    recs = _chunked_soql(
                        sf, f"SELECT {flds} FROM {obj} WHERE Id IN ({{IDS}})", needed,
                    )
                    for r in recs:
                        stg.put(obj, r["Id"], r, rnd)
                    cnt = stg.count(obj)
                    job["objects"][obj] = {"count": cnt}
                    total += len(recs)
                except Exception as e:
                    print(f"[staged] R{rnd} error {obj}: {e}", flush=True)
            _finish_round(job, total)
            print(f"[staged] R{rnd}: fetched {total} parent records", flush=True)

        # ── Done ─────────────────────────────────────────────────
        job["phase"] = "staged"
        job["status"] = "staged"
        job["running"] = False
        total = sum(v["count"] for v in job["objects"].values())
        print(f"[staged] Extract done: {total} records, {len(job['objects'])} objects", flush=True)
        store.save_job(_safe_job(job))

    except Exception as e:
        traceback.print_exc()
        job["phase"] = "error"
        job["status"] = "error"
        job["error"] = str(e)
        job["running"] = False


def _log(job, rnd, desc, status):
    job["rounds"].append({"round": rnd, "description": desc, "status": status})


def _finish_round(job, count, error=None):
    if job["rounds"]:
        job["rounds"][-1]["status"] = "error" if error else "done"
        job["rounds"][-1]["count"] = count
        if error:
            job["rounds"][-1]["error"] = error


# ---------------------------------------------------------------------------
# SOQL-based discovery & extract
# ---------------------------------------------------------------------------

def _parse_soql_object(soql):
    """Extract the main object name from a SOQL query."""
    m = re.search(r'\bFROM\s+(\w+)', soql, re.IGNORECASE)
    return m.group(1) if m else None


def discover_soql(source_conn_id, soql):
    """Analyze a SOQL query: run it, discover objects and their fields/lookups.

    Returns:
    {
      mainObject: "Contact",
      recordCount: 150,
      objects: {
        "Contact": { fields: [...], lookups: [...] },
        "Account": { fields: [...], lookups: [...], relationship: "AccountId on Contact" },
        ...
      }
    }
    """
    conn = store.get_salesforce(source_conn_id)
    sf = salesforce_client.connect(conn)

    main_obj = _parse_soql_object(soql)
    if not main_obj:
        return {"error": "Could not parse object from SOQL"}

    # Run the query to get record count and discover referenced objects
    try:
        result = sf.query_all(soql)
        records = result.get("records", [])
    except Exception as e:
        return {"error": f"SOQL error: {e}"}

    # Describe the main object to get full field info
    try:
        desc = getattr(sf, main_obj).describe()
    except Exception as e:
        return {"error": f"Cannot describe {main_obj}: {e}"}

    field_map = {}  # fieldName -> field metadata
    for f in desc["fields"]:
        field_map[f["name"]] = f

    # Identify all reference fields and which objects they point to
    discovered_objects = {}  # objName -> { relationship, ref_field, fields, lookups }

    main_lookups = []
    main_fields = []
    for f in desc["fields"]:
        if not f.get("createable") and f["name"] != "Id":
            continue
        finfo = {
            "name": f["name"],
            "label": f.get("label", f["name"]),
            "type": f.get("type"),
            "required": not f.get("nillable", True) and not f.get("defaultedOnCreate", False),
        }
        if f.get("type") == "reference" and f.get("referenceTo"):
            finfo["referenceTo"] = list(f["referenceTo"])
            main_lookups.append(finfo)
            # Discover referenced objects (skip system objects)
            for ref_obj in f["referenceTo"]:
                if ref_obj in _SKIP_PARENT_OBJECTS:
                    continue
                if ref_obj not in discovered_objects and ref_obj != main_obj:
                    discovered_objects[ref_obj] = {
                        "relationship": f"{f['name']} on {main_obj}",
                        "ref_field": f["name"],
                        "ref_label": f.get("label", f["name"]),
                    }
        else:
            main_fields.append(finfo)

    # For each discovered object, describe it to get its fields and lookups
    for obj_name in list(discovered_objects.keys()):
        try:
            obj_desc = getattr(sf, obj_name).describe()
            obj_fields = []
            obj_lookups = []
            for f in obj_desc["fields"]:
                if not f.get("createable") and f["name"] != "Id":
                    continue
                finfo = {
                    "name": f["name"],
                    "label": f.get("label", f["name"]),
                    "type": f.get("type"),
                    "required": not f.get("nillable", True) and not f.get("defaultedOnCreate", False),
                }
                if f.get("type") == "reference" and f.get("referenceTo"):
                    finfo["referenceTo"] = list(f["referenceTo"])
                    obj_lookups.append(finfo)
                else:
                    obj_fields.append(finfo)
            discovered_objects[obj_name]["fields"] = obj_fields
            discovered_objects[obj_name]["lookups"] = obj_lookups
        except Exception as e:
            discovered_objects[obj_name]["fields"] = []
            discovered_objects[obj_name]["lookups"] = []
            discovered_objects[obj_name]["error"] = str(e)

    # Scan records to see which referenced objects actually have IDs present
    ref_id_counts = {}  # ref_field -> count of non-null values
    for rec in records:
        for lookup in main_lookups:
            val = rec.get(lookup["name"])
            if val and isinstance(val, str) and len(val) >= 15:
                ref_id_counts[lookup["name"]] = ref_id_counts.get(lookup["name"], 0) + 1

    # Add counts to discovered objects
    for obj_name, info in discovered_objects.items():
        ref_field = info.get("ref_field")
        if ref_field:
            info["referenced_count"] = ref_id_counts.get(ref_field, 0)

    return {
        "mainObject": main_obj,
        "recordCount": len(records),
        "soql": soql,
        "objects": {
            main_obj: {
                "fields": main_fields,
                "lookups": main_lookups,
                "isMain": True,
            },
            **discovered_objects,
        },
    }


def start_soql_extract(source_conn_id, soql, include_objects, max_rounds=5):
    """Begin SOQL-based extraction.

    soql:             the user's SOQL query for the main object
    include_objects:   dict of {objName: {fields: [...], lookups_to_skip: [...]}}
                      — which discovered objects to include and which lookups to skip
    """
    job_id = str(uuid.uuid4())[:8]
    main_obj = _parse_soql_object(soql)

    job = {
        "id": job_id,
        "type": "staged_seed",
        "phase": "extracting",
        "status": "running",
        "running": True,
        "started_at": datetime.datetime.now().isoformat(),
        "source_conn_id": source_conn_id,
        "soql": soql,
        "main_object": main_obj,
        "include_objects": include_objects,
        "max_rounds": max_rounds,
        "rounds": [],
        "objects": {},
        "error": None,
    }
    with _lock:
        _jobs[job_id] = job
    threading.Thread(target=_run_soql_extract, args=(job_id,), daemon=True).start()
    return job_id


def _run_soql_extract(job_id):
    job = _jobs[job_id]
    try:
        conn = store.get_salesforce(job["source_conn_id"])
        sf = salesforce_client.connect(conn)

        stg = _StagingDB(os.path.join(_ensure_dir(job_id), "staging.duckdb"))
        job["_stg"] = stg

        main_obj = job["main_object"]
        soql = job["soql"]
        include_objects = job["include_objects"] or {}
        descs = {}

        def ensure_desc(obj):
            if obj not in descs:
                n, r, rn = _describe_fields(sf, obj)
                descs[obj] = {"names": n, "refs": r, "rel_names": rn}
            return descs[obj]

        # ── Round 1: Run the user's SOQL to get IDs, then fetch full records
        _log(job, 1, f"Running SOQL on {main_obj}", "running")
        recs = []

        try:
            # Step 1: Run the SOQL (may only select Id) to get matching IDs
            result = sf.query_all(soql)
            raw_recs = result.get("records", [])
            matched_ids = {r["Id"] for r in raw_recs if r.get("Id")}
            print(f"[soql-staged] R1 {main_obj}: {len(matched_ids)} IDs from SOQL", flush=True)

            # Step 2: Re-fetch those IDs with all createable fields
            if matched_ids:
                d = ensure_desc(main_obj)
                priority = {"Name", "FirstName", "LastName", "Subject"}
                front = [f for f in d["names"] if f in priority and f != "Id"]
                rest = [f for f in d["names"] if f not in priority and f != "Id"]
                ordered = ["Id"] + front + rest
                flds = ", ".join(ordered[:_MAX_FIELDS_PER_QUERY])
                recs = _chunked_soql(
                    sf, f"SELECT {flds} FROM {main_obj} WHERE Id IN ({{IDS}})", matched_ids,
                )
                for r in recs:
                    stg.put(main_obj, r["Id"], r, 1)
                print(f"[soql-staged] R1 {main_obj}: {len(recs)} full records fetched", flush=True)

            job["objects"][main_obj] = {"count": len(recs)}
        except Exception as e:
            print(f"[soql-staged] R1 SOQL error: {e}", flush=True)
            job["objects"][main_obj] = {"count": 0, "error": str(e)}

        _finish_round(job, len(recs))

        # ── Round 2: Fetch parent records for included objects ───
        included_set = set(include_objects.keys())
        included_set.add(main_obj)

        # Get lookups to skip per object
        skip_lookups = {}
        for obj_name, cfg in include_objects.items():
            skip_lookups[obj_name] = set(cfg.get("lookups_to_skip", []))
        skip_lookups.setdefault(main_obj, set())

        print(f"[soql-staged] included_set={included_set}, skip_lookups keys={list(skip_lookups.keys())}", flush=True)

        for rnd in range(2, job["max_rounds"] + 2):
            all_ids = stg.all_ids()
            missing = {}  # obj -> set(ids)

            for obj_name in stg.objects():
                desc = ensure_desc(obj_name)
                skips = skip_lookups.get(obj_name, set())
                ref_count = 0
                for _, rec in stg.get_records(obj_name):
                    for fname, ref_objs in desc["refs"].items():
                        if fname in skips:
                            continue
                        val = rec.get(fname)
                        if not val or val in all_ids:
                            continue
                        for ro in ref_objs:
                            if ro in _SKIP_PARENT_OBJECTS:
                                continue
                            if ro in included_set:
                                missing.setdefault(ro, set()).add(val)

            if not missing:
                # Debug: show what was checked
                for obj_name in stg.objects():
                    desc = ensure_desc(obj_name)
                    ref_targets = {}
                    for fname, ref_objs in desc["refs"].items():
                        for ro in ref_objs:
                            if ro in included_set and ro != obj_name:
                                ref_targets[fname] = ro
                    recs = stg.get_records(obj_name)
                    non_null = 0
                    for _, rec in recs:
                        for fname in ref_targets:
                            if rec.get(fname):
                                non_null += 1
                                break
                    print(f"[soql-staged] R{rnd} debug: {obj_name} has {len(ref_targets)} ref fields to included objs, {non_null}/{len(recs)} recs with non-null refs", flush=True)
                    if ref_targets:
                        print(f"[soql-staged]   ref fields: {ref_targets}", flush=True)
                print(f"[soql-staged] R{rnd}: no missing refs — done", flush=True)
                break

            desc_str = ", ".join(f"{o}({len(v)})" for o, v in missing.items())
            _log(job, rnd, f"Resolving parents: {desc_str}", "running")
            total = 0
            for obj, needed in missing.items():
                try:
                    d = ensure_desc(obj)
                    priority = {"Name", "FirstName", "LastName", "Subject"}
                    front = [f for f in d["names"] if f in priority and f != "Id"]
                    rest = [f for f in d["names"] if f not in priority and f != "Id"]
                    ordered = ["Id"] + front + rest
                    flds = ", ".join(ordered[:_MAX_FIELDS_PER_QUERY])
                    fetched = _chunked_soql(
                        sf, f"SELECT {flds} FROM {obj} WHERE Id IN ({{IDS}})", needed,
                    )
                    for r in fetched:
                        stg.put(obj, r["Id"], r, rnd)
                    cnt = stg.count(obj)
                    job["objects"][obj] = {"count": cnt}
                    total += len(fetched)
                except Exception as e:
                    print(f"[soql-staged] R{rnd} error {obj}: {e}", flush=True)
            _finish_round(job, total)
            print(f"[soql-staged] R{rnd}: fetched {total} parent records", flush=True)

        # ── Done ─────────────────────────────────────────────────
        job["phase"] = "staged"
        job["status"] = "staged"
        job["running"] = False
        total = sum(v["count"] for v in job["objects"].values())
        print(f"[soql-staged] Extract done: {total} records, {len(job['objects'])} objects", flush=True)
        store.save_job(_safe_job(job))

    except Exception as e:
        traceback.print_exc()
        job["phase"] = "error"
        job["status"] = "error"
        job["error"] = str(e)
        job["running"] = False


# ---------------------------------------------------------------------------
# Tree-based Extract — driven by the dependency tree built in the UI
# ---------------------------------------------------------------------------

def start_tree_extract(source_conn_id, main_object, sample_size, where_clause,
                       dep_tree):
    """Extract records based on the dependency tree.

    dep_tree: list of {parentObj, fieldName, targetObj}
      — each entry means parentObj.fieldName -> targetObj
      — ordered from main object outward (main's deps first, then their deps)

    Approach:
    1. Sample `sample_size` records from main_object (with WHERE if provided)
    2. For each dep link from main_object, collect distinct parent IDs
    3. Fetch those parent records with all createable fields
    4. Repeat for deeper deps
    """
    job_id = str(uuid.uuid4())[:8]
    job = {
        "id": job_id,
        "type": "staged_seed",
        "phase": "extracting",
        "status": "running",
        "running": True,
        "started_at": datetime.datetime.now().isoformat(),
        "source_conn_id": source_conn_id,
        "main_object": main_object,
        "sample_size": sample_size,
        "where_clause": where_clause,
        "dep_tree": dep_tree,
        "rounds": [],
        "objects": {},
        "error": None,
    }
    with _lock:
        _jobs[job_id] = job
    threading.Thread(target=_run_tree_extract, args=(job_id,), daemon=True).start()
    return job_id


def _run_tree_extract(job_id):
    job = _jobs[job_id]
    try:
        conn = store.get_salesforce(job["source_conn_id"])
        sf = salesforce_client.connect(conn)

        stg = _StagingDB(os.path.join(_ensure_dir(job_id), "staging.duckdb"))
        job["_stg"] = stg

        main_obj = job["main_object"]
        sample_size = job["sample_size"]
        where_clause = (job["where_clause"] or "").strip()
        dep_tree = job["dep_tree"] or []
        descs = {}

        def ensure_desc(obj):
            if obj not in descs:
                n, r, rn = _describe_fields(sf, obj)
                descs[obj] = {"names": n, "refs": r, "rel_names": rn}
            return descs[obj]

        # Collect all dep field names so they get prioritized in SELECT
        all_dep_fields = set()
        for dep in dep_tree:
            all_dep_fields.add(dep["fieldName"])

        def _field_list(obj):
            d = ensure_desc(obj)
            priority = {"Name", "FirstName", "LastName", "Subject"} | all_dep_fields
            front = [f for f in d["names"] if f in priority and f != "Id"]
            rest = [f for f in d["names"] if f not in priority and f != "Id"]
            ordered = ["Id"] + front + rest
            return ", ".join(ordered[:_MAX_FIELDS_PER_QUERY])

        # ── Step 1: Sample main object records ──────────────────
        # Auto-add WHERE != null for each dep field from main object
        # so sampled records actually have the dependency populated
        print(f"[tree] dep_tree={dep_tree}, main_obj={main_obj}", flush=True)
        dep_fields_from_main = [
            d["fieldName"] for d in dep_tree if d["parentObj"] == main_obj
        ]
        print(f"[tree] dep_fields_from_main={dep_fields_from_main}", flush=True)
        conditions = []
        if where_clause:
            conditions.append(f"({where_clause})")
        for fn in dep_fields_from_main:
            conditions.append(f"{fn} != null")
        where_str = " AND ".join(conditions)

        _log(job, 1, f"Sampling {sample_size} records from {main_obj}", "running")

        flds = _field_list(main_obj)
        soql = f"SELECT {flds} FROM {main_obj}"
        if where_str:
            soql += f" WHERE {where_str}"
        soql += f" LIMIT {sample_size}"

        recs = []
        try:
            print(f"[tree] Step 1 SOQL: ...WHERE {where_str} LIMIT {sample_size}", flush=True)
            result = sf.query(soql)  # query (not query_all) to respect LIMIT
            recs = result.get("records", [])
            for r in recs:
                stg.put(main_obj, r["Id"], r, 1)
            job["objects"][main_obj] = {"count": len(recs)}
            print(f"[tree] Step 1: {main_obj} — {len(recs)} records", flush=True)
        except Exception as e:
            print(f"[tree] Step 1 error: {e}", flush=True)
            traceback.print_exc()
            job["objects"][main_obj] = {"count": 0, "error": str(e)}
        _finish_round(job, len(recs))

        # ── Step 2+: For each dep link, collect parent IDs and fetch ─
        # Group dep_tree by depth: first main_obj's deps, then their deps...
        # dep_tree is ordered: main's deps first, deeper deps later.
        # Process them in order — each link: parentObj.fieldName -> targetObj
        rnd = 2
        for dep in dep_tree:
            parent_obj = dep["parentObj"]
            field_name = dep["fieldName"]
            target_obj = dep["targetObj"]

            print(f"[tree] Step {rnd}: processing {parent_obj}.{field_name} -> {target_obj}", flush=True)

            # Collect distinct IDs from the parent object's records
            parent_recs = stg.get_records(parent_obj)
            target_ids = set()
            for _, rec in parent_recs:
                val = rec.get(field_name)
                if val and isinstance(val, str) and len(val) >= 15:
                    target_ids.add(val)
            print(f"[tree] Step {rnd}: found {len(target_ids)} distinct {target_obj} IDs in {len(parent_recs)} {parent_obj} records", flush=True)

            # Remove IDs we already have
            existing = stg.all_ids()
            needed = target_ids - existing

            if not needed:
                _log(job, rnd, f"{target_obj}: 0 new records (all {len(target_ids)} already staged)", "done")
                print(f"[tree] Step {rnd}: {target_obj} via {parent_obj}.{field_name} — 0 new (all already staged)", flush=True)
                rnd += 1
                continue

            _log(job, rnd, f"Fetching {len(needed)} {target_obj} records (via {parent_obj}.{field_name})", "running")

            try:
                flds = _field_list(target_obj)
                fetched = _chunked_soql(
                    sf, f"SELECT {flds} FROM {target_obj} WHERE Id IN ({{IDS}})", needed,
                )
                for r in fetched:
                    stg.put(target_obj, r["Id"], r, rnd)
                cnt = stg.count(target_obj)
                job["objects"][target_obj] = {"count": cnt}
                _finish_round(job, len(fetched))
                print(f"[tree] Step {rnd}: {target_obj} — {len(fetched)} records fetched", flush=True)
            except Exception as e:
                print(f"[tree] Step {rnd} error {target_obj}: {e}", flush=True)
                _finish_round(job, 0, error=str(e))

            rnd += 1

        # ── Done ─────────────────────────────────────────────────
        job["phase"] = "staged"
        job["status"] = "staged"
        job["running"] = False
        total = sum(v["count"] for v in job["objects"].values())
        print(f"[tree] Extract done: {total} records, {len(job['objects'])} objects", flush=True)
        store.save_job(_safe_job(job))

    except Exception as e:
        traceback.print_exc()
        job["phase"] = "error"
        job["status"] = "error"
        job["error"] = str(e)
        job["running"] = False


_EXT_ID_FIELD = "dr_external_id__c"


def _ensure_external_id_field(sf_dest, obj):
    """Create dr_external_id__c (Text 18, External ID) on target object if missing.

    Returns True if field exists (or was created), False on failure.
    """
    # Check if field already exists
    try:
        desc = getattr(sf_dest, obj).describe()
        for f in desc["fields"]:
            if f["name"].lower() == _EXT_ID_FIELD.lower():
                print(f"[staged] {obj}.{_EXT_ID_FIELD} already exists", flush=True)
                return True
    except Exception as e:
        print(f"[staged] Error describing {obj}: {e}", flush=True)
        return False

    # Create via Tooling API
    print(f"[staged] Creating {obj}.{_EXT_ID_FIELD}...", flush=True)
    try:
        payload = {
            "FullName": f"{obj}.{_EXT_ID_FIELD}",
            "Metadata": {
                "label": "DR External ID",
                "type": "Text",
                "length": 18,
                "externalId": True,
                "unique": False,
                "description": "Data Rover external ID for sandbox seeding",
            },
        }
        result = sf_dest.restful(
            "tooling/sobjects/CustomField",
            method="POST",
            json=payload,
        )
        print(f"[staged] Created {obj}.{_EXT_ID_FIELD}: {result}", flush=True)
        return True
    except Exception as e:
        err_str = str(e)
        # If the field already exists (race condition or partial create), that's OK
        if "DUPLICATE_DEVELOPER_NAME" in err_str or "already exists" in err_str.lower():
            print(f"[staged] {obj}.{_EXT_ID_FIELD} already exists (from error)", flush=True)
            return True
        print(f"[staged] Failed to create {obj}.{_EXT_ID_FIELD}: {e}", flush=True)
        return False


# ---------------------------------------------------------------------------
# Insert (Phase 2)
# ---------------------------------------------------------------------------

def start_insert(job_id, dest_conn_id):
    job = _jobs.get(job_id)
    if not job:
        return None
    job["phase"] = "inserting"
    job["status"] = "running"
    job["running"] = True
    job["dest_conn_id"] = dest_conn_id
    job["insert_progress"] = {}
    job["error"] = None
    threading.Thread(target=_run_insert, args=(job_id,), daemon=True).start()
    return job_id


def _run_insert(job_id):
    job = _jobs[job_id]
    stg = job.get("_stg")
    if not stg:
        job.update(phase="error", status="error", error="No staging data", running=False)
        return

    try:
        dest_conn = store.get_salesforce(job["dest_conn_id"])
        sf_dest = salesforce_client.connect(dest_conn)

        objects = stg.objects()

        # Describe each object on destination
        descs = {}
        for obj in objects:
            try:
                names, refs, rel_names = _describe_fields(sf_dest, obj)
                descs[obj] = {"createable": set(names) - {"Id"}, "refs": refs, "rel_names": rel_names}
            except Exception as e:
                print(f"[staged] Can't describe {obj} on dest: {e}", flush=True)

        # Build full dependency map
        obj_set = set(objects)
        full_dep_map = {}   # obj -> set of objects it references
        dep_fields = {}     # obj -> {target_obj: set(field_names)}
        for obj in objects:
            deps = set()
            for fname, ref_objs in descs.get(obj, {}).get("refs", {}).items():
                for ro in ref_objs:
                    if ro in obj_set and ro != obj:
                        deps.add(ro)
                        dep_fields.setdefault(obj, {}).setdefault(ro, set()).add(fname)
            full_dep_map[obj] = deps

        # Detect circular deps (A depends on B AND B depends on A)
        circular_pairs = set()
        for obj, deps in full_dep_map.items():
            for dep in deps:
                if obj in full_dep_map.get(dep, set()):
                    pair = tuple(sorted([obj, dep]))
                    circular_pairs.add(pair)

        # Break cycles: deps inserted FIRST, main object LAST.
        # For circular deps involving main, the dep object skips its
        # back-reference to main (backfilled after all inserts).
        main_obj = job.get("main_object")
        broken_dep_map = {}
        backfill = {}  # {obj: set(field_names)} — fields to update after all inserts
        for obj in objects:
            deps = set(full_dep_map.get(obj, set()))
            if circular_pairs:
                for dep in list(deps):
                    pair = tuple(sorted([obj, dep]))
                    if pair in circular_pairs:
                        if dep == main_obj:
                            # This dep object references main — skip it so dep inserts first
                            deps.discard(dep)
                            fields = dep_fields.get(obj, {}).get(dep, set())
                            backfill.setdefault(obj, set()).update(fields)
                        elif obj == main_obj:
                            # Main references this dep — keep the dep (main needs it)
                            pass
                        else:
                            # Non-main circular: break arbitrarily
                            deps.discard(dep)
                            fields = dep_fields.get(obj, {}).get(dep, set())
                            backfill.setdefault(obj, set()).update(fields)
            broken_dep_map[obj] = deps

        order = _topo_sort(objects, broken_dep_map)

        # Also detect any remaining circular refs from the topo order
        order_idx = {o: i for i, o in enumerate(order)}
        for obj in order:
            refs = descs.get(obj, {}).get("refs", {})
            for fname, ref_objs in refs.items():
                for ro in ref_objs:
                    if ro in order_idx and order_idx[ro] > order_idx[obj]:
                        backfill.setdefault(obj, set()).add(fname)

        print(f"[staged] Insert order: {' -> '.join(order)}", flush=True)
        if backfill:
            desc = ", ".join(f"{o}({','.join(sorted(fs))})" for o, fs in backfill.items())
            print(f"[staged] Circular deps — will backfill: {desc}", flush=True)

        # ── Create dr_external_id__c on each object if needed ──
        ext_id_ok = {}  # obj -> bool
        for obj in order:
            ext_id_ok[obj] = _ensure_external_id_field(sf_dest, obj)

        # Build set of objects that have dr_external_id__c (for ext-id referencing)
        ext_id_objects = {o for o, ok in ext_id_ok.items() if ok}

        # If any field creation failed, abort
        failed_objs = [o for o, ok in ext_id_ok.items() if not ok]
        if failed_objs:
            msg = f"Could not create {_EXT_ID_FIELD} on: {', '.join(failed_objs)}. Create the field manually (Text 18, External ID) and retry."
            print(f"[staged] ABORT: {msg}", flush=True)
            job.update(phase="error", status="error", error=msg, running=False)
            return

        # With external ID references, we don't need backfill for fields
        # whose target objects have dr_external_id__c — we can set them
        # directly during insert using the relationship syntax.
        for obj in list(backfill.keys()):
            remaining = set()
            for fname in backfill[obj]:
                target_objs = descs.get(obj, {}).get("refs", {}).get(fname, [])
                target_has_ext = any(t in ext_id_objects for t in target_objs)
                rel_name = descs.get(obj, {}).get("rel_names", {}).get(fname)
                if target_has_ext and rel_name:
                    # Can use ext ID ref — no backfill needed
                    print(f"[staged] {obj}.{fname}: ext ID available, skipping backfill", flush=True)
                else:
                    remaining.add(fname)
            if remaining:
                backfill[obj] = remaining
            else:
                del backfill[obj]

        if backfill:
            desc2 = ", ".join(f"{o}({','.join(sorted(fs))})" for o, fs in backfill.items())
            print(f"[staged] Remaining backfill (no ext ID): {desc2}", flush=True)
        else:
            print(f"[staged] No backfill needed — all resolved via external ID", flush=True)

        id_map = {}

        # ── Pass 1: Insert all objects, skipping circular-ref fields ──
        for obj in order:
            if obj not in descs:
                continue
            records = stg.get_records(obj)
            createable = descs[obj]["createable"]
            ref_fields = descs[obj]["refs"]
            rel_names = descs[obj].get("rel_names", {})
            skip_fields = backfill.get(obj, set())
            has_ext_id = obj in ext_id_objects

            ok, err = 0, 0
            error_details = []
            job["insert_progress"][obj] = {
                "total": len(records), "inserted": 0, "errors": 0,
                "error_details": [], "status": "inserting",
            }

            for sf_id, rec in records:
                new_rec = {}
                # Set dr_external_id__c = source SF ID
                if has_ext_id:
                    new_rec[_EXT_ID_FIELD] = sf_id

                for field, value in rec.items():
                    if field in _SYSTEM_FIELDS or field not in createable or value is None:
                        continue
                    if isinstance(value, dict):
                        continue
                    if field in skip_fields:
                        continue  # will backfill later
                    if field in ref_fields and isinstance(value, str) and len(value) >= 15:
                        # Check if the referenced object has dr_external_id__c
                        target_objs = ref_fields[field]
                        target_in_staged = [t for t in target_objs if t in ext_id_objects]
                        if target_in_staged and field in rel_names:
                            # Use external ID reference:
                            # e.g. {"BRE_OperationUnit__r": {"dr_external_id__c": "source_id"}}
                            rel_name = rel_names[field]
                            new_rec[rel_name] = {_EXT_ID_FIELD: value}
                        else:
                            # Fall back to ID remapping
                            mapped = id_map.get(value)
                            if mapped:
                                new_rec[field] = mapped
                            # else: skip — dangling ref
                    else:
                        new_rec[field] = value

                try:
                    result = getattr(sf_dest, obj).create(new_rec)
                    if result.get("success"):
                        id_map[sf_id] = result["id"]
                        stg.map_id(sf_id, result["id"], obj)
                        ok += 1
                    else:
                        err += 1
                        errors = result.get("errors", [])
                        msg = "; ".join(e.get("message", str(e)) for e in errors) if errors else str(result)
                        if len(error_details) < 10:
                            error_details.append(msg)
                        print(f"[staged] Insert fail {obj}: {msg}", flush=True)
                except Exception as e:
                    err += 1
                    if len(error_details) < 10:
                        error_details.append(str(e))
                    print(f"[staged] Insert error {obj}: {e}", flush=True)

                job["insert_progress"][obj]["inserted"] = ok
                job["insert_progress"][obj]["errors"] = err
                job["insert_progress"][obj]["error_details"] = error_details

            job["insert_progress"][obj]["status"] = (
                "done" if err == 0 else "partial" if ok > 0 else "error"
            )
            print(f"[staged] {obj}: {ok} inserted, {err} errors", flush=True)

        # ── Pass 2: Backfill circular-ref fields ──
        if backfill:
            for obj, fields_to_fill in backfill.items():
                records = stg.get_records(obj)
                ref_fields = descs[obj]["refs"]
                rel_names = descs[obj].get("rel_names", {})
                updated, skipped, errs = 0, 0, 0
                error_details = []
                progress_key = f"{obj} (backfill)"
                job["insert_progress"][progress_key] = {
                    "total": len(records), "inserted": 0, "errors": 0,
                    "error_details": [], "status": "backfilling",
                }

                for sf_id, rec in records:
                    new_id = id_map.get(sf_id)
                    if not new_id:
                        skipped += 1
                        continue

                    update_rec = {}
                    for field in fields_to_fill:
                        value = rec.get(field)
                        if value and isinstance(value, str) and len(value) >= 15:
                            # Use external ID reference if possible
                            target_objs = ref_fields.get(field, [])
                            target_in_staged = [t for t in target_objs if t in ext_id_objects]
                            if target_in_staged and field in rel_names:
                                rel_name = rel_names[field]
                                update_rec[rel_name] = {_EXT_ID_FIELD: value}
                            else:
                                mapped = id_map.get(value)
                                if mapped:
                                    update_rec[field] = mapped

                    if not update_rec:
                        skipped += 1
                        continue

                    try:
                        getattr(sf_dest, obj).update(new_id, update_rec)
                        updated += 1
                    except Exception as e:
                        errs += 1
                        if len(error_details) < 10:
                            error_details.append(str(e))
                        print(f"[staged] Backfill error {obj} {new_id}: {e}", flush=True)

                    job["insert_progress"][progress_key]["inserted"] = updated
                    job["insert_progress"][progress_key]["errors"] = errs
                    job["insert_progress"][progress_key]["error_details"] = error_details

                job["insert_progress"][progress_key]["status"] = (
                    "done" if errs == 0 else "partial" if updated > 0 else "error"
                )
                print(f"[staged] Backfill {obj}: {updated} updated, {skipped} skipped, {errs} errors", flush=True)

        job["phase"] = "complete"
        job["status"] = "complete"
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        store.save_job(_safe_job(job))

    except Exception as e:
        traceback.print_exc()
        job.update(phase="error", status="error", error=str(e), running=False)


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------

def get_job(job_id):
    job = _jobs.get(job_id)
    return _safe_job(job) if job else None


def get_staged_summary(job_id):
    job = _jobs.get(job_id)
    if not job:
        return None
    stg = job.get("_stg")
    if not stg:
        return None

    summary = {}
    for obj in stg.objects():
        records = stg.get_records(obj)
        sample = []
        for _, rec in records[:5]:
            flat = {}
            for k, v in rec.items():
                if k == "attributes":
                    continue
                if isinstance(v, dict):
                    v = v.get("Name") or v.get("Id") or ""
                flat[k] = str(v) if v is not None else ""
            sample.append(flat)
        cols = list(sample[0].keys())[:8] if sample else []
        summary[obj] = {"count": len(records), "sample": sample, "columns": cols}
    return summary


def validate_staged(job_id, dest_conn_id):
    """Validate staged records against destination schema.

    Returns per-object validation: which records will fail and why,
    along with suggested WHERE clauses to exclude bad records.
    """
    job = _jobs.get(job_id)
    if not job:
        return None
    stg = job.get("_stg")
    if not stg:
        return None

    try:
        dest_conn = store.get_salesforce(dest_conn_id)
        sf_dest = salesforce_client.connect(dest_conn)
    except Exception as e:
        return {"error": str(e)}

    all_staged_ids = stg.all_ids()
    staged_objects = set(stg.objects())
    result = {}

    for obj in stg.objects():
        try:
            dest_fields = _describe_fields_full(sf_dest, obj)
        except Exception as e:
            result[obj] = {
                "total": stg.count(obj),
                "valid": 0, "invalid": 0,
                "issues": [], "suggestions": [], "info": [],
            }
            continue

        records = stg.get_records(obj)
        createable_names = set(dest_fields.keys())
        required_fields = {n for n, f in dest_fields.items() if f["required"]}
        ref_fields = {n: f["referenceTo"] for n, f in dest_fields.items() if f["type"] == "reference" and f["referenceTo"]}

        issues = {}       # required_null issues → these WILL cause insert failure
        dangling_info = {}  # dangling refs → informational, will be cleared during insert
        invalid_ids = set()

        for sf_id, rec in records:
            rec_fails = False

            # Check required fields that are null/missing — these WILL fail on insert
            for fname in required_fields:
                if fname in _SYSTEM_FIELDS:
                    continue
                val = rec.get(fname)
                if val is None or val == "" or (isinstance(val, dict) and not val):
                    key = f"required_null:{fname}"
                    if key not in issues:
                        issues[key] = {
                            "type": "required_null",
                            "field": fname,
                            "label": dest_fields[fname]["label"],
                            "count": 0,
                        }
                    issues[key]["count"] += 1
                    rec_fails = True

            # Check reference fields pointing to IDs not in staged set
            for fname, ref_objs in ref_fields.items():
                val = rec.get(fname)
                if not val or not isinstance(val, str) or len(val) < 15:
                    continue
                skip = all(ro in _SKIP_PARENT_OBJECTS for ro in ref_objs)
                if skip:
                    continue
                if val not in all_staged_ids:
                    key = f"dangling_ref:{fname}"
                    if key not in dangling_info:
                        # Check if this references objects in our staged set or external
                        refs_staged = [ro for ro in ref_objs if ro in staged_objects]
                        refs_external = [ro for ro in ref_objs if ro not in staged_objects and ro not in _SKIP_PARENT_OBJECTS]
                        dangling_info[key] = {
                            "field": fname,
                            "label": dest_fields[fname]["label"],
                            "references": ref_objs,
                            "refs_staged": refs_staged,
                            "refs_external": refs_external,
                            "count": 0,
                        }
                    dangling_info[key]["count"] += 1

            if rec_fails:
                invalid_ids.add(sf_id)

        # Build suggestions — only for required_null (real failures)
        suggestions = []
        for key, issue in issues.items():
            suggestions.append({
                "field": issue["field"],
                "label": issue["label"],
                "type": "required_null",
                "affected": issue["count"],
                "where_clause": f"{issue['field']} != null",
                "message": f"{issue['field']} ({issue['label']}) is required but null in {issue['count']} records",
            })

        # Build info items for dangling refs (non-blocking, cleared during insert)
        info = []
        for key, d in dangling_info.items():
            if d["refs_external"]:
                info.append({
                    "field": d["field"],
                    "label": d["label"],
                    "type": "dangling_ref_external",
                    "affected": d["count"],
                    "references": d["refs_external"],
                    "message": f"{d['field']} ({d['label']}) references {', '.join(d['refs_external'])} (not in selected objects) — {d['count']} records will have this field cleared during insert",
                })
            if d["refs_staged"]:
                info.append({
                    "field": d["field"],
                    "label": d["label"],
                    "type": "dangling_ref_staged",
                    "affected": d["count"],
                    "references": d["refs_staged"],
                    "message": f"{d['field']} ({d['label']}) — {d['count']} records reference {', '.join(d['refs_staged'])} IDs not in staged data (will be cleared during insert)",
                })

        result[obj] = {
            "total": len(records),
            "valid": len(records) - len(invalid_ids),
            "invalid": len(invalid_ids),
            "issues": list(issues.values()),
            "suggestions": suggestions,
            "info": info,
        }

    return result


def cleanup_target(dest_conn_id, objects):
    """Delete all records for the given objects from the destination org.

    objects: list of object API names
    Returns: job_id
    """
    job_id = str(uuid.uuid4())[:8]
    job = {
        "id": job_id,
        "type": "staged_seed_cleanup",
        "phase": "cleaning",
        "status": "running",
        "running": True,
        "started_at": datetime.datetime.now().isoformat(),
        "dest_conn_id": dest_conn_id,
        "cleanup_objects": objects,
        "cleanup_progress": {},
        "error": None,
    }
    with _lock:
        _jobs[job_id] = job
    threading.Thread(target=_run_cleanup, args=(job_id,), daemon=True).start()
    return job_id


def _run_cleanup(job_id):
    job = _jobs[job_id]
    try:
        dest_conn = store.get_salesforce(job["dest_conn_id"])
        sf = salesforce_client.connect(dest_conn)

        objects = list(job["cleanup_objects"])

        # Build dependency map and delete in REVERSE topo order (children first)
        descs = {}
        for obj in objects:
            try:
                _, refs, _ = _describe_fields(sf, obj)
                descs[obj] = refs
            except Exception:
                descs[obj] = {}

        obj_set = set(objects)
        dep_map = {}
        for obj in objects:
            deps = set()
            for fname, ref_objs in descs.get(obj, {}).items():
                for ro in ref_objs:
                    if ro in obj_set and ro != obj:
                        deps.add(ro)
            dep_map[obj] = deps

        delete_order = list(reversed(_topo_sort(objects, dep_map)))
        print(f"[cleanup] Delete order: {' -> '.join(delete_order)}", flush=True)

        for obj in delete_order:
            job["cleanup_progress"][obj] = {"deleted": 0, "errors": 0, "status": "deleting"}
            try:
                result = sf.query_all(f"SELECT Id FROM {obj}")
                records = result.get("records", [])
                ids = [r["Id"] for r in records]
                job["cleanup_progress"][obj]["total"] = len(ids)

                if not ids:
                    job["cleanup_progress"][obj]["status"] = "done"
                    print(f"[cleanup] {obj}: 0 records to delete", flush=True)
                    continue

                # Use Bulk API for fast deletion
                delete_records = [{"Id": rid} for rid in ids]
                try:
                    bulk_result = salesforce_client.bulk_delete(sf, obj, delete_records)
                    deleted = sum(1 for r in bulk_result if r.get("success"))
                    errors = sum(1 for r in bulk_result if not r.get("success"))
                    job["cleanup_progress"][obj]["deleted"] = deleted
                    job["cleanup_progress"][obj]["errors"] = errors
                except Exception as bulk_err:
                    print(f"[cleanup] Bulk delete failed for {obj}, falling back to single: {bulk_err}", flush=True)
                    # Fallback to single record delete
                    deleted, errors = 0, 0
                    for rid in ids:
                        try:
                            getattr(sf, obj).delete(rid)
                            deleted += 1
                        except Exception as e:
                            errors += 1
                            if errors <= 3:
                                print(f"[cleanup] Delete error {obj}: {e}", flush=True)
                        if (deleted + errors) % 10 == 0:
                            job["cleanup_progress"][obj]["deleted"] = deleted
                            job["cleanup_progress"][obj]["errors"] = errors
                    job["cleanup_progress"][obj]["deleted"] = deleted
                    job["cleanup_progress"][obj]["errors"] = errors

                job["cleanup_progress"][obj]["status"] = (
                    "done" if job["cleanup_progress"][obj]["errors"] == 0
                    else "partial" if job["cleanup_progress"][obj]["deleted"] > 0
                    else "error"
                )
                print(f"[cleanup] {obj}: {job['cleanup_progress'][obj]['deleted']} deleted, {job['cleanup_progress'][obj]['errors']} errors", flush=True)
            except Exception as e:
                job["cleanup_progress"][obj]["status"] = "error"
                job["cleanup_progress"][obj]["error"] = str(e)
                print(f"[cleanup] Error querying {obj}: {e}", flush=True)

        job["phase"] = "complete"
        job["status"] = "complete"
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()

    except Exception as e:
        traceback.print_exc()
        job.update(phase="error", status="error", error=str(e), running=False)


def get_cleanup_job(job_id):
    job = _jobs.get(job_id)
    return _safe_job(job) if job else None


def _safe_job(job):
    if not job:
        return None
    return {k: v for k, v in job.items() if not k.startswith("_")}
