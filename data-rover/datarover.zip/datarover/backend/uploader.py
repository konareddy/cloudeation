import threading
import uuid
import traceback
import datetime
import decimal
import salesforce_client
import db_client
import config
import store

_jobs = {}

BATCH_SIZE = 200  # default; overridden at runtime from config


def _get_batch_size():
    try:
        return config.get_bulk_settings().get("sfUploadBatchSize", BATCH_SIZE)
    except Exception:
        return BATCH_SIZE


def _sanitize_value(val):
    """Convert Python DB values to JSON-compatible types for Salesforce API."""
    if val is None:
        return None
    if isinstance(val, decimal.Decimal):
        # Use int if no fractional part, else float
        if val == val.to_integral_value():
            return int(val)
        return float(val)
    if isinstance(val, datetime.datetime):
        return val.isoformat()
    if isinstance(val, datetime.date):
        return val.isoformat()
    if isinstance(val, datetime.time):
        return val.isoformat()
    if isinstance(val, bytes):
        return val.decode('utf-8', errors='replace')
    if isinstance(val, (list, dict)):
        return str(val)
    return val


def start_job(sf_conn_id, db_conn_id, table_name, object_name, operation, column_mapping, external_id_field=None, source_database=None):
    job_id = str(uuid.uuid4())[:8]
    # Resolve connection names for display
    sf_name = ""
    try:
        sf_conn = config.get_salesforce(sf_conn_id)
        if sf_conn:
            sf_name = sf_conn.get("name", "")
    except Exception:
        pass
    db_name = ""
    db_database = ""
    try:
        db_conn = config.get_database(db_conn_id)
        if db_conn:
            db_name = db_conn.get("name", "")
            db_database = db_conn.get("database", "")
    except Exception:
        pass
    _jobs[job_id] = {
        "id": job_id,
        "type": "SF Upload",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "total_records": 0,
        "success_count": 0,
        "error_count": 0,
        "errors": [],
        "record_results": [],
        "object_name": object_name,
        "table_name": table_name,
        "target_name": sf_name,
        "source_name": db_name,
        "source_database": db_database,
    }
    t = threading.Thread(
        target=_run_job,
        args=(job_id, sf_conn_id, db_conn_id, table_name, object_name, operation, column_mapping, external_id_field, source_database),
        daemon=True,
    )
    t.start()
    return job_id


def get_status(job_id):
    return _jobs.get(job_id)


def cancel_job(job_id):
    job = _jobs.get(job_id)
    if not job:
        return False
    if job.get("running"):
        job["_cancel"] = True
        return True
    return False


def _do_bulk_op(sf, object_name, operation, records, external_id_field):
    """Execute a single bulk API operation."""
    if operation == "insert":
        return salesforce_client.bulk_insert(sf, object_name, records)
    elif operation == "update":
        return salesforce_client.bulk_update(sf, object_name, records)
    elif operation == "upsert":
        return salesforce_client.bulk_upsert(sf, object_name, records, external_id_field)
    elif operation == "delete":
        return salesforce_client.bulk_delete(sf, object_name, records)
    else:
        raise ValueError(f"Unknown operation: {operation}")


def _run_job(job_id, sf_conn_id, db_conn_id, table_name, object_name, operation, column_mapping, external_id_field, source_database=None):
    job = _jobs[job_id]
    try:
        sf_conn = config.get_salesforce(sf_conn_id)
        db_conn = config.get_database(db_conn_id)
        sf = salesforce_client.connect(sf_conn)
        # Override database if specified (e.g. from terminal's active database)
        if source_database:
            db_conn = {**db_conn, "database": source_database}
        pg = db_client.get_connection(db_conn)

        # Read all rows from DB table
        job["status"] = "reading"
        job["progress"] = 5
        cur = pg.cursor()
        cur.execute(f'SELECT * FROM "{table_name}"')
        db_columns = [desc[0] for desc in cur.description]
        rows = cur.fetchall()
        cur.close()
        pg.close()

        total = len(rows)
        job["total_records"] = total
        job["progress"] = 20

        if total == 0:
            job["status"] = "complete"
            job["progress"] = 100
            return

        # Apply column mapping: convert DB rows to SF records
        job["status"] = "uploading"
        all_success = 0
        all_errors = 0
        all_error_details = []
        all_record_results = []

        batch_sz = _get_batch_size()
        for batch_start in range(0, total, batch_sz):
            batch_rows = rows[batch_start : batch_start + batch_sz]
            records = []
            for row in batch_rows:
                row_dict = dict(zip(db_columns, row))
                sf_record = {}
                for db_col, sf_field in column_mapping.items():
                    if sf_field and sf_field != "__skip__":
                        val = row_dict.get(db_col)
                        sf_record[sf_field] = _sanitize_value(val)
                records.append(sf_record)

            # Call appropriate SF bulk method (with retry on expired session)
            try:
                result = _do_bulk_op(sf, object_name, operation, records, external_id_field)
            except Exception as e:
                if "InvalidSessionId" in str(e) or "INVALID_SESSION_ID" in str(e) or "Invalid session id" in str(e):
                    # Token expired — re-read config (may have been updated) and reconnect
                    job["status"] = "refreshing session"
                    sf_conn = config.get_salesforce(sf_conn_id)
                    sf = salesforce_client.connect(sf_conn)
                    result = _do_bulk_op(sf, object_name, operation, records, external_id_field)
                else:
                    raise

            # Offset row numbers and attach source data to failed records
            batch_record_results = result.get("record_results", [])
            for rr in batch_record_results:
                rr["row"] = rr["row"] + batch_start
                if not rr.get("success"):
                    # Attach the original record data for this row (0-based index within batch)
                    batch_idx = rr["row"] - batch_start - 1
                    if 0 <= batch_idx < len(records):
                        rr["data"] = records[batch_idx]

            all_success += result["success_count"]
            all_errors += result["error_count"]
            all_error_details.extend(result["errors"])
            all_record_results.extend(batch_record_results)

            # Update progress (20% to 100%)
            processed = min(batch_start + batch_sz, total)
            job["progress"] = 20 + int((processed / total) * 80)
            job["success_count"] = all_success
            job["error_count"] = all_errors
            job["errors"] = all_error_details[:50]
            job["record_results"] = all_record_results

        job["status"] = "complete"
        job["progress"] = 100

    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["errors"] = [str(e)]
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass
