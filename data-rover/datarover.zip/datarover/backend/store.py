"""SQLite-backed persistent storage for Data Rover.

Replaces config.json with a proper database while keeping Fernet encryption
for sensitive connection fields.

Database location: ~/sfdc-loader/datarover.db  (or data/datarover.db for bundled builds)
Encryption key:   ~/sfdc-loader/.key           (unchanged from before)
"""

import datetime
import json
import os
import sqlite3
import threading

from cryptography.fernet import Fernet

# ---------------------------------------------------------------------------
# Paths  (mirror the logic from the old config.py)
# ---------------------------------------------------------------------------
_APP_DIR = os.path.dirname(os.path.abspath(__file__))
_LOCAL_DATA = os.path.join(_APP_DIR, "data")
_HOME_DATA = os.path.expanduser("~/sfdc-loader")

DATA_DIR = _LOCAL_DATA if os.path.isdir(_LOCAL_DATA) else _HOME_DATA
DB_PATH = os.path.join(DATA_DIR, "datarover.db")
KEY_PATH = os.path.join(DATA_DIR, ".key")

# ---------------------------------------------------------------------------
# Encryption  (identical scheme to the original config.py)
# ---------------------------------------------------------------------------
SENSITIVE_FIELDS = {
    "password", "securityToken", "accessToken", "refreshToken",
    "clientSecret", "accessKey", "secretKey", "apiKey",
}
_ENC_PREFIX = "enc:"

_fernet = None  # lazy


def _get_fernet():
    global _fernet
    if _fernet is not None:
        return _fernet
    if os.path.exists(KEY_PATH):
        with open(KEY_PATH, "rb") as f:
            key = f.read()
    else:
        os.makedirs(os.path.dirname(KEY_PATH), exist_ok=True)
        key = Fernet.generate_key()
        with open(KEY_PATH, "wb") as f:
            f.write(key)
    _fernet = Fernet(key)
    return _fernet


def encrypt_sensitive(data):
    """Encrypt sensitive fields in a dict before storing."""
    fernet = _get_fernet()
    data = dict(data)
    for field in SENSITIVE_FIELDS:
        val = data.get(field)
        if val and isinstance(val, str) and not val.startswith(_ENC_PREFIX):
            data[field] = _ENC_PREFIX + fernet.encrypt(val.encode()).decode()
    return data


def decrypt_sensitive(data):
    """Decrypt sensitive fields in a dict after loading."""
    fernet = _get_fernet()
    data = dict(data)
    for field in SENSITIVE_FIELDS:
        val = data.get(field)
        if val and isinstance(val, str) and val.startswith(_ENC_PREFIX):
            data[field] = fernet.decrypt(val[len(_ENC_PREFIX):].encode()).decode()
    return data


# ---------------------------------------------------------------------------
# Thread-local SQLite connections
# ---------------------------------------------------------------------------
_local = threading.local()


def _get_db():
    db = getattr(_local, "db", None)
    if db is None:
        os.makedirs(DATA_DIR, exist_ok=True)
        db = sqlite3.connect(DB_PATH, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        _local.db = db
    return db


def init():
    """Initialize the database schema and migrate from config.json if needed."""
    db = _get_db()
    db.executescript("""
        CREATE TABLE IF NOT EXISTS connections (
            id TEXT PRIMARY KEY,
            conn_type TEXT NOT NULL,
            data TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS pipelines (
            id TEXT PRIMARY KEY,
            data TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS saved_steps (
            id TEXT PRIMARY KEY,
            data TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS column_mappings (
            key TEXT PRIMARY KEY,
            data TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            job_type TEXT NOT NULL,
            started_at TEXT NOT NULL,
            finished_at TEXT,
            status TEXT NOT NULL DEFAULT 'running',
            data TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_jobs_started ON jobs(started_at);
        CREATE TABLE IF NOT EXISTS seed_templates (
            id TEXT PRIMARY KEY,
            data TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS compare_templates (
            id TEXT PRIMARY KEY,
            data TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS compare_history (
            id TEXT PRIMARY KEY,
            ran_at TEXT NOT NULL,
            data TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_compare_history_ran ON compare_history(ran_at);
    """)
    db.commit()
    _migrate_from_json()


# ---------------------------------------------------------------------------
# Migration from config.json
# ---------------------------------------------------------------------------

def _migrate_from_json():
    """One-time migration: import config.json data into SQLite."""
    json_paths = [
        os.path.join(_APP_DIR, "data", "config.json"),
        os.path.expanduser("~/sfdc-loader/config.json"),
    ]
    json_path = None
    for p in json_paths:
        if os.path.exists(p):
            json_path = p
            break
    if not json_path:
        return

    # Only migrate if DB is empty
    db = _get_db()
    count = db.execute("SELECT COUNT(*) FROM connections").fetchone()[0]
    settings_count = db.execute("SELECT COUNT(*) FROM settings").fetchone()[0]
    if count > 0 or settings_count > 0:
        return

    try:
        with open(json_path, "r") as f:
            data = json.load(f)
    except Exception:
        return

    print(f"[store] Migrating data from {json_path} to SQLite...")

    # Connections (already encrypted in JSON -- store as-is)
    for conn in data.get("salesforce_connections", []):
        db.execute(
            "INSERT OR IGNORE INTO connections (id, conn_type, data) VALUES (?, ?, ?)",
            (conn["id"], "salesforce", json.dumps(conn)),
        )
    for conn in data.get("database_connections", []):
        db.execute(
            "INSERT OR IGNORE INTO connections (id, conn_type, data) VALUES (?, ?, ?)",
            (conn["id"], "database", json.dumps(conn)),
        )

    # Settings
    for key in ("ai_settings", "bulk_settings"):
        if key in data:
            db.execute(
                "INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)",
                (key, json.dumps(data[key])),
            )

    # Column mappings
    for k, v in data.get("column_mappings", {}).items():
        db.execute(
            "INSERT OR IGNORE INTO column_mappings (key, data) VALUES (?, ?)",
            (k, json.dumps(v)),
        )

    # Pipelines
    for p in data.get("pipelines", []):
        db.execute(
            "INSERT OR IGNORE INTO pipelines (id, data) VALUES (?, ?)",
            (p["id"], json.dumps(p)),
        )

    # Saved steps
    for s in data.get("savedSteps", []):
        db.execute(
            "INSERT OR IGNORE INTO saved_steps (id, data) VALUES (?, ?)",
            (s["id"], json.dumps(s)),
        )

    db.commit()

    # Rename old config.json to signal migration complete
    backup = json_path + ".bak"
    if not os.path.exists(backup):
        try:
            os.rename(json_path, backup)
            print(f"[store] Migration complete. Old config backed up to {backup}")
        except OSError:
            print(f"[store] Migration complete. Could not rename {json_path}")


# ---------------------------------------------------------------------------
# Connections
# ---------------------------------------------------------------------------

def get_all_connections():
    """Return {"salesforce_connections": [...], "database_connections": [...]}."""
    db = _get_db()
    sf = []
    dbconns = []
    for row in db.execute("SELECT conn_type, data FROM connections"):
        conn = decrypt_sensitive(json.loads(row["data"]))
        if row["conn_type"] == "salesforce":
            sf.append(conn)
        else:
            dbconns.append(conn)
    return {"salesforce_connections": sf, "database_connections": dbconns}


def get_salesforce(conn_id):
    db = _get_db()
    row = db.execute(
        "SELECT data FROM connections WHERE id = ? AND conn_type = 'salesforce'",
        (conn_id,),
    ).fetchone()
    return decrypt_sensitive(json.loads(row["data"])) if row else None


def get_database(conn_id):
    db = _get_db()
    row = db.execute(
        "SELECT data FROM connections WHERE id = ? AND conn_type = 'database'",
        (conn_id,),
    ).fetchone()
    return decrypt_sensitive(json.loads(row["data"])) if row else None


def upsert_connection(conn_type, conn):
    db = _get_db()
    encrypted = encrypt_sensitive(conn)
    db.execute(
        "INSERT OR REPLACE INTO connections (id, conn_type, data) VALUES (?, ?, ?)",
        (conn["id"], conn_type, json.dumps(encrypted)),
    )
    db.commit()
    return conn


def delete_connection(conn_type, conn_id):
    db = _get_db()
    db.execute(
        "DELETE FROM connections WHERE id = ? AND conn_type = ?",
        (conn_id, conn_type),
    )
    db.commit()


# ---------------------------------------------------------------------------
# Settings  (key-value)
# ---------------------------------------------------------------------------

def get_setting(key, default=None):
    db = _get_db()
    row = db.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    if not row:
        return default if default is not None else {}
    return json.loads(row["value"])


def save_setting(key, value):
    db = _get_db()
    db.execute(
        "INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)",
        (key, json.dumps(value)),
    )
    db.commit()


# ---------------------------------------------------------------------------
# Column Mappings
# ---------------------------------------------------------------------------

def get_mappings():
    db = _get_db()
    result = {}
    for row in db.execute("SELECT key, data FROM column_mappings"):
        result[row["key"]] = json.loads(row["data"])
    return result


def get_mapping(key):
    db = _get_db()
    row = db.execute(
        "SELECT data FROM column_mappings WHERE key = ?", (key,)
    ).fetchone()
    return json.loads(row["data"]) if row else None


def save_mapping(key, mapping):
    db = _get_db()
    db.execute(
        "INSERT OR REPLACE INTO column_mappings (key, data) VALUES (?, ?)",
        (key, json.dumps(mapping)),
    )
    db.commit()


def delete_mapping(key):
    db = _get_db()
    db.execute("DELETE FROM column_mappings WHERE key = ?", (key,))
    db.commit()


# ---------------------------------------------------------------------------
# Pipelines
# ---------------------------------------------------------------------------

def get_pipelines():
    db = _get_db()
    return [json.loads(row["data"]) for row in db.execute("SELECT data FROM pipelines")]


def get_pipeline(pipeline_id):
    db = _get_db()
    row = db.execute(
        "SELECT data FROM pipelines WHERE id = ?", (pipeline_id,)
    ).fetchone()
    return json.loads(row["data"]) if row else None


def upsert_pipeline(pipeline):
    db = _get_db()
    db.execute(
        "INSERT OR REPLACE INTO pipelines (id, data) VALUES (?, ?)",
        (pipeline["id"], json.dumps(pipeline)),
    )
    db.commit()
    return pipeline


def delete_pipeline(pipeline_id):
    db = _get_db()
    db.execute("DELETE FROM pipelines WHERE id = ?", (pipeline_id,))
    db.commit()



# ---------------------------------------------------------------------------
# Saved Steps
# ---------------------------------------------------------------------------

def get_saved_steps():
    db = _get_db()
    return [
        json.loads(row["data"])
        for row in db.execute("SELECT data FROM saved_steps")
    ]


def upsert_saved_step(step):
    db = _get_db()
    db.execute(
        "INSERT OR REPLACE INTO saved_steps (id, data) VALUES (?, ?)",
        (step["id"], json.dumps(step)),
    )
    db.commit()
    return step


def delete_saved_step(step_id):
    db = _get_db()
    db.execute("DELETE FROM saved_steps WHERE id = ?", (step_id,))
    db.commit()


# ---------------------------------------------------------------------------
# Jobs  (persistent history)
# ---------------------------------------------------------------------------

# Fields to strip from job data before persisting (large/transient)
_JOB_STRIP_FIELDS = {"record_results", "file_results", "_cancel"}


def save_job(job):
    """Persist a job snapshot to the database."""
    db = _get_db()
    job_id = job.get("id") or job.get("runId", "")
    job_type = job.get("type", job.get("jobType", "unknown"))
    started_at = job.get("started_at", job.get("startedAt", datetime.datetime.now().isoformat()))
    finished_at = job.get("finished_at", job.get("finishedAt"))
    status = job.get("status", "unknown")
    if job.get("running"):
        status = "running"

    # Store a slim copy without large arrays
    slim = {k: v for k, v in job.items() if k not in _JOB_STRIP_FIELDS}
    db.execute(
        """INSERT OR REPLACE INTO jobs (id, job_type, started_at, finished_at, status, data)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (job_id, job_type, started_at, finished_at, status, json.dumps(slim, default=str)),
    )
    db.commit()


def get_jobs(limit=500):
    """Return recent jobs from the database, newest first."""
    db = _get_db()
    rows = db.execute(
        "SELECT data FROM jobs ORDER BY started_at DESC LIMIT ?", (limit,)
    ).fetchall()
    return [json.loads(row["data"]) for row in rows]


def get_job(job_id):
    db = _get_db()
    row = db.execute("SELECT data FROM jobs WHERE id = ?", (job_id,)).fetchone()
    return json.loads(row["data"]) if row else None


def delete_old_jobs(keep_days=90):
    """Prune jobs older than keep_days."""
    db = _get_db()
    cutoff = (datetime.datetime.now() - datetime.timedelta(days=keep_days)).isoformat()
    db.execute("DELETE FROM jobs WHERE started_at < ?", (cutoff,))
    db.commit()


# ---------------------------------------------------------------------------
# Seed Templates
# ---------------------------------------------------------------------------

def get_seed_templates():
    db = _get_db()
    return [json.loads(row["data"]) for row in db.execute("SELECT data FROM seed_templates")]


def upsert_seed_template(template):
    db = _get_db()
    db.execute(
        "INSERT OR REPLACE INTO seed_templates (id, data) VALUES (?, ?)",
        (template["id"], json.dumps(template)),
    )
    db.commit()
    return template


def delete_seed_template(template_id):
    db = _get_db()
    db.execute("DELETE FROM seed_templates WHERE id = ?", (template_id,))
    db.commit()


# ---------------------------------------------------------------------------
# Compare Templates
# ---------------------------------------------------------------------------

def get_compare_templates():
    db = _get_db()
    return [json.loads(row["data"]) for row in db.execute("SELECT data FROM compare_templates")]


def upsert_compare_template(template):
    db = _get_db()
    db.execute(
        "INSERT OR REPLACE INTO compare_templates (id, data) VALUES (?, ?)",
        (template["id"], json.dumps(template)),
    )
    db.commit()
    return template


def delete_compare_template(template_id):
    db = _get_db()
    db.execute("DELETE FROM compare_templates WHERE id = ?", (template_id,))
    db.commit()


# ---------------------------------------------------------------------------
# Compare History
# ---------------------------------------------------------------------------

def save_compare_history(entry):
    db = _get_db()
    db.execute(
        "INSERT OR REPLACE INTO compare_history (id, ran_at, data) VALUES (?, ?, ?)",
        (entry["id"], entry["ranAt"], json.dumps(entry)),
    )
    db.commit()
    return entry


def get_compare_history(limit=100):
    db = _get_db()
    rows = db.execute(
        "SELECT data FROM compare_history ORDER BY ran_at DESC LIMIT ?", (limit,)
    ).fetchall()
    return [json.loads(row["data"]) for row in rows]


def delete_compare_history(entry_id):
    db = _get_db()
    db.execute("DELETE FROM compare_history WHERE id = ?", (entry_id,))
    db.commit()


def clear_compare_history():
    db = _get_db()
    db.execute("DELETE FROM compare_history")
    db.commit()


# ---------------------------------------------------------------------------
# Seed Mapping Tables  (source_id <-> destination_id per object)
# ---------------------------------------------------------------------------

def _sanitize_table_name(name):
    """Remove non-alphanumeric chars (except underscore) for safe table names."""
    import re
    return re.sub(r'[^a-zA-Z0-9_]', '_', name)


def ensure_seed_mapping_table(source_name, dest_name):
    """Create the mapping table if it doesn't exist. Returns table name."""
    table = _sanitize_table_name(f"{source_name}_to_{dest_name}")
    db = _get_db()
    db.execute(f"""
        CREATE TABLE IF NOT EXISTS "{table}" (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_id TEXT NOT NULL,
            destination_id TEXT,
            object_name TEXT NOT NULL,
            created_at TEXT DEFAULT (datetime('now'))
        )
    """)
    db.execute(f"""
        CREATE INDEX IF NOT EXISTS "idx_{table}_obj"
        ON "{table}" (object_name)
    """)
    db.execute(f"""
        CREATE UNIQUE INDEX IF NOT EXISTS "idx_{table}_src_obj"
        ON "{table}" (source_id, object_name)
    """)
    db.commit()
    return table


def get_seed_mappings(table, object_name=None, limit=500):
    """Return mappings from a seed mapping table."""
    db = _get_db()
    if object_name:
        rows = db.execute(
            f'SELECT source_id, destination_id, object_name, created_at FROM "{table}" WHERE object_name = ? ORDER BY id DESC LIMIT ?',
            (object_name, limit),
        ).fetchall()
    else:
        rows = db.execute(
            f'SELECT source_id, destination_id, object_name, created_at FROM "{table}" ORDER BY id DESC LIMIT ?',
            (limit,),
        ).fetchall()
    return [dict(r) for r in rows]


def upsert_seed_mapping(table, source_id, destination_id, object_name):
    """Insert or update a mapping row."""
    db = _get_db()
    db.execute(
        f'INSERT OR REPLACE INTO "{table}" (source_id, destination_id, object_name) VALUES (?, ?, ?)',
        (source_id, destination_id, object_name),
    )
    db.commit()


