"""Configuration layer — delegates all persistence to store.py (SQLite).

Public API is unchanged so existing callers (app.py, downloader.py, etc.)
continue to work without modification.
"""

import os
import store

# Re-export for any code that references config.SENSITIVE_FIELDS
SENSITIVE_FIELDS = store.SENSITIVE_FIELDS

# Legacy reference kept for anything that checks the path
CONFIG_PATH = os.path.join(store.DATA_DIR, "config.json")

DEFAULT = {"salesforce_connections": [], "database_connections": [], "pipelines": []}

BULK_DEFAULTS = {
    "sfUploadBatchSize": 200,
    "dbInsertBatchSize": 500,
    "bulkApiThreshold": 250,
    "requestTimeout": 300,
    "errorDisplayLimit": 200,
    "parallelWorkers": 2,
}


def _ensure_default_duckdb(data):
    """Auto-create a default Local DuckDB connection if none exists."""
    db_conns = data.get("database_connections", [])
    has_duckdb = any(c.get("dbType") == "duckdb" for c in db_conns)
    if not has_duckdb:
        duckdb_dir = os.path.expanduser("~/sfdc-loader/duckdb")
        os.makedirs(duckdb_dir, exist_ok=True)
        default_conn = {
            "id": "local-duckdb",
            "name": "Local DuckDB",
            "dbType": "duckdb",
            "filepath": "~/sfdc-loader/duckdb",
            "database": "default",
            "usage": ["extract", "transform", "source", "target"],
        }
        store.upsert_connection("database", default_conn)
        db_conns.append(default_conn)
        data["database_connections"] = db_conns
    return data


def get_all():
    data = store.get_all_connections()
    data = _ensure_default_duckdb(data)
    data["pipelines"] = store.get_pipelines()
    return data


def upsert_salesforce(conn):
    return store.upsert_connection("salesforce", conn)


def upsert_database(conn):
    return store.upsert_connection("database", conn)


def delete_connection(conn_type, conn_id):
    store.delete_connection(conn_type, conn_id)


def get_salesforce(conn_id):
    return store.get_salesforce(conn_id)


def get_database(conn_id):
    return store.get_database(conn_id)


def get_mappings():
    return store.get_mappings()


def get_mapping(key):
    return store.get_mapping(key)


def save_mapping(key, mapping):
    store.save_mapping(key, mapping)


def delete_mapping(key):
    store.delete_mapping(key)


def get_ai_settings():
    return store.get_setting("ai_settings", {})


def save_ai_settings(settings):
    existing = store.get_setting("ai_settings", {})
    existing.update(settings)
    store.save_setting("ai_settings", existing)


def get_bulk_settings():
    saved = store.get_setting("bulk_settings", {})
    return {**BULK_DEFAULTS, **saved}


def save_bulk_settings(settings):
    store.save_setting("bulk_settings", settings)


# ---------------------------------------------------------------------------
# Pipeline helpers
# ---------------------------------------------------------------------------

def get_pipelines():
    return store.get_pipelines()


def get_pipeline(pipeline_id):
    return store.get_pipeline(pipeline_id)


def upsert_pipeline(pipeline):
    return store.upsert_pipeline(pipeline)


def delete_pipeline(pipeline_id):
    store.delete_pipeline(pipeline_id)


# ---------------------------------------------------------------------------
# Legacy internal methods used by orchestrator.py
# ---------------------------------------------------------------------------

def _read():
    """Legacy: return a dict resembling the old config.json structure."""
    data = store.get_all_connections()
    data["pipelines"] = store.get_pipelines()
    data["column_mappings"] = store.get_mappings()
    data["ai_settings"] = store.get_setting("ai_settings", {})
    data["bulk_settings"] = store.get_setting("bulk_settings", {})
    data["savedSteps"] = store.get_saved_steps()
    data["workflows"] = store.get_workflows()
    return data


def _write(data):
    """Legacy: write a full config dict back."""
    for conn in data.get("salesforce_connections", []):
        store.upsert_connection("salesforce", conn)
    for conn in data.get("database_connections", []):
        store.upsert_connection("database", conn)
    if "ai_settings" in data:
        store.save_setting("ai_settings", data["ai_settings"])
    if "bulk_settings" in data:
        store.save_setting("bulk_settings", data["bulk_settings"])
    if "column_mappings" in data:
        for k, v in data["column_mappings"].items():
            store.save_mapping(k, v)
    for p in data.get("pipelines", []):
        store.upsert_pipeline(p)
    if "savedSteps" in data:
        for s in data["savedSteps"]:
            store.upsert_saved_step(s)
    if "workflows" in data:
        for w in data["workflows"]:
            store.upsert_workflow(w)
