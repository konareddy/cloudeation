import csv
import io
import time
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
from simple_salesforce import Salesforce, SalesforceAuthenticationFailed
import config


def connect(conn, force_refresh=False):
    """Connect with priority: stored token → refresh token → legacy password/SOAP."""
    # 1. If we have a stored access token, try it first (skip if force_refresh)
    if not force_refresh and conn.get("accessToken") and conn.get("instanceUrl"):
        try:
            return _connect_with_token(conn)
        except Exception:
            pass

    # 2. If we have a refresh token, try refreshing
    if conn.get("refreshToken") and conn.get("clientId"):
        try:
            return _refresh_and_connect(conn)
        except Exception:
            pass

    # 3. Legacy: OAuth2 password flow
    client_id = conn.get("clientId", "")
    client_secret = conn.get("clientSecret", "")
    if client_id and client_secret and conn.get("username") and conn.get("password"):
        return _connect_oauth(conn)

    # 4. Legacy: SOAP login
    if conn.get("username") and conn.get("password"):
        try:
            return Salesforce(
                username=conn["username"],
                password=conn["password"],
                security_token=conn.get("securityToken", ""),
                domain="test" if "test.salesforce.com" in conn.get("loginUrl", "") else "login",
            )
        except Exception as e:
            print(f"[SOAP login] exception type={type(e).__name__}, message={e}")
            raise Exception(f"Login failed: {e}")

    raise Exception(
        "Session expired and could not be refreshed. "
        "Please re-authenticate: edit your Salesforce connection and click 'Login with Salesforce' again."
    )


def _connect_with_token(conn):
    """Use stored accessToken + instanceUrl to connect."""
    sf = Salesforce(
        instance_url=conn["instanceUrl"],
        session_id=conn["accessToken"],
    )
    # Verify the token is still valid
    sf.restful("limits")
    return sf


def _refresh_and_connect(conn):
    """Refresh an expired access token using the refresh token."""
    login_url = conn.get("loginUrl", "https://login.salesforce.com")
    token_url = f"{login_url}/services/oauth2/token"
    payload = {
        "grant_type": "refresh_token",
        "client_id": conn["clientId"],
        "refresh_token": conn["refreshToken"],
    }
    if conn.get("clientSecret"):
        payload["client_secret"] = conn["clientSecret"]
    resp = requests.post(token_url, data=payload)
    if resp.status_code != 200:
        raise Exception("Token refresh failed")
    body = resp.json()

    # Update stored tokens in config
    conn["accessToken"] = body["access_token"]
    conn["instanceUrl"] = body["instance_url"]
    config.upsert_salesforce(conn)

    return Salesforce(
        instance_url=body["instance_url"],
        session_id=body["access_token"],
    )


def exchange_code_for_tokens(code, client_id, client_secret, login_url, redirect_uri, code_verifier=""):
    """Exchange an authorization code for access_token + refresh_token."""
    token_url = f"{login_url}/services/oauth2/token"
    payload = {
        "grant_type": "authorization_code",
        "code": code,
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": redirect_uri,
    }
    if code_verifier:
        payload["code_verifier"] = code_verifier
    resp = requests.post(token_url, data=payload)
    if resp.status_code != 200:
        body = resp.json()
        raise Exception(body.get("error_description", body.get("error", "Token exchange failed")))
    return resp.json()


def _connect_oauth(conn):
    login_url = conn.get("loginUrl", "https://login.salesforce.com")
    token_url = f"{login_url}/services/oauth2/token"
    payload = {
        "grant_type": "password",
        "client_id": conn["clientId"],
        "client_secret": conn["clientSecret"],
        "username": conn["username"],
        "password": conn["password"] + conn.get("securityToken", ""),
    }
    resp = requests.post(token_url, data=payload)
    if resp.status_code != 200:
        body = resp.json()
        raise SalesforceAuthenticationFailed(
            resp.status_code,
            body.get("error_description", body.get("error", "Unknown error")),
        )
    body = resp.json()
    return Salesforce(
        instance_url=body["instance_url"],
        session_id=body["access_token"],
    )


def test_connection(conn):
    try:
        sf = connect(conn)
        sf.restful("limits")
        return {"success": True, "message": "Connected successfully"}
    except SalesforceAuthenticationFailed as e:
        return {"success": False, "message": f"Authentication failed: {e}"}
    except Exception as e:
        return {"success": False, "message": str(e)}


def list_objects(sf):
    result = sf.describe()
    objects = []
    for obj in result["sobjects"]:
        if not obj["queryable"]:
            continue
        api_name = obj["name"]
        label = obj["label"]
        try:
            count_result = sf.query(f"SELECT COUNT() FROM {api_name}")
            count = count_result["totalSize"]
        except Exception:
            count = 0
        objects.append({
            "name": label,
            "apiName": api_name,
            "recordCount": count,
        })
    objects.sort(key=lambda o: o["name"])
    return objects


def list_objects_fast(sf):
    """Fast version — skips COUNT queries, returns all queryable objects quickly."""
    result = sf.describe()
    objects = []
    for obj in result["sobjects"]:
        if not obj["queryable"]:
            continue
        objects.append({
            "name": obj["label"],
            "apiName": obj["name"],
            "recordCount": 0,
        })
    objects.sort(key=lambda o: o["name"])
    return objects


# Compound field types that Bulk API cannot query
_COMPOUND_TYPES = {"address", "location"}


def _get_bulk_threshold():
    try:
        return config.get_bulk_settings().get("bulkApiThreshold", 250)
    except Exception:
        return 250


def _get_error_limit():
    try:
        return config.get_bulk_settings().get("errorDisplayLimit", 200)
    except Exception:
        return 200


def _filter_fields_for_bulk(fields):
    """Remove compound fields that Bulk API cannot handle."""
    # Also detect compound-by-name: fields whose compoundFieldName is set
    # and are themselves compound (type address/location)
    return [f for f in fields if f["type"].lower() not in _COMPOUND_TYPES]


_BULK_STREAM_CHUNK_SIZE = 10000

# PK Chunking thresholds
_PK_CHUNK_THRESHOLD = 10000  # use PK chunking for > 10K records
_PK_CHUNK_DOWNLOAD_WORKERS = 10  # parallel batch result downloads


def _get_pk_chunk_size():
    """Get configured PK chunk size (default 50000 to match DBAmp)."""
    try:
        return config.get_bulk_settings().get("pkChunkSize", 50000)
    except Exception:
        return 50000


def prepare_extract(sf, object_name):
    """Describe + count only — no data fetched. Returns (field_meta, total, use_bulk)."""
    desc = getattr(sf, object_name).describe()
    fields = desc["fields"]

    count_result = sf.query(f"SELECT COUNT() FROM {object_name}")
    total = count_result["totalSize"]

    use_bulk = total > _get_bulk_threshold()
    if use_bulk:
        field_meta = _filter_fields_for_bulk(fields)
    else:
        field_meta = fields

    return field_meta, total, use_bulk


def stream_records(sf, object_name, field_meta, use_bulk, batch_callback, progress_callback=None, pk_chunk_size=None, where_clause=None):
    """Stream records from SF, calling batch_callback(records_list) per page/chunk.
    Returns total_fetched count. pk_chunk_size overrides the global setting if provided."""
    field_names = [f["name"] for f in field_meta]
    soql = f"SELECT {', '.join(field_names)} FROM {object_name}"
    if where_clause:
        soql += f" WHERE {where_clause}"

    if use_bulk:
        # Try PK Chunking first for large datasets (PK Chunking does NOT support WHERE clauses)
        if not where_clause:
            try:
                count_result = sf.query(f"SELECT COUNT() FROM {object_name}")
                total = count_result.get("totalSize", 0)
            except Exception:
                total = 0

            if total > _PK_CHUNK_THRESHOLD:
                try:
                    chunk_size = pk_chunk_size or _get_pk_chunk_size()
                    if progress_callback:
                        progress_callback("bulk_started", f"Querying via Bulk API with PK Chunking ({chunk_size:,} per chunk)...", 0)
                    return _stream_pk_chunked(sf, object_name, soql, batch_callback, progress_callback, pk_chunk_size=chunk_size)
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    print(f"PK Chunking failed for {object_name}: {e}, falling back to standard Bulk API")
                    if progress_callback:
                        progress_callback("bulk_started", "PK Chunking failed, trying standard Bulk API...", 0)

        # Standard bulk (no PK chunking) for smaller datasets
        try:
            if progress_callback:
                progress_callback("bulk_started", "Querying via Bulk API (this may take a few minutes)...", 0)
            results_iter = sf.bulk.__getattr__(object_name).query(soql)
            return _stream_bulk_iter(results_iter, batch_callback, progress_callback)
        except Exception as e:
            print(f"Bulk API failed for {object_name}: {e}, falling back to REST streaming")
            if progress_callback:
                progress_callback("bulk_started", "Bulk API failed, using standard API...", 0)

    return _stream_rest(sf, soql, batch_callback, progress_callback)


# ---------------------------------------------------------------------------
# PK Chunking via Bulk API 1.0 REST
# ---------------------------------------------------------------------------

def _bulk_headers(sf):
    return {
        "X-SFDC-Session": sf.session_id,
        "Content-Type": "application/json",
        "Accept": "application/json",
    }


def _bulk_url(sf, path=""):
    return f"{sf.base_url.replace('/data/', '/async/')}{path}"


def _parse_xml_batch_list(xml_text):
    """Parse Bulk API XML batchInfoList into a list of dicts."""
    import xml.etree.ElementTree as ET
    ns = "{http://www.force.com/2009/06/asyncapi/dataload}"
    root = ET.fromstring(xml_text)
    batches = []
    for bi in root.findall(f"{ns}batchInfo"):
        batch = {}
        for child in bi:
            tag = child.tag.replace(ns, "")
            batch[tag] = child.text
        batches.append(batch)
    return batches


def _parse_xml_job(xml_text):
    """Parse Bulk API XML jobInfo into a dict."""
    import xml.etree.ElementTree as ET
    ns = "{http://www.force.com/2009/06/asyncapi/dataload}"
    root = ET.fromstring(xml_text)
    result = {}
    for child in root:
        tag = child.tag.replace(ns, "")
        result[tag] = child.text
    return result


def _parse_xml_result_list(xml_text):
    """Parse Bulk API XML result-list into a list of result IDs."""
    import xml.etree.ElementTree as ET
    ns = "{http://www.force.com/2009/06/asyncapi/dataload}"
    root = ET.fromstring(xml_text)
    return [child.text for child in root.findall(f"{ns}result")]


def _stream_pk_chunked(sf, object_name, soql, batch_callback, progress_callback=None, pk_chunk_size=None):
    """Use Salesforce Bulk API 1.0 with PK Chunking for maximum throughput.

    All Bulk 1.0 responses are XML when contentType=CSV, so we parse XML throughout.
    """
    base = sf.bulk_url  # e.g. https://instance.salesforce.com/services/async/XX.0/
    auth_header = {"X-SFDC-Session": sf.session_id}
    chunk_size = pk_chunk_size or _get_pk_chunk_size()

    # 1. Create the bulk job with PK Chunking header (use JSON for create)
    create_headers = {
        **auth_header,
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Sforce-Enable-PKChunking": f"chunkSize={chunk_size}",
    }
    job_payload = {
        "operation": "query",
        "object": object_name,
        "contentType": "CSV",
        "concurrencyMode": "Parallel",
    }
    resp = requests.post(f"{base}job", json=job_payload, headers=create_headers)
    resp.raise_for_status()
    job_info = resp.json()
    job_id = job_info["id"]
    print(f"[PK Chunking] Created job {job_id} for {object_name} (chunkSize={chunk_size})")

    try:
        # 2. Add the SOQL query as a batch
        batch_headers = {**auth_header, "Content-Type": "text/csv; charset=UTF-8"}
        resp = requests.post(
            f"{base}job/{job_id}/batch",
            data=soql.encode("utf-8"),
            headers=batch_headers,
        )
        resp.raise_for_status()

        # 3. Poll until all batches complete
        if progress_callback:
            progress_callback("bulk_started", "PK Chunking: waiting for Salesforce to split into batches...", 0)

        completed_batches = []
        poll_interval = 3
        max_polls = 720  # up to 1 hour
        for poll_num in range(max_polls):
            time.sleep(poll_interval)
            resp = requests.get(f"{base}job/{job_id}/batch", headers=auth_header)
            resp.raise_for_status()
            batch_list = _parse_xml_batch_list(resp.text)

            # The original batch will be NotProcessed (it's the PK chunk trigger)
            data_batches = [b for b in batch_list if b.get("state") != "NotProcessed"]
            total_batches = len(data_batches)
            done_batches = [b for b in data_batches if b.get("state") == "Completed"]
            failed_batches = [b for b in data_batches if b.get("state") == "Failed"]

            if progress_callback:
                msg = f"PK Chunking: {len(done_batches)}/{total_batches} batches complete"
                if failed_batches:
                    msg += f", {len(failed_batches)} failed"
                progress_callback("bulk_started", msg, 0)

            if poll_num == 0:
                print(f"[PK Chunking] {object_name}: {len(batch_list)} batches created ({total_batches} data batches)")

            # Check if all data batches are done
            all_done = total_batches > 0 and all(
                b.get("state") in ("Completed", "Failed") for b in data_batches
            )
            if all_done:
                completed_batches = done_batches
                break

            # Ramp up poll interval
            if poll_interval < 10:
                poll_interval = min(poll_interval + 1, 10)

        if not completed_batches:
            raise Exception("PK Chunking: no batches completed within timeout")

        print(f"[PK Chunking] {object_name}: all batches done — {len(completed_batches)} completed, {len(failed_batches)} failed")

        # 4. Download results from all completed batches in parallel
        #    Use a queue to pipeline: download threads → insert thread (overlap I/O with DB writes)
        import queue
        import threading

        total_fetched = 0
        insert_error = [None]
        if progress_callback:
            progress_callback("downloading", f"Downloading results from {len(completed_batches)} batches...", 0)

        insert_queue = queue.Queue(maxsize=4)  # back-pressure: max 4 chunks queued

        def _insert_worker():
            """Drain the queue and feed chunks to batch_callback (DB insert)."""
            nonlocal total_fetched
            while True:
                item = insert_queue.get()
                if item is None:
                    break
                try:
                    batch_callback(item)
                    total_fetched += len(item)
                except Exception as e:
                    insert_error[0] = e
                    break

        inserter = threading.Thread(target=_insert_worker, daemon=True)
        inserter.start()

        def _download_with_retry(url, retries=3, timeout=300):
            """Download with retry and timeout."""
            for attempt in range(retries):
                try:
                    r = requests.get(url, headers=auth_header, stream=True, timeout=timeout)
                    r.raise_for_status()
                    return r
                except (requests.exceptions.ReadTimeout, requests.exceptions.ConnectionError) as e:
                    if attempt == retries - 1:
                        raise
                    print(f"[PK Chunking] Download retry {attempt + 1}/{retries}: {e}")
                    time.sleep(2 * (attempt + 1))

        def _download_batch_result(batch_info):
            """Download all result sets for a single batch, streaming CSV rows."""
            bid = batch_info["id"]
            r = requests.get(f"{base}job/{job_id}/batch/{bid}/result", headers=auth_header, timeout=120)
            r.raise_for_status()
            result_ids = _parse_xml_result_list(r.text)

            batch_count = 0
            for rid in result_ids:
                dr = _download_with_retry(f"{base}job/{job_id}/batch/{bid}/result/{rid}")
                # Stream CSV line-by-line to avoid loading entire response into memory
                chunk = []
                reader = csv.DictReader(dr.iter_lines(decode_unicode=True))
                for row in reader:
                    cleaned = {}
                    for k, v in row.items():
                        if v == "" or v == "#N/A":
                            cleaned[k] = None
                        else:
                            cleaned[k] = v
                    chunk.append(cleaned)
                    if len(chunk) >= _BULK_STREAM_CHUNK_SIZE:
                        insert_queue.put(chunk)
                        batch_count += len(chunk)
                        chunk = []
                        if insert_error[0]:
                            return batch_count
                if chunk:
                    insert_queue.put(chunk)
                    batch_count += len(chunk)
            return batch_count

        batches_done = 0
        workers = min(_PK_CHUNK_DOWNLOAD_WORKERS, len(completed_batches))
        with ThreadPoolExecutor(max_workers=workers) as pool:
            futures = {
                pool.submit(_download_batch_result, b): b for b in completed_batches
            }
            for future in as_completed(futures):
                future.result()  # propagate exceptions
                batches_done += 1
                if progress_callback:
                    progress_callback(
                        "downloading",
                        f"Downloaded {total_fetched:,} records ({batches_done}/{len(completed_batches)} batches)",
                        total_fetched,
                    )
                if insert_error[0]:
                    raise insert_error[0]

        # Signal insert worker to finish and wait
        insert_queue.put(None)
        inserter.join()
        if insert_error[0]:
            raise insert_error[0]

        return total_fetched

    finally:
        # 5. Close the bulk job
        try:
            requests.post(
                f"{base}job/{job_id}",
                json={"state": "Closed"},
                headers={**auth_header, "Content-Type": "application/json"},
            )
        except Exception:
            pass


def _stream_rest(sf, soql, batch_callback, progress_callback=None):
    """Stream via REST API — inserts each ~2000-record page immediately."""
    result = sf.query(soql)
    total_fetched = 0

    while True:
        page = []
        for rec in result["records"]:
            row = dict(rec)
            row.pop("attributes", None)
            page.append(row)

        if page:
            batch_callback(page)
            total_fetched += len(page)
            if progress_callback:
                progress_callback("downloading", f"{total_fetched:,} records streamed", total_fetched)

        if result.get("done", True) or not result.get("nextRecordsUrl"):
            break
        result = sf.query_more(result["nextRecordsUrl"], identifier_is_url=True)

    return total_fetched


def _stream_bulk_iter(results_iter, batch_callback, progress_callback=None):
    """Stream from Bulk API iterable — accumulates chunks of _BULK_STREAM_CHUNK_SIZE."""
    total_fetched = 0
    chunk = []

    for rec in results_iter:
        row = dict(rec)
        row.pop("attributes", None)
        chunk.append(row)

        if len(chunk) >= _BULK_STREAM_CHUNK_SIZE:
            batch_callback(chunk)
            total_fetched += len(chunk)
            chunk = []
            if progress_callback:
                progress_callback("downloading", f"{total_fetched:,} records streamed", total_fetched)

    # Flush remaining
    if chunk:
        batch_callback(chunk)
        total_fetched += len(chunk)
        if progress_callback:
            progress_callback("downloading", f"{total_fetched:,} records streamed", total_fetched)

    return total_fetched


def fetch_records(sf, object_name, progress_callback=None):
    desc = getattr(sf, object_name).describe()
    fields = desc["fields"]

    count_result = sf.query(f"SELECT COUNT() FROM {object_name}")
    total = count_result["totalSize"]

    if total <= _get_bulk_threshold():
        field_meta = fields
        field_names = [f["name"] for f in field_meta]
        soql = f"SELECT {', '.join(field_names)} FROM {object_name}"
        records = _query_all(sf, soql)
    else:
        # Bulk API: filter out compound fields
        field_meta = _filter_fields_for_bulk(fields)
        field_names = [f["name"] for f in field_meta]
        soql = f"SELECT {', '.join(field_names)} FROM {object_name}"
        try:
            records = _bulk_query(sf, object_name, soql, progress_callback=progress_callback)
        except Exception as e:
            # Fallback to standard query_all for any Bulk API failure
            print(f"Bulk API failed for {object_name}: {e}, falling back to standard API")
            if progress_callback:
                progress_callback("bulk_started", "Bulk API failed, using standard API...", 0)
            field_meta = fields
            field_names = [f["name"] for f in field_meta]
            soql = f"SELECT {', '.join(field_names)} FROM {object_name}"
            records = _query_all(sf, soql)

    return field_meta, records, total


def _strip_compound_fields_from_soql(sf, object_name, soql):
    """Remove compound fields from a SOQL SELECT clause for Bulk API compatibility."""
    import re
    try:
        desc = getattr(sf, object_name).describe()
        compound_names = {
            f["name"].lower()
            for f in desc["fields"]
            if f["type"].lower() in _COMPOUND_TYPES
        }
    except Exception:
        return soql  # Can't describe — return as-is

    if not compound_names:
        return soql

    # Match SELECT ... FROM
    m = re.match(r'(SELECT\s+)(.*?)(\s+FROM\s+)', soql, re.IGNORECASE | re.DOTALL)
    if not m:
        return soql

    select_part = m.group(2)
    fields = [f.strip() for f in select_part.split(',')]
    filtered = [f for f in fields if f.lower() not in compound_names]

    if not filtered:
        return soql  # Don't produce an empty SELECT

    return m.group(1) + ', '.join(filtered) + m.group(3) + soql[m.end():]


def _query_all(sf, soql):
    result = sf.query_all(soql)
    rows = []
    for rec in result["records"]:
        row = dict(rec)
        row.pop("attributes", None)
        rows.append(row)
    return rows


def _bulk_query(sf, object_name, soql, progress_callback=None):
    """Run a Bulk API query via simple_salesforce."""
    if progress_callback:
        progress_callback("bulk_started", "Querying via Bulk API (this may take a few minutes)...", 0)
    rows = []
    results = sf.bulk.__getattr__(object_name).query(soql)
    for rec in results:
        row = dict(rec)
        row.pop("attributes", None)
        rows.append(row)
    if progress_callback:
        progress_callback("downloading", f"{len(rows)} records downloaded", 0)
    return rows


def fetch_records_by_soql(sf, soql):
    """Execute arbitrary SOQL with smart routing. Returns (columns, records, total)."""
    import re
    has_limit = bool(re.search(r'\bLIMIT\b', soql, re.IGNORECASE))

    # Parse object name from FROM clause for bulk routing
    match = re.search(r'\bFROM\s+(\w+)', soql, re.IGNORECASE)
    object_name = match.group(1) if match else None

    if has_limit:
        # Use standard API for queries with LIMIT
        result = sf.query_all(soql)
        records = []
        columns = None
        for rec in result.get("records", []):
            row = dict(rec)
            row.pop("attributes", None)
            if columns is None:
                columns = list(row.keys())
            records.append(row)
        total = result.get("totalSize", len(records))
        return columns or [], records, total

    # Check count first to decide routing
    if object_name:
        try:
            count_result = sf.query(f"SELECT COUNT() FROM {object_name}")
            total = count_result.get("totalSize", 0)
        except Exception:
            total = 0
    else:
        total = 0

    if total <= _get_bulk_threshold() or not object_name:
        # Standard API
        result = sf.query_all(soql)
        records = []
        columns = None
        for rec in result.get("records", []):
            row = dict(rec)
            row.pop("attributes", None)
            if columns is None:
                columns = list(row.keys())
            records.append(row)
        total = result.get("totalSize", len(records))
        return columns or [], records, total
    else:
        # Bulk API — strip compound fields from the SOQL SELECT clause
        bulk_soql = _strip_compound_fields_from_soql(sf, object_name, soql)
        try:
            records = _bulk_query(sf, object_name, bulk_soql)
        except Exception as e:
            # If bulk still fails (e.g. other unsupported features), fall back to standard API
            if "FUNCTIONALITY_NOT_ENABLED" in str(e) or "compound" in str(e).lower():
                result = sf.query_all(soql)
                records = []
                columns = None
                for rec in result.get("records", []):
                    row = dict(rec)
                    row.pop("attributes", None)
                    if columns is None:
                        columns = list(row.keys())
                    records.append(row)
                return columns or [], records, result.get("totalSize", len(records))
            raise
        columns = list(records[0].keys()) if records else []
        return columns, records, len(records)


def _parse_bulk_results(results):
    """Parse bulk API results into a summary dict with per-record details."""
    success_count = 0
    error_count = 0
    errors = []
    record_results = []
    for i, r in enumerate(results):
        if r.get("success"):
            success_count += 1
            record_results.append({
                "row": i + 1,
                "success": True,
                "id": r.get("id", ""),
                "message": "",
                "statusCode": "",
            })
        else:
            error_count += 1
            err_msg = ""
            err_code = "UNKNOWN"
            for err in r.get("errors", []):
                err_msg = err.get("message", str(err))
                err_code = err.get("statusCode", "UNKNOWN")
                errors.append({
                    "row": i + 1,
                    "message": err_msg,
                    "statusCode": err_code,
                })
            record_results.append({
                "row": i + 1,
                "success": False,
                "id": "",
                "message": err_msg,
                "statusCode": err_code,
            })
    return {"success_count": success_count, "error_count": error_count, "errors": errors[:_get_error_limit()], "record_results": record_results}


def _parse_bulk2_results(sf, object_name, bulk2_results):
    """Parse Bulk API 2.0 results into the same format as _parse_bulk_results."""
    success_count = 0
    error_count = 0
    errors = []
    record_results = []

    for batch in bulk2_results:
        job_id = batch.get("job_id")
        if not job_id:
            continue
        # Fetch per-record details from Bulk API 2.0
        all_records = sf.bulk2.__getattr__(object_name).get_all_ingest_records(job_id)
        row_offset = len(record_results)

        for i, rec in enumerate(all_records.get("successfulRecords", [])):
            success_count += 1
            record_results.append({
                "row": row_offset + i + 1,
                "success": True,
                "id": rec.get("sf__Id", ""),
                "message": "",
                "statusCode": "",
            })

        for i, rec in enumerate(all_records.get("failedRecords", [])):
            error_count += 1
            err_msg = rec.get("sf__Error", "Unknown error")
            record_results.append({
                "row": row_offset + success_count + i + 1,
                "success": False,
                "id": "",
                "message": err_msg,
                "statusCode": "FAILED",
            })
            errors.append({
                "row": row_offset + success_count + i + 1,
                "message": err_msg,
                "statusCode": "FAILED",
            })

    return {"success_count": success_count, "error_count": error_count, "errors": errors[:_get_error_limit()], "record_results": record_results}


def bulk_insert(sf, object_name, records):
    """Insert records using Bulk API 2.0 (Bearer auth), falling back to 1.0."""
    try:
        results = sf.bulk2.__getattr__(object_name).insert(records=records)
        return _parse_bulk2_results(sf, object_name, results)
    except Exception:
        results = sf.bulk.__getattr__(object_name).insert(records)
        return _parse_bulk_results(results)


def bulk_update(sf, object_name, records):
    """Update records using Bulk API 2.0 (Bearer auth), falling back to 1.0."""
    try:
        results = sf.bulk2.__getattr__(object_name).update(records=records)
        return _parse_bulk2_results(sf, object_name, results)
    except Exception:
        results = sf.bulk.__getattr__(object_name).update(records)
        return _parse_bulk_results(results)


def bulk_upsert(sf, object_name, records, external_id_field):
    """Upsert records using Bulk API 2.0 (Bearer auth), falling back to 1.0."""
    try:
        results = sf.bulk2.__getattr__(object_name).upsert(records=records, external_id_field=external_id_field)
        return _parse_bulk2_results(sf, object_name, results)
    except Exception:
        results = sf.bulk.__getattr__(object_name).upsert(records, external_id_field)
        return _parse_bulk_results(results)


def bulk_delete(sf, object_name, records):
    """Delete records using Bulk API 2.0 (Bearer auth), falling back to 1.0."""
    try:
        results = sf.bulk2.__getattr__(object_name).delete(records=records)
        return _parse_bulk2_results(sf, object_name, results)
    except Exception:
        results = sf.bulk.__getattr__(object_name).delete(records)
        return _parse_bulk_results(results)
