import psycopg2
from psycopg2.extras import execute_values
from datetime import datetime, date, timezone

try:
    from pyathena import connect as athena_connect
    HAS_ATHENA = True
except ImportError:
    HAS_ATHENA = False

try:
    import mysql.connector as mysql_connector
    HAS_MYSQL = True
except ImportError:
    HAS_MYSQL = False

try:
    import duckdb
    HAS_DUCKDB = True
except ImportError:
    HAS_DUCKDB = False

SF_TYPE_MAP = {
    "string": "TEXT",
    "textarea": "TEXT",
    "picklist": "TEXT",
    "multipicklist": "TEXT",
    "phone": "TEXT",
    "email": "TEXT",
    "url": "TEXT",
    "encryptedstring": "TEXT",
    "combobox": "TEXT",
    "double": "DOUBLE PRECISION",
    "currency": "DOUBLE PRECISION",
    "percent": "DOUBLE PRECISION",
    "boolean": "BOOLEAN",
    "date": "DATE",
    "datetime": "TIMESTAMP",
    "time": "TEXT",
    "int": "BIGINT",
    "long": "BIGINT",
    "id": "VARCHAR(18)",
    "reference": "VARCHAR(18)",
    "base64": "TEXT",
    "address": "TEXT",
    "location": "TEXT",
}


def _is_athena(conn):
    return conn.get("dbType") == "athena"


def _is_redshift(conn):
    return conn.get("dbType") == "redshift"


def _is_mysql(conn):
    return conn.get("dbType") == "mysql"


def _is_duckdb(conn):
    return conn.get("dbType") == "duckdb"


def get_connection(conn, database=None):
    db_name = database or conn.get("database", "")
    if _is_duckdb(conn):
        if not HAS_DUCKDB:
            raise ImportError("duckdb is not installed. Run: pip install duckdb")
        import os
        filepath = os.path.expanduser(conn.get("filepath", "~/sfdc-loader/duckdb"))
        os.makedirs(filepath, exist_ok=True)
        db_file = os.path.join(filepath, f"{db_name or 'default'}.duckdb")
        return duckdb.connect(db_file)
    if _is_mysql(conn):
        if not HAS_MYSQL:
            raise ImportError("mysql-connector-python is not installed. Run: pip install mysql-connector-python")
        return mysql_connector.connect(
            host=conn.get("host", "localhost"),
            port=int(conn.get("port", 3306)),
            database=db_name,
            user=conn.get("username", ""),
            password=conn.get("password", ""),
        )
    if _is_athena(conn):
        if not HAS_ATHENA:
            raise ImportError("pyathena is not installed. Run: pip install pyathena")
        return athena_connect(
            aws_access_key_id=conn.get("accessKey", "").strip(),
            aws_secret_access_key=conn.get("secretKey", "").strip(),
            region_name=conn.get("region", "us-east-1"),
            schema_name=db_name or "default",
            s3_staging_dir=conn.get("s3OutputLocation", "").strip(),
        )
    return psycopg2.connect(
        host=conn["host"],
        port=int(conn.get("port", 5432)),
        dbname=db_name or conn["database"],
        user=conn["username"],
        password=conn.get("password", ""),
    )


def test_connection(conn):
    try:
        db = get_connection(conn)
        cur = db.cursor()
        cur.execute("SELECT 1")
        cur.close()
        db.close()
        return {"success": True, "message": "Connected successfully"}
    except Exception as e:
        return {"success": False, "message": str(e)}


def _pg_type(sf_field):
    sf_type = sf_field["type"].lower()
    return SF_TYPE_MAP.get(sf_type, "TEXT")


def _col_name(field_name):
    return field_name.lower()


def _is_mysql_conn(pg):
    """Detect if the connection object is a MySQL connection."""
    return type(pg).__module__.startswith("mysql")


def _is_duckdb_conn(pg):
    """Detect if the connection object is a DuckDB connection."""
    mod = type(pg).__module__
    return mod.startswith("duckdb") or mod.startswith("_duckdb")


def table_exists(pg, table_name):
    """Check if a table exists in the database."""
    is_mysql = _is_mysql_conn(pg)
    is_duck = _is_duckdb_conn(pg)
    cur = pg.cursor()
    try:
        if is_duck:
            cur.execute(f"SELECT 1 FROM information_schema.tables WHERE table_name = ?", [table_name])
        elif is_mysql:
            cur.execute("SELECT 1 FROM information_schema.tables WHERE table_name = %s", [table_name])
        else:
            cur.execute("SELECT 1 FROM information_schema.tables WHERE table_name = %s", [table_name])
        return cur.fetchone() is not None
    except Exception:
        return False
    finally:
        cur.close()


def create_table(pg, object_name, field_meta, raw_table_name=False):
    table = object_name if raw_table_name else object_name.lower()
    is_mysql = _is_mysql_conn(pg)
    is_duck = _is_duckdb_conn(pg)
    q = '`' if is_mysql else '"'
    cols = []
    for f in field_meta:
        col = _col_name(f["name"])
        pg_type = _pg_type(f)
        cols.append(f'{q}{col}{q} {pg_type}')
    col_defs = ",\n  ".join(cols)

    cur = pg.cursor()
    if is_mysql:
        cur.execute(f'DROP TABLE IF EXISTS {q}{table}{q}')
    elif is_duck:
        cur.execute(f'DROP TABLE IF EXISTS {q}{table}{q} CASCADE')
    else:
        cur.execute(f'DROP TABLE IF EXISTS {q}{table}{q} CASCADE')
    cur.execute(f'CREATE TABLE {q}{table}{q} (\n  {col_defs}\n)')
    pg.commit()
    cur.close()
    return table


def set_table_comment(pg, table_name, comment_text):
    """Set a comment on a table (stores source metadata)."""
    is_mysql = _is_mysql_conn(pg)
    q = '`' if is_mysql else '"'
    cur = pg.cursor()
    try:
        escaped = comment_text.replace("'", "''")
        if is_mysql:
            cur.execute(f"ALTER TABLE {q}{table_name}{q} COMMENT = '{escaped}'")
        else:
            cur.execute(f"COMMENT ON TABLE {q}{table_name}{q} IS '{escaped}'")
        pg.commit()
    except Exception:
        pass  # non-critical — don't fail the import
    finally:
        cur.close()


def _coerce_value(val, sf_type):
    """Convert Salesforce values to Python types compatible with PostgreSQL."""
    if val is None or val == "":
        return None
    sf_type = sf_type.lower()
    if sf_type in ("datetime", "date"):
        # Bulk API sometimes returns epoch milliseconds as int/float
        if isinstance(val, (int, float)):
            try:
                # Salesforce epoch is typically in milliseconds
                ts = val / 1000.0 if val > 1e12 else float(val)
                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                return dt.date() if sf_type == "date" else dt.replace(tzinfo=None)
            except (ValueError, OSError, OverflowError):
                return None
        # String epoch (from Bulk API CSV)
        if isinstance(val, str) and val.isdigit():
            try:
                ts = int(val)
                ts = ts / 1000.0 if ts > 1e12 else float(ts)
                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                return dt.date() if sf_type == "date" else dt.replace(tzinfo=None)
            except (ValueError, OSError, OverflowError):
                return None
        # Already a proper ISO string — pass through for psycopg2
        return val
    if sf_type == "boolean":
        if isinstance(val, str):
            return val.lower() in ("true", "1", "yes")
        return bool(val)
    if sf_type in ("double", "currency", "percent"):
        if isinstance(val, str):
            try:
                return float(val)
            except ValueError:
                return None
        return val
    if sf_type in ("int", "long"):
        if isinstance(val, str):
            try:
                return int(val)
            except ValueError:
                return None
        return val
    if isinstance(val, dict):
        return str(val)
    return val


def _get_db_batch_size():
    try:
        import config as _cfg
        return _cfg.get_bulk_settings().get("dbInsertBatchSize", 500)
    except Exception:
        return 500


def _copy_records_pg(pg, table, field_meta, records):
    """Ultra-fast bulk insert using PostgreSQL COPY FROM STDIN (CSV format).
    Returns the number of records inserted."""
    import io as _io
    columns = [_col_name(f["name"]) for f in field_meta]
    col_list = ", ".join(f'"{c}"' for c in columns)

    # Build coercion functions per column (avoid per-cell dict lookup)
    types = [f["type"].lower() for f in field_meta]
    names = [f["name"] for f in field_meta]

    buf = _io.StringIO()
    for rec in records:
        parts = []
        for name, sf_type in zip(names, types):
            val = rec.get(name)
            coerced = _coerce_value(val, sf_type)
            if coerced is None:
                parts.append("")
            else:
                s = str(coerced)
                # Escape for CSV: quote fields containing comma, quote, or newline
                if '"' in s or ',' in s or '\n' in s or '\r' in s:
                    s = '"' + s.replace('"', '""') + '"'
                parts.append(s)
        buf.write(",".join(parts))
        buf.write("\n")

    buf.seek(0)
    cur = pg.cursor()
    cur.copy_expert(f'COPY "{table}" ({col_list}) FROM STDIN WITH (FORMAT csv, NULL \'\')', buf)
    pg.commit()
    cur.close()
    return len(records)


def insert_records(pg, table, field_meta, records, batch_size=None, progress_callback=None):
    if not records:
        return 0

    is_mysql = _is_mysql_conn(pg)
    is_duck = _is_duckdb_conn(pg)

    # Use COPY for PostgreSQL/Redshift — much faster than INSERT
    if not is_mysql and not is_duck:
        try:
            count = _copy_records_pg(pg, table, field_meta, records)
            if progress_callback:
                progress_callback(count, count)
            return count
        except Exception:
            # Fallback to INSERT if COPY fails (e.g. type mismatch)
            try:
                pg.rollback()
            except Exception:
                pass

    if batch_size is None:
        batch_size = _get_db_batch_size()
    q = '`' if is_mysql else '"'
    columns = [_col_name(f["name"]) for f in field_meta]
    col_list = ", ".join(f'{q}{c}{q}' for c in columns)

    cur = pg.cursor()
    total = 0
    total_records = len(records)
    for i in range(0, total_records, batch_size):
        batch = records[i : i + batch_size]
        values = []
        for rec in batch:
            row = []
            for f in field_meta:
                val = rec.get(f["name"])
                row.append(_coerce_value(val, f["type"]))
            values.append(tuple(row))
        if is_duck:
            placeholders = ", ".join(["?"] * len(columns))
            cur.executemany(f'INSERT INTO {q}{table}{q} ({col_list}) VALUES ({placeholders})', values)
        elif is_mysql:
            placeholders = ", ".join(["%s"] * len(columns))
            cur.executemany(f'INSERT INTO {q}{table}{q} ({col_list}) VALUES ({placeholders})', values)
        else:
            template = "(" + ", ".join(["%s"] * len(columns)) + ")"
            execute_values(cur, f'INSERT INTO {q}{table}{q} ({col_list}) VALUES %s', values, template=template)
        total += len(batch)
        if progress_callback:
            progress_callback(total, total_records)
    pg.commit()
    cur.close()
    return total


# ── Compare temp-table helpers ──────────────────────────────────────

def create_compare_temp_table(pg, table_name, columns):
    """Create a temporary table with all TEXT columns for comparison."""
    is_mysql = _is_mysql_conn(pg)
    is_duck = _is_duckdb_conn(pg)
    q = '`' if is_mysql else '"'
    col_defs = ", ".join(f'{q}{c}{q} TEXT' for c in columns)
    keyword = "TEMPORARY" if is_mysql else "TEMP"
    cur = pg.cursor()
    cur.execute(f'CREATE {keyword} TABLE {q}{table_name}{q} ({col_defs})')
    pg.commit()
    cur.close()


def insert_compare_rows(pg, table_name, columns, rows, progress_callback=None):
    """Bulk insert string rows into a compare temp table.
    rows: list of tuples of str/None values matching columns order.
    """
    if not rows:
        return 0
    is_mysql = _is_mysql_conn(pg)
    is_duck = _is_duckdb_conn(pg)
    q = '`' if is_mysql else '"'
    col_list = ", ".join(f'{q}{c}{q}' for c in columns)
    total = len(rows)
    batch_size = 1000

    # Use COPY for Postgres — much faster
    if not is_mysql and not is_duck:
        try:
            import io as _io
            buf = _io.StringIO()
            for row in rows:
                parts = []
                for val in row:
                    if val is None:
                        parts.append("")
                    else:
                        s = str(val)
                        if '"' in s or ',' in s or '\n' in s or '\r' in s:
                            s = '"' + s.replace('"', '""') + '"'
                        parts.append(s)
                buf.write(",".join(parts))
                buf.write("\n")
            buf.seek(0)
            cur = pg.cursor()
            cur.copy_expert(
                f'COPY "{table_name}" ({col_list}) FROM STDIN WITH (FORMAT csv, NULL \'\')',
                buf,
            )
            pg.commit()
            cur.close()
            if progress_callback:
                progress_callback(total, total)
            return total
        except Exception:
            try:
                pg.rollback()
            except Exception:
                pass

    cur = pg.cursor()
    inserted = 0
    for i in range(0, total, batch_size):
        batch = rows[i : i + batch_size]
        if is_duck:
            placeholders = ", ".join(["?"] * len(columns))
            cur.executemany(f'INSERT INTO {q}{table_name}{q} ({col_list}) VALUES ({placeholders})', batch)
        elif is_mysql:
            placeholders = ", ".join(["%s"] * len(columns))
            cur.executemany(f'INSERT INTO {q}{table_name}{q} ({col_list}) VALUES ({placeholders})', batch)
        else:
            from psycopg2.extras import execute_values as _ev
            template = "(" + ", ".join(["%s"] * len(columns)) + ")"
            _ev(cur, f'INSERT INTO {q}{table_name}{q} ({col_list}) VALUES %s', batch, template=template)
        inserted += len(batch)
        if progress_callback:
            progress_callback(inserted, total)
    pg.commit()
    cur.close()
    return inserted


def drop_compare_temp_table(pg, table_name):
    """Drop the compare temp table (safe cleanup)."""
    is_mysql = _is_mysql_conn(pg)
    q = '`' if is_mysql else '"'
    try:
        cur = pg.cursor()
        cur.execute(f'DROP TABLE IF EXISTS {q}{table_name}{q}')
        pg.commit()
        cur.close()
    except Exception:
        pass
