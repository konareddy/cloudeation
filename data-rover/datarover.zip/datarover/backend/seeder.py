import threading
import uuid
import traceback
import datetime
import re
import random
import string
import salesforce_client
import config
import store

_jobs = {}


def cancel_job(job_id):
    job = _jobs.get(job_id)
    if not job:
        return False
    if job.get("running"):
        job["_cancel"] = True
        return True
    return False


# System audit fields that should never be inserted even if source marks them createable
_AUDIT_FIELDS = {
    "CreatedDate", "CreatedById", "LastModifiedDate", "LastModifiedById",
    "SystemModstamp", "LastActivityDate", "IsDeleted",
}

# ── PII Detection ──────────────────────────────────────────────────

_PII_PATTERNS = {
    "email": re.compile(r"(e[_\-]?mail)", re.IGNORECASE),
    "phone": re.compile(r"(phone|fax|mobile)", re.IGNORECASE),
    "name": re.compile(r"(firstname|lastname|first_name|last_name|middlename|middle_name)", re.IGNORECASE),
    "address": re.compile(r"(street|city|state|zip|postal|country|address|mailingcity|mailingstreet|mailingstate|mailingpostalcode|mailingcountry|billingcity|billingstreet|billingstate|billingpostalcode|billingcountry|otherstreet|othercity|otherstate|otherpostalcode|othercountry)", re.IGNORECASE),
    "ssn": re.compile(r"(ssn|social_?insurance|tax_?id|social_?sec)", re.IGNORECASE),
    "date": re.compile(r"(birthdate|dob|date_of_birth)", re.IGNORECASE),
}

_PII_FIELD_TYPES = {
    "email": "email",
    "phone": "phone",
    "url": "text",
    "address": "address",
}

_FAKE_FIRST_NAMES = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Quinn", "Avery", "Harper", "Skyler"]
_FAKE_LAST_NAMES = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Wilson", "Moore"]


def detect_pii_fields(fields):
    detected = []
    for f in fields:
        name = f.get("name", "")
        label = f.get("label", "")
        ftype = f.get("type", "").lower()
        if not f.get("createable", False):
            continue
        category = None
        strategy = None
        if ftype in _PII_FIELD_TYPES:
            category = ftype if ftype != "url" else "text"
            strategy = _PII_FIELD_TYPES[ftype]
        if not category:
            for cat, pattern in _PII_PATTERNS.items():
                if pattern.search(name):
                    category = cat
                    strategy = cat
                    break
        if category:
            detected.append({
                "fieldName": name, "fieldLabel": label, "fieldType": ftype,
                "piiCategory": category, "maskStrategy": strategy,
            })
    return detected


# ── Masking Functions ──────────────────────────────────────────────

def mask_email(val):
    if not val or not isinstance(val, str): return val
    suffix = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
    return f"user_{suffix}@masked.example.com"

def mask_phone(val):
    if not val or not isinstance(val, str): return val
    digits = re.sub(r'\D', '', val)
    prefix = digits[:3] if len(digits) >= 3 else digits
    remaining = ''.join(random.choices(string.digits, k=max(0, len(digits) - 3)))
    masked_digits = prefix + remaining
    result = []
    di = 0
    for ch in val:
        if ch.isdigit() and di < len(masked_digits):
            result.append(masked_digits[di])
            di += 1
        else:
            result.append(ch)
    return ''.join(result)

def mask_name(val):
    if not val or not isinstance(val, str): return val
    return random.choice(_FAKE_FIRST_NAMES + _FAKE_LAST_NAMES)

def mask_address(val):
    if not val or not isinstance(val, str): return val
    num = random.randint(100, 9999)
    streets = ["Main St", "Oak Ave", "Elm Dr", "Pine Rd", "Maple Ln", "Cedar Blvd", "Park Way"]
    return f"{num} {random.choice(streets)}"

def mask_ssn(val):
    if not val or not isinstance(val, str): return val
    last2 = ''.join(random.choices(string.digits, k=2))
    return f"XXX-XX-{last2}"

def mask_date(val):
    if not val: return val
    try:
        if isinstance(val, str):
            dt = datetime.datetime.fromisoformat(val.replace('Z', '+00:00'))
        else:
            dt = val
        shift = random.randint(-30, 30)
        dt = dt + datetime.timedelta(days=shift)
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return val

def mask_text(val):
    if not val: return val
    return "[MASKED]"

_MASK_FNS = {
    "email": mask_email, "phone": mask_phone, "name": mask_name,
    "address": mask_address, "ssn": mask_ssn, "date": mask_date, "text": mask_text,
}


def apply_masking(records, masking_rules):
    rule_map = {}
    for rule in masking_rules:
        fn = _MASK_FNS.get(rule["strategy"])
        if fn:
            rule_map[rule["fieldName"]] = fn
    for rec in records:
        for field_name, mask_fn in rule_map.items():
            if field_name in rec and rec[field_name] is not None:
                rec[field_name] = mask_fn(rec[field_name])
    return records


# ── Topological Sort ───────────────────────────────────────────────

def _compute_load_order(obj_names, dependencies):
    """Compute load order via topological sort. Returns (ordered_names, circular_pairs, broken_dep_map).

    dependencies: { objName: [{ object, field }, ...] }
    """
    dep_map = {}
    for name in obj_names:
        deps = dependencies.get(name, [])
        dep_map[name] = [d["object"] for d in deps if d["object"] in obj_names and d["object"] != name]

    # Detect and break circular deps
    circular_pairs = set()
    for a in obj_names:
        for b in (dep_map.get(a) or []):
            if a in (dep_map.get(b) or []):
                pair = tuple(sorted([a, b]))
                if pair not in circular_pairs:
                    circular_pairs.add(pair)
                    # Break: remove from whichever has more deps
                    if len(dep_map.get(a, [])) >= len(dep_map.get(b, [])):
                        dep_map[a] = [d for d in dep_map[a] if d != b]
                    else:
                        dep_map[b] = [d for d in dep_map[b] if d != a]

    # Topological sort
    ordered = []
    visited = set()
    in_stack = set()

    def visit(name):
        if name in visited:
            return
        if name in in_stack:
            return
        in_stack.add(name)
        for dep in (dep_map.get(name) or []):
            visit(dep)
        in_stack.discard(name)
        visited.add(name)
        ordered.append(name)

    for name in obj_names:
        visit(name)

    return ordered, circular_pairs, dep_map


def _get_ref_fields_for_dep(source_desc_fields, dep_object):
    """Find reference fields in source_desc_fields that point to dep_object.
    Returns only the first (primary) reference field to keep SOQL short."""
    for f in source_desc_fields:
        if f.get("type") == "reference" and dep_object in (f.get("referenceTo") or []):
            return [f["name"]]
    return []


# ── Smart Sampling ─────────────────────────────────────────────────

_ID_CHUNK_SIZE = 150

# Strategies:
#   fullRelationships - pick parents that have children across ALL selected child objects
#   recent            - ORDER BY LastModifiedDate DESC
#   topN              - parents with most child records (scored)
#   random            - random sample (default)

STRATEGIES = {"fullRelationships", "recent", "topN", "random"}


def _build_reverse_dep(obj_names, dep_map, sf, all_descs):
    """Build reverse_dep: parent -> [(child, ref_field)] from dep_map."""
    reverse_dep = {}
    for child in obj_names:
        for parent in dep_map.get(child, []):
            if child not in all_descs:
                try:
                    all_descs[child] = getattr(sf, child).describe()
                except Exception:
                    continue
            ref_fields = _get_ref_fields_for_dep(all_descs[child]["fields"], parent)
            if ref_fields:
                reverse_dep.setdefault(parent, []).append((child, ref_fields[0]))
    return reverse_dep


def _query_child_parent_ids(sf, child_obj, ref_field, rt_config=None, limit=10000):
    """Query a child object for its parent reference IDs. Returns set of parent IDs.
    Tries with RT filter first; if 0 results, retries without RT filter."""
    def _do_query(conds):
        where = " AND ".join(conds)
        soql = f"SELECT {ref_field} FROM {child_obj} WHERE {where} LIMIT {limit}"
        print(f"[seeder] Discovery: {soql[:200]}", flush=True)
        res = sf.query_all(soql)
        ids = set()
        for rec in res.get("records", []):
            v = rec.get(ref_field)
            if v:
                ids.add(v)
        return ids

    conds = [f"{ref_field} != null"]
    if rt_config:
        rt_ids = [r["id"] for r in rt_config]
        if rt_ids:
            rt_in = ",".join("'%s'" % r for r in rt_ids)
            conds.append(f"RecordTypeId IN ({rt_in})")

    ids = _do_query(conds)
    print(f"[seeder] Discovery: {child_obj}.{ref_field} -> {len(ids)} parent IDs", flush=True)

    # Fallback: if RT filter gave 0, retry without it
    if not ids and rt_config:
        print(f"[seeder] Discovery: retrying {child_obj} without RT filter...", flush=True)
        ids = _do_query([f"{ref_field} != null"])
        print(f"[seeder] Discovery (no RT): {child_obj}.{ref_field} -> {len(ids)} parent IDs", flush=True)

    return ids


def _discover_connected_ids(sf, obj_names, dep_map, all_descs, obj_cfg_map):
    """Bottom-up: find parent IDs that have children. Intersects across children
    so selected parents have related records in ALL child objects."""
    reverse_dep = _build_reverse_dep(obj_names, dep_map, sf, all_descs)
    print(f"[seeder] Discovery reverse_dep: {reverse_dep}", flush=True)

    connected_ids = {}
    for parent_obj, children_info in reverse_dep.items():
        per_child = {}
        for child_obj, ref_field in children_info:
            cfg = obj_cfg_map.get(child_obj, {})
            try:
                ids = _query_child_parent_ids(sf, child_obj, ref_field, cfg.get("recordTypes"))
                per_child[child_obj] = ids
            except Exception as e:
                print(f"[seeder] Discovery error {child_obj}.{ref_field}: {e}", flush=True)

        non_empty = [s for s in per_child.values() if s]
        if not non_empty:
            continue

        # Intersect: parents that appear in ALL children
        if len(non_empty) > 1:
            result = non_empty[0]
            for s in non_empty[1:]:
                result = result & s
            if result:
                print(f"[seeder] {parent_obj}: intersection = {len(result)} IDs (all children)", flush=True)
                connected_ids[parent_obj] = result
            else:
                # No overlap — score parents by how many children reference them
                from collections import Counter
                counter = Counter()
                for s in non_empty:
                    counter.update(s)
                # Pick parents that appear in the most children
                max_score = counter.most_common(1)[0][1] if counter else 0
                best = set(pid for pid, cnt in counter.items() if cnt == max_score)
                print(f"[seeder] {parent_obj}: no intersection; scored {len(best)} IDs (appear in {max_score}/{len(non_empty)} children)", flush=True)
                connected_ids[parent_obj] = best
        else:
            connected_ids[parent_obj] = non_empty[0]
            print(f"[seeder] {parent_obj}: {len(non_empty[0])} IDs from single child", flush=True)

    return connected_ids


def _build_order_clause(strategy):
    """Return ORDER BY clause for the given strategy."""
    if strategy == "recent":
        return " ORDER BY LastModifiedDate DESC"
    elif strategy == "topN":
        return " ORDER BY CreatedDate ASC"  # oldest = most established
    return ""


def _chunked_id_query(sf, obj_name, select_fields, base_conditions, id_field, id_list, limit):
    """Query records WHERE id_field IN (chunked id_list) with base_conditions."""
    records = []
    rem = limit
    for i in range(0, len(id_list), _ID_CHUNK_SIZE):
        if rem <= 0:
            break
        chunk = id_list[i:i + _ID_CHUNK_SIZE]
        ids_str = ",".join(f"'{pid}'" for pid in chunk)
        conds = list(base_conditions) + [f"{id_field} IN ({ids_str})"]
        soql = f"SELECT {', '.join(select_fields)} FROM {obj_name} WHERE {' AND '.join(conds)} LIMIT {rem}"
        try:
            res = sf.query_all(soql)
            batch = [{k: v for k, v in rec.items() if k != "attributes"} for rec in res.get("records", [])]
            records.extend(batch)
            rem -= len(batch)
        except Exception as e:
            print(f"[seeder] Warning: chunk query {obj_name}: {e}", flush=True)
    return records


def dry_run(source_conn_id, objects_config, dependencies, sampling_strategy="fullRelationships"):
    """Fetch from source only (no insert). Returns counts + sample data per object.

    Strategies:
      fullRelationships - pick parents with children in all selected child objects
      recent            - most recently modified records
      topN              - longest-established records (most likely to have children)
      random            - random sample
    """
    source_conn = config.get_salesforce(source_conn_id)
    sf_source = salesforce_client.connect(source_conn)

    obj_names = [o["name"] for o in objects_config]
    obj_cfg_map = {o["name"]: o for o in objects_config}
    ordered, circular_pairs, dep_map = _compute_load_order(obj_names, dependencies)

    if sampling_strategy not in STRATEGIES:
        sampling_strategy = "fullRelationships"

    print(f"[seeder] Dry run: strategy={sampling_strategy}, order={ordered}, deps={dep_map}", flush=True)

    all_descs = {}

    # Phase 1: discover connected parent IDs (for fullRelationships and topN)
    connected_ids = {}
    if sampling_strategy in ("fullRelationships", "topN"):
        connected_ids = _discover_connected_ids(sf_source, obj_names, dep_map, all_descs, obj_cfg_map)
    print(f"[seeder] Connected IDs: { {k: len(v) for k,v in connected_ids.items()} }", flush=True)

    # Phase 2: top-down fetch with iterative expansion
    fetched_ids = {}   # { obj: set of IDs }
    all_records = {}   # { obj: [records] }
    results = {}
    MAX_ITER = 3

    for iteration in range(MAX_ITER):
        any_short = False
        print(f"[seeder] === Iteration {iteration + 1} ===", flush=True)

        for obj_name in ordered:
            obj_cfg = obj_cfg_map.get(obj_name, {"name": obj_name})
            sample_size = obj_cfg.get("sampleSize", 100)
            already = len(fetched_ids.get(obj_name, set()))
            if already >= sample_size:
                continue
            remaining = sample_size - already

            user_where = (obj_cfg.get("where") or "").strip()
            record_types = obj_cfg.get("recordTypes")

            try:
                if obj_name not in all_descs:
                    all_descs[obj_name] = getattr(sf_source, obj_name).describe()
                desc = all_descs[obj_name]
                all_fields_desc = desc["fields"]
                field_names = [f["name"] for f in all_fields_desc
                               if f.get("createable", False) and f["name"] not in _AUDIT_FIELDS]

                # Base conditions
                base_conds = []
                if user_where:
                    base_conds.append(f"({user_where})")
                if record_types:
                    rt_ids = [rt["id"] for rt in record_types]
                    if rt_ids:
                        rt_in = ",".join("'%s'" % r for r in rt_ids)
                        base_conds.append(f"RecordTypeId IN ({rt_in})")

                # Exclude already-fetched
                already_ids = fetched_ids.get(obj_name, set())

                display_fields = ["Id", "Name"] if "Name" in [f["name"] for f in all_fields_desc] else ["Id"]
                select_fields = list(set(["Id"] + display_fields + field_names[:5]))

                parent_deps = dep_map.get(obj_name, [])
                msg_parts = []
                new_records = []

                # ── ROOT PARENT (no parent deps) ──
                if not parent_deps:
                    cids = connected_ids.get(obj_name, set()) - already_ids
                    if cids and sampling_strategy in ("fullRelationships", "topN"):
                        # Fetch from discovered connected IDs
                        msg_parts.append(f"Smart: {len(connected_ids[obj_name])} {obj_name} with related children.")
                        new_records = _chunked_id_query(
                            sf_source, obj_name, select_fields, base_conds,
                            "Id", list(cids), remaining
                        )
                    else:
                        # Random or recent — straight query with ORDER BY
                        conds = list(base_conds)
                        if already_ids:
                            excl = list(already_ids)[:_ID_CHUNK_SIZE]
                            excl_str = ",".join("'%s'" % e for e in excl)
                            conds.append(f"Id NOT IN ({excl_str})")
                        soql = f"SELECT {', '.join(select_fields)} FROM {obj_name}"
                        if conds:
                            soql += f" WHERE {' AND '.join(conds)}"
                        soql += _build_order_clause(sampling_strategy)
                        soql += f" LIMIT {remaining}"
                        print(f"[seeder] {obj_name}: {soql[:400]}", flush=True)
                        res = sf_source.query_all(soql)
                        new_records = [{k: v for k, v in r.items() if k != "attributes"}
                                       for r in res.get("records", [])]

                # ── CHILD (has parent deps) ──
                else:
                    for parent_obj in parent_deps:
                        pids = list(fetched_ids.get(parent_obj, set()))
                        if not pids:
                            continue
                        ref_fields = _get_ref_fields_for_dep(all_fields_desc, parent_obj)
                        if not ref_fields:
                            continue
                        rf = ref_fields[0]
                        msg_parts.append(f"Filtered by {rf} from {len(pids)} {parent_obj}.")

                        batch = _chunked_id_query(
                            sf_source, obj_name, select_fields, base_conds,
                            rf, pids, remaining - len(new_records)
                        )
                        new_records.extend(batch)

                    # If 0 with RT filter, retry without RT
                    if not new_records and record_types and iteration == 0:
                        print(f"[seeder] {obj_name}: 0 with RT, retrying without...", flush=True)
                        noRT_conds = [c for c in base_conds if "RecordTypeId" not in c]
                        for parent_obj in parent_deps:
                            pids = list(fetched_ids.get(parent_obj, set()))
                            if not pids:
                                continue
                            ref_fields = _get_ref_fields_for_dep(all_fields_desc, parent_obj)
                            if not ref_fields:
                                continue
                            batch = _chunked_id_query(
                                sf_source, obj_name, select_fields, noRT_conds,
                                ref_fields[0], pids, remaining - len(new_records)
                            )
                            new_records.extend(batch)
                        if new_records:
                            msg_parts.append(f"Note: RT filter returned 0; fetched {len(new_records)} without RT filter.")

                # Merge
                new_ids = set(r.get("Id") for r in new_records if r.get("Id"))
                fetched_ids.setdefault(obj_name, set()).update(new_ids)
                all_records.setdefault(obj_name, []).extend(new_records)
                total = len(fetched_ids[obj_name])
                print(f"[seeder] {obj_name}: +{len(new_records)} new, {total} total", flush=True)

                # Build display result
                recs = all_records.get(obj_name, [])
                sample_rows = recs[:5]
                sample_cols = display_fields[:6] if sample_rows else []
                clean_rows = []
                for row in sample_rows:
                    clean = {}
                    for c in sample_cols:
                        v = row.get(c)
                        clean[c] = str(v) if v is not None else ""
                    clean_rows.append(clean)

                results[obj_name] = {
                    "name": obj_name,
                    "fetchedCount": total,
                    "sampleColumns": sample_cols,
                    "sampleRows": clean_rows,
                    "message": " ".join(msg_parts) if msg_parts else None,
                }

                if total < sample_size:
                    any_short = True

            except Exception as e:
                import traceback as tb
                tb.print_exc()
                results[obj_name] = {
                    "name": obj_name,
                    "fetchedCount": len(fetched_ids.get(obj_name, set())),
                    "sampleColumns": [], "sampleRows": [],
                    "message": f"Error: {e}",
                }
                fetched_ids.setdefault(obj_name, set())

        if not any_short:
            print(f"[seeder] All satisfied after iteration {iteration + 1}", flush=True)
            break
        print(f"[seeder] Some short, continuing...", flush=True)

    # Build final in load order
    final = []
    for obj_name in ordered:
        r = results.get(obj_name, {"name": obj_name, "fetchedCount": 0,
                                    "sampleColumns": [], "sampleRows": [], "message": None})
        final.append(r)

    return {
        "loadOrder": ordered,
        "circularDeps": [list(p) for p in circular_pairs],
        "objects": final,
        "strategy": sampling_strategy,
    }


# ── Job Management ─────────────────────────────────────────────────

def start_seed_job(job_id, source_conn_id, dest_conn_id, objects_config, masking_rules_map,
                    dependencies=None, sampling_strategy="fullRelationships"):
    """Start a relationship-aware sandbox seeding job."""
    if dependencies is None:
        dependencies = {}

    src_name = ""
    try:
        c = config.get_salesforce(source_conn_id)
        if c:
            src_name = c.get("name", "")
    except Exception:
        pass
    dest_name = ""
    try:
        c = config.get_salesforce(dest_conn_id)
        if c:
            dest_name = c.get("name", "")
    except Exception:
        pass

    # Build config lookup
    obj_cfg_map = {}
    for obj in objects_config:
        obj_cfg_map[obj["name"]] = obj

    obj_names = [o["name"] for o in objects_config]
    ordered, circular_pairs, dep_map = _compute_load_order(obj_names, dependencies)

    objects_status = {}
    for name in ordered:
        cfg = obj_cfg_map.get(name, {})
        objects_status[name] = {
            "name": name,
            "status": "pending",
            "progress": 0,
            "total": 0,
            "fetched": 0,
            "inserted": 0,
            "message": "",
            "sampleSize": cfg.get("sampleSize", 100),
        }

    _jobs[job_id] = {
        "id": job_id,
        "type": "Sandbox Seed",
        "started_at": datetime.datetime.now().isoformat(),
        "running": True,
        "status": "starting",
        "progress": 0,
        "message": "Starting sandbox seeding...",
        "source_name": src_name,
        "target_name": dest_name,
        "objects": objects_status,
        "load_order": ordered,
        "circular_deps": [list(p) for p in circular_pairs],
        "total_objects": len(ordered),
        "completed_objects": 0,
        "error_objects": 0,
        "total_records_inserted": 0,
    }

    t = threading.Thread(
        target=_run_seed,
        args=(job_id, source_conn_id, dest_conn_id, obj_cfg_map, masking_rules_map,
              ordered, circular_pairs, dep_map, dependencies, sampling_strategy),
        daemon=True,
    )
    t.start()
    return job_id


def get_job_status(job_id):
    return _jobs.get(job_id)


def _run_seed(job_id, source_conn_id, dest_conn_id, obj_cfg_map, masking_rules_map,
              ordered, circular_pairs, dep_map, raw_dependencies, sampling_strategy="fullRelationships"):
    job = _jobs[job_id]
    try:
        source_conn = config.get_salesforce(source_conn_id)
        dest_conn = config.get_salesforce(dest_conn_id)
        sf_source = salesforce_client.connect(source_conn)
        sf_dest = salesforce_client.connect(dest_conn)

        job["status"] = "running"
        job["message"] = "Connected to source and destination"

        total_objects = len(ordered)

        # Bottom-up discovery of connected IDs
        job["message"] = "Discovering connected records..."
        all_descs = {}
        _seed_connected_ids = {}
        if sampling_strategy in ("fullRelationships", "topN"):
            _seed_connected_ids = _discover_connected_ids(sf_source, list(obj_cfg_map.keys()), dep_map, all_descs, obj_cfg_map)
        print(f"[seeder] Seed connected IDs: { {k: len(v) for k,v in _seed_connected_ids.items()} }", flush=True)

        # id_map: { objectName: { old_source_id: new_dest_id } }
        id_map = {}
        # fetched_ids: { objectName: set of source IDs fetched } — for relationship filtering
        fetched_ids = {}
        # deferred_updates: list of { object, records: [{ Id, field, value }] }
        deferred_updates = []

        for idx, obj_name in enumerate(ordered):
            if job.get("_cancel"):
                job["status"] = "cancelled"
                job["message"] = "Job cancelled by user"
                break

            obj_cfg = obj_cfg_map.get(obj_name, {"name": obj_name})
            sample_size = obj_cfg.get("sampleSize", 100)
            user_fields = obj_cfg.get("fields")
            user_where = (obj_cfg.get("where") or "").strip()
            record_types = obj_cfg.get("recordTypes")
            obj_status = job["objects"][obj_name]

            try:
                obj_status["status"] = "fetching"
                obj_status["message"] = "Fetching records from source..."
                job["message"] = f"Fetching {obj_name}..."

                # Describe source
                desc = getattr(sf_source, obj_name).describe()
                all_fields = desc["fields"]
                src_field_map = {f["name"]: f for f in all_fields}

                # Describe destination
                dest_desc = getattr(sf_dest, obj_name).describe()
                dest_field_map = {f["name"]: f for f in dest_desc["fields"] if f.get("createable", False)}

                # Determine fields to select
                if user_fields:
                    # User selected specific fields — use those, but validate against dest
                    field_names = [f for f in user_fields if f not in _AUDIT_FIELDS and f in dest_field_map]
                else:
                    # Fall back to all createable fields
                    createable = [f for f in all_fields if f.get("createable", False)]
                    field_names = [f["name"] for f in createable if f["name"] not in _AUDIT_FIELDS and f["name"] in dest_field_map]

                # Classify reference fields
                ref_field_targets = {}    # { fieldName: targetObjectName } — points to already-loaded selected objects
                circular_ref_fields = {}  # { fieldName: targetObjectName } — points to not-yet-loaded selected objects
                drop_ref_fields = set()   # reference fields pointing to objects NOT in our set (nillable only)

                all_selected = set(ordered)
                circ_obj_set = set()
                for pair in circular_pairs:
                    circ_obj_set.update(pair)

                for fn in field_names:
                    src_f = src_field_map.get(fn, {})
                    if src_f.get("type") != "reference":
                        continue
                    refs_to = src_f.get("referenceTo") or []
                    matched = False
                    for ref_obj in refs_to:
                        if ref_obj in id_map:
                            ref_field_targets[fn] = ref_obj
                            matched = True
                            break
                        if ref_obj in all_selected and ref_obj not in id_map and ref_obj != obj_name:
                            if obj_name in circ_obj_set:
                                circular_ref_fields[fn] = ref_obj
                            matched = True
                            break
                    if not matched:
                        # Points to object(s) not in our selected set — IDs won't exist in dest
                        # Drop if nillable to avoid "insufficient access rights on cross-reference id"
                        dest_f = dest_field_map.get(fn, {})
                        if dest_f.get("nillable", True):
                            drop_ref_fields.add(fn)

                # Build WHERE conditions
                conditions = []

                # 1. User WHERE condition
                if user_where:
                    conditions.append(f"({user_where})")

                # 2. Record type filter
                if record_types:
                    rt_ids = [rt["id"] for rt in record_types]
                    if rt_ids:
                        rt_in = ",".join(f"'{rid}'" for rid in rt_ids)
                        conditions.append(f"RecordTypeId IN ({rt_in})")

                # 3. Smart parent selection using pre-discovered connected IDs
                parent_deps = dep_map.get(obj_name, [])
                has_large_smart = False
                smart_ids = None

                if obj_name in _seed_connected_ids and _seed_connected_ids[obj_name]:
                    smart_ids = _seed_connected_ids[obj_name]
                    print(f"[seeder] Smart selection: {len(smart_ids)} {obj_name} IDs with children", flush=True)
                    id_list = list(smart_ids)[:sample_size * 3]
                    if len(id_list) <= _ID_CHUNK_SIZE:
                        ids_str = ",".join(f"'{pid}'" for pid in id_list)
                        conditions.append(f"Id IN ({ids_str})")
                    else:
                        has_large_smart = True

                # 4. Relationship-aware WHERE: filter by parent IDs already fetched
                parent_ref_info = []  # list of (ref_field_names, parent_id_list)
                for parent_obj in parent_deps:
                    source_ids_set = fetched_ids.get(parent_obj, set())
                    if source_ids_set:
                        ref_fields = _get_ref_fields_for_dep(all_fields, parent_obj)
                        if ref_fields:
                            parent_ref_info.append((ref_fields, list(source_ids_set)))

                # For small parent sets, inline in WHERE. For large sets, we'll chunk queries.
                has_large_parent_filter = any(len(pids) > _ID_CHUNK_SIZE for _, pids in parent_ref_info)

                # Add small parent filters to conditions directly
                for ref_fields, parent_ids in parent_ref_info:
                    if len(parent_ids) <= _ID_CHUNK_SIZE:
                        ids_str = ",".join(f"'{pid}'" for pid in parent_ids)
                        ref_conds = [f"{rf} IN ({ids_str})" for rf in ref_fields]
                        conditions.append(f"({' OR '.join(ref_conds)})")

                where_clause = " AND ".join(conditions)

                # Ensure we always select Id for mapping
                select_fields = list(field_names)
                if "Id" not in select_fields:
                    select_fields.insert(0, "Id")

                # Also include circular ref fields for deferred updates
                for cf in circular_ref_fields:
                    if cf not in select_fields:
                        select_fields.append(cf)

                # Helper to run a single SOQL and collect records
                def _query_records(extra_where, limit):
                    parts = [where_clause, extra_where] if extra_where else [where_clause]
                    full_where = " AND ".join(p for p in parts if p)
                    soql = f"SELECT {', '.join(select_fields)} FROM {obj_name}"
                    if full_where:
                        soql += f" WHERE {full_where}"
                    soql += f" LIMIT {limit}"
                    print(f"[seeder] SOQL ({obj_name}): {soql[:300]}...")
                    res = sf_source.query_all(soql)
                    recs = [{k: v for k, v in rec.items() if k != "attributes"}
                            for rec in res.get("records", [])]
                    print(f"[seeder] {obj_name}: got {len(recs)} records")
                    return recs

                # Fetch records — chunk large filters
                if has_large_smart:
                    # Root parent with many connected children — chunk by Id
                    all_records = []
                    remaining = sample_size
                    id_list = list(smart_ids)
                    for i in range(0, len(id_list), _ID_CHUNK_SIZE):
                        if remaining <= 0:
                            break
                        chunk = id_list[i:i + _ID_CHUNK_SIZE]
                        ids_str = ",".join(f"'{pid}'" for pid in chunk)
                        chunk_where = f"Id IN ({ids_str})"
                        try:
                            batch = _query_records(chunk_where, remaining)
                            all_records.extend(batch)
                            remaining -= len(batch)
                        except Exception as e:
                            print(f"[seeder] Warning: smart chunk query for {obj_name}: {e}")
                    records = all_records
                elif has_large_parent_filter:
                    # Find the large parent filter and chunk it
                    all_records = []
                    remaining = sample_size
                    for ref_fields, parent_ids in parent_ref_info:
                        if len(parent_ids) <= _ID_CHUNK_SIZE:
                            continue
                        for chunk_start in range(0, len(parent_ids), _ID_CHUNK_SIZE):
                            if remaining <= 0:
                                break
                            chunk = parent_ids[chunk_start:chunk_start + _ID_CHUNK_SIZE]
                            ids_str = ",".join(f"'{pid}'" for pid in chunk)
                            ref_conds = [f"{rf} IN ({ids_str})" for rf in ref_fields]
                            chunk_where = f"({' OR '.join(ref_conds)})"
                            try:
                                batch = _query_records(chunk_where, remaining)
                                all_records.extend(batch)
                                remaining -= len(batch)
                            except Exception as e:
                                print(f"[seeder] Warning: chunk query for {obj_name} failed: {e}")
                    records = all_records
                elif record_types and len(record_types) > 1:
                    # Fetch per record type with individual limits
                    all_records = []
                    for rt in record_types:
                        rt_conds = [c for c in conditions if "RecordTypeId IN" not in c]
                        rt_conds.append(f"RecordTypeId = '{rt['id']}'")
                        rt_where = " AND ".join(rt_conds)
                        rt_limit = rt.get("sampleSize", sample_size)
                        soql = f"SELECT {', '.join(select_fields)} FROM {obj_name}"
                        if rt_where:
                            soql += f" WHERE {rt_where}"
                        soql += f" LIMIT {rt_limit}"
                        try:
                            result = sf_source.query_all(soql)
                            for rec in result.get("records", []):
                                row = {k: v for k, v in rec.items() if k != "attributes"}
                                all_records.append(row)
                        except Exception as e:
                            print(f"[seeder] Warning: failed to query {obj_name} RT {rt['name']}: {e}")
                    records = all_records
                else:
                    records = _query_records(None, sample_size)

                obj_status["fetched"] = len(records)
                obj_status["total"] = len(records)
                obj_status["progress"] = 30
                obj_status["message"] = f"Fetched {len(records)} records"

                # Track all fetched source IDs for downstream relationship filtering
                fetched_ids[obj_name] = set(r.get("Id") for r in records if r.get("Id"))

                if not records:
                    obj_status["status"] = "complete"
                    obj_status["progress"] = 100
                    obj_status["message"] = "No records to seed"
                    id_map[obj_name] = {}
                    job["completed_objects"] += 1
                    continue

                # Save source IDs before we strip Id
                source_ids = [r.get("Id") for r in records if r.get("Id")]

                # Remap reference fields to use destination IDs
                obj_status["status"] = "mapping"
                obj_status["message"] = "Remapping reference IDs..."
                obj_status["progress"] = 40

                unmapped_refs = set()
                for rec in records:
                    for ref_field, target_obj in ref_field_targets.items():
                        old_id = rec.get(ref_field)
                        if old_id and target_obj in id_map:
                            new_id = id_map[target_obj].get(old_id)
                            if new_id:
                                rec[ref_field] = new_id
                            else:
                                # Source ID not in our fetched set — null it out if nillable
                                src_f = src_field_map.get(ref_field, {})
                                if src_f.get("nillable", True):
                                    rec[ref_field] = None
                                    unmapped_refs.add(ref_field)
                                else:
                                    unmapped_refs.add(ref_field)

                # Save circular ref values for deferred update, then remove from insert
                deferred_recs = []
                for rec in records:
                    deferred = {}
                    for cf, target_obj in circular_ref_fields.items():
                        if rec.get(cf):
                            deferred[cf] = rec[cf]  # save source ID
                            rec[cf] = None  # null out for initial insert
                    if deferred:
                        deferred["_source_id"] = rec.get("Id")
                        deferred_recs.append(deferred)

                # Strip Id, circular ref fields, and dropped ref fields from insert payload
                insert_records = []
                insert_field_set = set(fn for fn in field_names if fn in dest_field_map)
                insert_field_set -= set(circular_ref_fields.keys())
                insert_field_set -= drop_ref_fields

                for rec in records:
                    row = {}
                    for fn in insert_field_set:
                        if fn in rec and fn != "Id":
                            row[fn] = rec[fn]
                    insert_records.append(row)

                # Apply PII masking
                rules = masking_rules_map.get(obj_name, [])
                if rules:
                    obj_status["status"] = "masking"
                    obj_status["message"] = f"Masking {len(rules)} PII fields..."
                    obj_status["progress"] = 50
                    apply_masking(insert_records, rules)

                # Insert into destination
                obj_status["status"] = "inserting"
                obj_status["message"] = "Inserting into destination..."
                obj_status["progress"] = 60

                try:
                    result = salesforce_client.bulk_insert(sf_dest, obj_name, insert_records)
                except Exception as e:
                    if "InvalidSessionId" in str(e) or "INVALID_SESSION_ID" in str(e):
                        dest_conn = config.get_salesforce(dest_conn_id)
                        sf_dest = salesforce_client.connect(dest_conn)
                        result = salesforce_client.bulk_insert(sf_dest, obj_name, insert_records)
                    else:
                        raise

                inserted = result.get("success_count", 0)
                errors = result.get("error_count", 0)

                # Build old→new ID map from insert results
                id_map[obj_name] = {}
                for res in result.get("record_results", []):
                    row_idx = res.get("row", 0) - 1  # row is 1-based
                    if res.get("success") and res.get("id") and 0 <= row_idx < len(source_ids):
                        id_map[obj_name][source_ids[row_idx]] = res["id"]

                # Queue deferred updates for circular deps
                if deferred_recs and circular_ref_fields:
                    deferred_updates.append({
                        "object": obj_name,
                        "records": deferred_recs,
                        "circular_fields": circular_ref_fields,
                    })

                obj_status["inserted"] = inserted
                obj_status["progress"] = 100
                if unmapped_refs:
                    obj_status["message"] = f"Inserted {inserted} records ({len(unmapped_refs)} ref fields had unmapped IDs)"
                elif errors > 0:
                    err_msgs = [e.get("message", "") for e in result.get("errors", [])[:3]]
                    obj_status["message"] = f"Inserted {inserted}, {errors} errors: {'; '.join(err_msgs)}"
                    obj_status["status"] = "complete_with_errors"
                else:
                    obj_status["message"] = f"Inserted {inserted} records"
                    obj_status["status"] = "complete"

                if obj_status["status"] != "complete_with_errors":
                    obj_status["status"] = "complete"
                job["completed_objects"] += 1
                job["total_records_inserted"] += inserted

            except Exception as e:
                traceback.print_exc()
                obj_status["status"] = "error"
                obj_status["message"] = str(e)
                obj_status["progress"] = 0
                job["error_objects"] += 1
                id_map[obj_name] = {}
                if obj_name not in fetched_ids:
                    fetched_ids[obj_name] = set()

            # Update overall progress
            done = job["completed_objects"] + job["error_objects"]
            job["progress"] = int((done / total_objects) * 90) if total_objects > 0 else 90

        # ── Phase 2: Deferred updates for circular dependencies ──
        if deferred_updates and not job.get("_cancel"):
            job["message"] = "Updating circular reference fields..."
            for deferred in deferred_updates:
                obj_name = deferred["object"]
                circ_fields = deferred["circular_fields"]
                recs = deferred["records"]
                obj_status = job["objects"].get(obj_name)

                update_records = []
                for rec in recs:
                    source_id = rec.get("_source_id")
                    new_id = id_map.get(obj_name, {}).get(source_id)
                    if not new_id:
                        continue
                    update = {"Id": new_id}
                    has_update = False
                    for cf, target_obj in circ_fields.items():
                        old_ref = rec.get(cf)
                        if old_ref and target_obj in id_map:
                            new_ref = id_map[target_obj].get(old_ref)
                            if new_ref:
                                update[cf] = new_ref
                                has_update = True
                    if has_update:
                        update_records.append(update)

                if update_records:
                    if obj_status:
                        obj_status["message"] = f"Updating {len(update_records)} circular refs..."
                    try:
                        salesforce_client.bulk_update(sf_dest, obj_name, update_records)
                        if obj_status:
                            obj_status["message"] += f" Done. {obj_status.get('inserted', 0)} records total."
                    except Exception as e:
                        print(f"[seeder] Deferred update for {obj_name} failed: {e}")
                        if obj_status:
                            obj_status["message"] += f" (circular ref update failed: {e})"

        job["status"] = "complete"
        job["progress"] = 100
        job["message"] = f"Seeding complete: {job['total_records_inserted']} records inserted across {job['completed_objects']} objects"
        if job["error_objects"] > 0:
            job["message"] += f" ({job['error_objects']} objects had errors)"
        if deferred_updates:
            job["message"] += " (circular refs updated)"

    except Exception as e:
        traceback.print_exc()
        job["status"] = "error"
        job["message"] = str(e)
    finally:
        job["running"] = False
        job["finished_at"] = datetime.datetime.now().isoformat()
        try:
            store.save_job(job)
        except Exception:
            pass
