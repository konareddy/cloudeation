from flask import Flask, request, jsonify, Response, send_from_directory
from flask_cors import CORS
import io
import os
import csv
import uuid
import store
import config
import salesforce_client
import db_client
import downloader
import uploader
import attachment_handler
import quick_loader
import pipeline
import cli_handler
import script_runner
import secrets
import urllib.parse
import hashlib
import random
import string
from datetime import datetime, timedelta

# Initialize SQLite database (schema + migration from config.json)
store.init()

# Resolve the frontend dist directory (bundled alongside backend)
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "static")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
CORS(app)


@app.route("/")
def serve_index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/<path:path>")
def serve_frontend(path):
    # API paths should never fall through to SPA — return proper JSON 404
    if path.startswith("api/"):
        return jsonify({"error": "Not found"}), 404
    # Serve static file if it exists, otherwise fall back to index.html (SPA)
    file_path = os.path.join(FRONTEND_DIR, path)
    if os.path.isfile(file_path):
        return send_from_directory(FRONTEND_DIR, path)
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/api/connections", methods=["GET"])
def get_connections():
    return jsonify(config.get_all())


@app.route("/api/connections/salesforce", methods=["POST"])
def save_sf_connection():
    conn = request.json
    if not conn.get("id"):
        import time
        conn["id"] = str(int(time.time() * 1000))
    saved = config.upsert_salesforce(conn)
    return jsonify(saved)


@app.route("/api/connections/database", methods=["POST"])
def save_db_connection():
    conn = request.json
    if not conn.get("id"):
        import time
        conn["id"] = str(int(time.time() * 1000))
    saved = config.upsert_database(conn)
    return jsonify(saved)


@app.route("/api/connections/<conn_type>/<conn_id>", methods=["DELETE"])
def delete_connection(conn_type, conn_id):
    config.delete_connection(conn_type, conn_id)
    return jsonify({"success": True})


@app.route("/api/saved-steps", methods=["GET"])
def get_saved_steps():
    return jsonify({"steps": store.get_saved_steps()})


@app.route("/api/saved-steps", methods=["POST"])
def create_saved_step():
    import time
    body = request.json
    step = {
        "id": body.get("id") or str(int(time.time() * 1000)),
        "name": body.get("name"),
        "type": body.get("type"),
        "config": body.get("config"),
        "savedAt": body.get("savedAt"),
    }
    store.upsert_saved_step(step)
    return jsonify(step)


@app.route("/api/saved-steps/<step_id>", methods=["DELETE"])
def delete_saved_step(step_id):
    store.delete_saved_step(step_id)
    return jsonify({"ok": True})


@app.route("/api/salesforce/test", methods=["POST"])
def test_sf():
    conn = request.json
    result = salesforce_client.test_connection(conn)
    return jsonify(result)


@app.route("/api/salesforce/oauth/authorize", methods=["GET"])
def oauth_authorize():
    """Build the SF authorize URL. All state kept client-side."""
    login_url = request.args.get("loginUrl", "https://login.salesforce.com")
    client_id = request.args.get("clientId", "")
    redirect_uri = request.args.get("redirectUri", "")
    code_challenge = request.args.get("codeChallenge", "")

    state = secrets.token_urlsafe(32)

    authorize_params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "state": state,
        "scope": "api",
    }
    if code_challenge:
        authorize_params["code_challenge"] = code_challenge
        authorize_params["code_challenge_method"] = "S256"

    params = urllib.parse.urlencode(authorize_params)
    authorize_url = f"{login_url}/services/oauth2/authorize?{params}"
    return jsonify({"authorizeUrl": authorize_url, "state": state})


@app.route("/api/salesforce/oauth/token", methods=["POST"])
def oauth_token():
    """Exchange authorization code for tokens and save connection. Stateless — all data from client."""
    body = request.json
    code = body.get("code")
    login_url = body.get("loginUrl", "https://login.salesforce.com")
    client_id = body.get("clientId", "")
    client_secret = body.get("clientSecret", "")
    redirect_uri = body.get("redirectUri", "")
    code_verifier = body.get("codeVerifier", "")
    conn_data = body.get("connData", {})

    try:
        token_data = salesforce_client.exchange_code_for_tokens(
            code=code,
            client_id=client_id,
            client_secret=client_secret,
            login_url=login_url,
            redirect_uri=redirect_uri,
            code_verifier=code_verifier,
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    # Build connection record
    import time
    conn = {
        "id": conn_data.get("id", "") or str(int(time.time() * 1000)),
        "name": conn_data.get("name", "") or "Salesforce",
        "loginUrl": login_url,
        "clientId": client_id,
        "clientSecret": client_secret,
        "accessToken": token_data["access_token"],
        "refreshToken": token_data.get("refresh_token", ""),
        "instanceUrl": token_data["instance_url"],
    }
    # Preserve usage settings from existing connection
    if conn_data.get("usage"):
        conn["usage"] = conn_data["usage"]
    saved = config.upsert_salesforce(conn)
    return jsonify({"success": True, "connection": saved})


@app.route("/api/salesforce/<conn_id>/objects", methods=["GET"])
def list_sf_objects(conn_id):
    conn = config.get_salesforce(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    try:
        sf = salesforce_client.connect(conn)
        objects = salesforce_client.list_objects_fast(sf)
        return jsonify(objects)
    except Exception as e:
        err_msg = str(e)
        needs_reauth = "re-authenticate" in err_msg.lower() or "session expired" in err_msg.lower()
        return jsonify({"error": err_msg, "needsReauth": needs_reauth}), 500


@app.route("/api/salesforce/<conn_id>/object/<object_name>/fields", methods=["GET"])
def get_object_fields(conn_id, object_name):
    conn = config.get_salesforce(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    try:
        sf = salesforce_client.connect(conn)
        desc = getattr(sf, object_name).describe()
        fields = []
        for f in desc["fields"]:
            fields.append({
                "name": f["name"],
                "label": f["label"],
                "type": f["type"],
                "createable": f.get("createable", False),
                "updateable": f.get("updateable", False),
                "nillable": f.get("nillable", False),
                "defaultedOnCreate": f.get("defaultedOnCreate", False),
                "referenceTo": f.get("referenceTo", []),
            })
        return jsonify(fields)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/salesforce/<conn_id>/object/<object_name>/lookups", methods=["GET"])
def get_object_lookups(conn_id, object_name):
    """Return lookup/reference fields with detail for dependency tree building."""
    conn = config.get_salesforce(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    SKIP = {"User", "RecordType", "BusinessHours", "Organization", "Profile",
            "UserRole", "Group", "DandBCompany", "BusinessProcess", "ListView"}
    try:
        sf = salesforce_client.connect(conn)
        desc = getattr(sf, object_name).describe()
        lookups = []
        field_names = []
        for f in desc["fields"]:
            if f["type"] == "reference" and f.get("referenceTo") and f.get("createable"):
                targets = [r for r in f["referenceTo"] if r not in SKIP and r != object_name]
                if not targets:
                    continue
                lookups.append({
                    "fieldName": f["name"],
                    "fieldLabel": f.get("label", f["name"]),
                    "required": not f.get("nillable", True) and not f.get("defaultedOnCreate", False),
                    "referenceTo": targets,
                })
                field_names.append(f["name"])

        # Get population counts in one SOQL query
        if field_names:
            try:
                counts_expr = ", ".join(f"COUNT({fn}) {fn}" for fn in field_names)
                result = sf.query(f"SELECT {counts_expr} FROM {object_name}")
                if result.get("records"):
                    counts = result["records"][0]
                    for lk in lookups:
                        lk["populatedCount"] = counts.get(lk["fieldName"], 0)
            except Exception as e:
                print(f"[lookups] Count query failed for {object_name}: {e}", flush=True)

        return jsonify(lookups)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/salesforce/<conn_id>/object/<object_name>/field-stats", methods=["POST"])
def get_field_stats(conn_id, object_name):
    """Return record counts for dependency estimation.
    Body: { fields: ["Sales_Area__c", ...] }
    Returns: { "Sales_Area__c": { populated: 226, distinct: 45 }, ... }
    """
    conn = config.get_salesforce(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    body = request.json or {}
    fields = body.get("fields", [])
    if not fields:
        return jsonify({})
    try:
        sf = salesforce_client.connect(conn)
        result = {}
        for fname in fields:
            try:
                q = f"SELECT COUNT_DISTINCT({fname}) cnt FROM {object_name} WHERE {fname} != null"
                res = sf.query(q)
                distinct = res["records"][0]["cnt"] if res.get("records") else 0
                q2 = f"SELECT COUNT() FROM {object_name} WHERE {fname} != null"
                res2 = sf.query(q2)
                populated = res2.get("totalSize", 0)
                result[fname] = {"populated": populated, "distinct": distinct}
            except Exception as e:
                result[fname] = {"populated": 0, "distinct": 0, "error": str(e)}
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/salesforce/<conn_id>/object/<object_name>/dependencies", methods=["GET"])
def get_object_dependencies(conn_id, object_name):
    conn = config.get_salesforce(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    try:
        sf = salesforce_client.connect(conn)
        desc = getattr(sf, object_name).describe()
        deps = []
        seen = set()
        for f in desc["fields"]:
            if f["type"] == "reference" and f.get("referenceTo"):
                for ref in f["referenceTo"]:
                    if ref not in seen and ref != object_name:
                        seen.add(ref)
                        deps.append({"apiName": ref, "fieldName": f["name"], "fieldLabel": f["label"]})
        return jsonify(deps)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/salesforce/<conn_id>/object/<object_name>/recordtypes", methods=["GET"])
def get_object_record_types(conn_id, object_name):
    conn = config.get_salesforce(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    try:
        sf = salesforce_client.connect(conn)
        desc = getattr(sf, object_name).describe()
        rts = []
        for rt in desc.get("recordTypeInfos", []):
            if rt.get("available", True) and rt.get("recordTypeId") != "012000000000000AAA":
                rts.append({
                    "id": rt["recordTypeId"],
                    "name": rt["name"],
                    "developerName": rt.get("developerName", rt["name"]),
                    "default": rt.get("defaultRecordTypeMapping", False),
                })
        return jsonify(rts)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/database/test", methods=["POST"])
def test_db():
    conn = request.json
    result = db_client.test_connection(conn)
    return jsonify(result)


@app.route("/api/database/<conn_id>/databases", methods=["GET"])
def list_databases(conn_id):
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    try:
        db_type = conn.get("dbType", "")
        if db_type == "duckdb":
            filepath = os.path.expanduser(conn.get("filepath", "~/sfdc-loader/duckdb"))
            os.makedirs(filepath, exist_ok=True)
            databases = [f[:-7] for f in os.listdir(filepath) if f.endswith(".duckdb")]
            if not databases:
                databases = ["default"]
            return jsonify({"databases": sorted(databases)})
        if db_type == "athena":
            db = db_client.get_connection(conn)
            cur = db.cursor()
            cur.execute("SHOW DATABASES")
            databases = [row[0] for row in cur.fetchall()]
            cur.close()
            db.close()
            return jsonify({"databases": databases})
        if db_type == "mysql":
            db = db_client.get_connection(conn)
            cur = db.cursor()
            cur.execute("SHOW DATABASES")
            databases = [row[0] for row in cur.fetchall()]
            cur.close()
            db.close()
            return jsonify({"databases": databases})
        # PostgreSQL / Redshift
        db = db_client.get_connection(conn)
        cur = db.cursor()
        cur.execute("SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname")
        databases = [row[0] for row in cur.fetchall()]
        cur.close()
        db.close()
        return jsonify({"databases": databases})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/database/<conn_id>/create-database", methods=["POST"])
def create_database(conn_id):
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    db_name = (request.json or {}).get("name", "").strip()
    if not db_name:
        return jsonify({"error": "Database name is required"}), 400
    if not all(c.isalnum() or c == '_' for c in db_name):
        return jsonify({"error": "Database name must contain only letters, numbers, and underscores"}), 400
    try:
        db_type = conn.get("dbType", "")
        if db_type == "duckdb":
            # Creating a DuckDB database = creating a new .duckdb file
            db = db_client.get_connection(conn, database=db_name)
            db.close()
        elif db_type == "athena":
            db = db_client.get_connection(conn)
            cur = db.cursor()
            cur.execute(f"CREATE DATABASE `{db_name}`")
            cur.close()
            db.close()
        elif db_type == "mysql":
            db = db_client.get_connection(conn)
            cur = db.cursor()
            cur.execute(f"CREATE DATABASE `{db_name}`")
            cur.close()
            db.close()
        else:
            # PostgreSQL / Redshift: CREATE DATABASE requires autocommit
            db = db_client.get_connection(conn)
            db.autocommit = True
            cur = db.cursor()
            cur.execute(f'CREATE DATABASE "{db_name}"')
            cur.close()
            db.close()
        return jsonify({"success": True, "database": db_name})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/database/<conn_id>/tables", methods=["GET"])
def list_db_tables(conn_id):
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    # Allow overriding the database via query param
    db_override = request.args.get("database")
    if db_override:
        conn = {**conn, "database": db_override}
    try:
        db_type = conn.get("dbType", "")
        is_athena = db_type == "athena"
        is_mysql = db_type == "mysql"
        is_duckdb = db_type == "duckdb"
        db = db_client.get_connection(conn)
        cur = db.cursor()
        table_comments = {}
        if is_duckdb:
            cur.execute("SHOW TABLES")
            tables = [row[0] for row in cur.fetchall()]
            # Fetch table comments for DuckDB
            try:
                cur.execute("SELECT table_name, comment FROM duckdb_tables() WHERE comment IS NOT NULL AND comment != ''")
                for tname, tcomment in cur.fetchall():
                    table_comments[tname] = tcomment
            except Exception:
                pass
        elif is_athena:
            cur.execute("SHOW TABLES")
            tables = [row[0] for row in cur.fetchall()]
        elif is_mysql:
            cur.execute("SHOW TABLES")
            tables = [row[0] for row in cur.fetchall()]
            # Fetch table comments for MySQL
            try:
                db_name = conn.get("database") or ""
                if db_name:
                    cur.execute(f"SELECT table_name, table_comment FROM information_schema.tables WHERE table_schema = %s", (db_name,))
                    for tname, tcomment in cur.fetchall():
                        if tcomment:
                            table_comments[tname] = tcomment
            except Exception:
                pass
        else:
            cur.execute("""
                SELECT table_name
                FROM information_schema.tables
                WHERE table_schema = 'public'
                ORDER BY table_name
            """)
            tables = [row[0] for row in cur.fetchall()]
            # Fetch table comments for PostgreSQL
            try:
                cur.execute("""
                    SELECT c.relname, d.description
                    FROM pg_catalog.pg_class c
                    JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                    LEFT JOIN pg_catalog.pg_description d ON d.objoid = c.oid AND d.objsubid = 0
                    WHERE n.nspname = 'public' AND c.relkind = 'r' AND d.description IS NOT NULL
                """)
                for tname, desc in cur.fetchall():
                    table_comments[tname] = desc
            except Exception:
                pass
        cur.close()
        db.close()
        dbname = conn.get("database") or "default"
        return jsonify({"database": dbname, "tables": tables, "tableComments": table_comments})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/database/<conn_id>/tables/<table_name>/columns", methods=["GET"])
def table_columns(conn_id, table_name):
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    db_override = request.args.get("database")
    if db_override:
        conn = {**conn, "database": db_override}
    try:
        db_type = conn.get("dbType", "")
        is_athena = db_type == "athena"
        is_mysql = db_type == "mysql"
        is_duckdb = db_type == "duckdb"
        db = db_client.get_connection(conn)
        cur = db.cursor()
        if is_duckdb:
            cur.execute("SELECT column_name, data_type FROM information_schema.columns WHERE table_name = ? ORDER BY ordinal_position", (table_name,))
            columns = [{"name": row[0], "type": row[1]} for row in cur.fetchall()]
        elif is_athena:
            cur.execute(f"DESCRIBE {table_name}")
            columns = []
            for row in cur.fetchall():
                # Athena DESCRIBE returns tab-separated name/type in a single column
                parts = row[0].split("\t")
                parts = [p.strip() for p in parts if p.strip()]
                if len(parts) >= 2 and not parts[0].startswith("#"):
                    columns.append({"name": parts[0], "type": parts[1]})
        elif is_mysql:
            cur.execute(f"SHOW COLUMNS FROM `{table_name}`")
            columns = [{"name": row[0], "type": row[1]} for row in cur.fetchall()]
        else:
            cur.execute("""
                SELECT column_name, data_type
                FROM information_schema.columns
                WHERE table_schema = 'public' AND table_name = %s
                ORDER BY ordinal_position
            """, (table_name,))
            columns = [{"name": row[0], "type": row[1]} for row in cur.fetchall()]
        cur.close()
        db.close()
        return jsonify({"table": table_name, "columns": columns})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/database/<conn_id>/tables/<table_name>/sample", methods=["GET"])
def sample_table(conn_id, table_name):
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    db_override = request.args.get("database")
    if db_override:
        conn = {**conn, "database": db_override}
    try:
        db_type = conn.get("dbType", "")
        is_athena = db_type == "athena"
        is_mysql = db_type == "mysql"
        is_duckdb = db_type == "duckdb"
        db = db_client.get_connection(conn)
        cur = db.cursor()
        if not is_athena and not is_mysql and not is_duckdb:
            # Sanitize table name (PostgreSQL / Redshift)
            cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_name=%s", (table_name,))
            if not cur.fetchone():
                cur.close()
                db.close()
                return jsonify({"error": "Table not found"}), 404
        if is_athena:
            quote = ''
        elif is_mysql:
            quote = '`'
        else:
            quote = '"'
        cur.execute(f'SELECT * FROM {quote}{table_name}{quote} LIMIT 25')
        columns = [desc[0] for desc in cur.description]
        rows = []
        for row in cur.fetchall():
            rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
        cur.execute(f'SELECT COUNT(*) FROM {quote}{table_name}{quote}')
        count = cur.fetchone()[0]
        cur.close()
        db.close()
        return jsonify({"table": table_name, "columns": columns, "rows": rows, "totalRows": count})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/database/<conn_id>/query", methods=["POST"])
def run_sql_query(conn_id):
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    db_override = request.json.get("database")
    if db_override:
        conn = {**conn, "database": db_override}
    sql = request.json.get("sql", "").strip()
    if not sql:
        return jsonify({"error": "No SQL provided"}), 400
    try:
        pg = db_client.get_connection(conn)
        cur = pg.cursor()
        cur.execute(sql)
        # Check if query returns rows
        if cur.description:
            columns = [desc[0] for desc in cur.description]
            rows = []
            for row in cur.fetchall():
                rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
            result = {"columns": columns, "rows": rows, "rowCount": len(rows)}
        else:
            pg.commit()
            result = {"columns": [], "rows": [], "rowCount": cur.rowcount, "message": f"{cur.rowcount} row(s) affected"}
        cur.close()
        pg.close()
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/salesforce/<conn_id>/describe/<object_name>", methods=["GET"])
def describe_sf_object(conn_id, object_name):
    conn_data = config.get_salesforce(conn_id)
    if not conn_data:
        return jsonify({"error": "Connection not found"}), 404
    try:
        sf = salesforce_client.connect(conn_data)
        desc = getattr(sf, object_name).describe()
        fields = []
        for f in desc["fields"]:
            field = {
                "name": f["name"],
                "label": f["label"],
                "type": f["type"],
                "length": f.get("length", 0),
                "precision": f.get("precision", 0),
                "scale": f.get("scale", 0),
                "nillable": f.get("nillable", False),
                "unique": f.get("unique", False),
                "createable": f.get("createable", False),
                "updateable": f.get("updateable", False),
                "filterable": f.get("filterable", False),
                "sortable": f.get("sortable", False),
                "defaultValue": f.get("defaultValue"),
                "referenceTo": f.get("referenceTo", []),
                "relationshipName": f.get("relationshipName"),
                "externalId": f.get("externalId", False),
                "autoNumber": f.get("autoNumber", False),
                "calculated": f.get("calculated", False),
                "defaultedOnCreate": f.get("defaultedOnCreate", False),
                "picklistValues": f.get("picklistValues", []),
            }
            fields.append(field)
        obj_info = {
            "name": desc.get("name", object_name),
            "label": desc.get("label", ""),
            "keyPrefix": desc.get("keyPrefix", ""),
            "queryable": desc.get("queryable", False),
            "createable": desc.get("createable", False),
            "updateable": desc.get("updateable", False),
            "deletable": desc.get("deletable", False),
            "custom": desc.get("custom", False),
        }
        return jsonify({"fields": fields, "objectInfo": obj_info})
    except Exception as e:
        err_msg = str(e)
        needs_reauth = "re-authenticate" in err_msg.lower() or "session expired" in err_msg.lower()
        return jsonify({"error": err_msg, "needsReauth": needs_reauth}), 400


@app.route("/api/salesforce/<conn_id>/preview/<object_name>", methods=["GET"])
def preview_sf_object(conn_id, object_name):
    """Return sample records from a Salesforce object."""
    conn_data = config.get_salesforce(conn_id)
    if not conn_data:
        return jsonify({"error": "Connection not found"}), 404
    limit = request.args.get("limit", 10, type=int)
    if limit > 50:
        limit = 50
    try:
        sf = salesforce_client.connect(conn_data)
        desc = getattr(sf, object_name).describe()
        # Pick first queryable fields (max 20 to keep response manageable)
        field_names = [f["name"] for f in desc["fields"] if f.get("type") != "address"][:20]
        if not field_names:
            field_names = ["Id"]
        soql = f"SELECT {', '.join(field_names)} FROM {object_name} LIMIT {limit}"
        result = sf.query(soql)
        rows = []
        for rec in result.get("records", []):
            row = dict(rec)
            row.pop("attributes", None)
            rows.append(row)
        return jsonify({"columns": field_names, "rows": rows, "rowCount": len(rows), "totalSize": result.get("totalSize", 0)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/salesforce/<conn_id>/recordcount/<object_name>", methods=["GET"])
def sf_record_count(conn_id, object_name):
    """Get record count for an object (async call)."""
    conn_data = config.get_salesforce(conn_id)
    if not conn_data:
        return jsonify({"error": "Connection not found"}), 404
    try:
        sf = salesforce_client.connect(conn_data)
        result = sf.query(f"SELECT COUNT() FROM {object_name}")
        return jsonify({"count": result.get("totalSize", 0)})
    except Exception as e:
        return jsonify({"count": None, "error": str(e)})


@app.route("/api/salesforce/<conn_id>/fieldcounts/<object_name>", methods=["POST"])
def sf_field_counts(conn_id, object_name):
    """Get record counts where each field is not null."""
    conn_data = config.get_salesforce(conn_id)
    if not conn_data:
        return jsonify({"error": "Connection not found"}), 404
    fields = (request.json or {}).get("fields", [])
    if not fields:
        return jsonify({"counts": {}})
    try:
        sf = salesforce_client.connect(conn_data)
        counts = {}
        for fname in fields:
            try:
                result = sf.query(f"SELECT COUNT() FROM {object_name} WHERE {fname} != null")
                counts[fname] = result.get("totalSize", 0)
            except Exception:
                counts[fname] = 0
        return jsonify({"counts": counts})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ---------------------------------------------------------------------------
# Seed Templates
# ---------------------------------------------------------------------------

@app.route("/api/seed/templates", methods=["GET"])
def list_seed_templates():
    return jsonify(store.get_seed_templates())


@app.route("/api/seed/templates", methods=["POST"])
def save_seed_template():
    body = request.json
    if not body.get("id"):
        body["id"] = str(uuid.uuid4())[:8]
    saved = store.upsert_seed_template(body)
    return jsonify(saved)


@app.route("/api/seed/templates/<template_id>", methods=["DELETE"])
def delete_seed_template(template_id):
    store.delete_seed_template(template_id)
    return jsonify({"success": True})


@app.route("/api/seed/mapping-table", methods=["POST"])
def create_seed_mapping_table():
    """Create or ensure mapping table exists for source->dest org pair."""
    body = request.json or {}
    source_name = body.get("sourceName", "").strip()
    dest_name = body.get("destName", "").strip()
    if not source_name or not dest_name:
        return jsonify({"error": "sourceName and destName required"}), 400
    table = store.ensure_seed_mapping_table(source_name, dest_name)
    return jsonify({"table": table})


@app.route("/api/seed/mappings/<table_name>", methods=["GET"])
def get_seed_mappings(table_name):
    """Get mappings from a seed mapping table."""
    object_name = request.args.get("object")
    limit = int(request.args.get("limit", 500))
    try:
        rows = store.get_seed_mappings(table_name, object_name, limit)
        return jsonify(rows)
    except Exception as e:
        return jsonify({"error": str(e)}), 500


def _apply_masking(value, rule):
    """Apply a masking rule to a single field value. Returns the masked value."""
    if value is None:
        return None
    technique = rule.get("technique", "none")
    if technique == "none":
        return value

    s = str(value)

    # ── String masking ──
    if technique == "redact":
        return "XXXXX"
    if technique == "partial_mask":
        show = rule.get("showChars", 2)
        if len(s) <= show * 2:
            return "*" * len(s)
        return s[:show] + "*" * (len(s) - show * 2) + s[-show:]
    if technique == "hash":
        return hashlib.sha256(s.encode()).hexdigest()[:16]
    if technique == "fake_name":
        first_names = ["Alex", "Jordan", "Taylor", "Morgan", "Casey", "Riley", "Quinn", "Avery", "Parker", "Sage"]
        last_names = ["Smith", "Johnson", "Brown", "Davis", "Wilson", "Miller", "Moore", "Taylor", "Anderson", "Thomas"]
        return random.choice(first_names) + " " + random.choice(last_names)
    if technique == "random_string":
        length = max(len(s), 8)
        return "".join(random.choices(string.ascii_letters + string.digits, k=length))
    if technique == "prefix":
        return (rule.get("value", "MASKED_") or "MASKED_") + s
    if technique == "suffix":
        return s + (rule.get("value", "_MASKED") or "_MASKED")
    if technique == "constant":
        return rule.get("value", "")
    if technique == "shuffle":
        chars = list(s)
        random.shuffle(chars)
        return "".join(chars)
    if technique == "null_out":
        return None

    # ── Email masking ──
    if technique == "fake_email":
        user = "".join(random.choices(string.ascii_lowercase, k=8))
        return f"{user}@example.com"
    if technique == "domain_replace":
        domain = rule.get("value", "example.com") or "example.com"
        if "@" in s:
            local = s.split("@")[0]
            return f"{local}@{domain}"
        return s
    if technique == "hash_email":
        if "@" in s:
            local, domain = s.split("@", 1)
            hashed = hashlib.sha256(local.encode()).hexdigest()[:10]
            return f"{hashed}@{domain}"
        return s

    # ── Phone masking ──
    if technique == "random_phone":
        digits = "".join(random.choices(string.digits, k=10))
        return f"{digits[:3]}-{digits[3:6]}-{digits[6:]}"
    if technique == "random_digits":
        length = rule.get("length", 10)
        return "".join(random.choices(string.digits, k=length))

    # ── Number masking ──
    if technique == "round":
        try:
            precision = rule.get("precision", 10)
            num = float(value)
            return round(num / precision) * precision
        except (ValueError, TypeError):
            return value
    if technique == "range_random":
        try:
            mn = float(rule.get("min", 0))
            mx = float(rule.get("max", 100))
            if isinstance(value, int):
                return random.randint(int(mn), int(mx))
            return round(random.uniform(mn, mx), 2)
        except (ValueError, TypeError):
            return value
    if technique == "add_noise":
        try:
            pct = rule.get("percent", 10) / 100.0
            num = float(value)
            noise = num * random.uniform(-pct, pct)
            result = num + noise
            return round(result, 2) if isinstance(value, float) else int(round(result))
        except (ValueError, TypeError):
            return value
    if technique == "zero":
        return 0

    # ── Date masking ──
    if technique == "date_shift":
        try:
            days = rule.get("days", 30)
            for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S.%f+0000", "%Y-%m-%d"):
                try:
                    dt = datetime.strptime(s.replace("+0000", "+00:00").rstrip("Z") if "Z" in s else s, fmt.replace("%z", ""))
                    shifted = dt + timedelta(days=days)
                    return shifted.strftime(fmt.split(".")[0].replace("%z", "")) + ("+0000" if "+" in s or "Z" in s else "")
                except ValueError:
                    continue
            # Fallback: just return original
            return value
        except Exception:
            return value
    if technique == "year_only":
        try:
            year = s[:4]
            return f"{year}-01-01" + s[10:] if len(s) > 10 else f"{year}-01-01"
        except Exception:
            return value
    if technique == "random_date":
        try:
            start = datetime.strptime(rule.get("startDate", "2020-01-01"), "%Y-%m-%d")
            end = datetime.strptime(rule.get("endDate", "2025-12-31"), "%Y-%m-%d")
            delta = (end - start).days
            rand_date = start + timedelta(days=random.randint(0, max(delta, 1)))
            if "T" in s:
                return rand_date.strftime("%Y-%m-%dT%H:%M:%S.000+0000")
            return rand_date.strftime("%Y-%m-%d")
        except Exception:
            return value

    # ── Boolean masking ──
    if technique == "randomize":
        return random.choice([True, False])
    if technique == "always_true":
        return True
    if technique == "always_false":
        return False

    return value


@app.route("/api/seed/push", methods=["POST"])
def seed_push_records():
    """Push records from source org to destination org.

    For each source record:
    - Check mapping table for existing destination_id
    - If destination_id exists: update the record in dest org
    - If not: insert a new record and save the mapping
    - Remap lookup/reference field values using the mapping table
    """
    body = request.json or {}
    source_conn_id = body.get("sourceConnId")
    dest_conn_id = body.get("destConnId")
    mapping_table = body.get("mappingTable")
    object_name = body.get("objectName")
    source_ids = body.get("sourceIds", [])
    fields = body.get("fields", [])
    masking_rules = body.get("maskingRules", {})

    if not all([source_conn_id, dest_conn_id, mapping_table, object_name, source_ids]):
        return jsonify({"error": "Missing required parameters"}), 400

    try:
        # Load seed settings
        _seed_settings = store.get_setting("seed_settings", {})
        _email_suffix = _seed_settings.get("emailSuffix", SEED_DEFAULTS["emailSuffix"])
        if not _email_suffix:
            _email_suffix = ""  # empty = don't append

        # Connect to both orgs
        src_conn = config.get_salesforce(source_conn_id)
        dst_conn = config.get_salesforce(dest_conn_id)
        if not src_conn:
            return jsonify({"error": "Source connection not found"}), 404
        if not dst_conn:
            return jsonify({"error": "Destination connection not found"}), 404
        sf_src = salesforce_client.connect(src_conn)
        sf_dst = salesforce_client.connect(dst_conn)

        # Describe object in SOURCE to know field types (for reference detection)
        src_desc = getattr(sf_src, object_name).describe()
        src_field_meta = {f["name"]: f for f in src_desc["fields"]}

        # Describe object in DESTINATION to know which fields are createable/updateable
        dst_desc = getattr(sf_dst, object_name).describe()
        dst_field_meta = {f["name"]: f for f in dst_desc["fields"]}
        createable_fields = {f["name"] for f in dst_desc["fields"] if f.get("createable")}
        updateable_fields = {f["name"] for f in dst_desc["fields"] if f.get("updateable")}

        # Compound field types that cannot be used in DML or bulk queries
        compound_types = {"address", "location"}

        # Fields with unique / externalId constraints — skip these during UPDATE
        # (their values shouldn't change after initial insert)
        unique_fields = {
            f["name"] for f in dst_desc["fields"]
            if f.get("externalId") or f.get("unique")
        }

        # System / user-reference fields to never push
        # OwnerId defaults to the running user in the dest org; pushing it causes
        # INVALID_CROSS_REFERENCE_KEY because source-org User IDs don't exist there.
        audit_fields = {
            "Id", "CreatedDate", "CreatedById", "LastModifiedDate", "LastModifiedById",
            "SystemModstamp", "LastActivityDate", "IsDeleted",
            "OwnerId",
        }

        # Build the list of fields to query from source (exclude compound + audit)
        # Include fields referenced in masking rules so they get queried and masked
        masked_fields = [f for f in masking_rules.keys() if f not in (fields or []) and f not in audit_fields]
        if not fields:
            query_candidates = [f for f in createable_fields if f not in audit_fields]
        else:
            query_candidates = [f for f in (fields + masked_fields) if f not in audit_fields]

        # Filter out compound fields from the query
        query_fields = ["Id"]
        for fname in query_candidates:
            fm = src_field_meta.get(fname, {})
            if fm.get("type") in compound_types:
                continue
            # Also skip if field doesn't exist in source describe
            if fname not in src_field_meta:
                continue
            query_fields.append(fname)
        query_fields = list(dict.fromkeys(query_fields))  # dedupe preserving order

        # Identify reference/lookup fields so we can remap IDs
        # Skip references to User/Group — those IDs won't have mappings and
        # should be left as-is or excluded via audit_fields above.
        _skip_ref_targets = {"User", "Group", "Organization", "Profile", "UserRole",
                             "BusinessProcess", "RecordType"}
        reference_fields = {}
        for fname in query_fields:
            fm = src_field_meta.get(fname, {})
            if fm.get("type") == "reference" and fm.get("referenceTo"):
                targets = fm["referenceTo"]
                if not _skip_ref_targets.intersection(targets):
                    reference_fields[fname] = targets

        # Fetch full records from source org
        id_list = ",".join(f"'{sid}'" for sid in source_ids)
        soql = f"SELECT {', '.join(query_fields)} FROM {object_name} WHERE Id IN ({id_list})"
        src_result = sf_src.query_all(soql)
        src_records = src_result.get("records", [])
        if not src_records:
            return jsonify({"error": "No records found in source org", "inserted": 0, "updated": 0})

        # Load ALL existing mappings from the mapping table (for this object + referenced objects)
        all_mappings = {}  # source_id -> destination_id (across all objects)
        try:
            # Get mappings for the current object
            for m in store.get_seed_mappings(mapping_table, object_name, limit=10000):
                all_mappings[m["source_id"]] = m["destination_id"]
            # Get mappings for referenced objects (so we can remap lookup fields)
            ref_objects = set()
            for targets in reference_fields.values():
                ref_objects.update(targets)
            for ref_obj in ref_objects:
                for m in store.get_seed_mappings(mapping_table, ref_obj, limit=10000):
                    all_mappings[m["source_id"]] = m["destination_id"]
        except Exception:
            pass

        # Split records into insert vs update batches
        to_insert = []
        to_update = []
        insert_source_ids = []

        for rec in src_records:
            source_id = rec["Id"]
            # Strip Salesforce metadata and Id
            clean = {}
            for k, v in rec.items():
                if k in ("attributes", "Id"):
                    continue
                if isinstance(v, dict):
                    continue  # skip compound field values (OrderedDict)
                clean[k] = v

            # Remap reference/lookup field values to destination IDs
            for ref_fname in reference_fields:
                src_ref_val = clean.get(ref_fname)
                if src_ref_val and isinstance(src_ref_val, str):
                    dest_ref_val = all_mappings.get(src_ref_val)
                    if dest_ref_val:
                        clean[ref_fname] = dest_ref_val
                    else:
                        # No mapping exists — null it out to avoid invalid cross-reference
                        clean[ref_fname] = None

            # Append email suffix to email fields to avoid sending to real addresses
            if _email_suffix:
                for fname, fmeta in src_field_meta.items():
                    if fmeta.get("type") == "email" and fname in clean:
                        val = clean[fname]
                        if val and isinstance(val, str) and "@" in val and not val.endswith(_email_suffix):
                            clean[fname] = val + _email_suffix

            # Apply data masking rules
            if masking_rules:
                for mask_field, mask_rule in masking_rules.items():
                    if mask_field in clean and mask_rule.get("technique", "none") != "none":
                        clean[mask_field] = _apply_masking(clean[mask_field], mask_rule)

            dest_id = all_mappings.get(source_id)
            if dest_id:
                # Update: include Id, only updateable fields, skip unique/externalId fields
                upd = {"Id": dest_id}
                for k, v in clean.items():
                    if k in updateable_fields and k not in unique_fields:
                        upd[k] = v
                to_update.append(upd)
            else:
                # Insert: only createable fields
                ins = {}
                for k, v in clean.items():
                    if k in createable_fields:
                        ins[k] = v
                to_insert.append(ins)
                insert_source_ids.append(source_id)

        results = {
            "inserted": 0, "updated": 0, "errors": [], "mappings_saved": 0,
            "insert_results": [],  # per-record: {sourceId, destId, success, message}
            "update_results": [],  # per-record: {sourceId, destId, success, message}
        }

        # Track which source IDs go to update (for result mapping)
        update_source_ids = []
        for rec in src_records:
            sid = rec["Id"]
            if all_mappings.get(sid):
                update_source_ids.append(sid)

        # Perform updates
        if to_update:
            try:
                upd_result = salesforce_client.bulk_update(sf_dst, object_name, to_update)
                results["updated"] = upd_result.get("success_count", 0)
                rr = upd_result.get("record_results", [])
                # Track failed updates that need to be re-inserted (ENTITY_IS_DELETED, NOT_FOUND, etc.)
                retry_as_insert = []
                for i, rres in enumerate(rr):
                    src_id = update_source_ids[i] if i < len(update_source_ids) else ""
                    status_code = rres.get("statusCode", "")
                    success = rres.get("success", False)
                    if not success and status_code in ("ENTITY_IS_DELETED", "NOT_FOUND", "INVALID_CROSS_REFERENCE_KEY", "MALFORMED_ID"):
                        # Stale mapping — delete it and queue for re-insert
                        stale_dest_id = to_update[i].get("Id") if i < len(to_update) else ""
                        if src_id:
                            try:
                                store._get_db().execute(
                                    f'DELETE FROM "{mapping_table}" WHERE source_id = ? AND object_name = ?',
                                    (src_id, object_name)
                                )
                                store._get_db().commit()
                            except Exception:
                                pass
                            # Find the original source record and build an insert payload
                            src_rec = next((r for r in src_records if r["Id"] == src_id), None)
                            if src_rec:
                                clean = {}
                                for k, v in src_rec.items():
                                    if k in ("attributes", "Id"):
                                        continue
                                    if isinstance(v, dict):
                                        continue
                                    clean[k] = v
                                # Remap reference fields
                                for ref_fname in reference_fields:
                                    src_ref_val = clean.get(ref_fname)
                                    if src_ref_val and isinstance(src_ref_val, str):
                                        dest_ref_val = all_mappings.get(src_ref_val)
                                        clean[ref_fname] = dest_ref_val if dest_ref_val else None
                                ins = {k: v for k, v in clean.items() if k in createable_fields}
                                retry_as_insert.append(ins)
                                insert_source_ids.append(src_id)
                        continue  # Don't add to update_results — will appear in insert_results
                    results["update_results"].append({
                        "sourceId": src_id,
                        "destId": rres.get("id") or (to_update[i].get("Id") if i < len(to_update) else ""),
                        "success": success,
                        "message": rres.get("message", ""),
                        "statusCode": status_code,
                    })
                # Add retries to insert batch
                if retry_as_insert:
                    to_insert.extend(retry_as_insert)
            except Exception as e:
                results["errors"].append(f"Update failed: {str(e)}")

        # Perform inserts + save mappings
        if to_insert:
            try:
                ins_result = salesforce_client.bulk_insert(sf_dst, object_name, to_insert)
                results["inserted"] = ins_result.get("success_count", 0)
                rr = ins_result.get("record_results", [])
                for i, rres in enumerate(rr):
                    src_id = insert_source_ids[i] if i < len(insert_source_ids) else ""
                    dest_id = rres.get("id", "")
                    success = rres.get("success", False)
                    results["insert_results"].append({
                        "sourceId": src_id,
                        "destId": dest_id,
                        "success": success,
                        "message": rres.get("message", ""),
                        "statusCode": rres.get("statusCode", ""),
                    })
                    # Save mapping for successful inserts
                    if success and dest_id and src_id:
                        try:
                            store.upsert_seed_mapping(
                                mapping_table, src_id, dest_id, object_name,
                            )
                            results["mappings_saved"] += 1
                        except Exception as me:
                            results["errors"].append(f"Mapping save failed: {str(me)}")
                if ins_result.get("errors"):
                    results["errors"].extend(ins_result["errors"][:20])
            except Exception as e:
                results["errors"].append(f"Insert failed: {str(e)}")

        return jsonify(results)
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


@app.route("/api/delta-analysis", methods=["POST"])
def delta_analysis():
    """Analyze delta sync status: compare SF source vs target DB table."""
    body = request.json
    sf_conn_id = body["sfConnectionId"]
    db_conn_id = body["dbConnectionId"]
    object_name = body["objectName"]
    table_name = body["tableName"]
    target_database = body.get("targetDatabase", "")

    result = {
        "object": object_name,
        "table": table_name,
        "sfCount": None,
        "dbCount": None,
        "deltaCount": None,
        "lastModified": None,
        "orgMatch": None,
        "warnings": [],
    }

    try:
        # 1. Get SF record count + latest SystemModstamp
        sf_conn = config.get_salesforce(sf_conn_id)
        sf = salesforce_client.connect(sf_conn)
        count_res = sf.query(f"SELECT COUNT() FROM {object_name}")
        result["sfCount"] = count_res.get("totalSize", 0)

        # 2. Get target DB stats
        db_conn = config.get_database(db_conn_id)
        pg = db_client.get_connection(db_conn, database=target_database)
        cur = pg.cursor()

        # DB record count
        try:
            cur.execute(f'SELECT COUNT(*) FROM "{table_name}"')
            result["dbCount"] = cur.fetchone()[0]
        except Exception:
            pg.rollback()
            result["warnings"].append(f'Table "{table_name}" does not exist or is not accessible')
            cur.close()
            pg.close()
            return jsonify(result)

        # Last SystemModstamp in DB
        last_mod = None
        try:
            cur.execute(f'SELECT MAX("systemmodstamp") FROM "{table_name}"')
            row = cur.fetchone()
            if row and row[0]:
                val = row[0]
                last_mod = val.isoformat() + "Z" if hasattr(val, "isoformat") else str(val)
                result["lastModified"] = last_mod
        except Exception:
            pg.rollback()

        # 3. Count delta records (modified since last extract)
        if last_mod:
            try:
                delta_res = sf.query(f"SELECT COUNT() FROM {object_name} WHERE SystemModstamp > {last_mod}")
                result["deltaCount"] = delta_res.get("totalSize", 0)
            except Exception as e:
                result["warnings"].append(f"Could not count delta: {e}")

        # 4. Org validation — sample 5 IDs from SF and check if they exist in the DB table
        try:
            sample_res = sf.query(f"SELECT Id FROM {object_name} ORDER BY CreatedDate DESC LIMIT 5")
            sf_ids = [r["Id"] for r in sample_res.get("records", [])]
            if sf_ids:
                placeholders = ", ".join(f"'{sid}'" for sid in sf_ids)
                try:
                    cur.execute(f'SELECT COUNT(*) FROM "{table_name}" WHERE "id" IN ({placeholders})')
                    matched = cur.fetchone()[0]
                except Exception:
                    pg.rollback()
                    # Try with uppercase Id
                    try:
                        cur.execute(f'SELECT COUNT(*) FROM "{table_name}" WHERE "Id" IN ({placeholders})')
                        matched = cur.fetchone()[0]
                    except Exception:
                        pg.rollback()
                        matched = -1

                if matched == -1:
                    result["orgMatch"] = "unknown"
                    result["warnings"].append("Could not verify org match — no 'id' column found")
                elif matched == 0:
                    result["orgMatch"] = "mismatch"
                    result["warnings"].append(
                        "None of the latest 5 SF record IDs were found in the target table. "
                        "The target table may be from a DIFFERENT Salesforce org or sandbox."
                    )
                elif matched < len(sf_ids):
                    result["orgMatch"] = "partial"
                    result["warnings"].append(
                        f"Only {matched}/{len(sf_ids)} recent SF IDs found in target. "
                        "Some records may be missing or the table may be outdated."
                    )
                else:
                    result["orgMatch"] = "match"
        except Exception as e:
            result["warnings"].append(f"Org validation failed: {e}")

        # 5. Detect record count discrepancy
        if result["dbCount"] is not None and result["sfCount"] is not None:
            diff = result["sfCount"] - result["dbCount"]
            if diff > 0 and result["deltaCount"] is not None and diff != result["deltaCount"]:
                result["warnings"].append(
                    f"Record count gap ({diff:,}) differs from delta count ({result['deltaCount']:,}). "
                    "Some records may have been deleted in Salesforce."
                )

        cur.close()
        pg.close()
    except Exception as e:
        result["warnings"].append(str(e))

    return jsonify(result)


@app.route("/api/salesforce/<conn_id>/soql", methods=["POST"])
def run_soql_query(conn_id):
    conn_data = config.get_salesforce(conn_id)
    if not conn_data:
        return jsonify({"error": "Connection not found"}), 404
    soql = request.json.get("soql", "").strip()
    if not soql:
        return jsonify({"error": "No SOQL provided"}), 400
    try:
        sf = salesforce_client.connect(conn_data)
        result = sf.query_all(soql)
        records = result.get("records", [])
        if not records:
            return jsonify({"columns": [], "rows": [], "rowCount": result.get("totalSize", 0)})
        # Extract columns from first record, skip 'attributes'
        raw_columns = [k for k in records[0].keys() if k != "attributes"]
        # Flatten relationship fields (e.g. RecordType -> RecordType.Name)
        columns = []
        for col in raw_columns:
            sample = records[0].get(col)
            if isinstance(sample, dict) and "attributes" in sample:
                # Relationship field – extract sub-fields
                sub_keys = [k for k in sample.keys() if k != "attributes"]
                for sk in sub_keys:
                    columns.append(f"{col}.{sk}")
            else:
                columns.append(col)
        rows = []
        for rec in records:
            row = {}
            for col in raw_columns:
                val = rec.get(col)
                if isinstance(val, dict) and "attributes" in val:
                    sub_keys = [k for k in val.keys() if k != "attributes"]
                    for sk in sub_keys:
                        sv = val.get(sk)
                        row[f"{col}.{sk}"] = str(sv) if sv is not None else None
                else:
                    row[col] = str(val) if val is not None else None
            rows.append(row)
        return jsonify({"columns": columns, "rows": rows, "rowCount": result.get("totalSize", 0)})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/download", methods=["POST"])
def start_download():
    body = request.json
    sf_conn_id = body["sfConnectionId"]
    db_conn_id = body["dbConnectionId"]
    objects = body["objects"]
    table_names = body.get("tableNames", {})
    source_info = body.get("sourceInfo")
    target_database = body.get("targetDatabase")
    import_modes = body.get("importModes", {})
    pk_chunk_sizes = body.get("pkChunkSizes", {})
    job_id = downloader.start_job(sf_conn_id, db_conn_id, objects, table_names=table_names, target_database=target_database, source_info=source_info, import_modes=import_modes, pk_chunk_sizes=pk_chunk_sizes)
    return jsonify({"jobId": job_id})


@app.route("/api/download/<job_id>/status", methods=["GET"])
def download_status(job_id):
    status = downloader.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(status)


@app.route("/api/database/<conn_id>/tables/<table_name>/data", methods=["GET"])
def table_data(conn_id, table_name):
    """Fetch all rows from a DB table (for upload)."""
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    try:
        db_type = conn.get("dbType", "")
        is_mysql = db_type == "mysql"
        is_athena = db_type == "athena"
        is_duckdb = db_type == "duckdb"
        pg = db_client.get_connection(conn)
        cur = pg.cursor()
        if not is_mysql and not is_athena and not is_duckdb:
            # Sanitize table name (PostgreSQL / Redshift)
            cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_name=%s", (table_name,))
            if not cur.fetchone():
                cur.close()
                pg.close()
                return jsonify({"error": "Table not found"}), 404
        if is_athena:
            quote = ''
        elif is_mysql:
            quote = '`'
        else:
            quote = '"'
        cur.execute(f'SELECT * FROM {quote}{table_name}{quote}')
        columns = [desc[0] for desc in cur.description]
        rows = []
        for row in cur.fetchall():
            rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
        cur.close()
        pg.close()
        return jsonify({"table": table_name, "columns": columns, "rows": rows, "totalRows": len(rows)})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/upload", methods=["POST"])
def start_upload():
    body = request.json
    sf_conn_id = body["sfConnectionId"]
    db_conn_id = body["dbConnectionId"]
    table_name = body["tableName"]
    object_name = body["objectName"]
    operation = body["operation"]
    column_mapping = body["columnMapping"]
    external_id_field = body.get("externalIdField")
    job_id = uploader.start_job(sf_conn_id, db_conn_id, table_name, object_name, operation, column_mapping, external_id_field)
    return jsonify({"jobId": job_id})


@app.route("/api/upload/<job_id>/status", methods=["GET"])
def upload_status(job_id):
    status = uploader.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    # Don't send full record_results in polling — too large.
    # Client fetches them separately via /results endpoint.
    resp = {k: v for k, v in status.items() if k != "record_results"}
    resp["has_record_results"] = len(status.get("record_results", [])) > 0
    return jsonify(resp)


@app.route("/api/upload/<job_id>/results", methods=["GET"])
def upload_results(job_id):
    """Return full per-record results for a completed upload job."""
    status = uploader.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({"record_results": status.get("record_results", [])})


@app.route("/api/salesforce/<conn_id>/export-csv", methods=["POST"])
def export_sf_csv(conn_id):
    """Export all records of an object or SOQL result as CSV file."""
    conn_data = config.get_salesforce(conn_id)
    if not conn_data:
        return jsonify({"error": "Connection not found"}), 404
    body = request.json
    object_name = body.get("objectName")
    soql = body.get("soql", "").strip()

    try:
        sf = salesforce_client.connect(conn_data)

        if object_name and not soql:
            # Export all records of an object
            field_meta, records, total = salesforce_client.fetch_records(sf, object_name)
            columns = [f["name"] for f in field_meta]
        elif soql:
            # Export SOQL results
            columns, records, total = salesforce_client.fetch_records_by_soql(sf, soql)
        else:
            return jsonify({"error": "Provide objectName or soql"}), 400

        # Build CSV in memory
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(columns)
        for rec in records:
            row = []
            for col in columns:
                val = rec.get(col)
                if isinstance(val, dict):
                    val = str(val)
                row.append(val if val is not None else "")
            writer.writerow(row)

        csv_content = output.getvalue()
        filename = f"{object_name or 'soql_export'}.csv"

        return Response(
            csv_content,
            mimetype="text/csv",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/import-csv", methods=["POST"])
def import_csv_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files['file']
    target_db_id = request.form.get('targetDbConnectionId')
    table_name = request.form.get('tableName', '')

    if not target_db_id:
        return jsonify({"error": "No target database specified"}), 400

    import os
    if not table_name:
        table_name = os.path.splitext(file.filename)[0].lower().replace(' ', '_')

    content = file.read().decode('utf-8')
    reader = csv.DictReader(io.StringIO(content))
    columns = reader.fieldnames or []
    records = list(reader)

    if not columns:
        return jsonify({"error": "CSV has no columns"}), 400

    source_info = None
    try:
        import json as _json
        source_info = _json.loads(request.form.get('sourceInfo', 'null'))
    except Exception:
        pass
    job_id = downloader.start_csv_import_job(target_db_id, table_name, columns, records, source_info=source_info)
    return jsonify({"jobId": job_id, "columns": columns, "rowCount": len(records), "tableName": table_name})


@app.route("/api/import-csv/<job_id>/status", methods=["GET"])
def csv_import_status(job_id):
    status = downloader.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(status)


@app.route("/api/import-sql", methods=["POST"])
def start_sql_import():
    body = request.json
    source_db_conn_id = body["sourceDbConnectionId"]
    target_db_conn_id = body["targetDbConnectionId"]
    sql = body["sql"]
    table_name = body.get("tableName", "sql_import")
    source_database = body.get("sourceDatabase")
    target_database = body.get("targetDatabase")
    source_info = body.get("sourceInfo")
    job_id = downloader.start_sql_import_job(source_db_conn_id, target_db_conn_id, sql, table_name, source_database=source_database, target_database=target_database, source_info=source_info)
    return jsonify({"jobId": job_id})


@app.route("/api/import-sql/<job_id>/status", methods=["GET"])
def sql_import_status(job_id):
    status = downloader.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(status)


@app.route("/api/import-soql", methods=["POST"])
def start_soql_import():
    body = request.json
    sf_conn_id = body["sfConnectionId"]
    db_conn_id = body["dbConnectionId"]
    soql = body["soql"]
    table_name = body.get("tableName", "")
    if not table_name:
        import re
        match = re.search(r'\bFROM\s+(\w+)', soql, re.IGNORECASE)
        table_name = match.group(1).lower() if match else "soql_import"
    source_info = body.get("sourceInfo")
    target_database = body.get("targetDatabase")
    job_id = downloader.start_soql_import_job(sf_conn_id, db_conn_id, soql, table_name, target_database=target_database, source_info=source_info)
    return jsonify({"jobId": job_id})


@app.route("/api/import-soql/<job_id>/status", methods=["GET"])
def soql_import_status(job_id):
    status = downloader.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(status)


@app.route("/api/database/<conn_id>/table-exists/<table_name>", methods=["GET"])
def check_table_exists(conn_id, table_name):
    """Check if a table already exists in the target database."""
    conn = config.get_database(conn_id)
    if not conn:
        return jsonify({"exists": False})
    db_override = request.args.get("database")
    if db_override:
        conn = {**conn, "database": db_override}
    try:
        db_type = conn.get("dbType", "")
        db = db_client.get_connection(conn)
        cur = db.cursor()
        if db_type == "duckdb":
            cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'main'")
            tables = [row[0] for row in cur.fetchall()]
        elif db_type == "athena":
            cur.execute("SHOW TABLES")
            tables = [row[0] for row in cur.fetchall()]
        elif db_type == "mysql":
            cur.execute("SHOW TABLES")
            tables = [row[0] for row in cur.fetchall()]
        else:
            cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")
            tables = [row[0] for row in cur.fetchall()]
        cur.close()
        db.close()
        exists = table_name.lower() in [t.lower() for t in tables]
        return jsonify({"exists": exists, "table": table_name})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"exists": False, "error": str(e)})


@app.route("/api/attachments/download", methods=["POST"])
def start_attachment_download():
    body = request.json
    sf_conn_id = body["sfConnectionId"]
    object_type = body.get("objectType", "Attachment")
    where_clause = body.get("whereClause")
    output_dir = body.get("outputDir")
    job_id = attachment_handler.start_download_job(sf_conn_id, object_type, where_clause, output_dir)
    return jsonify({"jobId": job_id})


@app.route("/api/attachments/download/<job_id>/status", methods=["GET"])
def attachment_download_status(job_id):
    status = attachment_handler.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    # Exclude file_results from polling (can be large)
    resp = {k: v for k, v in status.items() if k != "file_results"}
    resp["has_file_results"] = len(status.get("file_results", [])) > 0
    return jsonify(resp)


@app.route("/api/attachments/download/<job_id>/results", methods=["GET"])
def attachment_download_results(job_id):
    status = attachment_handler.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({"file_results": status.get("file_results", [])})


@app.route("/api/attachments/upload", methods=["POST"])
def start_attachment_upload():
    body = request.json
    sf_conn_id = body["sfConnectionId"]
    object_type = body.get("objectType", "Attachment")
    source_dir = body["sourceDir"]
    default_parent_id = body.get("defaultParentId")
    link_to_record_id = body.get("linkToRecordId")
    job_id = attachment_handler.start_upload_job(sf_conn_id, object_type, source_dir, default_parent_id, link_to_record_id)
    return jsonify({"jobId": job_id})


@app.route("/api/attachments/upload/<job_id>/status", methods=["GET"])
def attachment_upload_status(job_id):
    status = attachment_handler.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    resp = {k: v for k, v in status.items() if k != "file_results"}
    resp["has_file_results"] = len(status.get("file_results", [])) > 0
    return jsonify(resp)


@app.route("/api/attachments/upload/<job_id>/results", methods=["GET"])
def attachment_upload_results(job_id):
    status = attachment_handler.get_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({"file_results": status.get("file_results", [])})


@app.route("/api/attachments/<job_id>/cancel", methods=["POST"])
def cancel_attachment_job(job_id):
    ok = attachment_handler.cancel_job(job_id)
    if not ok:
        return jsonify({"error": "Job not found or not running"}), 404
    return jsonify({"success": True})


@app.route("/api/attachments/folders", methods=["GET"])
def list_attachment_folders():
    return jsonify({"folders": attachment_handler.list_download_folders()})


@app.route("/api/attachments/count", methods=["POST"])
def attachment_count():
    body = request.json
    sf_conn_id = body["sfConnectionId"]
    object_type = body.get("objectType", "Attachment")
    where_clause = body.get("whereClause")
    try:
        count = attachment_handler.count_files(sf_conn_id, object_type, where_clause)
        return jsonify({"count": count})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/jobs/<job_id>/cancel", methods=["POST"])
def cancel_job(job_id):
    """Try to cancel a running job across all job modules."""
    for module in [downloader, uploader, attachment_handler, quick_loader]:
        if hasattr(module, "cancel_job") and module.cancel_job(job_id):
            return jsonify({"success": True})
    return jsonify({"error": "Job not found or not running"}), 404


@app.route("/api/jobs", methods=["GET"])
def list_all_jobs():
    # Collect in-memory jobs (includes running + recently finished)
    in_memory = {}
    for j in downloader._jobs.values():
        in_memory[j["id"]] = {**j, "jobType": "import"}
    for j in uploader._jobs.values():
        entry = {k: v for k, v in j.items() if k != "record_results"}
        entry["jobType"] = "upload"
        entry["has_record_results"] = len(j.get("record_results", [])) > 0
        in_memory[j["id"]] = entry
    for j in attachment_handler._jobs.values():
        entry = {k: v for k, v in j.items() if k != "file_results"}
        entry["jobType"] = "attachment"
        entry["has_file_results"] = len(j.get("file_results", [])) > 0
        in_memory[j["id"]] = entry
    for j in quick_loader._jobs.values():
        entry = {k: v for k, v in j.items() if k != "record_results"}
        entry["jobType"] = "quick_load"
        entry["has_record_results"] = len(j.get("record_results", [])) > 0
        in_memory[j["id"]] = entry
    for j in pipeline.get_all_runs():
        in_memory[j["runId"]] = {**j, "jobType": "pipeline"}

    # Merge persisted jobs (in-memory takes priority for active jobs)
    for j in store.get_jobs():
        job_id = j.get("id") or j.get("runId", "")
        if job_id not in in_memory:
            in_memory[job_id] = j

    return jsonify({"jobs": list(in_memory.values())})


@app.route("/api/mappings", methods=["GET"])
def list_mappings():
    return jsonify(config.get_mappings())


@app.route("/api/mappings/<path:key>", methods=["GET"])
def get_mapping(key):
    mapping = config.get_mapping(key)
    if mapping is None:
        return jsonify({"error": "Mapping not found"}), 404
    return jsonify({"key": key, "mapping": mapping})


@app.route("/api/mappings", methods=["POST"])
def save_mapping():
    body = request.json
    key = body["key"]
    mapping = body["mapping"]
    config.save_mapping(key, mapping)
    return jsonify({"success": True, "key": key})


@app.route("/api/mappings/<path:key>", methods=["DELETE"])
def delete_mapping(key):
    config.delete_mapping(key)
    return jsonify({"success": True})


UPLOADS_DIR = os.path.join(os.path.dirname(__file__), "uploads")
os.makedirs(UPLOADS_DIR, exist_ok=True)


@app.route("/api/uploads", methods=["GET"])
def list_uploads():
    files = []
    for fname in sorted(os.listdir(UPLOADS_DIR)):
        if not fname.lower().endswith(".csv"):
            continue
        fpath = os.path.join(UPLOADS_DIR, fname)
        stat = os.stat(fpath)
        # Read first line for column count
        cols = 0
        rows = 0
        try:
            with open(fpath, "r", encoding="utf-8") as f:
                reader = csv.reader(f)
                header = next(reader, None)
                cols = len(header) if header else 0
                rows = sum(1 for _ in reader)
        except Exception:
            pass
        files.append({
            "name": fname,
            "size": stat.st_size,
            "modified": stat.st_mtime,
            "columns": cols,
            "rows": rows,
        })
    files.sort(key=lambda f: f["modified"], reverse=True)
    return jsonify(files)


@app.route("/api/uploads", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files["file"]
    if not file.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only CSV files are supported"}), 400
    safe_name = file.filename.replace(os.sep, "_")
    fpath = os.path.join(UPLOADS_DIR, safe_name)
    file.save(fpath)
    return jsonify({"success": True, "name": safe_name})


@app.route("/api/uploads/<filename>", methods=["GET"])
def get_upload(filename):
    fpath = os.path.join(UPLOADS_DIR, filename)
    if not os.path.isfile(fpath):
        return jsonify({"error": "File not found"}), 404
    with open(fpath, "r", encoding="utf-8") as f:
        content = f.read()
    return Response(content, mimetype="text/csv")


@app.route("/api/uploads/<filename>", methods=["DELETE"])
def delete_upload(filename):
    fpath = os.path.join(UPLOADS_DIR, filename)
    if os.path.isfile(fpath):
        os.remove(fpath)
    return jsonify({"success": True})


# ── Bulk Operation Settings ─────────────────────────────────────────

@app.route("/api/bulk-settings", methods=["GET"])
def get_bulk_settings():
    return jsonify(config.get_bulk_settings())


@app.route("/api/bulk-settings", methods=["PUT"])
def save_bulk_settings():
    body = request.json
    # Validate and coerce to ints
    settings = {}
    for key, default in config.BULK_DEFAULTS.items():
        val = body.get(key)
        if val is not None:
            try:
                settings[key] = int(val)
            except (ValueError, TypeError):
                settings[key] = default
        else:
            settings[key] = default
    config.save_bulk_settings(settings)
    return jsonify({"success": True})


# ── AI SQL Generation (Google Gemini) ──────────────────────────────

# ── Sandbox Seed Settings ──────────────────────────────────────────
SEED_DEFAULTS = {
    "emailSuffix": ".drseed",
    "skipSystemRefs": True,
    "includeRecordTypeId": True,
}

@app.route("/api/seed/settings", methods=["GET"])
def get_seed_settings():
    saved = store.get_setting("seed_settings", {})
    return jsonify({**SEED_DEFAULTS, **saved})


@app.route("/api/seed/settings", methods=["PUT"])
def save_seed_settings():
    body = request.json or {}
    store.save_setting("seed_settings", body)
    return jsonify({"success": True})


@app.route("/api/ai/settings", methods=["GET"])
def get_ai_settings():
    settings = config.get_ai_settings()
    # Mask the API key, show only last 4 chars
    api_key = settings.get("apiKey", "")
    if api_key:
        settings = dict(settings)
        settings["apiKey"] = "****" + api_key[-4:] if len(api_key) > 4 else "****"
        settings["hasKey"] = True
    else:
        settings["hasKey"] = False
    return jsonify(settings)


@app.route("/api/ai/settings", methods=["PUT"])
def save_ai_settings():
    body = request.json
    config.save_ai_settings(body)
    return jsonify({"success": True})


@app.route("/api/ai/generate-sql", methods=["POST"])
def generate_sql():
    body = request.json
    prompt = body.get("prompt", "").strip()
    tables = body.get("tables", [])
    database = body.get("database", "")
    db_type = body.get("dbType", "")

    if not prompt:
        return jsonify({"error": "No prompt provided"}), 400

    # Get API key: config first, then env var
    ai_settings = config.get_ai_settings()
    api_key = ai_settings.get("apiKey") or os.environ.get("GEMINI_API_KEY", "")
    model_name = ai_settings.get("model", "gemini-2.0-flash")

    if not api_key:
        return jsonify({"error": "No Gemini API key configured. Go to Settings to add your API key, or set the GEMINI_API_KEY environment variable."}), 400

    # Build schema context
    schema_lines = []
    if database:
        schema_lines.append(f"Database: {database}")
    if db_type:
        schema_lines.append(f"Database type: {db_type}")
    for tbl in tables:
        cols = ", ".join(f"{c['name']} ({c['type']})" for c in tbl.get("columns", []))
        schema_lines.append(f"Table: {tbl['name']} — Columns: {cols}")
    schema_context = "\n".join(schema_lines) if schema_lines else "No schema information available."

    system_prompt = f"""You are a SQL query assistant. Generate SQL queries based on the user's natural language description.

Database schema:
{schema_context}

Rules:
- Return ONLY valid SQL for the given database type
- Use the exact table and column names from the schema
- Include a LIMIT clause for SELECT queries unless the user asks for all rows
- For the database type "{db_type or 'SQL'}", use appropriate syntax
- After the SQL, provide a brief one-line explanation starting with "Explanation: "

Format your response as:
```sql
YOUR SQL QUERY HERE
```
Explanation: Brief description of what the query does."""

    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        response = client.models.generate_content(
            model=model_name,
            contents=system_prompt + "\n\nUser request: " + prompt,
        )
        text = response.text

        # Parse SQL from response
        sql_match = None
        import re
        sql_block = re.search(r'```sql\s*(.*?)\s*```', text, re.DOTALL)
        if sql_block:
            sql_match = sql_block.group(1).strip()
        else:
            # Try plain code block
            code_block = re.search(r'```\s*(.*?)\s*```', text, re.DOTALL)
            if code_block:
                sql_match = code_block.group(1).strip()
            else:
                # Use the whole text as SQL (fallback)
                sql_match = text.strip()

        # Parse explanation
        explanation = ""
        expl_match = re.search(r'Explanation:\s*(.*)', text, re.IGNORECASE)
        if expl_match:
            explanation = expl_match.group(1).strip()

        return jsonify({"sql": sql_match, "explanation": explanation})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ── Quick Load (File → SQL → Salesforce) ───────────────────────────

@app.route("/api/quick-load/upload", methods=["POST"])
def quick_load_upload():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files["file"]
    fname = file.filename or ""
    ext = fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
    if ext not in ("csv", "xlsx"):
        return jsonify({"error": "Only CSV and XLSX files are supported"}), 400
    content = file.read()
    try:
        result = quick_loader.create_session(fname, content, ext)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/quick-load/<sid>/query", methods=["POST"])
def quick_load_query(sid):
    sql = (request.json or {}).get("sql", "").strip()
    if not sql:
        return jsonify({"error": "No SQL provided"}), 400
    try:
        result = quick_loader.run_query(sid, sql)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/quick-load/<sid>/preview", methods=["GET"])
def quick_load_preview(sid):
    try:
        result = quick_loader.get_preview(sid)
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/quick-load/<sid>/upload", methods=["POST"])
def quick_load_start_upload(sid):
    body = request.json
    try:
        job_id = quick_loader.start_upload(
            session_id=sid,
            sf_conn_id=body["sfConnectionId"],
            object_name=body["objectName"],
            operation=body["operation"],
            column_mapping=body["columnMapping"],
            external_id_field=body.get("externalIdField"),
        )
        return jsonify({"jobId": job_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/quick-load/<job_id>/status", methods=["GET"])
def quick_load_status(job_id):
    status = quick_loader.get_upload_status(job_id)
    if not status:
        return jsonify({"error": "Job not found"}), 404
    return jsonify(status)


@app.route("/api/quick-load/<job_id>/results", methods=["GET"])
def quick_load_results(job_id):
    results = quick_loader.get_upload_results(job_id)
    if results is None:
        return jsonify({"error": "Job not found"}), 404
    return jsonify({"record_results": results})


@app.route("/api/quick-load/<sid>", methods=["DELETE"])
def quick_load_cleanup(sid):
    quick_loader.cleanup_session(sid)
    return jsonify({"success": True})


# ---------------------------------------------------------------------------
# Pipeline endpoints
# ---------------------------------------------------------------------------

@app.route("/api/pipelines", methods=["GET"])
def list_pipelines():
    return jsonify({"pipelines": pipeline.get_all_pipelines()})


@app.route("/api/pipelines", methods=["POST"])
def save_pipeline_route():
    body = request.json
    saved = pipeline.save_pipeline(body)
    return jsonify(saved)


@app.route("/api/pipelines/<pipeline_id>", methods=["GET"])
def get_pipeline_route(pipeline_id):
    p = pipeline.get_pipeline(pipeline_id)
    if not p:
        return jsonify({"error": "Pipeline not found"}), 404
    return jsonify(p)


@app.route("/api/pipelines/<pipeline_id>", methods=["DELETE"])
def delete_pipeline_route(pipeline_id):
    pipeline.delete_pipeline_by_id(pipeline_id)
    return jsonify({"success": True})


@app.route("/api/pipelines/<pipeline_id>/run", methods=["POST"])
def run_pipeline_route(pipeline_id):
    try:
        run_id = pipeline.run_pipeline(pipeline_id)
        return jsonify({"runId": run_id})
    except ValueError as e:
        return jsonify({"error": str(e)}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/pipelines/runs", methods=["GET"])
def list_pipeline_runs():
    return jsonify({"runs": pipeline.get_all_runs()})


@app.route("/api/pipelines/runs/<run_id>", methods=["GET"])
def get_pipeline_run(run_id):
    run = pipeline.get_run(run_id)
    if not run:
        return jsonify({"error": "Run not found"}), 404
    return jsonify(run)


@app.route("/api/pipelines/schedules", methods=["GET"])
def list_pipeline_schedules():
    return jsonify({"schedules": pipeline.get_scheduled_jobs()})



# ---------------------------------------------------------------------------
# Excel to Text Files
# ---------------------------------------------------------------------------

@app.route("/api/excel-to-text/parse", methods=["POST"])
def excel_to_text_parse():
    if "file" not in request.files:
        return jsonify({"error": "No file provided"}), 400
    file = request.files["file"]
    fname = file.filename or ""
    ext = fname.rsplit(".", 1)[-1].lower() if "." in fname else ""
    if ext not in ("csv", "xlsx", "xls"):
        return jsonify({"error": "Only CSV and Excel files are supported"}), 400
    content = file.read()
    try:
        if ext == "csv":
            text = content.decode("utf-8", errors="replace")
            reader = csv.DictReader(io.StringIO(text))
            columns = reader.fieldnames or []
            rows = [dict(r) for r in reader]
        else:
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
            ws = wb.active
            rows_iter = ws.iter_rows(values_only=True)
            header = next(rows_iter, None)
            if not header:
                return jsonify({"error": "File has no header row"}), 400
            columns = [str(c).strip() if c is not None else f"col_{i}" for i, c in enumerate(header)]
            rows = []
            for row in rows_iter:
                if any(cell is not None for cell in row):
                    row_dict = {}
                    for i, cell in enumerate(row):
                        if cell is None:
                            row_dict[columns[i]] = ""
                        else:
                            val = str(cell)
                            # Preserve newlines: openpyxl may use \r\n or \r
                            val = val.replace("\r\n", "\n").replace("\r", "\n")
                            row_dict[columns[i]] = val
                    rows.append(row_dict)
            wb.close()
        return jsonify({"columns": columns, "rows": rows})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@app.route("/api/excel-to-text/generate", methods=["POST"])
def excel_to_text_generate():
    body = request.json
    text_col = body.get("textColumn", "")
    fname_col = body.get("fileNameColumn", "")
    rows = body.get("rows", [])
    if not text_col or not fname_col or not rows:
        return jsonify({"error": "Missing textColumn, fileNameColumn, or rows"}), 400
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for i, row in enumerate(rows):
            text = row.get(text_col, "")
            fname = row.get(fname_col, f"row_{i + 1}")
            # Ensure .txt extension
            if not fname.lower().endswith(".txt"):
                fname = fname + ".txt"
            # Sanitize filename
            fname = fname.replace("/", "_").replace("\\", "_")
            zf.writestr(fname, text)
    buf.seek(0)
    return Response(
        buf.getvalue(),
        mimetype="application/zip",
        headers={"Content-Disposition": "attachment; filename=text_files.zip"},
    )


# ---------------------------------------------------------------------------
# Compare Templates
# ---------------------------------------------------------------------------

@app.route("/api/compare/templates", methods=["GET"])
def list_compare_templates():
    return jsonify(store.get_compare_templates())


@app.route("/api/compare/templates", methods=["POST"])
def save_compare_template():
    body = request.json
    if not body.get("id"):
        body["id"] = str(uuid.uuid4())[:8]
    saved = store.upsert_compare_template(body)
    return jsonify(saved)


@app.route("/api/compare/templates/<template_id>", methods=["DELETE"])
def delete_compare_template(template_id):
    store.delete_compare_template(template_id)
    return jsonify({"success": True})


# ---------------------------------------------------------------------------
# Compare: Run
# ---------------------------------------------------------------------------

def _build_multitable_sql(obj, fields, quote, multi_table_cfg, key_field=None):
    """Build a SELECT with optional LEFT JOINs and ROW_NUMBER dedup.

    multi_table_cfg = {
        "enabled": true,
        "additionalTables": [
            {"table": "history", "primaryField": "id", "additionalField": "order_id",
             "fields": ["status", "updated_at"]},
        ],
        "dedupField": "history__updated_at"   # optional
    }

    Returns (sql_string, output_column_names).
    """
    q = quote  # shorthand
    additional = multi_table_cfg.get("additionalTables", [])
    dedup_field = multi_table_cfg.get("dedupField", "")

    has_joins = bool(additional)
    has_dedup = bool(dedup_field)

    # --- Single table, no joins ---
    if not has_joins and not has_dedup:
        col_list = ", ".join(f'{q}{f}{q}' for f in fields)
        return f'SELECT {col_list} FROM {q}{obj}{q}', fields

    # Build alias map: t0 = primary table, t1..tN = additional tables
    # Column list: primary fields come from t0, additional fields are aliased as table__field
    select_parts = []
    output_cols = []
    join_clauses = []

    if has_joins:
        # Build set of alias prefixes from additional tables for filtering
        additional_prefixes = set()
        for at in additional:
            tbl = at.get("table", "")
            if tbl:
                additional_prefixes.add(f'{tbl}__')

        # Primary table fields — skip any that are additional table aliases (table__col)
        for f in fields:
            if any(f.startswith(p) for p in additional_prefixes):
                continue  # This is an aliased field from an additional table, handled below
            select_parts.append(f't0.{q}{f}{q}')
            output_cols.append(f)

        # Additional table fields
        for idx, at in enumerate(additional):
            alias = f't{idx + 1}'
            tbl = at.get("table", "")
            pf = at.get("primaryField", "")
            af = at.get("additionalField", "")
            at_fields = at.get("fields", [])
            if not tbl or not pf or not af:
                continue
            join_clauses.append(
                f'LEFT JOIN {q}{tbl}{q} {alias} ON t0.{q}{pf}{q} = {alias}.{q}{af}{q}'
            )
            for col in at_fields:
                col_alias = f'{tbl}__{col}'
                select_parts.append(f'{alias}.{q}{col}{q} AS {q}{col_alias}{q}')
                output_cols.append(col_alias)

        from_clause = f'{q}{obj}{q} t0 ' + ' '.join(join_clauses)
    else:
        # Single table (dedup only, no joins)
        for f in fields:
            select_parts.append(f'{q}{f}{q}')
            output_cols.append(f)
        from_clause = f'{q}{obj}{q}'

    col_str = ', '.join(select_parts)

    if not has_dedup:
        # JOIN without dedup
        return f'SELECT {col_str} FROM {from_clause}', output_cols

    # --- Dedup via ROW_NUMBER ---
    # Resolve dedup field reference (which alias owns it)
    dedup_ref = None
    if has_joins:
        # Check additional tables FIRST — match against table__col pattern
        # (The fields list may contain aliased names like "table__col" added by
        #  the compare endpoint, so checking primary fields first would incorrectly
        #  assign them to t0.)
        for idx, at in enumerate(additional):
            tbl = at.get("table", "")
            if not tbl:
                continue
            prefix = f'{tbl}__'
            if dedup_field.startswith(prefix):
                actual_col = dedup_field[len(prefix):]
                dedup_ref = f't{idx + 1}.{q}{actual_col}{q}'
                # Also ensure the column is in the SELECT list
                col_alias = f'{tbl}__{actual_col}'
                if col_alias not in output_cols:
                    select_parts.append(f't{idx + 1}.{q}{actual_col}{q} AS {q}{col_alias}{q}')
                    output_cols.append(col_alias)
                break
        # Then check primary table fields
        if not dedup_ref and dedup_field in fields:
            dedup_ref = f't0.{q}{dedup_field}{q}'
        if not dedup_ref:
            # Fallback: use as-is
            dedup_ref = f't0.{q}{dedup_field}{q}' if has_joins else f'{q}{dedup_field}{q}'
    else:
        dedup_ref = f'{q}{dedup_field}{q}'

    # PARTITION BY the key field
    if key_field:
        if has_joins:
            partition_ref = f't0.{q}{key_field}{q}'
        else:
            partition_ref = f'{q}{key_field}{q}'
    else:
        partition_ref = dedup_ref  # fallback

    # Rebuild col_str in case dedup resolution added columns
    col_str = ', '.join(select_parts)

    inner_sql = (
        f'SELECT {col_str}, '
        f'ROW_NUMBER() OVER (PARTITION BY {partition_ref} ORDER BY {dedup_ref} DESC) AS _rn '
        f'FROM {from_clause}'
    )
    # Wrap output columns for outer select
    outer_cols = ', '.join(f'{q}{c}{q}' for c in output_cols)
    sql = f'SELECT {outer_cols} FROM ({inner_sql}) sub WHERE _rn = 1'
    return sql, output_cols


def _fetch_compare_records(side, progress=None):
    """Fetch records from a source or dest side config.
    Returns list of dicts with the requested fields.
    progress: optional callable(message_string) for status updates.
    """
    conn_type = side.get("connType")
    conn_id = side.get("connId")
    obj = side.get("object")
    fields = side.get("fields", [])
    database = side.get("database")
    multi_table = side.get("multiTable")
    key_field = side.get("keyField")
    _prog = progress or (lambda m: None)

    if not fields:
        return []

    if conn_type == "salesforce":
        conn = config.get_salesforce(conn_id)
        if not conn:
            raise ValueError(f"Salesforce connection {conn_id} not found")
        _prog(f"Connecting to Salesforce...")
        sf = salesforce_client.connect(conn)
        field_list = ", ".join(fields)
        soql = f"SELECT {field_list} FROM {obj}"
        _prog(f"SOQL: {soql}")

        # Check record count to pick the right API
        _prog(f"Counting {obj} records...")
        try:
            count_result = sf.query(f"SELECT COUNT() FROM {obj}")
            total = count_result.get("totalSize", 0)
        except Exception:
            total = 0

        bulk_threshold = salesforce_client._get_bulk_threshold()
        if total > bulk_threshold:
            _prog(f"Fetching {total:,} records via Bulk API...")
            try:
                records = salesforce_client._bulk_query(sf, obj, soql)
                _prog(f"Downloaded {len(records):,} records from Salesforce")
                return [{f: rec.get(f) for f in fields} for rec in records]
            except Exception:
                _prog(f"Bulk API failed, falling back to REST API...")
                result = sf.query_all(soql)
                records = result.get("records", [])
                _prog(f"Downloaded {len(records):,} records from Salesforce")
                return [{f: rec.get(f) for f in fields} for rec in records]
        else:
            _prog(f"Fetching {total:,} records via REST API...")
            result = sf.query_all(soql)
            records = result.get("records", [])
            _prog(f"Downloaded {len(records):,} records from Salesforce")
            return [{f: rec.get(f) for f in fields} for rec in records]
    else:
        conn = config.get_database(conn_id)
        if not conn:
            raise ValueError(f"Database connection {conn_id} not found")
        if database:
            conn = {**conn, "database": database}
        db_type = conn.get("dbType", "")
        db_label = db_type.capitalize() or "Database"
        if db_type == "mysql":
            quote = '`'
        elif db_type == "athena":
            quote = ''
        else:
            quote = '"'

        # Check for multi-table join / dedup
        if multi_table and multi_table.get("enabled"):
            n_joins = len([t for t in multi_table.get("additionalTables", []) if t.get("table")])
            dedup = multi_table.get("dedupField", "")
            desc_parts = []
            if n_joins:
                desc_parts.append(f"JOIN {n_joins} table{'s' if n_joins > 1 else ''}")
            if dedup:
                desc_parts.append(f"dedup by {dedup}")
            _prog(f"Querying {db_label}: {obj} ({', '.join(desc_parts)})...")
            sql, output_cols = _build_multitable_sql(obj, fields, quote, multi_table, key_field)
        else:
            _prog(f"Querying {db_label}: {obj}...")
            col_list = ", ".join(f'{quote}{f}{quote}' for f in fields)
            sql = f'SELECT {col_list} FROM {quote}{obj}{quote}'
            output_cols = fields

        _prog(f"SQL: {sql}")
        db = db_client.get_connection(conn)
        cur = db.cursor()
        cur.execute(sql)
        columns = [desc[0] for desc in cur.description]
        rows = []
        for row in cur.fetchall():
            rows.append({col: (str(val) if val is not None else None) for col, val in zip(columns, row)})
        cur.close()
        db.close()
        _prog(f"Downloaded {len(rows):,} records from {db_label}")
        return rows


def _compare_sse_stream(worker_fn, body):
    """Run worker_fn in a thread, stream progress + result via SSE.
    worker_fn(body, queue) should put {"progress": ...} and finally {"result": ...} or {"error": ...} into queue.
    """
    import json as _json
    import queue, threading

    q = queue.Queue()

    def _run():
        try:
            worker_fn(body, q)
        except Exception as e:
            q.put({"error": str(e)})

    t = threading.Thread(target=_run, daemon=True)
    t.start()

    def generate():
        while True:
            try:
                msg = q.get(timeout=30)
            except queue.Empty:
                # Send keepalive so the connection stays open; also check if thread is alive
                if not t.is_alive():
                    yield f"data: {_json.dumps({'error': 'Worker stopped unexpectedly'})}\n\n"
                    return
                yield f"data: {_json.dumps({'progress': 'Still working...'})}\n\n"
                continue
            yield f"data: {_json.dumps(msg)}\n\n"
            if "result" in msg or "error" in msg:
                return

    resp = Response(generate(), mimetype='text/event-stream',
                    headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no',
                             'Transfer-Encoding': 'chunked'})
    resp.implicit_sequence_conversion = False
    return resp


def _counts_worker(body, q):
    import time as _time
    t0 = _time.time()
    source_cfg = body.get("source", {})
    dest_cfg = body.get("dest", {})
    source_key = body.get("sourceKeyField")
    dest_key = body.get("destKeyField")

    if not source_key or not dest_key:
        q.put({"error": "sourceKeyField and destKeyField are required"})
        return

    source_cfg["fields"] = [source_key]
    dest_cfg["fields"] = [dest_key]
    source_cfg["keyField"] = source_key
    dest_cfg["keyField"] = dest_key

    if body.get("sourceMultiTable"):
        source_cfg["multiTable"] = body["sourceMultiTable"]
    if body.get("destMultiTable"):
        dest_cfg["multiTable"] = body["destMultiTable"]

    def _prog(msg):
        q.put({"progress": msg})

    try:
        _prog("Fetching source records...")
        src_records = _fetch_compare_records(source_cfg, progress=_prog)
        _prog("Fetching destination records...")
        dst_records = _fetch_compare_records(dest_cfg, progress=_prog)
    except Exception as e:
        q.put({"error": str(e)})
        return

    _prog(f"Comparing {len(src_records):,} source vs {len(dst_records):,} dest keys...")

    src_keys = {str(r.get(source_key, "")) for r in src_records if r.get(source_key) is not None}
    dst_keys = {str(r.get(dest_key, "")) for r in dst_records if r.get(dest_key) is not None}

    missing_in_dest = src_keys - dst_keys
    missing_in_source = dst_keys - src_keys
    elapsed = round(_time.time() - t0, 2)

    MAX_KEYS = 1000
    result = {
        "sourceCount": len(src_keys),
        "destCount": len(dst_keys),
        "matched": len(src_keys & dst_keys),
        "missingInDest": len(missing_in_dest),
        "missingInSource": len(missing_in_source),
        "missingInDestKeys": sorted(missing_in_dest)[:MAX_KEYS],
        "missingInSourceKeys": sorted(missing_in_source)[:MAX_KEYS],
        "elapsedSeconds": elapsed,
    }

    history_entry = {
        "id": str(uuid.uuid4())[:8],
        "ranAt": datetime.now().isoformat(),
        "type": "counts",
        "elapsedSeconds": elapsed,
        "sourceObject": source_cfg.get("object", ""),
        "destObject": dest_cfg.get("object", ""),
        "sourceDatabase": source_cfg.get("database", ""),
        "destDatabase": dest_cfg.get("database", ""),
        "sourceConnId": source_cfg.get("connId", ""),
        "destConnId": dest_cfg.get("connId", ""),
        "sourceCount": len(src_keys),
        "destCount": len(dst_keys),
        "matched": len(src_keys & dst_keys),
        "missingInDest": len(missing_in_dest),
        "missingInSource": len(missing_in_source),
    }
    try:
        store.save_compare_history(history_entry)
    except Exception:
        pass

    q.put({"result": result})


@app.route("/api/compare/counts", methods=["POST"])
def compare_counts():
    return _compare_sse_stream(_counts_worker, request.json or {})


def _pick_compare_db(source_cfg, dest_cfg, compare_db_id=None):
    """Decide where to run the SQL comparison.
    If compare_db_id is provided, use that specific DB connection.
    Returns (compare_side, other_side) where compare_side/other_side are
    'source' or 'dest'.  compare_side is the DB that will host the temp table.
    Returns ("external_db", conn_config) when using a third-party DB.
    Returns ("duckdb_local", None) as last resort.
    """
    # If user explicitly selected a compare DB, use it
    if compare_db_id:
        # Check if it matches source or dest — use the optimized path
        if dest_cfg.get("connType") == "database" and dest_cfg.get("connId") == compare_db_id:
            return ("dest", "source")
        if source_cfg.get("connType") == "database" and source_cfg.get("connId") == compare_db_id:
            return ("source", "dest")
        conn = config.get_database(compare_db_id)
        if conn and conn.get("dbType") not in ("athena",):
            return ("external_db", conn)

    def _is_writable_db(cfg):
        if cfg.get("connType") != "database":
            return False
        conn = config.get_database(cfg.get("connId"))
        if not conn:
            return False
        return conn.get("dbType") not in ("athena",)

    dst_writable = _is_writable_db(dest_cfg)
    src_writable = _is_writable_db(source_cfg)

    # Prefer dest as the compare DB
    if dst_writable:
        return ("dest", "source")
    if src_writable:
        return ("source", "dest")

    # Neither side is writable — look for any writable DB connection to use
    all_conns = config.get_all()
    for conn in all_conns.get("database_connections", []):
        db_type = conn.get("dbType", "")
        if db_type not in ("athena", "duckdb"):
            return ("external_db", conn)

    # Last resort — in-memory DuckDB
    return ("duckdb_local", None)


def _run_compare_python(source_cfg, dest_cfg, field_mappings, source_key, dest_key, _prog, q, t0):
    """Original in-memory comparison (fallback when no writable DB available)."""
    import time as _time
    try:
        _prog("Fetching source records...")
        src_records = _fetch_compare_records(source_cfg, progress=_prog)
        _prog("Fetching destination records...")
        dst_records = _fetch_compare_records(dest_cfg, progress=_prog)
    except Exception as e:
        q.put({"error": str(e)})
        return

    _prog(f"Indexing {len(src_records):,} source + {len(dst_records):,} dest records...")

    src_by_key = {}
    for rec in src_records:
        k = str(rec.get(source_key, "")) if rec.get(source_key) is not None else ""
        if k:
            src_by_key[k] = rec

    dst_by_key = {}
    for rec in dst_records:
        k = str(rec.get(dest_key, "")) if rec.get(dest_key) is not None else ""
        if k:
            dst_by_key[k] = rec

    src_keys = set(src_by_key.keys())
    dst_keys = set(dst_by_key.keys())
    common = src_keys & dst_keys
    source_only = src_keys - dst_keys
    dest_only = dst_keys - src_keys

    _prog(f"Comparing {len(common):,} matched keys across {len(field_mappings)} field(s)...")

    matched = 0
    mismatched = 0
    differences = []
    MAX_DIFFS = 5000
    MAX_ONLY = 1000

    for key in sorted(common):
        src_rec = src_by_key[key]
        dst_rec = dst_by_key[key]
        row_has_diff = False
        for m in field_mappings:
            sv = str(src_rec.get(m["source"], "")) if src_rec.get(m["source"]) is not None else ""
            dv = str(dst_rec.get(m["dest"], "")) if dst_rec.get(m["dest"]) is not None else ""
            if sv != dv:
                row_has_diff = True
                if len(differences) < MAX_DIFFS:
                    differences.append({
                        "key": key,
                        "sourceField": m["source"],
                        "destField": m["dest"],
                        "sourceVal": sv,
                        "destVal": dv,
                    })
        if row_has_diff:
            mismatched += 1
        else:
            matched += 1

    source_only_list = sorted(source_only)[:MAX_ONLY]
    dest_only_list = sorted(dest_only)[:MAX_ONLY]
    elapsed = round(_time.time() - t0, 2)

    _save_compare_history("fields", source_cfg, dest_cfg, elapsed,
                          len(src_keys), len(dst_keys), matched, mismatched,
                          len(source_only), len(dest_only), len(field_mappings))

    q.put({"result": {
        "summary": {
            "totalSource": len(src_keys), "totalDest": len(dst_keys),
            "matched": matched, "mismatched": mismatched,
            "sourceOnly": len(source_only), "destOnly": len(dest_only),
        },
        "differences": differences,
        "sourceOnlyKeys": source_only_list,
        "destOnlyKeys": dest_only_list,
        "elapsedSeconds": elapsed,
    }})


def _save_compare_history(ctype, source_cfg, dest_cfg, elapsed,
                          total_src, total_dst, matched, mismatched,
                          src_only, dst_only, mapping_count=0):
    entry = {
        "id": str(uuid.uuid4())[:8],
        "ranAt": datetime.now().isoformat(),
        "type": ctype,
        "elapsedSeconds": elapsed,
        "sourceObject": source_cfg.get("object", ""),
        "destObject": dest_cfg.get("object", ""),
        "sourceDatabase": source_cfg.get("database", ""),
        "destDatabase": dest_cfg.get("database", ""),
        "sourceConnId": source_cfg.get("connId", ""),
        "destConnId": dest_cfg.get("connId", ""),
        "totalSource": total_src,
        "totalDest": total_dst,
        "matched": matched,
        "mismatched": mismatched,
        "sourceOnly": src_only,
        "destOnly": dst_only,
    }
    if mapping_count:
        entry["fieldMappingCount"] = mapping_count
    try:
        store.save_compare_history(entry)
    except Exception:
        pass


def _run_compare_worker(body, q):
    import time as _time
    t0 = _time.time()
    source_cfg = body.get("source", {})
    dest_cfg = body.get("dest", {})
    field_mappings = body.get("fieldMappings", [])
    source_key = body.get("sourceKeyField")
    dest_key = body.get("destKeyField")

    if not field_mappings or not source_key or not dest_key:
        q.put({"error": "fieldMappings, sourceKeyField, and destKeyField are required"})
        return

    src_fields = list({source_key} | {m["source"] for m in field_mappings})
    dst_fields = list({dest_key} | {m["dest"] for m in field_mappings})
    source_cfg["fields"] = src_fields
    dest_cfg["fields"] = dst_fields
    source_cfg["keyField"] = source_key
    dest_cfg["keyField"] = dest_key

    for side_key, cfg, fld_list in [("sourceMultiTable", source_cfg, src_fields), ("destMultiTable", dest_cfg, dst_fields)]:
        mt = body.get(side_key)
        if mt and mt.get("enabled"):
            cfg["multiTable"] = mt
            for at in mt.get("additionalTables", []):
                tbl = at.get("table", "")
                for col in at.get("fields", []):
                    alias = f'{tbl}__{col}'
                    if alias not in fld_list:
                        fld_list.append(alias)

    def _prog(msg):
        q.put({"progress": msg})

    # Decide strategy: SQL on a database or local DuckDB
    compare_db_id = body.get("compareDbId")
    strategy = _pick_compare_db(source_cfg, dest_cfg, compare_db_id)

    compare_side, other_side = strategy  # e.g. ("dest", "source"), ("external_db", conn), or ("duckdb_local", None)
    use_both_sides = compare_side in ("duckdb_local", "external_db")

    if use_both_sides:
        # Both sides fetched and loaded into a comparison DB
        if compare_side == "external_db":
            ext_conn = other_side  # other_side holds the conn config
            db_type = ext_conn.get("dbType", "")
            compare_db_database = body.get("compareDbDatabase")
            if compare_db_database:
                ext_conn = {**ext_conn, "database": compare_db_database}
            db_label = ext_conn.get("name", db_type)
            db_name = compare_db_database or ext_conn.get("database", "")
            _prog(f"Using {db_label} / {db_name} ({db_type}) as comparison engine...")
            qc = '`' if db_type == "mysql" else '"'
            db = db_client.get_connection(ext_conn)
        else:
            _prog("Using local DuckDB for comparison...")
            qc = '"'
            import duckdb as _duckdb
            db = _duckdb.connect(":memory:")

        src_temp = f'_dr_src_{uuid.uuid4().hex[:8]}'
        dst_temp = f'_dr_dst_{uuid.uuid4().hex[:8]}'

        try:
            # Fetch both sides
            _prog("Fetching source records...")
            src_records = _fetch_compare_records(source_cfg, progress=_prog)
            _prog(f"Got {len(src_records):,} source records")

            _prog("Fetching destination records...")
            dst_records = _fetch_compare_records(dest_cfg, progress=_prog)
            _prog(f"Got {len(dst_records):,} destination records")

            # Create and load source temp table
            _prog(f"Loading source into DuckDB ({len(src_fields)} columns)...")
            db_client.create_compare_temp_table(db, src_temp, src_fields)
            src_rows = [tuple(str(rec.get(f, "")) if rec.get(f) is not None else None for f in src_fields) for rec in src_records]
            del src_records
            db_client.insert_compare_rows(db, src_temp, src_fields, src_rows,
                                          progress_callback=lambda done, total: _prog(f"Loaded {done:,} / {total:,} source records"))
            del src_rows

            # Create and load dest temp table
            _prog(f"Loading destination into DuckDB ({len(dst_fields)} columns)...")
            db_client.create_compare_temp_table(db, dst_temp, dst_fields)
            dst_rows = [tuple(str(rec.get(f, "")) if rec.get(f) is not None else None for f in dst_fields) for rec in dst_records]
            del dst_records
            db_client.insert_compare_rows(db, dst_temp, dst_fields, dst_rows,
                                          progress_callback=lambda done, total: _prog(f"Loaded {done:,} / {total:,} dest records"))
            del dst_rows

            # For the SQL comparison below, treat:
            #   native = dest temp table,  temp = source temp table
            native_ref = f'{qc}{dst_temp}{qc} AS native'
            temp_name = src_temp
            native_key_col = dest_key
            temp_key_col = source_key
            get_native_field = lambda m: m["dest"]
            get_temp_field = lambda m: m["source"]

        except Exception as e:
            q.put({"error": str(e)})
            try:
                db.close()
            except Exception:
                pass
            return
    else:
        compare_cfg = dest_cfg if compare_side == "dest" else source_cfg
        other_cfg = source_cfg if compare_side == "dest" else dest_cfg
        compare_key = dest_key if compare_side == "dest" else source_key
        other_key = source_key if compare_side == "dest" else dest_key

        _prog(f"Using database-side comparison on {compare_side} DB...")

        # Get connection config for the compare DB
        compare_conn = config.get_database(compare_cfg.get("connId"))
        if not compare_conn:
            _prog("Compare DB connection not found, falling back to DuckDB...")
            # Retry with local DuckDB by recursing with forced local
            _prog("Using local DuckDB for comparison...")
            # Just use Python fallback for this edge case
            _run_compare_python(source_cfg, dest_cfg, field_mappings, source_key, dest_key, _prog, q, t0)
            return

        if compare_cfg.get("database"):
            compare_conn = {**compare_conn, "database": compare_cfg["database"]}

        db_type = compare_conn.get("dbType", "")
        if db_type == "mysql":
            qc = '`'
        elif db_type == "athena":
            qc = ''
        else:
            qc = '"'

        # Build the native table reference (compare side's own table, possibly with JOINs)
        native_obj = compare_cfg.get("object", "")
        multi_table = compare_cfg.get("multiTable")
        native_fields = dst_fields if compare_side == "dest" else src_fields

        if multi_table and multi_table.get("enabled"):
            native_sql, native_cols = _build_multitable_sql(native_obj, native_fields, qc, multi_table, compare_key)
            native_ref = f'({native_sql}) AS native'
        else:
            native_ref = f'{qc}{native_obj}{qc} AS native'
            native_cols = native_fields

        # Determine temp table columns = other side's fields
        other_fields = src_fields if compare_side == "dest" else dst_fields
        temp_name = f'_dr_cmp_{uuid.uuid4().hex[:8]}'

        if compare_side == "dest":
            native_key_col = compare_key
            temp_key_col = other_key
            get_native_field = lambda m: m["dest"]
            get_temp_field = lambda m: m["source"]
        else:
            native_key_col = compare_key
            temp_key_col = other_key
            get_native_field = lambda m: m["source"]
            get_temp_field = lambda m: m["dest"]

        db = None
        try:
            db = db_client.get_connection(compare_conn)

            # 1. Fetch other side's records
            _prog(f"Fetching {other_side} records...")
            other_records = _fetch_compare_records(other_cfg, progress=_prog)
            _prog(f"Got {len(other_records):,} records from {other_side}")

            # 2. Create temp table
            _prog(f"Creating comparison table ({len(other_fields)} columns)...")
            db_client.create_compare_temp_table(db, temp_name, other_fields)

            # 3. Insert records into temp table
            rows = []
            for rec in other_records:
                row = tuple(str(rec.get(f, "")) if rec.get(f) is not None else None for f in other_fields)
                rows.append(row)
            del other_records

            _prog(f"Loading {len(rows):,} records into comparison table...")
            db_client.insert_compare_rows(db, temp_name, other_fields,
                                          rows,
                                          progress_callback=lambda done, total: _prog(f"Loaded {done:,} / {total:,} records"))
            del rows
        except Exception as e:
            q.put({"error": str(e)})
            if db:
                try:
                    db_client.drop_compare_temp_table(db, temp_name)
                    db.close()
                except Exception:
                    pass
            return

    # ── Shared SQL comparison logic (used by both DB-side and DuckDB-local paths) ──
    temp_ref = f'{qc}{temp_name}{qc}'

    # ── Run SQL comparison queries on the database ──
    try:
        _prog("Counting records...")
        cur = db.cursor()

        cur.execute(f'SELECT COUNT(DISTINCT {qc}{temp_key_col}{qc}) FROM {temp_ref}')
        temp_count = cur.fetchone()[0]

        cur.execute(f'SELECT COUNT(DISTINCT COALESCE(CAST(native.{qc}{native_key_col}{qc} AS TEXT), \'\')) FROM {native_ref}')
        native_count = cur.fetchone()[0]

        # temp always holds source data, native always holds dest data
        # (for duckdb_local: temp=source, native=dest; for "dest": temp=source, native=dest; for "source": temp=dest, native=source)
        if compare_side == "source":
            total_src = native_count
            total_dst = temp_count
        else:
            total_src = temp_count
            total_dst = native_count

        _prog(f"Source: {total_src:,} keys, Dest: {total_dst:,} keys")

        MAX_ONLY = 1000

        # Keys in temp but not in native
        _prog("Finding keys only in temp table...")
        sql_temp_only = (
            f'SELECT DISTINCT t.{qc}{temp_key_col}{qc} FROM {temp_ref} t '
            f'LEFT JOIN {native_ref} ON '
            f'COALESCE(CAST(t.{qc}{temp_key_col}{qc} AS TEXT), \'\') = '
            f'COALESCE(CAST(native.{qc}{native_key_col}{qc} AS TEXT), \'\') '
            f'WHERE native.{qc}{native_key_col}{qc} IS NULL '
            f'LIMIT {MAX_ONLY}'
        )
        _prog(f"SQL: {sql_temp_only}")
        cur.execute(sql_temp_only)
        temp_only_keys = [str(r[0]) for r in cur.fetchall() if r[0] is not None]

        # Keys in native but not in temp
        _prog("Finding keys only in native table...")
        sql_native_only = (
            f'SELECT DISTINCT COALESCE(CAST(native.{qc}{native_key_col}{qc} AS TEXT), \'\') FROM {native_ref} '
            f'LEFT JOIN {temp_ref} t ON '
            f'COALESCE(CAST(t.{qc}{temp_key_col}{qc} AS TEXT), \'\') = '
            f'COALESCE(CAST(native.{qc}{native_key_col}{qc} AS TEXT), \'\') '
            f'WHERE t.{qc}{temp_key_col}{qc} IS NULL '
            f'LIMIT {MAX_ONLY}'
        )
        _prog(f"SQL: {sql_native_only}")
        cur.execute(sql_native_only)
        native_only_keys = [str(r[0]) for r in cur.fetchall() if r[0] is not None]

        # Assign to source/dest
        if compare_side == "source":
            source_only_keys = native_only_keys
            dest_only_keys = temp_only_keys
        else:
            # compare_side == "dest" or "duckdb_local": temp=source, native=dest
            source_only_keys = temp_only_keys
            dest_only_keys = native_only_keys

        # Field comparison — find mismatched rows
        MAX_DIFFS = 5000
        where_parts = []
        select_parts = []
        for m in field_mappings:
            nf = get_native_field(m)
            tf = get_temp_field(m)
            nref = f'COALESCE(CAST(native.{qc}{nf}{qc} AS TEXT), \'\')'
            tref = f'COALESCE(CAST(t.{qc}{tf}{qc} AS TEXT), \'\')'
            where_parts.append(f'{nref} != {tref}')
            select_parts.append(f'{tref} AS {qc}src_{tf}{qc}')
            select_parts.append(f'{nref} AS {qc}dst_{nf}{qc}')

        join_cond = (
            f'COALESCE(CAST(t.{qc}{temp_key_col}{qc} AS TEXT), \'\') = '
            f'COALESCE(CAST(native.{qc}{native_key_col}{qc} AS TEXT), \'\')'
        )

        _prog(f"Comparing {len(field_mappings)} field(s) across matched keys...")
        sql_diffs = (
            f'SELECT COALESCE(CAST(t.{qc}{temp_key_col}{qc} AS TEXT), \'\') AS _key, '
            f'{", ".join(select_parts)} '
            f'FROM {temp_ref} t '
            f'INNER JOIN {native_ref} ON {join_cond} '
            f'WHERE {" OR ".join(where_parts)} '
            f'LIMIT {MAX_DIFFS}'
        )
        _prog(f"SQL: {sql_diffs}")
        cur.execute(sql_diffs)
        diff_rows = cur.fetchall()
        diff_cols = [desc[0] for desc in cur.description]

        # Count matched (no diffs)
        sql_matched = (
            f'SELECT COUNT(*) FROM {temp_ref} t '
            f'INNER JOIN {native_ref} ON {join_cond} '
            f'WHERE NOT ({" OR ".join(where_parts)})'
        )
        cur.execute(sql_matched)
        matched = cur.fetchone()[0]

        sql_mismatched = (
            f'SELECT COUNT(*) FROM {temp_ref} t '
            f'INNER JOIN {native_ref} ON {join_cond} '
            f'WHERE {" OR ".join(where_parts)}'
        )
        cur.execute(sql_mismatched)
        mismatched = cur.fetchone()[0]

        cur.close()

        # Build differences list in the format frontend expects
        differences = []
        for row in diff_rows:
            row_dict = dict(zip(diff_cols, row))
            key_val = row_dict.get("_key", "")
            for m in field_mappings:
                nf = get_native_field(m)
                tf = get_temp_field(m)
                sv = str(row_dict.get(f'src_{tf}', "")) if row_dict.get(f'src_{tf}') is not None else ""
                dv = str(row_dict.get(f'dst_{nf}', "")) if row_dict.get(f'dst_{nf}') is not None else ""
                if sv != dv:
                    differences.append({
                        "key": key_val,
                        "sourceField": m["source"],
                        "destField": m["dest"],
                        "sourceVal": sv,
                        "destVal": dv,
                    })

        elapsed = round(_time.time() - t0, 2)
        _prog(f"Done in {elapsed}s — {matched:,} matched, {mismatched:,} mismatched")

        _save_compare_history("fields", source_cfg, dest_cfg, elapsed,
                              total_src, total_dst, matched, mismatched,
                              len(source_only_keys), len(dest_only_keys), len(field_mappings))

        q.put({"result": {
            "summary": {
                "totalSource": total_src, "totalDest": total_dst,
                "matched": matched, "mismatched": mismatched,
                "sourceOnly": len(source_only_keys), "destOnly": len(dest_only_keys),
            },
            "differences": differences,
            "sourceOnlyKeys": sorted(source_only_keys)[:MAX_ONLY],
            "destOnlyKeys": sorted(dest_only_keys)[:MAX_ONLY],
            "elapsedSeconds": elapsed,
        }})

    except Exception as e:
        q.put({"error": str(e)})
    finally:
        if db:
            try:
                if use_local_duckdb:
                    db.close()
                else:
                    db_client.drop_compare_temp_table(db, temp_name)
                    db.close()
            except Exception:
                pass


@app.route("/api/compare/run", methods=["POST"])
def run_compare():
    return _compare_sse_stream(_run_compare_worker, request.json or {})


@app.route("/api/compare/preview-sql", methods=["POST"])
def preview_compare_sql():
    """Returns the SQL/SOQL that would be generated for each side without executing."""
    body = request.json or {}
    result = {}
    for side_name in ["source", "dest"]:
        side = body.get(side_name, {})
        conn_type = side.get("connType")
        obj = side.get("object")
        fields = side.get("fields", [])
        database = side.get("database")
        multi_table = side.get("multiTable")
        key_field = side.get("keyField")
        conn_id = side.get("connId")

        if not obj or not fields:
            result[side_name] = {"query": "(no object/fields selected)", "type": "none"}
            continue

        if conn_type == "salesforce":
            field_list = ", ".join(fields)
            soql = f"SELECT {field_list} FROM {obj}"
            result[side_name] = {"query": soql, "type": "soql"}
        else:
            conn = config.get_database(conn_id) if conn_id else {}
            if conn and database:
                conn = {**conn, "database": database}
            db_type = (conn or {}).get("dbType", "")
            if db_type == "mysql":
                quote = '`'
            elif db_type == "athena":
                quote = ''
            else:
                quote = '"'

            if multi_table and multi_table.get("enabled"):
                sql, _ = _build_multitable_sql(obj, fields, quote, multi_table, key_field)
            else:
                col_list = ", ".join(f'{quote}{f}{quote}' for f in fields)
                sql = f'SELECT {col_list} FROM {quote}{obj}{quote}'
            result[side_name] = {"query": sql, "type": "sql"}

    return jsonify(result)


@app.route("/api/compare/history", methods=["GET"])
def list_compare_history():
    return jsonify(store.get_compare_history())


@app.route("/api/compare/history", methods=["DELETE"])
def clear_compare_history_endpoint():
    store.clear_compare_history()
    return jsonify({"success": True})


@app.route("/api/compare/history/<entry_id>", methods=["DELETE"])
def delete_compare_history_entry(entry_id):
    store.delete_compare_history(entry_id)
    return jsonify({"success": True})


@app.route("/api/compare/export", methods=["POST"])
def compare_export_csv():
    """Export comparison results as a CSV file."""
    body = request.json or {}
    export_type = body.get("type", "")
    keys = body.get("keys", [])
    differences = body.get("differences", [])

    output = io.StringIO()
    writer = csv.writer(output)

    if export_type == "differences":
        writer.writerow(["key", "sourceField", "destField", "sourceVal", "destVal"])
        for d in differences:
            writer.writerow([d.get("key", ""), d.get("sourceField", ""), d.get("destField", ""),
                             d.get("sourceVal", ""), d.get("destVal", "")])
    else:
        # missingInDest, missingInSource, or generic keys
        writer.writerow(["key"])
        for k in keys:
            writer.writerow([k])

    csv_content = output.getvalue()
    output.close()
    return Response(
        csv_content,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename=compare_{export_type}.csv"},
    )


@app.route("/api/compare/import-to-db", methods=["POST"])
def compare_import_to_db():
    """Create/replace a table in a database connection with comparison result data."""
    body = request.json or {}
    conn_id = body.get("connId")
    database = body.get("database")
    table_name = body.get("tableName")
    import_type = body.get("type", "")
    keys = body.get("keys", [])
    differences = body.get("differences", [])

    if not conn_id or not table_name:
        return jsonify({"error": "connId and tableName are required"}), 400

    try:
        conn = config.get_database(conn_id)
        if not conn:
            return jsonify({"error": f"Database connection {conn_id} not found"}), 404
        if database:
            conn = {**conn, "database": database}

        db_type = conn.get("dbType", "")
        if db_type == "mysql":
            quote = '`'
        elif db_type == "athena":
            quote = ''
        else:
            quote = '"'

        q_table = f'{quote}{table_name}{quote}'

        db = db_client.get_connection(conn)
        cur = db.cursor()

        # Drop existing table
        cur.execute(f'DROP TABLE IF EXISTS {q_table}')

        if import_type == "differences":
            cur.execute(f'CREATE TABLE {q_table} ('
                        f'{quote}key_value{quote} TEXT, '
                        f'{quote}source_field{quote} TEXT, '
                        f'{quote}dest_field{quote} TEXT, '
                        f'{quote}source_value{quote} TEXT, '
                        f'{quote}dest_value{quote} TEXT)')
            for d in differences:
                cur.execute(f'INSERT INTO {q_table} ({quote}key_value{quote}, {quote}source_field{quote}, '
                            f'{quote}dest_field{quote}, {quote}source_value{quote}, {quote}dest_value{quote}) '
                            f'VALUES (%s, %s, %s, %s, %s)',
                            (d.get("key", ""), d.get("sourceField", ""), d.get("destField", ""),
                             d.get("sourceVal", ""), d.get("destVal", "")))
            row_count = len(differences)
        else:
            # missingKeys
            cur.execute(f'CREATE TABLE {q_table} ({quote}key_value{quote} TEXT)')
            for k in keys:
                cur.execute(f'INSERT INTO {q_table} ({quote}key_value{quote}) VALUES (%s)', (k,))
            row_count = len(keys)

        db.commit()
        cur.close()
        db.close()

        return jsonify({"success": True, "rowCount": row_count})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ---------------------------------------------------------------------------
# CLI / Terminal
# ---------------------------------------------------------------------------

@app.route("/api/cli", methods=["POST"])
def cli_execute():
    body = request.json
    command = body.get("command", "").strip()
    context = body.get("context", {})
    if not command:
        return jsonify({"output": "", "type": "text"})
    try:
        result = cli_handler.execute(command, context)
        return jsonify(result)
    except Exception as e:
        return jsonify({"output": str(e), "type": "error"})


@app.route("/api/cli/completions", methods=["POST"])
def cli_completions():
    body = request.json
    partial = body.get("partial", "")
    context = body.get("context", {})
    try:
        suggestions = cli_handler.get_completions(partial, context)
        return jsonify({"suggestions": suggestions})
    except Exception:
        return jsonify({"suggestions": []})


# ---------------------------------------------------------------------------
# Script Runner API
# ---------------------------------------------------------------------------

@app.route("/api/script/run", methods=["POST"])
def script_run():
    body = request.json or {}
    script_text = body.get("script", "")
    context = body.get("context", {})
    if not script_text.strip():
        return jsonify({"error": "Script is empty"}), 400
    run_id, error = script_runner.run_script(script_text, context)
    if error:
        return jsonify({"error": error}), 400
    return jsonify({"runId": run_id})


@app.route("/api/script/run/<run_id>", methods=["GET"])
def script_run_status(run_id):
    run = script_runner.get_run(run_id)
    if not run:
        return jsonify({"error": "Run not found"}), 404
    return jsonify(run)


@app.route("/api/script/runs", methods=["GET"])
def script_runs_list():
    runs = script_runner.get_all_runs()
    # Return summary only (no full step details)
    summary = []
    for r in runs:
        summary.append({
            "runId": r["runId"],
            "status": r["status"],
            "totalSteps": r["totalSteps"],
            "currentStep": r["currentStep"],
            "startedAt": r.get("startedAt"),
            "finishedAt": r.get("finishedAt"),
            "error": r.get("error"),
        })
    return jsonify({"runs": summary})


@app.route("/api/salesforce/<conn_id>/sample-insert", methods=["POST"])
def sample_insert(conn_id):
    """Insert sample/generated records into a Salesforce object via REST API."""
    conn = config.get_salesforce(conn_id)
    if not conn:
        return jsonify({"error": "Connection not found"}), 404
    try:
        sf = salesforce_client.connect(conn)
        data = request.json
        object_name = data.get("object")
        records = data.get("records", [])
        if not object_name or not records:
            return jsonify({"error": "Missing object or records"}), 400
        if len(records) > 200:
            return jsonify({"error": "Maximum 200 records per insert"}), 400

        results = []
        success_count = 0
        error_count = 0
        sf_obj = getattr(sf, object_name)
        for rec in records:
            try:
                result = sf_obj.create(rec)
                if result.get("success"):
                    results.append({"success": True, "id": result.get("id", "")})
                    success_count += 1
                else:
                    errs = result.get("errors", [])
                    msg = errs[0].get("message", "Unknown error") if errs else "Unknown error"
                    results.append({"success": False, "message": msg})
                    error_count += 1
            except Exception as e:
                results.append({"success": False, "message": str(e)})
                error_count += 1

        return jsonify({
            "results": results,
            "successCount": success_count,
            "errorCount": error_count,
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    import sys
    debug = "--debug" in sys.argv
    port = 5001
    for arg in sys.argv[1:]:
        if arg.startswith("--port="):
            port = int(arg.split("=")[1])
    if not debug:
        import threading, webbrowser
        threading.Timer(1.0, lambda: webbrowser.open(f"http://127.0.0.1:{port}")).start()

    # Initialize pipeline scheduler (guard against Werkzeug debug double-init)
    if not debug or os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        pipeline.init_scheduler()

    try:
        app.run(port=port, debug=debug, threaded=True)
    finally:
        pipeline.shutdown_scheduler()
