@echo off
setlocal
echo ============================================
echo   Data Rover - Windows Build
echo ============================================
echo.

:: Check prerequisites
where python >nul 2>&1 || (echo ERROR: Python not found. Install from python.org && exit /b 1)
where node >nul 2>&1 || (echo ERROR: Node.js not found. Install from nodejs.org && exit /b 1)

set ROOT=%~dp0
set DIST=%ROOT%dist\DataRover

:: 1. Build frontend
echo [1/4] Building frontend...
cd /d "%ROOT%frontend"
call npm install --silent 2>nul
call npx vite build --outDir "%ROOT%backend\static" 2>nul
if errorlevel 1 (echo ERROR: Frontend build failed && exit /b 1)
echo       Done.

:: 2. Install Python dependencies + PyInstaller
echo [2/4] Installing Python dependencies...
cd /d "%ROOT%"
pip install -r backend\requirements.txt --quiet 2>nul
pip install pyinstaller --quiet 2>nul
echo       Done.

:: 3. Build executable
echo [3/4] Building executable with PyInstaller...
cd /d "%ROOT%"
pyinstaller datarover.spec --noconfirm --clean >nul 2>&1
if errorlevel 1 (
    echo       Retrying with verbose output...
    pyinstaller datarover.spec --noconfirm --clean
)
echo       Done.

:: 4. Create data and uploads folders alongside the exe
echo [4/4] Setting up runtime folders...
mkdir "%ROOT%dist\DataRover\data" 2>nul
mkdir "%ROOT%dist\DataRover\uploads" 2>nul

:: Create a launcher batch file
(
echo @echo off
echo setlocal
echo set PORT=5001
echo if not "%%1"=="" set PORT=%%1
echo echo.
echo echo   Data Rover starting on http://127.0.0.1:%%PORT%%
echo echo   Press Ctrl+C to stop.
echo echo.
echo cd /d "%%~dp0"
echo DataRover.exe --port=%%PORT%%
echo pause
) > "%ROOT%dist\DataRover\Start DataRover.bat"

echo.
echo ============================================
echo   Build complete!
echo ============================================
echo.
echo   Output: %ROOT%dist\DataRover\
echo.
echo   To run:
echo     Double-click "Start DataRover.bat"
echo     Or: DataRover.exe --port=5001
echo.
echo   To distribute:
echo     Zip the dist\DataRover folder and share it.
echo     No Python or Node.js needed on the target machine.
echo.
pause
