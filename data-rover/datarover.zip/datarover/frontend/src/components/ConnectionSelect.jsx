import React, { useState, useRef, useEffect } from 'react'
import { connectionDisplayName } from './ConnectionModal.jsx'

// Inline SVG icons for each connection type
const SalesforceIcon = () => (
  <svg width="16" height="12" viewBox="0 0 24 18" fill="none" style={{ flexShrink: 0 }}>
    <path d="M10 1.5c-1.7 0-3.2.8-4.2 2C5 2.6 3.9 2.1 2.7 2.1 1.2 2.1 0 3.5 0 5.2c0 .5.1 1 .3 1.4C.1 7.2 0 7.8 0 8.5c0 2.5 2 4.5 4.4 4.5.7 0 1.3-.2 1.9-.4.7 1.1 2 1.9 3.4 1.9 1 0 1.9-.4 2.6-1 .7.6 1.6 1 2.6 1 1.4 0 2.7-.8 3.4-1.9.6.3 1.2.4 1.9.4 2.4 0 4.4-2 4.4-4.5 0-.7-.1-1.3-.3-1.9.2-.4.3-.9.3-1.4 0-1.7-1.2-3.1-2.7-3.1-1.2 0-2.3.5-3.1 1.4-1-1.2-2.5-2-4.2-2-.8 0-1.6.2-2.3.5-.7-.3-1.5-.5-2.3-.5z" fill="#00A1E0"/>
  </svg>
)

const AthenaIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <path d="M12 2L3 7v10l9 5 9-5V7l-9-5z" fill="#8C4FFF" opacity="0.15"/>
    <path d="M12 2L3 7v10l9 5 9-5V7l-9-5z" stroke="#8C4FFF" strokeWidth="1.5" fill="none"/>
    <path d="M12 7l-5 3v4l5 3 5-3v-4l-5-3z" fill="#8C4FFF" opacity="0.4"/>
    <circle cx="12" cy="12" r="2" fill="#8C4FFF"/>
  </svg>
)

const RedshiftIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <path d="M12 2L3 7v10l9 5 9-5V7l-9-5z" fill="#E7157B" opacity="0.15"/>
    <path d="M12 2L3 7v10l9 5 9-5V7l-9-5z" stroke="#E7157B" strokeWidth="1.5" fill="none"/>
    <rect x="9" y="8" width="6" height="2" rx="0.5" fill="#E7157B"/>
    <rect x="9" y="11" width="6" height="2" rx="0.5" fill="#E7157B"/>
    <rect x="9" y="14" width="6" height="2" rx="0.5" fill="#E7157B"/>
  </svg>
)

const MySQLIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <ellipse cx="12" cy="6" rx="8" ry="3" fill="#00758F" opacity="0.2" stroke="#00758F" strokeWidth="1.2"/>
    <path d="M4 6v6c0 1.66 3.58 3 8 3s8-1.34 8-3V6" stroke="#00758F" strokeWidth="1.2" fill="none"/>
    <path d="M4 12v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6" stroke="#00758F" strokeWidth="1.2" fill="none"/>
  </svg>
)

const PostgresIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <ellipse cx="12" cy="6" rx="8" ry="3" fill="#336791" opacity="0.2" stroke="#336791" strokeWidth="1.2"/>
    <path d="M4 6v6c0 1.66 3.58 3 8 3s8-1.34 8-3V6" stroke="#336791" strokeWidth="1.2" fill="none"/>
    <path d="M4 12v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6" stroke="#336791" strokeWidth="1.2" fill="none"/>
  </svg>
)

const DuckDBIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <ellipse cx="12" cy="6" rx="8" ry="3" fill="#FFC107" opacity="0.25" stroke="#F59E0B" strokeWidth="1.2"/>
    <path d="M4 6v6c0 1.66 3.58 3 8 3s8-1.34 8-3V6" stroke="#F59E0B" strokeWidth="1.2" fill="none"/>
    <path d="M4 12v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6" stroke="#F59E0B" strokeWidth="1.2" fill="none"/>
  </svg>
)

export const CsvIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <path d="M6 2h8l6 6v12a2 2 0 01-2 2H6a2 2 0 01-2-2V4a2 2 0 012-2z" fill="#22C55E" opacity="0.15" stroke="#22C55E" strokeWidth="1.2"/>
    <path d="M14 2v6h6" stroke="#22C55E" strokeWidth="1.2" fill="none"/>
    <text x="12" y="17" textAnchor="middle" fill="#22C55E" fontSize="6" fontWeight="700" fontFamily="sans-serif">CSV</text>
  </svg>
)

export const DbIcon = ({ size = 14, color = '#6366f1' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
    <ellipse cx="12" cy="6" rx="8" ry="3" fill={color} opacity="0.25" stroke={color} strokeWidth="1.3"/>
    <path d={`M4 6v6c0 1.66 3.58 3 8 3s8-1.34 8-3V6`} stroke={color} strokeWidth="1.3" fill="none"/>
    <path d={`M4 12v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6`} stroke={color} strokeWidth="1.3" fill="none"/>
  </svg>
)

export function getConnectionIcon(conn) {
  if (!conn) return null
  if (conn === '__csv__') return <CsvIcon />
  if (conn.loginUrl) return <SalesforceIcon />
  if (conn.dbType === 'athena') return <AthenaIcon />
  if (conn.dbType === 'redshift') return <RedshiftIcon />
  if (conn.dbType === 'mysql') return <MySQLIcon />
  if (conn.dbType === 'duckdb') return <DuckDBIcon />
  return <PostgresIcon />
}

export function DatabaseSelect({ databases = [], value = '', onChange, placeholder = 'Select database...' }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  return (
    <div ref={ref} className="conn-select-wrapper">
      <div
        className={`conn-select-trigger ${open ? 'open' : ''}`}
        onClick={() => setOpen(!open)}
      >
        <div className="conn-select-value">
          {value && <span className="conn-select-icon"><DbIcon size={14} color="#6366f1" /></span>}
          <span className={`conn-select-text ${!value ? 'placeholder' : ''}`}>{value || placeholder}</span>
        </div>
        <span className="conn-select-arrow">{open ? '\u25B4' : '\u25BE'}</span>
      </div>
      {open && (
        <div className="conn-select-dropdown">
          <div
            className={`conn-select-option ${!value ? 'selected' : ''}`}
            onClick={() => { onChange(''); setOpen(false) }}
          >
            <span className="conn-select-opt-text placeholder">{placeholder}</span>
          </div>
          {databases.map(db => (
            <div
              key={db}
              className={`conn-select-option ${value === db ? 'selected' : ''}`}
              onClick={() => { onChange(db); setOpen(false) }}
            >
              <span className="conn-select-icon"><DbIcon size={14} color="#6366f1" /></span>
              <span className="conn-select-opt-text">{db}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export default function ConnectionSelect({ connections = [], value = '', onChange, extraOptions = [], placeholder = 'Select connection...' }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const selectedConn = connections.find(c => c.id === value)
  const selectedExtra = extraOptions.find(o => o.value === value)

  const displayText = selectedConn
    ? connectionDisplayName(selectedConn)
    : selectedExtra
      ? selectedExtra.label
      : placeholder

  const displayIcon = selectedConn
    ? getConnectionIcon(selectedConn)
    : selectedExtra
      ? selectedExtra.icon || null
      : null

  return (
    <div ref={ref} className="conn-select-wrapper">
      <div
        className={`conn-select-trigger ${open ? 'open' : ''}`}
        onClick={() => setOpen(!open)}
      >
        <div className="conn-select-value">
          {displayIcon && <span className="conn-select-icon">{displayIcon}</span>}
          <span className={`conn-select-text ${!selectedConn && !selectedExtra ? 'placeholder' : ''}`}>{displayText}</span>
        </div>
        <span className="conn-select-arrow">{open ? '\u25B4' : '\u25BE'}</span>
      </div>
      {open && (
        <div className="conn-select-dropdown">
          <div
            className={`conn-select-option ${!value ? 'selected' : ''}`}
            onClick={() => { onChange(''); setOpen(false) }}
          >
            <span className="conn-select-opt-text placeholder">{placeholder}</span>
          </div>
          {connections.map(c => (
            <div
              key={c.id}
              className={`conn-select-option ${value === c.id ? 'selected' : ''}`}
              onClick={() => { onChange(c.id); setOpen(false) }}
            >
              <span className="conn-select-icon">{getConnectionIcon(c)}</span>
              <span className="conn-select-opt-text">{connectionDisplayName(c)}</span>
            </div>
          ))}
          {extraOptions.length > 0 && (
            <>
              <div className="conn-select-divider" />
              {extraOptions.map(o => (
                <div
                  key={o.value}
                  className={`conn-select-option ${value === o.value ? 'selected' : ''}`}
                  onClick={() => { onChange(o.value); setOpen(false) }}
                >
                  {o.icon && <span className="conn-select-icon">{o.icon}</span>}
                  <span className="conn-select-opt-text">{o.label}</span>
                </div>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  )
}
