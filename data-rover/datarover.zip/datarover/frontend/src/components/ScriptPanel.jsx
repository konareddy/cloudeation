import React, { useState, useEffect, useCallback, useRef } from 'react'

const api = (path, opts) => fetch(path, opts).then(r => {
  if (!r.ok) return r.text().then(t => { throw new Error(`${r.status}: ${t}`) })
  return r.json()
})

const STATUS_ICONS = {
  pending: '⏳',
  running: '🔄',
  waiting: '⏳',
  complete: '✅',
  error: '❌',
  warning: '⚠️',
}

const STATUS_COLORS = {
  pending: '#6b7280',
  running: '#3b82f6',
  waiting: '#f59e0b',
  complete: '#10b981',
  error: '#ef4444',
  warning: '#f59e0b',
}

const SAMPLE_SCRIPT = `# Example: Extract SF objects, transform in Postgres, load back to SF
#
# Step 1: Mirror SF objects to local database
extract Product2 User

# Step 2: Build update table with SQL
sql CREATE TABLE product_update AS
  SELECT id, name FROM product2 LIMIT 10;

# Step 3: Load back to Salesforce
load product_update Product2 update
`

// Syntax highlighting keywords
const KEYWORDS = ['extract', 'load', 'sql', 'query', 'use', 'connections', 'objects', 'databases', 'tables', 'describe', 'count', 'preview']

function highlightLine(line) {
  if (line.trim().startsWith('#') || line.trim().startsWith('--')) {
    return <span style={{ color: '#6b7280', fontStyle: 'italic' }}>{line}</span>
  }
  const firstWord = line.trim().split(/\s/)[0]?.toLowerCase()
  if (KEYWORDS.includes(firstWord)) {
    const idx = line.indexOf(firstWord)
    return (
      <>
        {line.slice(0, idx)}
        <span style={{ color: '#60a5fa', fontWeight: 600 }}>{firstWord}</span>
        <span style={{ color: '#d1d5db' }}>{line.slice(idx + firstWord.length)}</span>
      </>
    )
  }
  return <span style={{ color: '#d1d5db' }}>{line}</span>
}

export default function ScriptPanel({
  sfConnections = [],
  dbConnections = [],
  activeSfId,
  activeDbId,
  activeDatabase,
}) {
  const [localSfId, setLocalSfId] = useState(activeSfId || '')
  const [localDbId, setLocalDbId] = useState(activeDbId || '')
  const [localDatabase, setLocalDatabase] = useState(activeDatabase || '')
  const [databases, setDatabases] = useState([])

  // Sync from parent when they change
  useEffect(() => { if (activeSfId) setLocalSfId(activeSfId) }, [activeSfId])
  useEffect(() => { if (activeDbId) setLocalDbId(activeDbId) }, [activeDbId])
  useEffect(() => { if (activeDatabase) setLocalDatabase(activeDatabase) }, [activeDatabase])

  // Fetch databases when DB connection changes
  useEffect(() => {
    if (!localDbId) { setDatabases([]); return }
    fetch(`/api/database/${localDbId}/databases`)
      .then(r => r.json())
      .then(data => setDatabases(data.databases || []))
      .catch(() => setDatabases([]))
  }, [localDbId])

  // Fetch SF object names for autocomplete
  useEffect(() => {
    if (!localSfId) { setSfObjects([]); return }
    fetch(`/api/salesforce/${localSfId}/objects`)
      .then(r => r.json())
      .then(data => setSfObjects((data.objects || []).map(o => o.name || o.apiName || o)))
      .catch(() => setSfObjects([]))
  }, [localSfId])

  // Fetch DB table names for autocomplete
  useEffect(() => {
    if (!localDbId) { setDbTables([]); return }
    const dbParam = localDatabase ? `?database=${localDatabase}` : ''
    fetch(`/api/database/${localDbId}/tables${dbParam}`)
      .then(r => r.json())
      .then(data => setDbTables((data.tables || []).map(t => t.name || t.table_name || t)))
      .catch(() => setDbTables([]))
  }, [localDbId, localDatabase])

  const [script, setScript] = useState(() => {
    return localStorage.getItem('datarover_script') || SAMPLE_SCRIPT
  })
  const [runId, setRunId] = useState(null)
  const [runStatus, setRunStatus] = useState(null)
  const [isRunning, setIsRunning] = useState(false)
  const [savedScripts, setSavedScripts] = useState(() => {
    try { return JSON.parse(localStorage.getItem('datarover_scripts') || '{}') } catch { return {} }
  })
  const [scriptName, setScriptName] = useState('Untitled')
  const [showSaveDialog, setShowSaveDialog] = useState(false)
  const [showLoadDialog, setShowLoadDialog] = useState(false)
  const [suggestions, setSuggestions] = useState([])
  const [suggestPos, setSuggestPos] = useState(null) // {top, left}
  const [suggestIdx, setSuggestIdx] = useState(0)
  const [sfObjects, setSfObjects] = useState([])
  const [dbTables, setDbTables] = useState([])
  const textareaRef = useRef(null)
  const logRef = useRef(null)
  const pollRef = useRef(null)

  // Auto-save script to localStorage
  useEffect(() => {
    localStorage.setItem('datarover_script', script)
  }, [script])

  // Poll for run status
  useEffect(() => {
    if (!runId || !isRunning) return
    const poll = () => {
      api(`/api/script/run/${runId}`)
        .then(data => {
          setRunStatus(data)
          if (data.status === 'complete' || data.status === 'error') {
            setIsRunning(false)
          }
        })
        .catch(() => {})
    }
    poll()
    pollRef.current = setInterval(poll, 1500)
    return () => clearInterval(pollRef.current)
  }, [runId, isRunning])

  // Auto-scroll log to current step
  useEffect(() => {
    if (logRef.current) {
      logRef.current.scrollTop = logRef.current.scrollHeight
    }
  }, [runStatus])

  const handleRun = useCallback(() => {
    if (!script.trim()) return
    const context = {
      sfConnectionId: localSfId || '',
      dbConnectionId: localDbId || '',
      database: localDatabase || '',
    }
    api('/api/script/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ script, context }),
    })
      .then(data => {
        setRunId(data.runId)
        setRunStatus(null)
        setIsRunning(true)
      })
      .catch(err => {
        setRunStatus({ status: 'error', error: err.message, steps: [] })
      })
  }, [script, localSfId, localDbId, localDatabase])

  const handleStop = useCallback(() => {
    // TODO: implement stop
    setIsRunning(false)
  }, [])

  const handleSave = useCallback(() => {
    const name = scriptName.trim() || 'Untitled'
    const updated = { ...savedScripts, [name]: script }
    setSavedScripts(updated)
    localStorage.setItem('datarover_scripts', JSON.stringify(updated))
    setShowSaveDialog(false)
  }, [scriptName, script, savedScripts])

  const handleLoad = useCallback((name) => {
    if (savedScripts[name]) {
      setScript(savedScripts[name])
      setScriptName(name)
    }
    setShowLoadDialog(false)
  }, [savedScripts])

  const handleDelete = useCallback((name, e) => {
    e.stopPropagation()
    const updated = { ...savedScripts }
    delete updated[name]
    setSavedScripts(updated)
    localStorage.setItem('datarover_scripts', JSON.stringify(updated))
  }, [savedScripts])

  // Autocomplete: commands that suggest SF objects vs DB tables
  const SF_COMMANDS = ['extract', 'describe', 'count', 'preview']
  const DB_COMMANDS = ['load', 'sql', 'query', 'tables']

  const handleScriptChange = useCallback((e) => {
    const val = e.target.value
    setScript(val)

    // Autocomplete logic: get current line and cursor position
    const ta = textareaRef.current
    if (!ta) return
    const cursorPos = ta.selectionStart
    const textBefore = val.substring(0, cursorPos)
    const currentLine = textBefore.split('\n').pop() || ''
    const words = currentLine.trim().split(/\s+/)
    const cmd = words[0]?.toLowerCase() || ''
    const lastWord = words[words.length - 1] || ''

    // Only suggest if we're typing an argument (not the command itself)
    if (words.length < 2 || !lastWord) {
      setSuggestions([])
      return
    }

    let pool = []
    if (SF_COMMANDS.includes(cmd)) pool = sfObjects
    else if (cmd === 'load') pool = dbTables
    else if (cmd === 'use' && words[1]?.toLowerCase() === 'database') pool = databases

    if (!pool.length) { setSuggestions([]); return }

    const prefix = lastWord.toLowerCase()
    const matches = pool.filter(n => n.toLowerCase().startsWith(prefix) && n.toLowerCase() !== prefix).slice(0, 8)
    if (matches.length === 0) { setSuggestions([]); return }

    // Compute position for dropdown
    const lines = textBefore.split('\n')
    const lineNum = lines.length - 1
    const colNum = lines[lines.length - 1].length
    setSuggestPos({ top: (lineNum + 1) * 19.2 + 8, left: colNum * 7.2 + 48 })
    setSuggestions(matches)
    setSuggestIdx(0)
  }, [sfObjects, dbTables, databases])

  const applySuggestion = useCallback((suggestion) => {
    const ta = textareaRef.current
    if (!ta) return
    const cursorPos = ta.selectionStart
    const textBefore = script.substring(0, cursorPos)
    const textAfter = script.substring(cursorPos)
    const currentLine = textBefore.split('\n').pop() || ''
    const words = currentLine.trim().split(/\s+/)
    const lastWord = words[words.length - 1] || ''
    // Replace the partial word with the suggestion
    const newBefore = textBefore.substring(0, textBefore.length - lastWord.length) + suggestion + ' '
    setScript(newBefore + textAfter)
    setSuggestions([])
    // Restore cursor
    setTimeout(() => {
      ta.focus()
      ta.selectionStart = ta.selectionEnd = newBefore.length
    }, 0)
  }, [script])

  const handleScriptKeyDown = useCallback((e) => {
    if (suggestions.length === 0) return
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      setSuggestIdx(i => Math.min(i + 1, suggestions.length - 1))
    } else if (e.key === 'ArrowUp') {
      e.preventDefault()
      setSuggestIdx(i => Math.max(i - 1, 0))
    } else if (e.key === 'Tab' || e.key === 'Enter') {
      if (suggestions[suggestIdx]) {
        e.preventDefault()
        applySuggestion(suggestions[suggestIdx])
      }
    } else if (e.key === 'Escape') {
      setSuggestions([])
    }
  }, [suggestions, suggestIdx, applySuggestion])

  const sfName = sfConnections.find(c => c.id === localSfId)?.name || 'None'
  const dbName = dbConnections.find(c => c.id === localDbId)?.name || 'None'

  return (
    <div className="script-panel">
      {/* Toolbar */}
      <div className="script-toolbar">
        <div className="script-toolbar-left">
          <button
            className="script-btn script-btn-primary"
            onClick={handleRun}
            disabled={isRunning || !script.trim()}
          >
            {isRunning ? '⏳ Running...' : '▶ Run Script'}
          </button>
          {isRunning && (
            <button className="script-btn script-btn-danger" onClick={handleStop}>
              ⏹ Stop
            </button>
          )}
          <button className="script-btn" onClick={() => setShowSaveDialog(true)}>
            💾 Save
          </button>
          <button className="script-btn" onClick={() => setShowLoadDialog(true)}>
            📂 Load
          </button>
          <button
            className="script-btn"
            onClick={() => { setScript(''); setRunStatus(null); setRunId(null) }}
          >
            🗑 Clear
          </button>
        </div>
        <div className="script-toolbar-right">
          <label className="script-conn-label">SF:</label>
          <select
            className="script-conn-select"
            value={localSfId}
            onChange={e => setLocalSfId(e.target.value)}
          >
            <option value="">Select...</option>
            {sfConnections.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <label className="script-conn-label">DB:</label>
          <select
            className="script-conn-select"
            value={localDbId}
            onChange={e => { setLocalDbId(e.target.value); setLocalDatabase('') }}
          >
            <option value="">Select...</option>
            {dbConnections.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          {databases.length > 0 && (
            <>
              <label className="script-conn-label">/</label>
              <select
                className="script-conn-select"
                value={localDatabase}
                onChange={e => setLocalDatabase(e.target.value)}
              >
                <option value="">Default</option>
                {databases.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </>
          )}
        </div>
      </div>

      {/* Main content: editor + log */}
      <div className="script-body">
        {/* Editor */}
        <div className="script-editor-pane">
          <div className="script-editor-header">
            <span>📝 Script Editor</span>
            <span className="script-line-count">{script.split('\n').length} lines</span>
          </div>
          <div className="script-editor-container">
            {/* Line numbers */}
            <div className="script-line-numbers">
              {script.split('\n').map((_, i) => (
                <div key={i} className="script-line-num">{i + 1}</div>
              ))}
            </div>
            <div style={{ position: 'relative', flex: 1 }}>
              <textarea
                ref={textareaRef}
                className="script-textarea"
                value={script}
                onChange={handleScriptChange}
                onKeyDown={handleScriptKeyDown}
                onBlur={() => setTimeout(() => setSuggestions([]), 150)}
                spellCheck={false}
                placeholder="# Write your Data Rover script here..."
              />
              {suggestions.length > 0 && suggestPos && (
                <div
                  className="script-autocomplete"
                  style={{ top: suggestPos.top, left: suggestPos.left }}
                >
                  {suggestions.map((s, i) => (
                    <div
                      key={s}
                      className={`script-autocomplete-item ${i === suggestIdx ? 'active' : ''}`}
                      onMouseDown={(e) => { e.preventDefault(); applySuggestion(s) }}
                    >
                      {s}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Execution Log */}
        <div className="script-log-pane">
          <div className="script-editor-header">
            <span>📋 Execution Log</span>
            {runStatus && (
              <span style={{ color: STATUS_COLORS[runStatus.status] || '#9ca3af', fontWeight: 600 }}>
                {runStatus.status?.toUpperCase()}
              </span>
            )}
          </div>
          <div className="script-log" ref={logRef}>
            {!runStatus && !runId && (
              <div className="script-log-empty">
                Click "▶ Run Script" to execute your script.<br />
                Each step runs sequentially. Extract and Load steps wait for completion.
              </div>
            )}
            {runStatus?.steps?.map((step, i) => (
              <div
                key={i}
                className={`script-step ${step.status}`}
              >
                <div className="script-step-header">
                  <span className="script-step-num">Step {step.stepNum}</span>
                  <span className="script-step-icon">{STATUS_ICONS[step.status] || '⏳'}</span>
                  <span className="script-step-cmd">{step.command?.substring(0, 80)}{step.command?.length > 80 ? '...' : ''}</span>
                </div>
                {step.output && (
                  <div className="script-step-output">{step.output}</div>
                )}
                {step.error && (
                  <div className="script-step-error">{step.error}</div>
                )}
                {step.startedAt && step.finishedAt && (
                  <div className="script-step-duration">
                    {((new Date(step.finishedAt) - new Date(step.startedAt)) / 1000).toFixed(1)}s
                  </div>
                )}
              </div>
            ))}
            {runStatus?.error && (
              <div className="script-step error">
                <div className="script-step-error">⛔ {runStatus.error}</div>
              </div>
            )}
            {runStatus?.status === 'complete' && (
              <div className="script-complete-msg">
                ✅ Script completed successfully ({runStatus.totalSteps} steps)
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Save Dialog */}
      {showSaveDialog && (
        <div className="script-dialog-overlay" onClick={() => setShowSaveDialog(false)}>
          <div className="script-dialog" onClick={e => e.stopPropagation()}>
            <h3>Save Script</h3>
            <input
              type="text"
              value={scriptName}
              onChange={e => setScriptName(e.target.value)}
              placeholder="Script name..."
              className="script-dialog-input"
              autoFocus
              onKeyDown={e => e.key === 'Enter' && handleSave()}
            />
            <div className="script-dialog-actions">
              <button className="script-btn script-btn-primary" onClick={handleSave}>Save</button>
              <button className="script-btn" onClick={() => setShowSaveDialog(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Load Dialog */}
      {showLoadDialog && (
        <div className="script-dialog-overlay" onClick={() => setShowLoadDialog(false)}>
          <div className="script-dialog" onClick={e => e.stopPropagation()}>
            <h3>Load Script</h3>
            {Object.keys(savedScripts).length === 0 ? (
              <p style={{ color: '#9ca3af' }}>No saved scripts yet.</p>
            ) : (
              <div className="script-list">
                {Object.keys(savedScripts).map(name => (
                  <div key={name} className="script-list-item" onClick={() => handleLoad(name)}>
                    <span>{name}</span>
                    <button
                      className="script-btn-small"
                      onClick={(e) => handleDelete(name, e)}
                    >✕</button>
                  </div>
                ))}
              </div>
            )}
            <div className="script-dialog-actions">
              <button className="script-btn" onClick={() => setShowLoadDialog(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
