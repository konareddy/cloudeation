import React, { useState, useEffect } from 'react'

export const FONTS = [
  'Inter, -apple-system, sans-serif',
  'SF Mono, Fira Code, monospace',
  'Menlo, Monaco, monospace',
  'Georgia, serif',
  'system-ui, sans-serif',
]

export const FONT_LABELS = [
  'Inter (Default)',
  'SF Mono',
  'Menlo',
  'Georgia',
  'System UI',
]

export const THEMES = [
  { id: 'light', label: 'Light', bg: '#f0f2f5', text: '#1a1a2e', card: '#ffffff', accent: '#2563eb', headerBg: 'linear-gradient(135deg, #0061a0, #00a1e0)' },
  { id: 'dark', label: 'Dark', bg: '#1a1b2e', text: '#e4e4e7', card: '#262738', accent: '#60a5fa', headerBg: 'linear-gradient(135deg, #1e293b, #334155)' },
  { id: 'blue', label: 'Blue', bg: '#eff6ff', text: '#1e3a5f', card: '#ffffff', accent: '#1d4ed8', headerBg: 'linear-gradient(135deg, #1e40af, #3b82f6)' },
  { id: 'green', label: 'Green', bg: '#f0fdf4', text: '#14532d', card: '#ffffff', accent: '#16a34a', headerBg: 'linear-gradient(135deg, #166534, #22c55e)' },
]

export const DEFAULT_SETTINGS = {
  fontFamily: FONTS[0],
  fontSize: 14,
  theme: 'light',
  editorFontSize: 13,
  tableFontSize: 12,
}

function loadSettings() {
  try {
    const saved = localStorage.getItem('app_settings')
    return saved ? { ...DEFAULT_SETTINGS, ...JSON.parse(saved) } : DEFAULT_SETTINGS
  } catch { return DEFAULT_SETTINGS }
}

function saveSettings(settings) {
  localStorage.setItem('app_settings', JSON.stringify(settings))
}

export function applySettings(settings) {
  const theme = THEMES.find(t => t.id === settings.theme) || THEMES[0]
  const root = document.documentElement

  // Set CSS variables
  root.style.setProperty('--font-family', settings.fontFamily)
  root.style.setProperty('--font-size', settings.fontSize + 'px')
  root.style.setProperty('--editor-font-size', settings.editorFontSize + 'px')
  root.style.setProperty('--table-font-size', settings.tableFontSize + 'px')
  root.style.setProperty('--bg-color', theme.bg)
  root.style.setProperty('--text-color', theme.text)
  root.style.setProperty('--card-color', theme.card)
  root.style.setProperty('--accent-color', theme.accent)

  // Apply directly to body for immediate effect
  document.body.style.fontFamily = settings.fontFamily
  document.body.style.fontSize = settings.fontSize + 'px'
  document.body.style.background = theme.bg
  document.body.style.color = theme.text

  // Apply to all cards/panels
  document.querySelectorAll('.object-browser, .work-area, .modal, .config-card').forEach(el => {
    el.style.background = theme.card
    el.style.color = theme.text
  })

  // Apply header theme
  const header = document.querySelector('.header')
  if (header) header.style.background = theme.headerBg

  // Apply editor font size
  document.querySelectorAll('.sql-editor').forEach(el => {
    el.style.fontSize = settings.editorFontSize + 'px'
  })

  // Apply table font size
  document.querySelectorAll('.results-table').forEach(el => {
    el.style.fontSize = settings.tableFontSize + 'px'
  })
}

export function useSettings() {
  const [settings, setSettings] = useState(loadSettings)

  useEffect(() => {
    applySettings(settings)
  }, [settings])

  // Re-apply when DOM changes (new elements added by tab switching, etc.)
  useEffect(() => {
    const observer = new MutationObserver(() => {
      applySettings(settings)
    })
    observer.observe(document.body, { childList: true, subtree: true })
    return () => observer.disconnect()
  }, [settings])

  const updateSettings = (updates) => {
    setSettings(prev => {
      const next = { ...prev, ...updates }
      saveSettings(next)
      return next
    })
  }

  return [settings, updateSettings]
}

const AI_MODELS = [
  { id: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash (Fast, Free)' },
  { id: 'gemini-2.0-flash-lite', label: 'Gemini 2.0 Flash Lite (Fastest)' },
  { id: 'gemini-1.5-pro', label: 'Gemini 1.5 Pro (Most capable)' },
]

function AiSettingsSection() {
  const [aiKey, setAiKey] = useState('')
  const [aiModel, setAiModel] = useState('gemini-2.0-flash')
  const [showKey, setShowKey] = useState(false)
  const [hasKey, setHasKey] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [maskedKey, setMaskedKey] = useState('')

  useEffect(() => {
    fetch('/api/ai/settings')
      .then(r => r.json())
      .then(data => {
        setHasKey(!!data.hasKey)
        setAiModel(data.model || 'gemini-2.0-flash')
        if (data.hasKey) setMaskedKey(data.apiKey || '****')
      })
      .catch(() => {})
  }, [])

  const handleSave = async () => {
    setSaving(true)
    setSaved(false)
    const payload = { model: aiModel }
    if (aiKey.trim()) payload.apiKey = aiKey.trim()
    try {
      await fetch('/api/ai/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (aiKey.trim()) { setHasKey(true); setMaskedKey('****' + aiKey.slice(-4)); setAiKey('') }
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    } catch { /* ignore */ }
    setSaving(false)
  }

  return (
    <div style={{ paddingTop: 12, borderTop: '1px solid #e5e7eb' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <label style={{ fontWeight: 600, fontSize: 13, margin: 0 }}>AI Assistant</label>
        <span style={{
          width: 8, height: 8, borderRadius: '50%', display: 'inline-block',
          background: hasKey ? '#10b981' : '#ef4444',
        }} title={hasKey ? 'API key configured' : 'No API key'} />
      </div>
      <div className="form-group" style={{ marginBottom: 8 }}>
        <label style={{ fontSize: 12 }}>
          Gemini API Key {hasKey && <span style={{ color: '#9ca3af', fontSize: 11 }}>({maskedKey})</span>}
        </label>
        <div style={{ display: 'flex', gap: 4 }}>
          <input
            type={showKey ? 'text' : 'password'}
            className="form-input"
            value={aiKey}
            onChange={e => setAiKey(e.target.value)}
            placeholder={hasKey ? 'Enter new key to replace...' : 'Paste your Gemini API key'}
            style={{ flex: 1, fontSize: 12 }}
          />
          <button
            onClick={() => setShowKey(p => !p)}
            style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 4, cursor: 'pointer', padding: '0 8px', fontSize: 11, color: '#6b7280' }}
          >{showKey ? 'Hide' : 'Show'}</button>
        </div>
        <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>
          Get a free key from <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener noreferrer" style={{ color: '#2563eb' }}>Google AI Studio</a>
        </div>
      </div>
      <div className="form-group" style={{ marginBottom: 8 }}>
        <label style={{ fontSize: 12 }}>Model</label>
        <select className="form-input" value={aiModel} onChange={e => setAiModel(e.target.value)} style={{ fontSize: 12 }}>
          {AI_MODELS.map(m => <option key={m.id} value={m.id}>{m.label}</option>)}
        </select>
      </div>
      <button
        className="btn btn-primary"
        onClick={handleSave}
        disabled={saving}
        style={{ fontSize: 12, padding: '4px 16px' }}
      >
        {saving ? 'Saving...' : saved ? 'Saved!' : 'Save AI Settings'}
      </button>
    </div>
  )
}

export default function SettingsPanel({ settings, onUpdate, onClose }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" style={{ maxWidth: 420 }} onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>Settings</h2>
          <button className="btn-close" onClick={onClose}>&times;</button>
        </div>
        <div className="modal-body">
          <div className="form-group">
            <label>Theme</label>
            <div style={{ display: 'flex', gap: 8 }}>
              {THEMES.map(t => (
                <button
                  key={t.id}
                  onClick={() => onUpdate({ theme: t.id })}
                  style={{
                    flex: 1, padding: '8px 4px',
                    border: settings.theme === t.id ? '2px solid #2563eb' : '1px solid #d1d5db',
                    borderRadius: 6, cursor: 'pointer', background: t.bg, color: t.text,
                    fontSize: 12, fontWeight: 500,
                  }}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </div>

          <div className="form-group">
            <label>Font Family</label>
            <select className="form-input" value={settings.fontFamily} onChange={e => onUpdate({ fontFamily: e.target.value })}>
              {FONTS.map((f, i) => <option key={f} value={f} style={{ fontFamily: f }}>{FONT_LABELS[i]}</option>)}
            </select>
          </div>

          <div className="form-group">
            <label>UI Font Size: {settings.fontSize}px</label>
            <input type="range" min="11" max="20" value={settings.fontSize} onChange={e => onUpdate({ fontSize: parseInt(e.target.value) })} style={{ width: '100%' }} />
          </div>

          <div className="form-group">
            <label>Editor Font Size: {settings.editorFontSize}px</label>
            <input type="range" min="10" max="22" value={settings.editorFontSize} onChange={e => onUpdate({ editorFontSize: parseInt(e.target.value) })} style={{ width: '100%' }} />
          </div>

          <div className="form-group">
            <label>Table Font Size: {settings.tableFontSize}px</label>
            <input type="range" min="9" max="18" value={settings.tableFontSize} onChange={e => onUpdate({ tableFontSize: parseInt(e.target.value) })} style={{ width: '100%' }} />
          </div>

          <div style={{ paddingTop: 8, borderTop: '1px solid #e5e7eb' }}>
            <button className="btn btn-secondary" onClick={() => onUpdate({ ...DEFAULT_SETTINGS })} style={{ fontSize: 12 }}>Reset to Defaults</button>
          </div>

          <AiSettingsSection />
        </div>
      </div>
    </div>
  )
}
