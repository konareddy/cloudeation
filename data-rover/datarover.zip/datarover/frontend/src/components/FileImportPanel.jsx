import React, { useState, useRef, useEffect } from 'react'
import { connectionDisplayName } from './ConnectionModal.jsx'

export default function FileImportPanel({ dbConnections = [], onOpenModal }) {
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [tableName, setTableName] = useState('')
  const [targetDbId, setTargetDbId] = useState('')
  const [importing, setImporting] = useState(false)
  const [importJob, setImportJob] = useState(null)
  const [dragOver, setDragOver] = useState(false)
  const fileInputRef = useRef(null)
  const pollRef = useRef(null)

  useEffect(() => {
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [])

  useEffect(() => {
    if (dbConnections.length > 0 && !targetDbId) {
      setTargetDbId(dbConnections[0].id)
    }
  }, [dbConnections])

  const parseCSV = (text) => {
    const lines = text.split('\n').filter(l => l.trim())
    if (lines.length === 0) return null
    const parseLine = (line) => {
      const cells = []
      let current = '', inQuotes = false
      for (let i = 0; i < line.length; i++) {
        const ch = line[i]
        if (ch === '"') { inQuotes = !inQuotes }
        else if (ch === ',' && !inQuotes) { cells.push(current.trim()); current = '' }
        else { current += ch }
      }
      cells.push(current.trim())
      return cells
    }
    const columns = parseLine(lines[0])
    const rows = lines.slice(1, 6).map(line => {
      const cells = parseLine(line)
      const row = {}
      columns.forEach((col, i) => { row[col] = cells[i] || '' })
      return row
    })
    return { columns, rows, totalRows: lines.length - 1 }
  }

  const handleFile = (f) => {
    if (!f || !f.name.toLowerCase().endsWith('.csv')) return
    setFile(f)
    setImportJob(null)
    const name = f.name.replace(/\.csv$/i, '').toLowerCase().replace(/[^a-z0-9_]/g, '_')
    setTableName(name)
    const reader = new FileReader()
    reader.onload = (e) => { setPreview(parseCSV(e.target.result)) }
    reader.readAsText(f)
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setDragOver(false)
    handleFile(e.dataTransfer.files[0])
  }

  const handleImport = () => {
    if (!file || !targetDbId || !tableName) return
    setImporting(true)
    setImportJob({ status: 'starting', progress: 0, message: 'Uploading CSV...' })
    const formData = new FormData()
    formData.append('file', file)
    formData.append('targetDbConnectionId', targetDbId)
    formData.append('tableName', tableName)
    fetch('/api/import-csv', { method: 'POST', body: formData })
      .then(r => r.json())
      .then(data => {
        if (data.error) {
          setImportJob({ status: 'error', progress: 0, message: data.error })
          setImporting(false)
          return
        }
        const jobId = data.jobId
        pollRef.current = setInterval(() => {
          fetch(`/api/import-csv/${jobId}/status`).then(r => r.json()).then(s => {
            setImportJob(s)
            if (!s.running) { clearInterval(pollRef.current); pollRef.current = null; setImporting(false) }
          }).catch(() => {})
        }, 1000)
      })
      .catch(err => { setImportJob({ status: 'error', progress: 0, message: err.message }); setImporting(false) })
  }

  const handleClear = (e) => {
    e.stopPropagation()
    setFile(null)
    setPreview(null)
    setImportJob(null)
    setTableName('')
  }

  return (
    <div className="work-area" style={{ display: 'flex', flexDirection: 'column', padding: 20, gap: 14, overflow: 'auto' }}>
      {/* Drop zone */}
      <div
        onDrop={handleDrop}
        onDragOver={e => { e.preventDefault(); setDragOver(true) }}
        onDragLeave={() => setDragOver(false)}
        onClick={() => fileInputRef.current?.click()}
        className={`file-drop-zone ${dragOver ? 'file-drop-active' : ''} ${file ? 'file-drop-has-file' : ''}`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          style={{ display: 'none' }}
          onChange={e => { handleFile(e.target.files[0]); e.target.value = '' }}
        />
        {file ? (
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, width: '100%' }}>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
              <rect x="3" y="1" width="18" height="22" rx="2.5" stroke="#3b82f6" strokeWidth="1.5"/>
              <text x="12" y="15" textAnchor="middle" fontSize="7" fontWeight="700" fill="#3b82f6">CSV</text>
            </svg>
            <div style={{ flex: 1, textAlign: 'left' }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: '#1f2937' }}>{file.name}</div>
              <div style={{ fontSize: 11, color: '#6b7280' }}>
                {(file.size / 1024).toFixed(1)} KB
                {preview && <> &middot; {preview.totalRows.toLocaleString()} rows &middot; {preview.columns.length} columns</>}
              </div>
            </div>
            <button
              onClick={handleClear}
              style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 18, padding: '0 4px' }}
              title="Remove file"
            >&times;</button>
          </div>
        ) : (
          <>
            <svg width="36" height="36" viewBox="0 0 36 36" fill="none" style={{ margin: '0 auto 8px' }}>
              <rect x="6" y="3" width="24" height="30" rx="3" stroke="#d1d5db" strokeWidth="1.5"/>
              <path d="M14 18l4-4 4 4M18 14v10" stroke="#9ca3af" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
            <div style={{ fontSize: 13, color: '#6b7280' }}>Drop a CSV file here or click to browse</div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>Import data from .csv files into PostgreSQL or MySQL</div>
          </>
        )}
      </div>

      {/* Preview table */}
      {preview && preview.columns.length > 0 && (
        <div style={{ border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden', flexShrink: 0 }}>
          <div style={{ padding: '6px 12px', fontSize: 11, fontWeight: 600, color: '#374151', background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
            Preview (first {preview.rows.length} of {preview.totalRows.toLocaleString()} rows)
          </div>
          <div style={{ overflow: 'auto', maxHeight: 200 }}>
            <table className="results-table">
              <thead><tr>{preview.columns.map(c => <th key={c}>{c}</th>)}</tr></thead>
              <tbody>
                {preview.rows.map((row, i) => (
                  <tr key={i}>{preview.columns.map(c => <td key={c}>{row[c] || ''}</td>)}</tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Import config */}
      {file && (
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' }}>
          <div style={{ flex: 1, minWidth: 160 }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Table Name</label>
            <input
              className="form-input"
              value={tableName}
              onChange={e => setTableName(e.target.value)}
              placeholder="e.g. my_data"
              style={{ fontSize: 12, padding: '6px 10px' }}
            />
          </div>
          <div style={{ flex: 1, minWidth: 200 }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Target Database</label>
            <div style={{ display: 'flex', gap: 4 }}>
              <select
                className="config-select"
                value={targetDbId}
                onChange={e => setTargetDbId(e.target.value)}
                style={{ flex: 1, fontSize: 12, padding: '6px 10px' }}
              >
                <option value="">Select database...</option>
                {dbConnections.map(c => (
                  <option key={c.id} value={c.id}>{connectionDisplayName(c)}</option>
                ))}
              </select>
              {onOpenModal && (
                <button className="btn-inline-add" style={{ width: 28, height: 28, fontSize: 13 }} onClick={onOpenModal} title="Add connection">+</button>
              )}
            </div>
          </div>
          <button
            className="btn btn-primary"
            style={{ padding: '6px 20px', fontSize: 12, flexShrink: 0 }}
            onClick={handleImport}
            disabled={importing || !tableName.trim() || !targetDbId}
          >
            {importing ? 'Importing...' : 'Import to Database'}
          </button>
        </div>
      )}

      {/* Import progress */}
      {importJob && (
        <div style={{
          border: '1px solid',
          borderColor: importJob.status === 'complete' ? '#bbf7d0' : importJob.status === 'error' ? '#fecaca' : '#e5e7eb',
          borderRadius: 8,
          padding: '10px 14px',
          background: importJob.status === 'complete' ? '#f0fdf4' : importJob.status === 'error' ? '#fef2f2' : '#f9fafb',
        }}>
          <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6, color: importJob.status === 'complete' ? '#166534' : importJob.status === 'error' ? '#991b1b' : '#374151' }}>
            {importJob.status === 'complete' ? 'Import Complete' : importJob.status === 'error' ? 'Import Failed' : 'Importing...'}
          </div>
          <div className="progress-bar-container" style={{ width: '100%', height: 6, marginBottom: 6 }}>
            <div className={`progress-bar ${importJob.status === 'complete' ? 'complete' : importJob.status === 'error' ? 'error' : 'downloading'}`} style={{ width: `${importJob.progress || 0}%` }} />
          </div>
          <div style={{ fontSize: 11, color: '#6b7280' }}>{importJob.message || importJob.status}</div>
        </div>
      )}

      {/* Empty state hint */}
      {!file && !importJob && (
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 12 }}>
          Drop a CSV file above to import data into PostgreSQL or MySQL
        </div>
      )}
    </div>
  )
}
