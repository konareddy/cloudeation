import React, { useState, useEffect, useCallback, useRef, forwardRef, useImperativeHandle } from 'react'
import ConnectionSelect, { DatabaseSelect } from './ConnectionSelect.jsx'
import { connectionDisplayName } from './ConnectionModal.jsx'
import CompareHistoryPanel from './CompareHistoryPanel.jsx'

const PAGE_SIZE = 50

// Normalize field name for auto-mapping: lowercase, remove underscores
const normalize = (s) => s.toLowerCase().replace(/_/g, '')

// ---------------------------------------------------------------------------
// SearchSelect — type-to-filter dropdown for large field / object lists
// ---------------------------------------------------------------------------
function SearchSelect({ options = [], value = '', onChange, placeholder = '-- Select --', style = {} }) {
  const [open, setOpen] = useState(false)
  const [search, setSearch] = useState('')
  const ref = useRef(null)
  const inputRef = useRef(null)

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  useEffect(() => { if (open && inputRef.current) inputRef.current.focus() }, [open])

  // Normalize options: support both plain strings and {value, label} objects
  const normalized = options.map(o => typeof o === 'string' ? { value: o, label: o } : o)
  const filtered = search
    ? normalized.filter(o => o.label.toLowerCase().includes(search.toLowerCase()) || o.value.toLowerCase().includes(search.toLowerCase()))
    : normalized
  const displayLabel = normalized.find(o => o.value === value)?.label || value

  return (
    <div ref={ref} style={{ position: 'relative', ...style }}>
      <div
        onClick={() => { setOpen(!open); setSearch('') }}
        style={{
          width: '100%', padding: '5px 8px', borderRadius: 5, border: '1px solid #d1d5db',
          fontSize: 12, cursor: 'pointer', background: '#fff', display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          minHeight: 30,
        }}
      >
        <span style={{ color: value ? '#1a1a2e' : '#9ca3af', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {displayLabel || placeholder}
        </span>
        <span style={{ fontSize: 10, color: '#9ca3af', flexShrink: 0 }}>{open ? '\u25B4' : '\u25BE'}</span>
      </div>
      {open && (
        <div style={{
          position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 50,
          background: '#fff', border: '1px solid #d1d5db', borderRadius: 6,
          boxShadow: '0 4px 12px rgba(0,0,0,0.12)', maxHeight: 240, display: 'flex', flexDirection: 'column',
        }}>
          <input
            ref={inputRef}
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Type to search..."
            style={{
              padding: '6px 8px', border: 'none', borderBottom: '1px solid #e5e7eb',
              outline: 'none', fontSize: 12,
            }}
          />
          <div style={{ overflowY: 'auto', flex: 1 }}>
            <div
              onClick={() => { onChange(''); setOpen(false) }}
              style={{
                padding: '5px 8px', fontSize: 12, cursor: 'pointer', color: '#9ca3af',
                background: !value ? '#f3f4f6' : 'transparent',
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#f3f4f6'}
              onMouseLeave={e => e.currentTarget.style.background = !value ? '#f3f4f6' : 'transparent'}
            >{placeholder}</div>
            {filtered.map(o => (
              <div
                key={o.value}
                onClick={() => { onChange(o.value); setOpen(false) }}
                style={{
                  padding: '5px 8px', fontSize: 12, cursor: 'pointer',
                  background: value === o.value ? '#eff6ff' : 'transparent',
                  fontWeight: value === o.value ? 600 : 400,
                }}
                onMouseEnter={e => e.currentTarget.style.background = '#f3f4f6'}
                onMouseLeave={e => e.currentTarget.style.background = value === o.value ? '#eff6ff' : 'transparent'}
              >{o.label}</div>
            ))}
            {filtered.length === 0 && (
              <div style={{ padding: '8px', fontSize: 12, color: '#9ca3af', textAlign: 'center' }}>No matches</div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------------
// DataComparePanel
// ---------------------------------------------------------------------------
function DataComparePanel({ sfConnections = [], dbConnections = [] }, ref) {
  // Template state
  const [templates, setTemplates] = useState([])
  const [selectedTemplateId, setSelectedTemplateId] = useState('')
  const [templateName, setTemplateName] = useState('')

  // Source config
  const [srcConnId, setSrcConnId] = useState('')
  const [srcObject, setSrcObject] = useState('')
  const [srcDatabase, setSrcDatabase] = useState('')
  const [srcObjects, setSrcObjects] = useState([])
  const [srcFields, setSrcFields] = useState([])
  const [srcDatabases, setSrcDatabases] = useState([])

  // Dest config
  const [dstConnId, setDstConnId] = useState('')
  const [dstObject, setDstObject] = useState('')
  const [dstDatabase, setDstDatabase] = useState('')
  const [dstObjects, setDstObjects] = useState([])
  const [dstFields, setDstFields] = useState([])
  const [dstDatabases, setDstDatabases] = useState([])

  // Mappings
  const [fieldMappings, setFieldMappings] = useState([{ source: '', dest: '' }])
  const [srcKeyField, setSrcKeyField] = useState('')
  const [dstKeyField, setDstKeyField] = useState('')

  // Multi-table JOIN + Dedup (per side, DB only)
  const [srcMultiTableEnabled, setSrcMultiTableEnabled] = useState(false)
  const [srcAdditionalTables, setSrcAdditionalTables] = useState([]) // [{table, primaryField, additionalField, fields}]
  const [srcDedupField, setSrcDedupField] = useState('')
  const [dstMultiTableEnabled, setDstMultiTableEnabled] = useState(false)
  const [dstAdditionalTables, setDstAdditionalTables] = useState([])
  const [dstDedupField, setDstDedupField] = useState('')
  // Cache of fetched columns for additional tables: { "connId:table": ["col1", ...] }
  const additionalTableColsCache = useRef({})

  // Results
  const [results, setResults] = useState(null)
  const [running, setRunning] = useState(false)
  const [error, setError] = useState('')
  const [activeResultTab, setActiveResultTab] = useState('fieldSummary')
  const [diffPage, setDiffPage] = useState(0)
  const [diffFieldFilter, setDiffFieldFilter] = useState('')  // filter differences by field pair
  const [srcOnlyPage, setSrcOnlyPage] = useState(0)
  const [dstOnlyPage, setDstOnlyPage] = useState(0)

  // Comparison history
  const [history, setHistory] = useState([])
  const [subTab, setSubTab] = useState('compare')

  // Quick compare (key-only counts)
  const [quickResults, setQuickResults] = useState(null)
  const [quickRunning, setQuickRunning] = useState(false)
  const [quickError, setQuickError] = useState('')
  const [quickTab, setQuickTab] = useState('missingInDest')
  const [quickPage, setQuickPage] = useState(0)

  // Live progress from SSE compare endpoints
  const [compareProgress, setCompareProgress] = useState('')
  const [progressLog, setProgressLog] = useState([])  // accumulates all progress messages
  const [previewSql, setPreviewSql] = useState(null)  // {source: {query, type}, dest: {query, type}}
  const [compareDbId, setCompareDbId] = useState('')  // DB connection to use as comparison engine
  const [compareDbDatabase, setCompareDbDatabase] = useState('')  // database on the compare DB
  const [compareDbDatabases, setCompareDbDatabases] = useState([])  // available databases on compare DB

  // Loading overlay
  const [loadingMessage, setLoadingMessage] = useState(null) // null = hidden, string = shown

  const cancelLoading = useCallback(() => {
    pendingTemplateRef.current = null
    setLoadingMessage(null)
  }, [])

  // Field mapping modal
  const [showFieldMapping, setShowFieldMapping] = useState(false)

  // Bulk mapping modal
  const [showBulkMap, setShowBulkMap] = useState(false)
  const [bulkCandidates, setBulkCandidates] = useState([]) // [{source, dest, checked}]
  const [bulkSearch, setBulkSearch] = useState('')
  const [unmappedSrcFields, setUnmappedSrcFields] = useState([])  // source fields with no auto-match

  // Template name prompt modal
  const [showNamePrompt, setShowNamePrompt] = useState(false)
  const [promptName, setPromptName] = useState('')
  const promptInputRef = useRef(null)

  // Template rename
  const [editingName, setEditingName] = useState(false)
  const nameInputRef = useRef(null)

  // Unsaved changes modal
  const [unsavedModal, setUnsavedModal] = useState(false)
  const pendingActionRef = useRef(null)

  // ---- Dirty tracking ----
  const cleanSnapshotRef = useRef(null)
  const makeSnapshot = () => JSON.stringify({
    srcConnId, srcObject, srcDatabase, dstConnId, dstObject, dstDatabase,
    fieldMappings, srcKeyField, dstKeyField,
    srcMultiTableEnabled, srcAdditionalTables, srcDedupField,
    dstMultiTableEnabled, dstAdditionalTables, dstDedupField,
  })

  const isDirty = !!(
    (srcConnId || dstConnId || fieldMappings.some(m => m.source || m.dest)) &&
    cleanSnapshotRef.current !== null &&
    cleanSnapshotRef.current !== makeSnapshot()
  )

  // Mark clean after template load/save
  const markClean = () => { cleanSnapshotRef.current = makeSnapshot() }

  // Browser beforeunload warning
  useEffect(() => {
    if (!isDirty) return
    const handler = (e) => { e.preventDefault(); e.returnValue = '' }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [isDirty])

  const guardUnsaved = (action) => {
    if (!isDirty) { action(); return }
    pendingActionRef.current = action
    setUnsavedModal(true)
  }

  // Expose dirty state + guard to parent via ref
  useImperativeHandle(ref, () => ({
    isDirty: () => {
      const snap = makeSnapshot()
      return !!(
        (srcConnId || dstConnId || fieldMappings.some(m => m.source || m.dest)) &&
        cleanSnapshotRef.current !== null &&
        cleanSnapshotRef.current !== snap
      )
    },
    guardUnsaved,
  }))

  const allConnections = [...sfConnections, ...dbConnections]
  const getConnType = (connId) => {
    const conn = allConnections.find(c => c.id === connId)
    if (!conn) return null
    return conn.loginUrl ? 'salesforce' : 'database'
  }

  // Load templates + history
  useEffect(() => {
    fetch('/api/compare/templates').then(r => r.json()).then(setTemplates).catch(() => {})
    fetch('/api/compare/history').then(r => r.json()).then(data => { if (Array.isArray(data)) setHistory(data) }).catch(() => {})
  }, [])

  // Set initial clean snapshot
  useEffect(() => { cleanSnapshotRef.current = makeSnapshot() }, [])

  // Fetch databases for a DB connection; returns true if multi-db
  const fetchDatabases = useCallback(async (connId, setDbs) => {
    try {
      const res = await fetch(`/api/database/${connId}/databases`)
      const data = await res.json()
      const dbs = data.databases || []
      if (dbs.length > 1) {
        setDbs(dbs)
        return true
      }
      setDbs([])
      return false
    } catch {
      setDbs([])
      return false
    }
  }, [])

  // Fetch tables for a DB connection (with optional database override)
  const fetchTables = useCallback((connId, database, setSetter) => {
    const dbParam = database ? `?database=${encodeURIComponent(database)}` : ''
    fetch(`/api/database/${connId}/tables${dbParam}`)
      .then(r => r.json())
      .then(data => setSetter(data.tables || []))
      .catch(() => setSetter([]))
  }, [])

  // Fetch objects/tables when connection changes
  const fetchObjects = useCallback(async (connId, database, setSetter, setDbs) => {
    if (!connId) { setSetter([]); return }
    const connType = getConnType(connId)
    if (connType === 'salesforce') {
      fetch(`/api/salesforce/${connId}/objects`)
        .then(r => r.json())
        .then(data => {
          if (Array.isArray(data)) setSetter(data.map(o => {
            if (typeof o === 'string') return o
            const apiName = o.apiName || o.name
            const label = o.name || apiName
            return label !== apiName ? { value: apiName, label: `${label} (${apiName})` } : apiName
          }))
          else if (data.error) setSetter([])
        }).catch(() => setSetter([]))
    } else {
      const isMultiDb = await fetchDatabases(connId, setDbs)
      if (!isMultiDb || database) {
        fetchTables(connId, database, setSetter)
      } else {
        setSetter([])
      }
    }
  }, [allConnections])

  // Fetch fields when object changes
  const fetchFields = useCallback((connId, object, database, setSetter) => {
    if (!connId || !object) { setSetter([]); return }
    const connType = getConnType(connId)
    if (connType === 'salesforce') {
      fetch(`/api/salesforce/${connId}/object/${object}/fields`)
        .then(r => r.json())
        .then(data => {
          if (Array.isArray(data)) setSetter(data.map(f => {
            const apiName = f.name
            const label = f.label || apiName
            return label !== apiName ? { value: apiName, label: `${label} (${apiName})` } : apiName
          }))
          else setSetter([])
        }).catch(() => setSetter([]))
    } else {
      const dbParam = database ? `?database=${encodeURIComponent(database)}` : ''
      fetch(`/api/database/${connId}/tables/${encodeURIComponent(object)}/columns${dbParam}`)
        .then(r => r.json())
        .then(data => setSetter((data.columns || []).map(c => c.name)))
        .catch(() => setSetter([]))
    }
  }, [allConnections])

  // Source connection change
  useEffect(() => {
    setSrcObject('')
    setSrcFields([])
    setSrcDatabase('')
    setSrcDatabases([])
    setSrcMultiTableEnabled(false)
    setSrcAdditionalTables([])
    setSrcDedupField('')
    fetchObjects(srcConnId, '', setSrcObjects, setSrcDatabases)
  }, [srcConnId])

  // Source database change
  useEffect(() => {
    if (srcDatabase && srcConnId) {
      setSrcObject('')
      setSrcFields([])
      setSrcMultiTableEnabled(false)
      setSrcAdditionalTables([])
      setSrcDedupField('')
      fetchTables(srcConnId, srcDatabase, setSrcObjects)
    }
  }, [srcDatabase])

  // Source object change
  useEffect(() => {
    fetchFields(srcConnId, srcObject, srcDatabase, setSrcFields)
  }, [srcConnId, srcObject, srcDatabase])

  // Dest connection change
  useEffect(() => {
    setDstObject('')
    setDstFields([])
    setDstDatabase('')
    setDstDatabases([])
    setDstMultiTableEnabled(false)
    setDstAdditionalTables([])
    setDstDedupField('')
    fetchObjects(dstConnId, '', setDstObjects, setDstDatabases)
  }, [dstConnId])

  // Dest database change
  useEffect(() => {
    if (dstDatabase && dstConnId) {
      setDstObject('')
      setDstFields([])
      setDstMultiTableEnabled(false)
      setDstAdditionalTables([])
      setDstDedupField('')
      fetchTables(dstConnId, dstDatabase, setDstObjects)
    }
  }, [dstDatabase])

  // Dest object change
  useEffect(() => {
    fetchFields(dstConnId, dstObject, dstDatabase, setDstFields)
  }, [dstConnId, dstObject, dstDatabase])

  // Build auto-map candidates
  const buildAutoMapCandidates = () => {
    const dstNormMap = {}
    dstFields.forEach(f => { dstNormMap[normalize(f)] = f })
    const matched = []
    const unmatched = []
    srcFields.forEach(sf => {
      const match = dstNormMap[normalize(sf)]
      if (match) matched.push({ source: sf, dest: match, checked: true })
      else unmatched.push(sf)
    })
    return { matched, unmatched }
  }

  // Quick auto-map (applies all matches immediately)
  const handleAutoMap = () => {
    if (!srcFields.length || !dstFields.length) return
    const { matched } = buildAutoMapCandidates()
    if (matched.length) {
      setFieldMappings(matched.map(m => ({ source: m.source, dest: m.dest })))
      if (!srcKeyField) {
        const idField = srcFields.find(f => f.toLowerCase() === 'id')
        if (idField) setSrcKeyField(idField)
      }
      if (!dstKeyField) {
        const idField = dstFields.find(f => f.toLowerCase() === 'id')
        if (idField) setDstKeyField(idField)
      }
    }
  }

  // Open bulk mapping modal
  const handleOpenBulkMap = () => {
    if (!srcFields.length || !dstFields.length) return
    const { matched, unmatched } = buildAutoMapCandidates()
    setBulkCandidates(matched)
    setUnmappedSrcFields(unmatched)
    setBulkSearch('')
    setShowBulkMap(true)
  }

  // Apply selected bulk mappings
  const handleApplyBulkMap = () => {
    const selected = bulkCandidates.filter(c => c.checked)
    if (selected.length) {
      setFieldMappings(selected.map(m => ({ source: m.source, dest: m.dest })))
      if (!srcKeyField) {
        const idField = srcFields.find(f => f.toLowerCase() === 'id')
        if (idField) setSrcKeyField(idField)
      }
      if (!dstKeyField) {
        const idField = dstFields.find(f => f.toLowerCase() === 'id')
        if (idField) setDstKeyField(idField)
      }
    }
    setShowBulkMap(false)
  }

  // CSV export helper
  const downloadCSV = async (type, data) => {
    const res = await fetch('/api/compare/export', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    })
    const blob = await res.blob()
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `compare_${type}_${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  // --- Multi-table helpers ---
  const fetchAdditionalTableCols = useCallback(async (connId, database, table) => {
    const cacheKey = `${connId}:${database || ''}:${table}`
    if (additionalTableColsCache.current[cacheKey]) return additionalTableColsCache.current[cacheKey]
    const dbParam = database ? `?database=${encodeURIComponent(database)}` : ''
    try {
      const res = await fetch(`/api/database/${connId}/tables/${encodeURIComponent(table)}/columns${dbParam}`)
      const data = await res.json()
      const cols = (data.columns || []).map(c => c.name)
      additionalTableColsCache.current[cacheKey] = cols
      return cols
    } catch { return [] }
  }, [])

  const buildMultiTablePayload = (enabled, additionalTables, dedupField) => {
    if (!enabled) return undefined
    return {
      enabled: true,
      additionalTables: additionalTables.filter(at => at.table && at.primaryField && at.additionalField),
      dedupField: dedupField || '',
    }
  }

  // Collect all available fields for a side (primary + additional table aliases)
  const getAllFields = (primaryFields, additionalTables) => {
    const all = [...primaryFields]
    for (const at of additionalTables) {
      if (!at.table) continue
      for (const col of (at.fields || [])) {
        const alias = `${at.table}__${col}`
        if (!all.includes(alias)) all.push(alias)
      }
    }
    return all
  }

  // Helper: consume SSE stream from compare endpoints
  // Each line is "data: {...}\n\n" with either {progress}, {result}, or {error}
  const consumeSSE = async (url, payload, { onProgress, onResult, onError }) => {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    })
    const reader = res.body.getReader()
    const decoder = new TextDecoder()
    let buffer = ''
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      buffer += decoder.decode(value, { stream: true })
      // Parse complete SSE lines
      const lines = buffer.split('\n')
      buffer = lines.pop() // keep incomplete last line
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue
        try {
          const msg = JSON.parse(line.slice(6))
          if (msg.progress) onProgress(msg.progress)
          else if (msg.result) onResult(msg.result)
          else if (msg.error) onError(msg.error)
        } catch {}
      }
    }
  }

  // Quick compare — key-only count + missing records
  const canQuickCompare = srcConnId && srcObject && dstConnId && dstObject && srcKeyField && dstKeyField

  const handleQuickCompare = async () => {
    setQuickError('')
    setQuickResults(null)
    setQuickRunning(true)
    setQuickPage(0)
    setCompareProgress('')
    setProgressLog([])
    try {
      await consumeSSE('/api/compare/counts', {
        source: { connType: getConnType(srcConnId), connId: srcConnId, object: srcObject, database: srcDatabase },
        dest: { connType: getConnType(dstConnId), connId: dstConnId, object: dstObject, database: dstDatabase },
        sourceKeyField: srcKeyField,
        destKeyField: dstKeyField,
        sourceMultiTable: buildMultiTablePayload(srcMultiTableEnabled, srcAdditionalTables, srcDedupField),
        destMultiTable: buildMultiTablePayload(dstMultiTableEnabled, dstAdditionalTables, dstDedupField),
        compareDbId: compareDbId || undefined,
        compareDbDatabase: compareDbDatabase || undefined,
      }, {
        onProgress: (msg) => { setCompareProgress(msg); if (msg !== 'Still working...') setProgressLog(prev => [...prev, msg]) },
        onResult: (data) => {
          setQuickResults(data)
          fetch('/api/compare/history').then(r => r.json()).then(d => { if (Array.isArray(d)) setHistory(d) }).catch(() => {})
        },
        onError: (err) => setQuickError(err),
      })
    } catch (e) {
      setQuickError(e.message)
    } finally {
      setQuickRunning(false)
      setCompareProgress('')
    }
  }

  // Run compare — streams progress via SSE
  const handleCompare = async () => {
    setError('')
    setResults(null)
    setRunning(true)
    setDiffPage(0)
    setSrcOnlyPage(0)
    setDstOnlyPage(0)
    setCompareProgress('')
    setProgressLog([])
    try {
      await consumeSSE('/api/compare/run', {
        source: { connType: getConnType(srcConnId), connId: srcConnId, object: srcObject, database: srcDatabase },
        dest: { connType: getConnType(dstConnId), connId: dstConnId, object: dstObject, database: dstDatabase },
        fieldMappings: fieldMappings.filter(m => m.source && m.dest),
        sourceKeyField: srcKeyField,
        destKeyField: dstKeyField,
        sourceMultiTable: buildMultiTablePayload(srcMultiTableEnabled, srcAdditionalTables, srcDedupField),
        destMultiTable: buildMultiTablePayload(dstMultiTableEnabled, dstAdditionalTables, dstDedupField),
        compareDbId: compareDbId || undefined,
        compareDbDatabase: compareDbDatabase || undefined,
      }, {
        onProgress: (msg) => { setCompareProgress(msg); if (msg !== 'Still working...') setProgressLog(prev => [...prev, msg]) },
        onResult: (data) => {
          setResults(data)
          fetch('/api/compare/history').then(r => r.json()).then(d => { if (Array.isArray(d)) setHistory(d) }).catch(() => {})
        },
        onError: (err) => setError(err),
      })
    } catch (e) {
      setError(e.message)
    } finally {
      setRunning(false)
      setCompareProgress('')
    }
  }

  // Preview SQL — show generated queries without executing
  const handlePreviewSql = async () => {
    try {
      const srcFields = fieldMappings.filter(m => m.source).map(m => m.source)
      const dstFields = fieldMappings.filter(m => m.dest).map(m => m.dest)
      if (srcKeyField && !srcFields.includes(srcKeyField)) srcFields.unshift(srcKeyField)
      if (dstKeyField && !dstFields.includes(dstKeyField)) dstFields.unshift(dstKeyField)
      const res = await fetch('/api/compare/preview-sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source: { connType: getConnType(srcConnId), connId: srcConnId, object: srcObject, database: srcDatabase,
            fields: srcFields.length ? srcFields : [srcKeyField || '*'],
            keyField: srcKeyField,
            multiTable: buildMultiTablePayload(srcMultiTableEnabled, srcAdditionalTables, srcDedupField) },
          dest: { connType: getConnType(dstConnId), connId: dstConnId, object: dstObject, database: dstDatabase,
            fields: dstFields.length ? dstFields : [dstKeyField || '*'],
            keyField: dstKeyField,
            multiTable: buildMultiTablePayload(dstMultiTableEnabled, dstAdditionalTables, dstDedupField) },
        })
      })
      const data = await res.json()
      setPreviewSql(data)
    } catch (e) {
      setPreviewSql({ error: e.message })
    }
  }

  // Template save — prompt for name if empty
  const doSaveTemplate = async (name) => {
    const tmpl = {
      id: selectedTemplateId || undefined,
      name,
      sourceConnId: srcConnId, sourceObject: srcObject, sourceDatabase: srcDatabase,
      destConnId: dstConnId, destObject: dstObject, destDatabase: dstDatabase,
      fieldMappings: fieldMappings.filter(m => m.source && m.dest),
      sourceKeyField: srcKeyField, destKeyField: dstKeyField,
      srcMultiTableEnabled, srcAdditionalTables, srcDedupField,
      dstMultiTableEnabled, dstAdditionalTables, dstDedupField,
    }
    const res = await fetch('/api/compare/templates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tmpl),
    })
    const saved = await res.json()
    setTemplates(prev => {
      const idx = prev.findIndex(t => t.id === saved.id)
      if (idx >= 0) { const next = [...prev]; next[idx] = saved; return next }
      return [...prev, saved]
    })
    setSelectedTemplateId(saved.id)
    setTemplateName(name)
    markClean()
  }

  const handleSaveTemplate = () => {
    const name = templateName.trim()
    if (!name) {
      setPromptName('')
      setShowNamePrompt(true)
      setTimeout(() => promptInputRef.current?.focus(), 50)
      return
    }
    doSaveTemplate(name)
  }

  // Pending template restore — used to defer database/object/field restoration
  const pendingTemplateRef = useRef(null)

  // Template load
  const handleLoadTemplate = (id) => {
    const doLoad = () => {
      setSelectedTemplateId(id)
      if (!id) {
        setTemplateName('')
        pendingTemplateRef.current = null; setLoadingMessage(null)
        return
      }
      const tmpl = templates.find(t => t.id === id)
      if (!tmpl) return
      setTemplateName(tmpl.name || '')
      setResults(null)
      setError('')
      setQuickResults(null)
      setQuickError('')
      // Store full template for deferred restore
      pendingTemplateRef.current = tmpl
      setLoadingMessage('Loading template...')
      // Safety timeout — clear loading after 10s if cascade doesn't finish
      setTimeout(() => { if (pendingTemplateRef.current) { pendingTemplateRef.current = null; setLoadingMessage(null) } }, 15000)
      // Set connections — the useEffect chains will handle databases/objects/fields
      setSrcConnId(tmpl.sourceConnId || '')
      setDstConnId(tmpl.destConnId || '')
    }
    if (isDirty) {
      guardUnsaved(doLoad)
    } else {
      doLoad()
    }
  }

  // When srcDatabases load, restore pending template's srcDatabase
  useEffect(() => {
    const tmpl = pendingTemplateRef.current
    if (!tmpl) return
    if (tmpl.sourceConnId === srcConnId) {
      if (tmpl.sourceDatabase && srcDatabases.length > 0) {
        setSrcDatabase(tmpl.sourceDatabase)
      } else if (!tmpl.sourceDatabase || srcDatabases.length === 0) {
        // No multi-db or not a DB connection — restore object directly
        if (srcObjects.length > 0 || getConnType(srcConnId) === 'salesforce') {
          // Objects will be set once srcObjects loads via separate effect
        }
      }
    }
  }, [srcDatabases])

  // When srcObjects load, restore pending template's srcObject
  useEffect(() => {
    const tmpl = pendingTemplateRef.current
    if (!tmpl) return
    if (tmpl.sourceConnId === srcConnId && srcObjects.length > 0 && tmpl.sourceObject) {
      setSrcObject(tmpl.sourceObject)
    }
  }, [srcObjects])

  // When srcFields load, restore pending template's source key + field mappings + multi-table
  useEffect(() => {
    const tmpl = pendingTemplateRef.current
    if (!tmpl) return
    if (tmpl.sourceConnId === srcConnId && srcFields.length > 0) {
      if (tmpl.sourceKeyField) setSrcKeyField(tmpl.sourceKeyField)
      // Restore multi-table config
      setSrcMultiTableEnabled(!!tmpl.srcMultiTableEnabled)
      setSrcAdditionalTables(tmpl.srcAdditionalTables || [])
      setSrcDedupField(tmpl.srcDedupField || '')
      // Only set mappings once both sides have fields
      if (dstFields.length > 0 && tmpl.fieldMappings?.length) {
        setFieldMappings(tmpl.fieldMappings)
        setTimeout(() => markClean(), 100)
        pendingTemplateRef.current = null; setLoadingMessage(null)
      }
    }
  }, [srcFields])

  // When dstDatabases load, restore pending template's dstDatabase
  useEffect(() => {
    const tmpl = pendingTemplateRef.current
    if (!tmpl) return
    if (tmpl.destConnId === dstConnId && tmpl.destDatabase && dstDatabases.length > 0) {
      setDstDatabase(tmpl.destDatabase)
    }
  }, [dstDatabases])

  // When dstObjects load, restore pending template's dstObject
  useEffect(() => {
    const tmpl = pendingTemplateRef.current
    if (!tmpl) return
    if (tmpl.destConnId === dstConnId && dstObjects.length > 0 && tmpl.destObject) {
      setDstObject(tmpl.destObject)
    }
  }, [dstObjects])

  // When dstFields load, restore pending template's dest key + field mappings + multi-table
  useEffect(() => {
    const tmpl = pendingTemplateRef.current
    if (!tmpl) return
    if (tmpl.destConnId === dstConnId && dstFields.length > 0) {
      if (tmpl.destKeyField) setDstKeyField(tmpl.destKeyField)
      // Restore multi-table config
      setDstMultiTableEnabled(!!tmpl.dstMultiTableEnabled)
      setDstAdditionalTables(tmpl.dstAdditionalTables || [])
      setDstDedupField(tmpl.dstDedupField || '')
      // Only set mappings once both sides have fields
      if (srcFields.length > 0 && tmpl.fieldMappings?.length) {
        setFieldMappings(tmpl.fieldMappings)
        setTimeout(() => markClean(), 100)
        pendingTemplateRef.current = null; setLoadingMessage(null)
      }
    }
  }, [dstFields])

  // Template delete
  const handleDeleteTemplate = async () => {
    if (!selectedTemplateId) return
    await fetch(`/api/compare/templates/${selectedTemplateId}`, { method: 'DELETE' })
    setTemplates(prev => prev.filter(t => t.id !== selectedTemplateId))
    setSelectedTemplateId('')
    setTemplateName('')
    markClean()
  }

  // Fetch databases when compare DB selection changes
  useEffect(() => {
    if (!compareDbId) { setCompareDbDatabases([]); setCompareDbDatabase(''); return }
    fetchDatabases(compareDbId, setCompareDbDatabases)
    setCompareDbDatabase('')
  }, [compareDbId])

  const canCompare = srcConnId && srcObject && dstConnId && dstObject && srcKeyField && dstKeyField &&
    fieldMappings.some(m => m.source && m.dest)

  // Pagination helpers
  const paginate = (arr, page) => arr.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE)
  const totalPages = (arr) => Math.max(1, Math.ceil(arr.length / PAGE_SIZE))

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, padding: 16, height: '100%', overflow: 'auto', position: 'relative' }}>
      {/* Sub-tab bar */}
      <div style={{ display: 'flex', gap: 0, borderBottom: '2px solid #e5e7eb', marginBottom: 2 }}>
        {[
          { id: 'compare', label: 'Compare' },
          { id: 'history', label: `History${history.length > 0 ? ` (${history.length})` : ''}` },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => setSubTab(t.id)}
            style={{
              padding: '8px 20px', fontSize: 13, fontWeight: subTab === t.id ? 600 : 400,
              border: 'none', borderBottom: subTab === t.id ? '2px solid #6366f1' : '2px solid transparent',
              background: 'none', cursor: 'pointer', marginBottom: -2,
              color: subTab === t.id ? '#6366f1' : '#6b7280',
            }}
          >{t.label}</button>
        ))}
      </div>

      {subTab === 'history' ? (
        <CompareHistoryPanel
          history={history}
          setHistory={setHistory}
          sfConnections={sfConnections}
          dbConnections={dbConnections}
        />
      ) : (<>
      {/* Loading overlay */}
      {loadingMessage && (
        <div style={{
          position: 'absolute', inset: 0, zIndex: 900,
          background: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(2px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{
            background: '#fff', borderRadius: 12, padding: '28px 40px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)', textAlign: 'center',
            minWidth: 260,
          }}>
            <div style={{
              width: 36, height: 36, margin: '0 auto 14px',
              border: '3px solid #e5e7eb', borderTopColor: '#6366f1',
              borderRadius: '50%',
              animation: 'spin 0.8s linear infinite',
            }} />
            <div style={{ fontSize: 14, fontWeight: 600, color: '#1f2937', marginBottom: 6 }}>
              {loadingMessage}
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 16 }}>
              Please wait...
            </div>
            <button
              onClick={cancelLoading}
              style={{
                padding: '6px 20px', borderRadius: 6, border: '1px solid #d1d5db',
                background: '#fff', fontSize: 12, cursor: 'pointer', color: '#dc2626',
                fontWeight: 600,
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#fef2f2'}
              onMouseLeave={e => e.currentTarget.style.background = '#fff'}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      {/* Template bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
        <select
          value={selectedTemplateId}
          onChange={e => handleLoadTemplate(e.target.value)}
          style={{ padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db', fontSize: 13 }}
        >
          <option value="">-- Saved Templates --</option>
          {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
        </select>
        {editingName ? (
          <input
            ref={nameInputRef}
            placeholder="Template name"
            value={templateName}
            onChange={e => setTemplateName(e.target.value)}
            onBlur={() => setEditingName(false)}
            onKeyDown={e => { if (e.key === 'Enter') setEditingName(false); if (e.key === 'Escape') setEditingName(false) }}
            style={{ padding: '6px 10px', borderRadius: 6, border: '1px solid #6366f1', fontSize: 13, width: 200, outline: 'none' }}
            autoFocus
          />
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
            <span style={{ fontSize: 13, color: templateName ? '#1a1a2e' : '#9ca3af', fontWeight: templateName ? 500 : 400 }}>
              {templateName || 'Untitled'}
            </span>
            <button
              onClick={() => { setEditingName(true); setTimeout(() => nameInputRef.current?.focus(), 50) }}
              title="Rename template"
              style={{ background: 'none', border: 'none', cursor: 'pointer', padding: '2px 4px', color: '#6b7280', display: 'flex', alignItems: 'center' }}
            >
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 3a2.828 2.828 0 114 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>
              </svg>
            </button>
          </div>
        )}
        <button
          onClick={handleSaveTemplate}
          className="btn btn-primary"
          style={{
            fontSize: 12, padding: '5px 14px',
            border: isDirty ? '2px solid #f59e0b' : 'none',
            background: isDirty ? '#f59e0b' : undefined,
          }}
        >
          {isDirty ? 'Save *' : 'Save'}
        </button>
        {isDirty && (
          <button
            onClick={() => { cleanSnapshotRef.current = makeSnapshot() }}
            className="btn"
            style={{ fontSize: 12, padding: '5px 14px', color: '#6b7280' }}
            title="Discard unsaved changes"
          >
            Discard
          </button>
        )}
        {selectedTemplateId && (
          <button onClick={handleDeleteTemplate} className="btn" style={{ fontSize: 12, padding: '5px 14px', color: '#ef4444' }}>
            Delete
          </button>
        )}
      </div>

      {/* Configuration area - two columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
        {/* Source */}
        <div style={{ background: '#fff', borderRadius: 10, padding: 14, border: '1px solid #e5e7eb' }}>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, color: '#0d9488' }}>Source</div>
          <div style={{ marginBottom: 8 }}>
            <ConnectionSelect
              connections={allConnections}
              value={srcConnId}
              onChange={setSrcConnId}
              placeholder="Select source connection..."
            />
          </div>
          {srcDatabases.length > 0 && (
            <div style={{ marginBottom: 8 }}>
              <DatabaseSelect databases={srcDatabases} value={srcDatabase} onChange={setSrcDatabase} placeholder="Select database..." />
            </div>
          )}
          {srcConnId && (
            <div style={{ marginBottom: 8 }}>
              <SearchSelect
                options={srcObjects}
                value={srcObject}
                onChange={setSrcObject}
                placeholder="-- Select object/table --"
                style={{ width: '100%' }}
              />
            </div>
          )}
          {srcFields.length > 0 && (
            <div style={{ fontSize: 11, color: '#6b7280' }}>{srcFields.length} fields available</div>
          )}
          {getConnType(srcConnId) === 'database' && srcObject && (
            <div style={{ marginTop: 6 }}>
              <label style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer', color: '#374151' }}>
                <input type="checkbox" checked={srcMultiTableEnabled} onChange={e => {
                  setSrcMultiTableEnabled(e.target.checked)
                  if (!e.target.checked) { setSrcAdditionalTables([]); setSrcDedupField('') }
                }} />
                Join Tables + Dedup
              </label>
              {srcMultiTableEnabled && srcAdditionalTables.length > 0 && (
                <span style={{ fontSize: 10, color: '#6366f1', background: '#eff6ff', padding: '1px 8px', borderRadius: 8, marginTop: 3, display: 'inline-block' }}>
                  {srcAdditionalTables.filter(t => t.table).length} table{srcAdditionalTables.filter(t => t.table).length !== 1 ? 's' : ''} joined
                </span>
              )}
            </div>
          )}
        </div>

        {/* Dest */}
        <div style={{ background: '#fff', borderRadius: 10, padding: 14, border: '1px solid #e5e7eb' }}>
          <div style={{ fontWeight: 600, fontSize: 13, marginBottom: 8, color: '#7c3aed' }}>Destination</div>
          <div style={{ marginBottom: 8 }}>
            <ConnectionSelect
              connections={allConnections}
              value={dstConnId}
              onChange={setDstConnId}
              placeholder="Select dest connection..."
            />
          </div>
          {dstDatabases.length > 0 && (
            <div style={{ marginBottom: 8 }}>
              <DatabaseSelect databases={dstDatabases} value={dstDatabase} onChange={setDstDatabase} placeholder="Select database..." />
            </div>
          )}
          {dstConnId && (
            <div style={{ marginBottom: 8 }}>
              <SearchSelect
                options={dstObjects}
                value={dstObject}
                onChange={setDstObject}
                placeholder="-- Select object/table --"
                style={{ width: '100%' }}
              />
            </div>
          )}
          {dstFields.length > 0 && (
            <div style={{ fontSize: 11, color: '#6b7280' }}>{dstFields.length} fields available</div>
          )}
          {getConnType(dstConnId) === 'database' && dstObject && (
            <div style={{ marginTop: 6 }}>
              <label style={{ fontSize: 11, display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer', color: '#374151' }}>
                <input type="checkbox" checked={dstMultiTableEnabled} onChange={e => {
                  setDstMultiTableEnabled(e.target.checked)
                  if (!e.target.checked) { setDstAdditionalTables([]); setDstDedupField('') }
                }} />
                Join Tables + Dedup
              </label>
              {dstMultiTableEnabled && dstAdditionalTables.length > 0 && (
                <span style={{ fontSize: 10, color: '#6366f1', background: '#eff6ff', padding: '1px 8px', borderRadius: 8, marginTop: 3, display: 'inline-block' }}>
                  {dstAdditionalTables.filter(t => t.table).length} table{dstAdditionalTables.filter(t => t.table).length !== 1 ? 's' : ''} joined
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Field Mapping + Key fields — summary with mapping table */}
      <div style={{ background: '#fff', borderRadius: 10, padding: 14, border: '1px solid #e5e7eb' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: fieldMappings.some(m => m.source && m.dest) ? 10 : 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <span style={{ fontWeight: 600, fontSize: 13 }}>Field Configuration</span>
            {fieldMappings.filter(m => m.source && m.dest).length > 0 && (
              <span style={{
                fontSize: 11, color: '#10b981', background: '#ecfdf5', padding: '2px 10px',
                borderRadius: 10, border: '1px solid #10b98122', fontWeight: 500,
              }}>
                {fieldMappings.filter(m => m.source && m.dest).length} field{fieldMappings.filter(m => m.source && m.dest).length !== 1 ? 's' : ''} mapped
              </span>
            )}
            {srcKeyField && dstKeyField && (
              <span style={{
                fontSize: 11, color: '#6366f1', background: '#eff6ff', padding: '2px 10px',
                borderRadius: 10, border: '1px solid #6366f122', fontWeight: 500,
              }}>
                Key: {srcKeyField} &rarr; {dstKeyField}
              </span>
            )}
            {(!srcKeyField || !dstKeyField) && (
              <span style={{ fontSize: 11, color: '#f59e0b' }}>Key fields not set</span>
            )}
          </div>
          <button
            onClick={() => setShowFieldMapping(true)}
            disabled={!srcFields.length && !dstFields.length}
            className="btn"
            style={{
              fontSize: 12, padding: '6px 18px', background: '#0d9488', color: '#fff',
              border: 'none', borderRadius: 6,
              opacity: (!srcFields.length && !dstFields.length) ? 0.4 : 1,
            }}
          >
            Configure Fields
          </button>
        </div>
        {/* Mapping table on background */}
        {fieldMappings.some(m => m.source && m.dest) && (
          <div style={{ maxHeight: 180, overflowY: 'auto', border: '1px solid #e5e7eb', borderRadius: 6 }}>
            <table style={{ width: '100%', fontSize: 11, borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: '#f9fafb', position: 'sticky', top: 0, zIndex: 1 }}>
                  <th style={{ padding: '3px 8px', textAlign: 'left', fontWeight: 600, color: '#6b7280' }}>Source</th>
                  <th style={{ padding: '3px 4px', width: 24, textAlign: 'center' }}></th>
                  <th style={{ padding: '3px 8px', textAlign: 'left', fontWeight: 600, color: '#6b7280' }}>Destination</th>
                  <th style={{ width: 28 }}></th>
                </tr>
              </thead>
              <tbody>
                {fieldMappings.filter(m => m.source && m.dest).map((m, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                    <td style={{ padding: '2px 8px', fontFamily: 'monospace', fontSize: 11 }}>{m.source}</td>
                    <td style={{ textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>&rarr;</td>
                    <td style={{ padding: '2px 8px', fontFamily: 'monospace', fontSize: 11 }}>{m.dest}</td>
                    <td style={{ textAlign: 'center', padding: '2px 4px' }}>
                      <button
                        onClick={() => {
                          const updated = fieldMappings.filter(fm => !(fm.source === m.source && fm.dest === m.dest))
                          setFieldMappings(updated.length ? updated : [{ source: '', dest: '' }])
                        }}
                        title="Remove mapping"
                        style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 13, padding: 0, lineHeight: 1 }}
                      >&times;</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Quick Compare — key-only record count + missing keys */}
      {canQuickCompare && (
        <div style={{ background: '#fff', borderRadius: 10, padding: 14, border: '1px solid #e5e7eb' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: quickResults ? 12 : 0 }}>
            <span style={{ fontWeight: 600, fontSize: 13 }}>Record Count Comparison</span>
            <button
              onClick={handleQuickCompare}
              disabled={quickRunning}
              className="btn"
              style={{ fontSize: 11, padding: '4px 14px', background: '#7c3aed', color: '#fff', border: 'none', borderRadius: 5, opacity: quickRunning ? 0.6 : 1 }}
            >
              {quickRunning ? 'Checking...' : 'Check Counts'}
            </button>
            {quickRunning && compareProgress && (
              <span style={{ fontSize: 11, color: '#7c3aed', fontWeight: 500, display: 'flex', alignItems: 'center', gap: 5, maxWidth: 500 }}>
                <span style={{
                  display: 'inline-block', width: 10, height: 10, flexShrink: 0,
                  border: '2px solid #e5e7eb', borderTopColor: '#7c3aed',
                  borderRadius: '50%', animation: 'spin 0.8s linear infinite',
                }} />
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{compareProgress}</span>
              </span>
            )}
            {quickError && <span style={{ color: '#ef4444', fontSize: 11 }}>{quickError}</span>}
            {quickResults && (
              <span style={{ fontSize: 11, color: '#6b7280', marginLeft: 4 }}>
                Completed in {quickResults.elapsedSeconds}s
              </span>
            )}
          </div>

          {quickResults && (
            <>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8, marginBottom: 10 }}>
                {[
                  { label: 'Source Records', value: quickResults.sourceCount, color: '#0d9488', bg: '#f0fdfa' },
                  { label: 'Dest Records', value: quickResults.destCount, color: '#7c3aed', bg: '#f5f3ff' },
                  { label: 'Key Matched', value: quickResults.matched, color: '#10b981', bg: '#ecfdf5' },
                  { label: 'Missing in Dest', value: quickResults.missingInDest, color: '#ef4444', bg: '#fef2f2' },
                  { label: 'Missing in Source', value: quickResults.missingInSource, color: '#f59e0b', bg: '#fffbeb' },
                ].map(c => (
                  <div key={c.label} style={{
                    background: c.bg, borderRadius: 8, padding: '8px 10px', textAlign: 'center',
                    border: `1px solid ${c.color}22`,
                  }}>
                    <div style={{ fontSize: 20, fontWeight: 700, color: c.color }}>{c.value.toLocaleString()}</div>
                    <div style={{ fontSize: 10, color: c.color, fontWeight: 500 }}>{c.label}</div>
                  </div>
                ))}
              </div>

              {/* Missing keys detail */}
              {(quickResults.missingInDest > 0 || quickResults.missingInSource > 0) && (
                <>
                  <div style={{ display: 'flex', gap: 4, marginBottom: 8 }}>
                    {quickResults.missingInDest > 0 && (
                      <button
                        onClick={() => { setQuickTab('missingInDest'); setQuickPage(0) }}
                        style={{
                          padding: '4px 12px', fontSize: 11, borderRadius: 4, border: '1px solid #d1d5db',
                          background: quickTab === 'missingInDest' ? '#ef4444' : '#fff',
                          color: quickTab === 'missingInDest' ? '#fff' : '#374151',
                          cursor: 'pointer', fontWeight: quickTab === 'missingInDest' ? 600 : 400,
                        }}
                      >Missing in Dest ({quickResults.missingInDestKeys.length}{quickResults.missingInDest > quickResults.missingInDestKeys.length ? '+' : ''})</button>
                    )}
                    {quickResults.missingInSource > 0 && (
                      <button
                        onClick={() => { setQuickTab('missingInSource'); setQuickPage(0) }}
                        style={{
                          padding: '4px 12px', fontSize: 11, borderRadius: 4, border: '1px solid #d1d5db',
                          background: quickTab === 'missingInSource' ? '#f59e0b' : '#fff',
                          color: quickTab === 'missingInSource' ? '#fff' : '#374151',
                          cursor: 'pointer', fontWeight: quickTab === 'missingInSource' ? 600 : 400,
                        }}
                      >Missing in Source ({quickResults.missingInSourceKeys.length}{quickResults.missingInSource > quickResults.missingInSourceKeys.length ? '+' : ''})</button>
                    )}
                    <button
                      onClick={() => downloadCSV('missingKeys', {
                        type: quickTab,
                        keys: quickTab === 'missingInDest' ? quickResults.missingInDestKeys : quickResults.missingInSourceKeys,
                      })}
                      className="btn"
                      style={{ marginLeft: 'auto', fontSize: 11, padding: '4px 12px', display: 'flex', alignItems: 'center', gap: 4 }}
                    >
                      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                      Export Missing Keys
                    </button>
                  </div>
                  <div style={{ maxHeight: 180, overflow: 'auto' }}>
                    {quickTab === 'missingInDest' && quickResults.missingInDestKeys.length > 0 && (
                      <>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                          {paginate(quickResults.missingInDestKeys, quickPage).map((k, i) => (
                            <span key={i} style={{
                              padding: '2px 8px', background: '#fef2f2', borderRadius: 4, fontSize: 11,
                              fontFamily: 'monospace', border: '1px solid #fecaca',
                            }}>{k}</span>
                          ))}
                        </div>
                        {quickResults.missingInDestKeys.length > PAGE_SIZE && (
                          <Pagination page={quickPage} setPage={setQuickPage} total={totalPages(quickResults.missingInDestKeys)} />
                        )}
                      </>
                    )}
                    {quickTab === 'missingInSource' && quickResults.missingInSourceKeys.length > 0 && (
                      <>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                          {paginate(quickResults.missingInSourceKeys, quickPage).map((k, i) => (
                            <span key={i} style={{
                              padding: '2px 8px', background: '#fffbeb', borderRadius: 4, fontSize: 11,
                              fontFamily: 'monospace', border: '1px solid #fde68a',
                            }}>{k}</span>
                          ))}
                        </div>
                        {quickResults.missingInSourceKeys.length > PAGE_SIZE && (
                          <Pagination page={quickPage} setPage={setQuickPage} total={totalPages(quickResults.missingInSourceKeys)} />
                        )}
                      </>
                    )}
                  </div>
                </>
              )}
            </>
          )}
        </div>
      )}

      {/* Compare button + DB selector */}
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
        <button
          onClick={handleCompare}
          disabled={!canCompare || running}
          className="btn btn-primary"
          style={{ padding: '8px 28px', fontSize: 13, opacity: (!canCompare || running) ? 0.5 : 1 }}
        >
          {running ? 'Comparing...' : 'Compare Fields'}
        </button>
        {dbConnections.length > 0 && (
          <label style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11, color: '#6b7280' }}>
            Compare on:
            <select
              value={compareDbId}
              onChange={e => setCompareDbId(e.target.value)}
              style={{ fontSize: 11, padding: '3px 6px', borderRadius: 4, border: '1px solid #d1d5db' }}
            >
              <option value="">Auto</option>
              {dbConnections.filter(c => c.dbType !== 'athena').map(c => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            {compareDbId && compareDbDatabases.length > 0 && (
              <select
                value={compareDbDatabase}
                onChange={e => setCompareDbDatabase(e.target.value)}
                style={{ fontSize: 11, padding: '3px 6px', borderRadius: 4, border: '1px solid #d1d5db' }}
              >
                <option value="">Default DB</option>
                {compareDbDatabases.map(db => (
                  <option key={db} value={db}>{db}</option>
                ))}
              </select>
            )}
          </label>
        )}
        {(running || quickRunning) && progressLog.length > 0 && (
          <div style={{
            background: '#1e1e2e', color: '#a6e3a1', borderRadius: 8, padding: '8px 12px',
            fontFamily: 'monospace', fontSize: 11, lineHeight: 1.6,
            maxHeight: 120, overflowY: 'auto', marginTop: 6, width: '100%',
          }}>
            {progressLog.map((msg, i) => (
              <div key={i} style={{ color: msg.startsWith('SQL:') || msg.startsWith('SOQL:') ? '#89b4fa' : '#a6e3a1' }}>
                {msg.startsWith('SQL:') || msg.startsWith('SOQL:') ? (
                  <span style={{ wordBreak: 'break-all' }}>{msg}</span>
                ) : (
                  <>&#x25B8; {msg}</>
                )}
              </div>
            ))}
            {compareProgress === 'Still working...' && (
              <div style={{ color: '#f9e2af' }}>&#x25B8; Still working...</div>
            )}
          </div>
        )}
        <button
          onClick={handlePreviewSql}
          disabled={!srcObject && !dstObject}
          style={{ fontSize: 11, padding: '6px 14px', background: 'transparent', color: '#6366f1', border: '1px solid #6366f1',
            borderRadius: 5, cursor: 'pointer', opacity: (!srcObject && !dstObject) ? 0.4 : 1 }}
        >
          Preview SQL
        </button>
        {!running && !quickRunning && !previewSql && <span style={{ fontSize: 11, color: '#9ca3af' }}>Requires field mappings above</span>}
        {error && <span style={{ color: '#ef4444', fontSize: 12, marginLeft: 8 }}>{error}</span>}
      </div>

      {/* Preview SQL */}
      {previewSql && !previewSql.error && (
        <div style={{ background: '#1e1e2e', borderRadius: 8, padding: '10px 14px', marginBottom: 8 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
            <span style={{ color: '#cdd6f4', fontSize: 12, fontWeight: 600 }}>Generated Queries</span>
            <button onClick={() => setPreviewSql(null)} style={{ background: 'none', border: 'none', color: '#6c7086', cursor: 'pointer', fontSize: 14 }}>&times;</button>
          </div>
          {['source', 'dest'].map(side => previewSql[side] && (
            <div key={side} style={{ marginBottom: 8 }}>
              <div style={{ color: '#89b4fa', fontSize: 10, fontWeight: 600, textTransform: 'uppercase', marginBottom: 2 }}>
                {side} ({previewSql[side].type})
              </div>
              <pre style={{
                color: '#a6e3a1', fontSize: 11, fontFamily: 'monospace', whiteSpace: 'pre-wrap', wordBreak: 'break-all',
                background: '#313244', borderRadius: 4, padding: '6px 10px', margin: 0, cursor: 'pointer',
              }}
                onClick={() => { navigator.clipboard.writeText(previewSql[side].query); }}
                title="Click to copy"
              >{previewSql[side].query}</pre>
            </div>
          ))}
        </div>
      )}

      {/* Results */}
      {results && (
        <div style={{ background: '#fff', borderRadius: 10, padding: 14, border: '1px solid #e5e7eb', flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
          {/* Summary cards */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 10, marginBottom: 14 }}>
            {[
              { label: 'Matched', value: results.summary.matched, color: '#10b981', bg: '#ecfdf5' },
              { label: 'Mismatched', value: results.summary.mismatched, color: '#f59e0b', bg: '#fffbeb' },
              { label: 'Source Only', value: results.summary.sourceOnly, color: '#3b82f6', bg: '#eff6ff' },
              { label: 'Dest Only', value: results.summary.destOnly, color: '#ef4444', bg: '#fef2f2' },
              { label: 'Missing in Dest', value: results.summary.sourceOnly + results.summary.mismatched, color: '#7c3aed', bg: '#f5f3ff' },
            ].map(c => (
              <div key={c.label} style={{
                background: c.bg, borderRadius: 8, padding: '10px 14px', textAlign: 'center',
                border: `1px solid ${c.color}22`,
              }}>
                <div style={{ fontSize: 22, fontWeight: 700, color: c.color }}>{c.value.toLocaleString()}</div>
                <div style={{ fontSize: 11, color: c.color, fontWeight: 500 }}>{c.label}</div>
              </div>
            ))}
          </div>

          {/* Totals + elapsed */}
          <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 10 }}>
            Source: {results.summary.totalSource.toLocaleString()} records | Dest: {results.summary.totalDest.toLocaleString()} records
            {results.summary.totalSource > results.summary.totalDest && (
              <span style={{ color: '#7c3aed', fontWeight: 600, marginLeft: 8 }}>
                ({(results.summary.totalSource - results.summary.totalDest).toLocaleString()} fewer in destination)
              </span>
            )}
            {results.elapsedSeconds != null && (
              <span style={{ marginLeft: 8 }}>| Completed in {results.elapsedSeconds}s</span>
            )}
          </div>

          {/* Tab buttons + export */}
          <div style={{ display: 'flex', gap: 4, marginBottom: 10, alignItems: 'center' }}>
            {[
              { id: 'fieldSummary', label: 'Field Summary' },
              { id: 'differences', label: `Differences (${results.differences.length})` },
              { id: 'sourceOnly', label: `Source Only (${results.sourceOnlyKeys.length})` },
              { id: 'destOnly', label: `Dest Only (${results.destOnlyKeys.length})` },
            ].map(t => (
              <button
                key={t.id}
                onClick={() => setActiveResultTab(t.id)}
                style={{
                  padding: '5px 14px', fontSize: 12, borderRadius: 5, border: '1px solid #d1d5db',
                  background: activeResultTab === t.id ? '#0d9488' : '#fff',
                  color: activeResultTab === t.id ? '#fff' : '#374151',
                  cursor: 'pointer', fontWeight: activeResultTab === t.id ? 600 : 400,
                }}
              >
                {t.label}
              </button>
            ))}
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
              {results.differences.length > 0 && (
                <button
                  onClick={() => downloadCSV('differences', { type: 'differences', differences: results.differences })}
                  className="btn"
                  style={{ fontSize: 11, padding: '4px 12px', display: 'flex', alignItems: 'center', gap: 4 }}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  Export Differences
                </button>
              )}
              {(results.sourceOnlyKeys.length > 0 || results.destOnlyKeys.length > 0) && (
                <button
                  onClick={() => downloadCSV('missingKeys', {
                    type: 'missingKeys',
                    keys: [...results.sourceOnlyKeys, ...results.destOnlyKeys],
                  })}
                  className="btn"
                  style={{ fontSize: 11, padding: '4px 12px', display: 'flex', alignItems: 'center', gap: 4 }}
                >
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                  Export Missing Keys
                </button>
              )}
            </div>
          </div>

          {/* Tab content */}
          <div style={{ flex: 1, overflow: 'auto' }}>
            {activeResultTab === 'fieldSummary' && (() => {
              // Compute per-field diff counts
              const fieldCounts = {}
              results.differences.forEach(d => {
                const key = `${d.sourceField} / ${d.destField}`
                fieldCounts[key] = (fieldCounts[key] || 0) + 1
              })
              const sorted = Object.entries(fieldCounts).sort((a, b) => b[1] - a[1])
              const totalMatched = results.summary.matched
              const totalCompared = results.summary.matched + results.summary.mismatched
              return (
                <>
                  <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>
                    {sorted.length} field pair{sorted.length !== 1 ? 's' : ''} with differences out of {fieldMappings.filter(m => m.source && m.dest).length} mapped
                  </div>
                  <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={{ background: '#f9fafb', position: 'sticky', top: 0 }}>
                        <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Field Pair (Source / Dest)</th>
                        <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Differences</th>
                        <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Match Rate</th>
                        <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb', width: '30%' }}></th>
                      </tr>
                    </thead>
                    <tbody>
                      {sorted.map(([field, count]) => {
                        const matchRate = totalCompared > 0 ? ((totalCompared - count) / totalCompared * 100) : 100
                        return (
                          <tr key={field} style={{ borderBottom: '1px solid #f3f4f6', cursor: count > 0 ? 'pointer' : 'default' }}
                            onClick={() => { if (count > 0) { setDiffFieldFilter(field); setDiffPage(0); setActiveResultTab('differences') } }}
                            title={count > 0 ? 'Click to view differences' : ''}
                          >
                            <td style={{ padding: '5px 8px', fontWeight: 500, color: count > 0 ? '#2563eb' : undefined, textDecoration: count > 0 ? 'underline' : 'none' }}>{field}</td>
                            <td style={{ padding: '5px 8px', textAlign: 'right', color: '#ef4444', fontWeight: 600 }}>{count.toLocaleString()}</td>
                            <td style={{ padding: '5px 8px', textAlign: 'right', color: matchRate >= 95 ? '#10b981' : matchRate >= 80 ? '#f59e0b' : '#ef4444' }}>
                              {matchRate.toFixed(1)}%
                            </td>
                            <td style={{ padding: '5px 8px' }}>
                              <div style={{ background: '#e5e7eb', borderRadius: 3, height: 8, overflow: 'hidden' }}>
                                <div style={{
                                  width: `${matchRate}%`, height: '100%', borderRadius: 3,
                                  background: matchRate >= 95 ? '#10b981' : matchRate >= 80 ? '#f59e0b' : '#ef4444',
                                }} />
                              </div>
                            </td>
                          </tr>
                        )
                      })}
                      {/* Fields with 100% match */}
                      {fieldMappings.filter(m => m.source && m.dest).filter(m => !fieldCounts[`${m.source} / ${m.dest}`]).map(m => (
                        <tr key={`${m.source}/${m.dest}`} style={{ borderBottom: '1px solid #f3f4f6' }}>
                          <td style={{ padding: '5px 8px', fontWeight: 500 }}>{m.source} / {m.dest}</td>
                          <td style={{ padding: '5px 8px', textAlign: 'right', color: '#10b981' }}>0</td>
                          <td style={{ padding: '5px 8px', textAlign: 'right', color: '#10b981' }}>100.0%</td>
                          <td style={{ padding: '5px 8px' }}>
                            <div style={{ background: '#e5e7eb', borderRadius: 3, height: 8, overflow: 'hidden' }}>
                              <div style={{ width: '100%', height: '100%', borderRadius: 3, background: '#10b981' }} />
                            </div>
                          </td>
                        </tr>
                      ))}
                      {sorted.length === 0 && fieldMappings.filter(m => m.source && m.dest).length === 0 && (
                        <tr><td colSpan={4} style={{ padding: 16, textAlign: 'center', color: '#9ca3af' }}>No field mappings to summarize</td></tr>
                      )}
                    </tbody>
                  </table>
                </>
              )
            })()}

            {activeResultTab === 'differences' && (() => {
              // Compute unique field pairs for the filter dropdown
              const fieldPairs = [...new Set(results.differences.map(d => `${d.sourceField} / ${d.destField}`))]
              const filtered = diffFieldFilter
                ? results.differences.filter(d => `${d.sourceField} / ${d.destField}` === diffFieldFilter)
                : results.differences
              return (
                <>
                  {/* Field filter bar */}
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 8 }}>
                    <label style={{ fontSize: 11, color: '#6b7280' }}>Filter by field:</label>
                    <select
                      value={diffFieldFilter}
                      onChange={e => { setDiffFieldFilter(e.target.value); setDiffPage(0) }}
                      style={{ fontSize: 11, padding: '3px 8px', borderRadius: 4, border: '1px solid #d1d5db', minWidth: 180 }}
                    >
                      <option value="">All fields ({results.differences.length})</option>
                      {fieldPairs.map(fp => (
                        <option key={fp} value={fp}>{fp} ({results.differences.filter(d => `${d.sourceField} / ${d.destField}` === fp).length})</option>
                      ))}
                    </select>
                    {diffFieldFilter && (
                      <button onClick={() => { setDiffFieldFilter(''); setDiffPage(0) }}
                        style={{ fontSize: 11, padding: '2px 8px', background: '#f3f4f6', border: '1px solid #d1d5db', borderRadius: 4, cursor: 'pointer' }}
                      >Clear</button>
                    )}
                    <span style={{ fontSize: 11, color: '#9ca3af', marginLeft: 'auto' }}>
                      {filtered.length.toLocaleString()} difference{filtered.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                  <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
                    <thead>
                      <tr style={{ background: '#f9fafb', position: 'sticky', top: 0 }}>
                        <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Key</th>
                        {!diffFieldFilter && <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Field</th>}
                        <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Source Value</th>
                        <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Dest Value</th>
                      </tr>
                    </thead>
                    <tbody>
                      {paginate(filtered, diffPage).map((d, i) => (
                        <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                          <td style={{ padding: '5px 8px', fontFamily: 'monospace', fontSize: 11 }}>{d.key}</td>
                          {!diffFieldFilter && <td style={{ padding: '5px 8px' }}>{d.sourceField} / {d.destField}</td>}
                          <td style={{ padding: '5px 8px', background: '#fef2f2', fontFamily: 'monospace', fontSize: 11 }}>{d.sourceVal}</td>
                          <td style={{ padding: '5px 8px', background: '#fef2f2', fontFamily: 'monospace', fontSize: 11 }}>{d.destVal}</td>
                        </tr>
                      ))}
                      {filtered.length === 0 && (
                        <tr><td colSpan={4} style={{ padding: 16, textAlign: 'center', color: '#9ca3af' }}>No differences found</td></tr>
                      )}
                    </tbody>
                  </table>
                  {filtered.length > PAGE_SIZE && (
                    <Pagination page={diffPage} setPage={setDiffPage} total={totalPages(filtered)} />
                  )}
                </>
              )
            })()}

            {activeResultTab === 'sourceOnly' && (
              <>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                  {paginate(results.sourceOnlyKeys, srcOnlyPage).map((k, i) => (
                    <span key={i} style={{
                      padding: '3px 10px', background: '#eff6ff', borderRadius: 4, fontSize: 12,
                      fontFamily: 'monospace', border: '1px solid #bfdbfe',
                    }}>{k}</span>
                  ))}
                  {results.sourceOnlyKeys.length === 0 && (
                    <span style={{ color: '#9ca3af', fontSize: 12 }}>None</span>
                  )}
                </div>
                {results.sourceOnlyKeys.length > PAGE_SIZE && (
                  <Pagination page={srcOnlyPage} setPage={setSrcOnlyPage} total={totalPages(results.sourceOnlyKeys)} />
                )}
              </>
            )}

            {activeResultTab === 'destOnly' && (
              <>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                  {paginate(results.destOnlyKeys, dstOnlyPage).map((k, i) => (
                    <span key={i} style={{
                      padding: '3px 10px', background: '#fef2f2', borderRadius: 4, fontSize: 12,
                      fontFamily: 'monospace', border: '1px solid #fecaca',
                    }}>{k}</span>
                  ))}
                  {results.destOnlyKeys.length === 0 && (
                    <span style={{ color: '#9ca3af', fontSize: 12 }}>None</span>
                  )}
                </div>
                {results.destOnlyKeys.length > PAGE_SIZE && (
                  <Pagination page={dstOnlyPage} setPage={setDstOnlyPage} total={totalPages(results.destOnlyKeys)} />
                )}
              </>
            )}
          </div>
        </div>
      )}

      </>)}

      {/* Template name prompt modal */}
      {showNamePrompt && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 9999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowNamePrompt(false)}>
          <div
            onClick={e => e.stopPropagation()}
            style={{ background: '#fff', borderRadius: 12, padding: 24, minWidth: 340, boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}
          >
            <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 12 }}>Save Template</div>
            <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 10 }}>Enter a name for this comparison template:</div>
            <input
              ref={promptInputRef}
              value={promptName}
              onChange={e => setPromptName(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && promptName.trim()) {
                  setShowNamePrompt(false)
                  setTemplateName(promptName.trim())
                  doSaveTemplate(promptName.trim())
                }
              }}
              placeholder="e.g. Account Compare - Prod vs Sandbox"
              style={{ width: '100%', padding: '8px 12px', borderRadius: 6, border: '1px solid #d1d5db', fontSize: 13, marginBottom: 14 }}
            />
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button onClick={() => setShowNamePrompt(false)} className="btn" style={{ padding: '6px 16px', fontSize: 12 }}>Cancel</button>
              <button
                disabled={!promptName.trim()}
                onClick={() => {
                  setShowNamePrompt(false)
                  setTemplateName(promptName.trim())
                  doSaveTemplate(promptName.trim())
                }}
                className="btn btn-primary"
                style={{ padding: '6px 16px', fontSize: 12, opacity: promptName.trim() ? 1 : 0.5 }}
              >Save</button>
            </div>
          </div>
        </div>
      )}

      {/* Field Mapping modal */}
      {showFieldMapping && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 9998,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowFieldMapping(false)}>
          <div
            onClick={e => e.stopPropagation()}
            style={{ background: '#fff', borderRadius: 12, padding: 20, width: 860, maxHeight: '92vh', display: 'flex', flexDirection: 'column', boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}
          >
            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={{ fontWeight: 600, fontSize: 15 }}>Field Configuration</div>
              <button
                onClick={() => setShowFieldMapping(false)}
                style={{ background: 'none', border: 'none', fontSize: 18, cursor: 'pointer', color: '#6b7280', padding: '2px 6px' }}
              >&times;</button>
            </div>

            {/* Key Fields — inline row */}
            <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 12, padding: '8px 10px', background: '#f9fafb', borderRadius: 8, border: '1px solid #e5e7eb' }}>
              <span style={{ fontSize: 11, fontWeight: 600, color: '#374151', whiteSpace: 'nowrap' }}>Key Fields:</span>
              <SearchSelect options={srcFields} value={srcKeyField} onChange={setSrcKeyField} placeholder="Source key..." style={{ flex: 1 }} />
              <span style={{ color: '#9ca3af', fontSize: 11 }}>&rarr;</span>
              <SearchSelect options={dstFields} value={dstKeyField} onChange={setDstKeyField} placeholder="Dest key..." style={{ flex: 1 }} />
            </div>

            {/* Multi-Table JOIN + Dedup sections */}
            {[
              { label: 'Source', enabled: srcMultiTableEnabled, tables: srcAdditionalTables, setTables: setSrcAdditionalTables,
                dedupField: srcDedupField, setDedupField: setSrcDedupField, connId: srcConnId, database: srcDatabase,
                primaryFields: srcFields, objectList: srcObjects, color: '#0d9488' },
              { label: 'Destination', enabled: dstMultiTableEnabled, tables: dstAdditionalTables, setTables: setDstAdditionalTables,
                dedupField: dstDedupField, setDedupField: setDstDedupField, connId: dstConnId, database: dstDatabase,
                primaryFields: dstFields, objectList: dstObjects, color: '#7c3aed' },
            ].filter(s => s.enabled).map(side => (
              <div key={side.label} style={{ marginBottom: 12, padding: '10px 12px', background: '#f9fafb', borderRadius: 8, border: '1px solid #e5e7eb', maxHeight: 220, overflowY: 'auto' }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: side.color, marginBottom: 8 }}>
                  {side.label} — Join Tables + Dedup
                </div>
                {/* Additional tables list */}
                {side.tables.map((at, idx) => (
                  <div key={idx} style={{ marginBottom: 8, padding: '8px 10px', background: '#fff', borderRadius: 6, border: '1px solid #e5e7eb' }}>
                    {/* Row 1: Table name (full width) + remove button */}
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 2 }}>Table</div>
                        <SearchSelect
                          options={side.objectList.filter(t => t !== (side.label === 'Source' ? srcObject : dstObject))}
                          value={at.table}
                          onChange={async (v) => {
                            const next = [...side.tables]
                            next[idx] = { ...next[idx], table: v, additionalField: '', fields: [] }
                            side.setTables(next)
                            if (v) await fetchAdditionalTableCols(side.connId, side.database, v)
                          }}
                          placeholder="Select table..."
                        />
                      </div>
                      <button
                        onClick={() => { const next = side.tables.filter((_, i) => i !== idx); side.setTables(next) }}
                        title="Remove table"
                        style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 16, padding: '0 6px', marginTop: 14, flexShrink: 0 }}
                      >&times;</button>
                    </div>
                    {/* Row 2: Join fields side by side */}
                    <div style={{ display: 'flex', gap: 8, marginBottom: 4 }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 2 }}>Primary join field</div>
                        <SearchSelect
                          options={side.primaryFields}
                          value={at.primaryField}
                          onChange={v => { const next = [...side.tables]; next[idx] = { ...next[idx], primaryField: v }; side.setTables(next) }}
                          placeholder="Primary field..."
                        />
                      </div>
                      <div style={{ display: 'flex', alignItems: 'flex-end', paddingBottom: 6, color: '#9ca3af', fontSize: 11, flexShrink: 0 }}>=</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 2 }}>Additional join field</div>
                        <SearchSelect
                          options={additionalTableColsCache.current[`${side.connId}:${side.database || ''}:${at.table}`] || []}
                          value={at.additionalField}
                          onChange={v => { const next = [...side.tables]; next[idx] = { ...next[idx], additionalField: v }; side.setTables(next) }}
                          placeholder="Join field..."
                        />
                      </div>
                    </div>
                    {/* Row 3: Fields to include */}
                    {at.table && (additionalTableColsCache.current[`${side.connId}:${side.database || ''}:${at.table}`] || []).length > 0 && (
                      <div style={{ marginTop: 4 }}>
                        <div style={{ fontSize: 10, color: '#6b7280', marginBottom: 3 }}>Include fields:</div>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
                          {(additionalTableColsCache.current[`${side.connId}:${side.database || ''}:${at.table}`] || []).map(col => {
                            const checked = (at.fields || []).includes(col)
                            return (
                              <label key={col} style={{ fontSize: 10, display: 'flex', alignItems: 'center', gap: 3, cursor: 'pointer',
                                padding: '2px 7px', borderRadius: 4, background: checked ? '#eff6ff' : '#f3f4f6', border: `1px solid ${checked ? '#6366f122' : '#e5e7eb'}` }}>
                                <input type="checkbox" checked={checked} onChange={e => {
                                  const next = [...side.tables]
                                  const curFields = next[idx].fields || []
                                  next[idx] = { ...next[idx], fields: e.target.checked ? [...curFields, col] : curFields.filter(f => f !== col) }
                                  side.setTables(next)
                                }} style={{ width: 12, height: 12 }} />
                                {col}
                              </label>
                            )
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
                <button
                  onClick={() => side.setTables([...side.tables, { table: '', primaryField: '', additionalField: '', fields: [] }])}
                  className="btn"
                  style={{ fontSize: 10, padding: '3px 10px', marginBottom: 8 }}
                >+ Add Table</button>
                {/* Dedup field */}
                <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 4 }}>
                  <span style={{ fontSize: 11, fontWeight: 600, color: '#374151', whiteSpace: 'nowrap' }}>Pick latest by:</span>
                  <SearchSelect
                    options={getAllFields(side.primaryFields, side.tables)}
                    value={side.dedupField}
                    onChange={side.setDedupField}
                    placeholder="Dedup field (optional)..."
                    style={{ flex: 1, maxWidth: 280 }}
                  />
                  {side.dedupField && (
                    <button onClick={() => side.setDedupField('')}
                      style={{ background: 'none', border: 'none', color: '#6b7280', cursor: 'pointer', fontSize: 12 }}
                    >Clear</button>
                  )}
                </div>
              </div>
            ))}

            {/* Mapping toolbar */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 12, fontWeight: 600, color: '#374151' }}>
                Field Mappings
                <span style={{ fontWeight: 400, color: '#6b7280', fontSize: 11, marginLeft: 6 }}>
                  {fieldMappings.filter(m => m.source && m.dest).length} of {Math.max(srcFields.length, dstFields.length)} mapped
                </span>
              </span>
              <div style={{ display: 'flex', gap: 4 }}>
                <button onClick={handleOpenBulkMap} disabled={!srcFields.length || !dstFields.length} className="btn"
                  style={{ fontSize: 10, padding: '3px 8px', background: '#6366f1', color: '#fff', border: 'none', borderRadius: 4, opacity: (!srcFields.length || !dstFields.length) ? 0.4 : 1 }}>Bulk Map</button>
                <button onClick={handleAutoMap} className="btn" style={{ fontSize: 10, padding: '3px 8px' }}>Auto-Map</button>
                <button onClick={() => setFieldMappings(prev => [...prev, { source: '', dest: '' }])} className="btn" style={{ fontSize: 10, padding: '3px 8px' }}>+ Add</button>
                {fieldMappings.filter(m => m.source || m.dest).length > 1 && (
                  <button onClick={() => setFieldMappings([{ source: '', dest: '' }])} className="btn" style={{ fontSize: 10, padding: '3px 8px', color: '#ef4444' }}>Clear</button>
                )}
              </div>
            </div>

            {/* Mapping rows */}
            <div style={{ flex: 1, overflow: 'auto', minHeight: 120, border: '1px solid #e5e7eb', borderRadius: 6 }}>
              {fieldMappings.map((m, i) => (
                <div key={i} style={{
                  display: 'flex', alignItems: 'center', gap: 6, padding: '4px 8px',
                  borderBottom: '1px solid #f3f4f6', background: i % 2 === 0 ? '#fff' : '#fafbfc',
                }}>
                  <span style={{ fontSize: 10, color: '#9ca3af', width: 18, textAlign: 'center', flexShrink: 0 }}>{i + 1}</span>
                  <SearchSelect
                    options={srcMultiTableEnabled ? getAllFields(srcFields, srcAdditionalTables) : srcFields} value={m.source}
                    onChange={v => { const next = [...fieldMappings]; next[i] = { ...next[i], source: v }; setFieldMappings(next) }}
                    placeholder="Source field..." style={{ flex: 1 }}
                  />
                  <span style={{ color: '#9ca3af', fontSize: 10, flexShrink: 0 }}>&rarr;</span>
                  <SearchSelect
                    options={dstMultiTableEnabled ? getAllFields(dstFields, dstAdditionalTables) : dstFields} value={m.dest}
                    onChange={v => { const next = [...fieldMappings]; next[i] = { ...next[i], dest: v }; setFieldMappings(next) }}
                    placeholder="Dest field..." style={{ flex: 1 }}
                  />
                  <button
                    onClick={() => { const u = fieldMappings.filter((_, j) => j !== i); setFieldMappings(u.length ? u : [{ source: '', dest: '' }]) }}
                    style={{ background: 'none', border: 'none', color: '#ef4444', cursor: 'pointer', fontSize: 14, padding: '0 4px', flexShrink: 0, lineHeight: 1 }}
                  >&times;</button>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 12, paddingTop: 10, borderTop: '1px solid #e5e7eb' }}>
              <button onClick={() => setShowFieldMapping(false)} className="btn btn-primary" style={{ padding: '6px 22px', fontSize: 12 }}>Done</button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Map modal */}
      {showBulkMap && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 9999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowBulkMap(false)}>
          <div
            onClick={e => e.stopPropagation()}
            style={{ background: '#fff', borderRadius: 12, padding: 20, width: 700, maxHeight: '80vh', display: 'flex', flexDirection: 'column', boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>Bulk Field Mapping</div>
                <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2 }}>
                  {bulkCandidates.filter(c => c.checked).length} of {bulkCandidates.length} auto-matched fields selected
                  {unmappedSrcFields.length > 0 && ` | ${unmappedSrcFields.length} source fields unmatched`}
                </div>
              </div>
              <div style={{ display: 'flex', gap: 6 }}>
                <button
                  onClick={() => setBulkCandidates(prev => prev.map(c => ({ ...c, checked: true })))}
                  className="btn" style={{ fontSize: 11, padding: '3px 10px' }}
                >Select All</button>
                <button
                  onClick={() => setBulkCandidates(prev => prev.map(c => ({ ...c, checked: false })))}
                  className="btn" style={{ fontSize: 11, padding: '3px 10px' }}
                >Deselect All</button>
              </div>
            </div>

            <input
              placeholder="Search fields..."
              value={bulkSearch}
              onChange={e => setBulkSearch(e.target.value)}
              style={{ padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db', fontSize: 12, marginBottom: 10 }}
            />

            <div style={{ flex: 1, overflow: 'auto', minHeight: 0 }}>
              {/* Auto-matched fields */}
              <table style={{ width: '100%', fontSize: 12, borderCollapse: 'collapse' }}>
                <thead>
                  <tr style={{ background: '#f9fafb', position: 'sticky', top: 0, zIndex: 1 }}>
                    <th style={{ width: 30, padding: '5px 6px' }}></th>
                    <th style={{ textAlign: 'left', padding: '5px 6px', fontWeight: 600 }}>Source Field</th>
                    <th style={{ textAlign: 'center', padding: '5px 6px', fontWeight: 600, width: 30 }}></th>
                    <th style={{ textAlign: 'left', padding: '5px 6px', fontWeight: 600 }}>Dest Field</th>
                  </tr>
                </thead>
                <tbody>
                  {bulkCandidates
                    .filter(c => !bulkSearch || c.source.toLowerCase().includes(bulkSearch.toLowerCase()) || c.dest.toLowerCase().includes(bulkSearch.toLowerCase()))
                    .map((c, i) => {
                      const origIdx = bulkCandidates.indexOf(c)
                      return (
                        <tr key={i} style={{ borderBottom: '1px solid #f3f4f6', background: c.checked ? '#f0fdf4' : 'transparent' }}>
                          <td style={{ padding: '4px 6px', textAlign: 'center' }}>
                            <input
                              type="checkbox"
                              checked={c.checked}
                              onChange={e => {
                                const next = [...bulkCandidates]
                                next[origIdx] = { ...next[origIdx], checked: e.target.checked }
                                setBulkCandidates(next)
                              }}
                            />
                          </td>
                          <td style={{ padding: '4px 6px', fontFamily: 'monospace', fontSize: 11 }}>{c.source}</td>
                          <td style={{ padding: '4px 6px', textAlign: 'center', color: '#9ca3af' }}>&rarr;</td>
                          <td style={{ padding: '4px 6px', fontFamily: 'monospace', fontSize: 11 }}>{c.dest}</td>
                        </tr>
                      )
                    })}
                </tbody>
              </table>

              {/* Unmatched source fields */}
              {unmappedSrcFields.length > 0 && (
                <div style={{ marginTop: 12 }}>
                  <div style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', marginBottom: 4, padding: '0 6px' }}>
                    Unmatched Source Fields ({unmappedSrcFields.filter(f => !bulkSearch || f.toLowerCase().includes(bulkSearch.toLowerCase())).length})
                  </div>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, padding: '0 6px' }}>
                    {unmappedSrcFields
                      .filter(f => !bulkSearch || f.toLowerCase().includes(bulkSearch.toLowerCase()))
                      .map(f => (
                        <span key={f} style={{
                          padding: '2px 8px', background: '#fef2f2', borderRadius: 4, fontSize: 11,
                          fontFamily: 'monospace', border: '1px solid #fecaca', color: '#6b7280',
                        }}>{f}</span>
                      ))}
                  </div>
                </div>
              )}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 14, paddingTop: 12, borderTop: '1px solid #e5e7eb' }}>
              <button onClick={() => setShowBulkMap(false)} className="btn" style={{ padding: '6px 16px', fontSize: 12 }}>Cancel</button>
              <button
                onClick={handleApplyBulkMap}
                disabled={!bulkCandidates.some(c => c.checked)}
                className="btn btn-primary"
                style={{ padding: '6px 16px', fontSize: 12, opacity: bulkCandidates.some(c => c.checked) ? 1 : 0.5 }}
              >
                Apply {bulkCandidates.filter(c => c.checked).length} Mappings
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unsaved changes modal */}
      {unsavedModal && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.4)', zIndex: 9999,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setUnsavedModal(false)}>
          <div
            onClick={e => e.stopPropagation()}
            style={{ background: '#fff', borderRadius: 12, padding: 24, minWidth: 340, boxShadow: '0 8px 32px rgba(0,0,0,0.18)' }}
          >
            <div style={{ fontWeight: 600, fontSize: 15, marginBottom: 8 }}>Unsaved Changes</div>
            <div style={{ fontSize: 13, color: '#6b7280', marginBottom: 16 }}>
              You have unsaved changes. Do you want to save before continuing?
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
              <button
                onClick={() => setUnsavedModal(false)}
                className="btn"
                style={{ padding: '6px 16px', fontSize: 12 }}
              >Cancel</button>
              <button
                onClick={() => {
                  setUnsavedModal(false)
                  cleanSnapshotRef.current = makeSnapshot()
                  if (pendingActionRef.current) { pendingActionRef.current(); pendingActionRef.current = null }
                }}
                className="btn"
                style={{ padding: '6px 16px', fontSize: 12, color: '#ef4444' }}
              >Discard</button>
              <button
                onClick={async () => {
                  setUnsavedModal(false)
                  const name = templateName.trim()
                  if (name) {
                    await doSaveTemplate(name)
                  } else {
                    setPromptName('')
                    setShowNamePrompt(true)
                    // After save completes in prompt, the pending action won't auto-run,
                    // but at least the data is saved
                    return
                  }
                  if (pendingActionRef.current) { pendingActionRef.current(); pendingActionRef.current = null }
                }}
                className="btn btn-primary"
                style={{ padding: '6px 16px', fontSize: 12 }}
              >Save & Continue</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function Pagination({ page, setPage, total }) {
  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 8, marginTop: 8, paddingBottom: 4 }}>
      <button
        disabled={page === 0}
        onClick={() => setPage(p => p - 1)}
        style={{ padding: '3px 10px', fontSize: 12, borderRadius: 4, border: '1px solid #d1d5db', cursor: page === 0 ? 'default' : 'pointer', opacity: page === 0 ? 0.4 : 1 }}
      >Prev</button>
      <span style={{ fontSize: 12, color: '#6b7280' }}>{page + 1} / {total}</span>
      <button
        disabled={page >= total - 1}
        onClick={() => setPage(p => p + 1)}
        style={{ padding: '3px 10px', fontSize: 12, borderRadius: 4, border: '1px solid #d1d5db', cursor: page >= total - 1 ? 'default' : 'pointer', opacity: page >= total - 1 ? 0.4 : 1 }}
      >Next</button>
    </div>
  )
}

export default forwardRef(DataComparePanel)
