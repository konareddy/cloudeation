import React, { useState } from 'react'

const TYPE_COLORS = {
  extract: '#3b82f6',
  transform: '#8b5cf6',
  load: '#10b981',
}

export default function SaveStepModal({ type, configSummary, onSave, onClose }) {
  const [name, setName] = useState('')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleSave = async () => {
    if (!name.trim()) return
    setSaving(true)
    try {
      await onSave(name.trim())
      setSaved(true)
      setTimeout(() => onClose(), 1200)
    } catch {
      setSaving(false)
    }
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()} style={{ width: 440 }}>
        <div className="modal-header" style={{ padding: '16px 20px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <span style={{
              display: 'inline-block', padding: '3px 10px', borderRadius: 5, fontSize: 11, fontWeight: 700,
              color: '#fff', background: TYPE_COLORS[type] || '#6b7280', textTransform: 'uppercase',
              letterSpacing: '0.05em',
            }}>{type}</span>
            <h2 style={{ fontSize: 16, fontWeight: 600, margin: 0, color: '#1f2937' }}>Save as Reusable Step</h2>
          </div>
          <button className="btn-close" onClick={onClose}>&times;</button>
        </div>
        <div style={{ padding: '20px 24px' }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>Step Name</label>
          <input
            autoFocus
            value={name}
            onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSave()}
            placeholder={`e.g. ${type === 'extract' ? 'Extract Accounts' : type === 'transform' ? 'Transform Contacts' : 'Load Leads'}`}
            style={{
              width: '100%', padding: '10px 12px', fontSize: 14, border: '1.5px solid #d1d5db',
              borderRadius: 8, outline: 'none', transition: 'border-color 0.15s',
            }}
            onFocus={e => e.target.style.borderColor = TYPE_COLORS[type] || '#6b7280'}
            onBlur={e => e.target.style.borderColor = '#d1d5db'}
          />
          {configSummary && (
            <div style={{
              marginTop: 14, padding: '10px 12px', background: '#f8fafc', borderRadius: 8,
              fontSize: 12, color: '#64748b', lineHeight: 1.6, whiteSpace: 'pre-wrap',
              border: '1px solid #f1f5f9',
            }}>
              {configSummary}
            </div>
          )}
          {saved && (
            <div style={{ marginTop: 12, padding: '8px 12px', background: '#ecfdf5', borderRadius: 8, fontSize: 12, color: '#059669', fontWeight: 500 }}>
              Step saved! Switch to the Orchestrator tab to use it in a workflow.
            </div>
          )}
        </div>
        <div style={{ padding: '14px 24px', borderTop: '1px solid #f1f5f9', display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
          <button
            onClick={onClose}
            style={{
              padding: '8px 18px', fontSize: 13, border: '1px solid #d1d5db', borderRadius: 8,
              background: '#fff', cursor: 'pointer', color: '#374151', fontWeight: 500,
            }}
          >Cancel</button>
          <button
            onClick={handleSave}
            disabled={!name.trim() || saving}
            style={{
              padding: '8px 20px', fontSize: 13, border: 'none', borderRadius: 8, cursor: 'pointer', color: '#fff',
              background: name.trim() && !saving ? (TYPE_COLORS[type] || '#6b7280') : '#d1d5db',
              fontWeight: 600, boxShadow: name.trim() ? `0 2px 8px ${TYPE_COLORS[type] || '#6b7280'}40` : 'none',
              transition: 'all 0.15s',
            }}
          >
            {saving ? 'Saving...' : 'Save Step'}
          </button>
        </div>
      </div>
    </div>
  )
}
