import React, { useState, useEffect, useRef, useCallback } from 'react'
import { connectionDisplayName } from './ConnectionModal.jsx'

const STEPS = [
  { label: 'Upload', desc: 'Drop file' },
  { label: 'SQL', desc: 'Transform' },
  { label: 'Target', desc: 'SF object' },
  { label: 'Mapping', desc: 'Columns' },
  { label: 'Execute', desc: 'Upload' },
]

function getErrorSuggestion(statusCode, message) {
  const code = (statusCode || '').toUpperCase()
  const msg = (message || '').toLowerCase()
  if (code === 'REQUIRED_FIELD_MISSING' || msg.includes('required field')) return { cause: 'A required field has no value.', fix: 'Map the missing field or provide a default value.' }
  if (code === 'DUPLICATES_DETECTED' || msg.includes('duplicate')) return { cause: 'A duplicate rule matched.', fix: 'Use Upsert with External ID, or de-duplicate your data.' }
  if (code === 'INVALID_FIELD_FOR_INSERT_UPDATE' || msg.includes('read-only')) return { cause: 'Writing to a read-only field.', fix: 'Remove read-only fields from mapping.' }
  if (code === 'MALFORMED_ID' || msg.includes('malformed id')) return { cause: 'Invalid Salesforce ID format.', fix: 'IDs must be 15 or 18 characters.' }
  if (code === 'STRING_TOO_LONG' || msg.includes('too long')) return { cause: 'Value exceeds field length.', fix: 'Truncate value to fit.' }
  if (code === 'INVALID_SESSION_ID') return { cause: 'Session expired.', fix: 'Re-authenticate your Salesforce connection.' }
  return null
}

export default function QuickLoadPanel({ sfConnections = [], sfRefreshKey = 0 }) {
  const [step, setStep] = useState(0)

  // Step 1: File upload
  const [dragOver, setDragOver] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadError, setUploadError] = useState('')
  const [sessionId, setSessionId] = useState(null)
  const [fileInfo, setFileInfo] = useState(null)
  const [preview, setPreview] = useState(null)
  const fileInputRef = useRef(null)

  // Step 2: SQL transform
  const [sql, setSql] = useState('')
  const [sqlRunning, setSqlRunning] = useState(false)
  const [sqlResult, setSqlResult] = useState(null)
  const [sqlError, setSqlError] = useState('')

  // Step 3: Target selection
  const [selectedSfId, setSelectedSfId] = useState('')
  const [sfObjects, setSfObjects] = useState([])
  const [loadingObjects, setLoadingObjects] = useState(false)
  const [selectedObject, setSelectedObject] = useState('')
  const [objectSearch, setObjectSearch] = useState(null)
  const [showObjectDropdown, setShowObjectDropdown] = useState(false)
  const [operation, setOperation] = useState('insert')
  const [externalIdField, setExternalIdField] = useState('')
  const [sfFields, setSfFields] = useState([])
  const [loadingFields, setLoadingFields] = useState(false)

  // Step 4: Column mapping
  const [columnMapping, setColumnMapping] = useState({})

  // Step 5: Execute
  const [jobId, setJobId] = useState(null)
  const [uploadState, setUploadState] = useState(null)
  const [recordResults, setRecordResults] = useState([])
  const pollRef = useRef(null)
  const [expandedRow, setExpandedRow] = useState(null)

  // Auto-select SF connection if only one
  useEffect(() => {
    if (sfConnections.length === 1 && !selectedSfId) setSelectedSfId(sfConnections[0].id)
  }, [sfConnections])

  // Fetch SF objects when connection selected
  useEffect(() => {
    if (!selectedSfId) { setSfObjects([]); return }
    setLoadingObjects(true)
    fetch(`/api/salesforce/${selectedSfId}/objects`)
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setSfObjects(data); else setSfObjects([]) })
      .catch(() => setSfObjects([]))
      .finally(() => setLoadingObjects(false))
  }, [selectedSfId, sfRefreshKey])

  // Fetch SF fields when object selected
  useEffect(() => {
    if (!selectedSfId || !selectedObject) { setSfFields([]); return }
    setLoadingFields(true)
    fetch(`/api/salesforce/${selectedSfId}/describe/${selectedObject}`)
      .then(r => r.json())
      .then(data => setSfFields(data.fields || []))
      .catch(() => setSfFields([]))
      .finally(() => setLoadingFields(false))
  }, [selectedSfId, selectedObject])

  // Auto-map columns when preview + SF fields available
  useEffect(() => {
    if (!preview?.columns || sfFields.length === 0) return
    const mapping = {}
    for (const col of preview.columns) {
      const norm = col.toLowerCase().replace(/^sf_/, '')
      const match = sfFields.find(f => f.name.toLowerCase() === norm)
      if (!match) { mapping[col] = '__skip__'; continue }
      if (operation === 'delete') { mapping[col] = match.name === 'Id' ? 'Id' : '__skip__'; continue }
      if (operation === 'insert' && !match.createable) { mapping[col] = '__skip__'; continue }
      if (operation && operation !== 'insert' && !match.updateable && match.name !== 'Id') { mapping[col] = '__skip__'; continue }
      mapping[col] = match.name
    }
    setColumnMapping(mapping)
  }, [preview?.columns, sfFields, operation])

  // Reset external ID when operation changes
  useEffect(() => { if (operation !== 'upsert') setExternalIdField('') }, [operation])

  // Cleanup on unmount
  useEffect(() => {
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [])

  // ── File upload handlers ──

  const handleFile = useCallback(async (file) => {
    const ext = file.name.split('.').pop().toLowerCase()
    if (!['csv', 'xlsx'].includes(ext)) {
      setUploadError('Only CSV and XLSX files are supported')
      return
    }
    setUploading(true)
    setUploadError('')
    const formData = new FormData()
    formData.append('file', file)
    try {
      const resp = await fetch('/api/quick-load/upload', { method: 'POST', body: formData })
      const data = await resp.json()
      if (data.error) { setUploadError(data.error); return }
      setSessionId(data.sessionId)
      setFileInfo({ name: data.filename, columns: data.columns, rowCount: data.rowCount })
      setPreview(data.preview)
    } catch (e) {
      setUploadError(e.message)
    } finally {
      setUploading(false)
    }
  }, [])

  const handleDrop = useCallback((e) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }, [handleFile])

  const handleFileInput = useCallback((e) => {
    const file = e.target.files[0]
    if (file) handleFile(file)
  }, [handleFile])

  // ── SQL handlers ──

  const handleRunSql = async () => {
    if (!sql.trim() || !sessionId) return
    setSqlRunning(true)
    setSqlError('')
    setSqlResult(null)
    try {
      const resp = await fetch(`/api/quick-load/${sessionId}/query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql }),
      })
      const data = await resp.json()
      if (data.error) { setSqlError(data.error); return }
      setSqlResult(data)
      // Refresh preview after DML
      if (data.message || !data.columns?.length) {
        const prev = await fetch(`/api/quick-load/${sessionId}/preview`).then(r => r.json())
        if (!prev.error) setPreview(prev)
      } else {
        // SELECT result — show it inline but also refresh the data table preview
        const prev = await fetch(`/api/quick-load/${sessionId}/preview`).then(r => r.json())
        if (!prev.error) setPreview(prev)
      }
    } catch (e) {
      setSqlError(e.message)
    } finally {
      setSqlRunning(false)
    }
  }

  // ── Upload handler ──

  const handleStartUpload = async () => {
    if (!sessionId || !selectedSfId || !selectedObject) return
    const activeMapping = {}
    for (const [col, sfField] of Object.entries(columnMapping)) {
      if (sfField && sfField !== '__skip__') activeMapping[col] = sfField
    }
    setUploadState({ running: true, status: 'starting', progress: 0, total_records: 0, success_count: 0, error_count: 0, errors: [] })
    setRecordResults([])

    try {
      const resp = await fetch(`/api/quick-load/${sessionId}/upload`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sfConnectionId: selectedSfId,
          objectName: selectedObject,
          operation,
          columnMapping: activeMapping,
          externalIdField: operation === 'upsert' ? externalIdField : undefined,
        }),
      })
      const data = await resp.json()
      if (data.error) { setUploadState({ running: false, status: 'error', errors: [data.error] }); return }
      setJobId(data.jobId)

      pollRef.current = setInterval(() => {
        fetch(`/api/quick-load/${data.jobId}/status`)
          .then(r => r.json())
          .then(s => {
            setUploadState(s)
            if (!s.running) {
              clearInterval(pollRef.current)
              pollRef.current = null
              if (s.has_record_results) {
                fetch(`/api/quick-load/${data.jobId}/results`)
                  .then(r => r.json())
                  .then(d => setRecordResults(d.record_results || []))
                  .catch(() => {})
              }
            }
          })
          .catch(() => {})
      }, 1000)
    } catch (e) {
      setUploadState({ running: false, status: 'error', errors: [e.message] })
    }
  }

  // ── Reset ──
  const handleReset = () => {
    if (sessionId) fetch(`/api/quick-load/${sessionId}`, { method: 'DELETE' }).catch(() => {})
    if (pollRef.current) { clearInterval(pollRef.current); pollRef.current = null }
    setStep(0)
    setSessionId(null); setFileInfo(null); setPreview(null); setUploadError('')
    setSql(''); setSqlResult(null); setSqlError('')
    setSelectedObject(''); setObjectSearch(null); setSfFields([]); setOperation('insert'); setExternalIdField('')
    setColumnMapping({})
    setJobId(null); setUploadState(null); setRecordResults([])
  }

  // ── Navigation ──

  const canNext = () => {
    if (step === 0) return !!sessionId
    if (step === 1) return true // SQL is optional
    if (step === 2) return !!selectedSfId && !!selectedObject && !!operation && (operation !== 'upsert' || !!externalIdField)
    if (step === 3) return Object.values(columnMapping).some(v => v && v !== '__skip__')
    return false
  }

  // ── Derived ──
  const mappedCount = Object.values(columnMapping).filter(v => v && v !== '__skip__').length
  const totalCols = preview?.columns?.length || 0
  const creatableFields = operation === 'delete'
    ? sfFields.filter(f => f.name === 'Id')
    : operation === 'insert'
      ? sfFields.filter(f => f.createable)
      : sfFields.filter(f => f.createable || f.updateable || f.name === 'Id')

  const selectedSfConn = sfConnections.find(c => c.id === selectedSfId)
  const isProduction = selectedSfConn?.loginUrl ? !selectedSfConn.loginUrl.includes('test.salesforce.com') : false
  const recordErrors = uploadState?.errors?.filter(e => typeof e === 'object' && e.row) || []
  const stringErrors = uploadState?.errors?.filter(e => typeof e === 'string') || []

  // ── Download errors as CSV ──
  const downloadErrorsCsv = () => {
    if (!recordErrors.length) return
    const headers = ['Row', 'Status Code', 'Error Message']
    const csvRows = [headers.join(',')]
    recordErrors.forEach(err => {
      csvRows.push([err.row, `"${err.statusCode || ''}"`, `"${(err.message || '').replace(/"/g, '""')}"`].join(','))
    })
    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = 'upload_errors.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  // ── Render ──

  const sectionStyle = {
    background: '#fff', borderRadius: 10, border: '1px solid #e5e7eb',
    padding: '20px 24px', marginBottom: 16,
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'auto', padding: '16px 20px' }}>
      {/* Step indicator */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 20, alignItems: 'center' }}>
        {STEPS.map((s, i) => (
          <React.Fragment key={i}>
            <div
              onClick={() => { if (i < step || (i <= step && canNext())) setStep(i) }}
              style={{
                display: 'flex', alignItems: 'center', gap: 8, padding: '8px 14px',
                borderRadius: 8, cursor: i <= step ? 'pointer' : 'default',
                background: i === step ? '#ede9fe' : i < step ? '#f0fdf4' : '#f9fafb',
                border: `1px solid ${i === step ? '#8b5cf6' : i < step ? '#86efac' : '#e5e7eb'}`,
                transition: 'all 0.15s',
              }}
            >
              <span style={{
                width: 24, height: 24, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12, fontWeight: 700,
                background: i === step ? '#8b5cf6' : i < step ? '#22c55e' : '#d1d5db',
                color: '#fff',
              }}>
                {i < step ? '\u2713' : i + 1}
              </span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: i === step ? '#7c3aed' : i < step ? '#16a34a' : '#6b7280' }}>{s.label}</div>
                <div style={{ fontSize: 10, color: '#9ca3af' }}>{s.desc}</div>
              </div>
            </div>
            {i < STEPS.length - 1 && <div style={{ width: 20, height: 1, background: '#d1d5db' }} />}
          </React.Fragment>
        ))}
        <div style={{ flex: 1 }} />
        {sessionId && (
          <button onClick={handleReset} style={{
            padding: '6px 14px', borderRadius: 6, border: '1px solid #e5e7eb',
            background: '#fff', fontSize: 12, cursor: 'pointer', color: '#6b7280',
          }}>
            Start Over
          </button>
        )}
      </div>

      {/* Step 0: File Upload */}
      {step === 0 && (
        <div style={sectionStyle}>
          <h3 style={{ margin: '0 0 12px', fontSize: 15, fontWeight: 600 }}>Upload File</h3>
          <p style={{ fontSize: 12, color: '#6b7280', margin: '0 0 16px' }}>
            Drop a CSV or XLSX file to get started. The file will be loaded into an in-memory database for optional SQL transformation.
          </p>

          {!sessionId ? (
            <div
              onDragOver={e => { e.preventDefault(); setDragOver(true) }}
              onDragLeave={() => setDragOver(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              style={{
                border: `2px dashed ${dragOver ? '#8b5cf6' : '#d1d5db'}`,
                borderRadius: 12, padding: '48px 24px', textAlign: 'center',
                background: dragOver ? '#faf5ff' : '#fafafa',
                cursor: 'pointer', transition: 'all 0.15s',
              }}
            >
              <input ref={fileInputRef} type="file" accept=".csv,.xlsx" onChange={handleFileInput} style={{ display: 'none' }} />
              <div style={{ fontSize: 36, marginBottom: 8 }}>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none">
                  <rect x="8" y="6" width="32" height="36" rx="4" fill="#ede9fe" stroke="#8b5cf6" strokeWidth="1.5"/>
                  <path d="M24 18v12M18 24h12" stroke="#8b5cf6" strokeWidth="2" strokeLinecap="round"/>
                </svg>
              </div>
              {uploading ? (
                <div style={{ fontSize: 14, color: '#8b5cf6', fontWeight: 500 }}>Uploading...</div>
              ) : (
                <>
                  <div style={{ fontSize: 14, fontWeight: 500, color: '#374151' }}>Drop CSV or XLSX here</div>
                  <div style={{ fontSize: 12, color: '#9ca3af', marginTop: 4 }}>or click to browse</div>
                </>
              )}
            </div>
          ) : (
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, padding: '10px 14px', background: '#f0fdf4', borderRadius: 8, border: '1px solid #bbf7d0' }}>
                <span style={{ color: '#22c55e', fontWeight: 700, fontSize: 16 }}>{'\u2713'}</span>
                <span style={{ fontSize: 13, fontWeight: 500 }}>{fileInfo?.name}</span>
                <span style={{ fontSize: 12, color: '#6b7280' }}>{fileInfo?.rowCount} rows, {fileInfo?.columns?.length} columns</span>
              </div>
              {preview && <PreviewTable preview={preview} maxHeight={300} />}
            </div>
          )}

          {uploadError && <div style={{ color: '#ef4444', fontSize: 12, marginTop: 8 }}>{uploadError}</div>}
        </div>
      )}

      {/* Step 1: SQL Transform */}
      {step === 1 && (
        <div style={sectionStyle}>
          <h3 style={{ margin: '0 0 4px', fontSize: 15, fontWeight: 600 }}>SQL Transform <span style={{ fontSize: 11, color: '#9ca3af', fontWeight: 400 }}>(optional)</span></h3>
          <p style={{ fontSize: 12, color: '#6b7280', margin: '0 0 12px' }}>
            Your data is loaded into a table called <code style={{ background: '#f3f4f6', padding: '1px 5px', borderRadius: 3, fontSize: 11 }}>data</code>.
            Run SQL to filter, transform, or reshape before uploading.
          </p>

          <div style={{ display: 'flex', gap: 8, marginBottom: 10 }}>
            <textarea
              value={sql}
              onChange={e => setSql(e.target.value)}
              placeholder="SELECT * FROM data WHERE amount > 100"
              onKeyDown={e => { if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') handleRunSql() }}
              style={{
                flex: 1, minHeight: 80, padding: '10px 12px', borderRadius: 8,
                border: '1px solid #d1d5db', fontFamily: 'monospace', fontSize: 12,
                resize: 'vertical',
              }}
            />
          </div>

          <div style={{ display: 'flex', gap: 8, marginBottom: 12, flexWrap: 'wrap', alignItems: 'center' }}>
            <button
              onClick={handleRunSql}
              disabled={sqlRunning || !sql.trim()}
              style={{
                padding: '7px 18px', borderRadius: 6, border: 'none',
                background: sqlRunning ? '#d1d5db' : '#8b5cf6', color: '#fff',
                fontSize: 12, fontWeight: 600, cursor: sqlRunning ? 'not-allowed' : 'pointer',
              }}
            >
              {sqlRunning ? 'Running...' : 'Run SQL'}
            </button>
            <span style={{ fontSize: 11, color: '#9ca3af' }}>Ctrl+Enter to run</span>

            <div style={{ flex: 1 }} />
            <div style={{ display: 'flex', gap: 4 }}>
              {['UPDATE data SET col = UPPER(col)', 'DELETE FROM data WHERE col IS NULL', 'ALTER TABLE data DROP COLUMN col', 'SELECT * FROM data LIMIT 10'].map((hint, i) => (
                <button key={i} onClick={() => setSql(hint)} style={{
                  padding: '3px 8px', borderRadius: 4, border: '1px solid #e5e7eb',
                  background: '#f9fafb', fontSize: 10, cursor: 'pointer', color: '#6b7280',
                }}>
                  {['UPPER()', 'Filter NULLs', 'Drop col', 'Preview'][i]}
                </button>
              ))}
            </div>
          </div>

          {sqlError && <div style={{ color: '#ef4444', fontSize: 12, marginBottom: 8, padding: '8px 12px', background: '#fef2f2', borderRadius: 6 }}>{sqlError}</div>}

          {sqlResult?.message && (
            <div style={{ fontSize: 12, color: '#16a34a', marginBottom: 8, padding: '8px 12px', background: '#f0fdf4', borderRadius: 6 }}>
              {sqlResult.message}
            </div>
          )}

          {sqlResult?.rows?.length > 0 && (
            <div style={{ marginBottom: 12 }}>
              <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 4 }}>Query result ({sqlResult.rowCount} rows):</div>
              <PreviewTable preview={sqlResult} maxHeight={200} />
            </div>
          )}

          <div style={{ borderTop: '1px solid #f3f4f6', paddingTop: 12 }}>
            <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 4 }}>Current data table ({preview?.totalRows || 0} rows):</div>
            {preview && <PreviewTable preview={preview} maxHeight={250} />}
          </div>
        </div>
      )}

      {/* Step 2: Target Selection */}
      {step === 2 && (
        <div style={sectionStyle}>
          <h3 style={{ margin: '0 0 12px', fontSize: 15, fontWeight: 600 }}>Salesforce Target</h3>

          {/* SF Connection */}
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Connection</label>
            <select
              value={selectedSfId}
              onChange={e => { setSelectedSfId(e.target.value); setSelectedObject(''); setSfFields([]) }}
              style={{ width: '100%', maxWidth: 400, padding: '8px 10px', borderRadius: 6, border: '1px solid #d1d5db', fontSize: 13 }}
            >
              <option value="">Select Salesforce connection...</option>
              {sfConnections.map(c => (
                <option key={c.id} value={c.id}>{connectionDisplayName(c)}</option>
              ))}
            </select>
            {isProduction && selectedSfId && (
              <div style={{ fontSize: 11, color: '#dc2626', marginTop: 4, fontWeight: 500 }}>
                This is a PRODUCTION org. Proceed with caution.
              </div>
            )}
          </div>

          {/* SF Object */}
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Object</label>
            {loadingObjects ? (
              <div style={{ fontSize: 12, color: '#9ca3af' }}>Loading objects...</div>
            ) : (
              <div style={{ position: 'relative', maxWidth: 400 }}>
                <input
                  type="text"
                  value={objectSearch !== null ? objectSearch : selectedObject}
                  onChange={e => { setObjectSearch(e.target.value); setShowObjectDropdown(true) }}
                  onFocus={() => setShowObjectDropdown(true)}
                  onBlur={() => setTimeout(() => setShowObjectDropdown(false), 200)}
                  placeholder="Search objects..."
                  style={{ width: '100%', padding: '8px 10px', borderRadius: 6, border: '1px solid #d1d5db', fontSize: 13 }}
                />
                {showObjectDropdown && sfObjects.length > 0 && (
                  <div style={{
                    position: 'absolute', top: '100%', left: 0, right: 0, maxHeight: 200,
                    overflow: 'auto', background: '#fff', border: '1px solid #d1d5db', borderRadius: 6,
                    boxShadow: '0 4px 12px rgba(0,0,0,0.1)', zIndex: 10,
                  }}>
                    {sfObjects
                      .filter(o => {
                        const q = (objectSearch || '').toLowerCase()
                        return !q || o.name.toLowerCase().includes(q) || o.apiName.toLowerCase().includes(q)
                      })
                      .slice(0, 50)
                      .map(o => (
                        <div key={o.apiName}
                          onMouseDown={() => {
                            setSelectedObject(o.apiName)
                            setObjectSearch(null)
                            setShowObjectDropdown(false)
                          }}
                          style={{
                            padding: '6px 10px', cursor: 'pointer', fontSize: 12,
                            background: o.apiName === selectedObject ? '#ede9fe' : 'transparent',
                          }}
                        >
                          <span style={{ fontWeight: 500 }}>{o.apiName}</span>
                          <span style={{ color: '#9ca3af', marginLeft: 6 }}>{o.name}</span>
                        </div>
                      ))}
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Operation */}
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Operation</label>
            <div style={{ display: 'flex', gap: 6 }}>
              {['insert', 'update', 'upsert', 'delete'].map(op => (
                <button key={op} onClick={() => setOperation(op)} style={{
                  padding: '7px 16px', borderRadius: 6, fontSize: 12, fontWeight: 500, cursor: 'pointer',
                  border: `1px solid ${operation === op ? '#8b5cf6' : '#d1d5db'}`,
                  background: operation === op ? '#ede9fe' : '#fff',
                  color: operation === op ? '#7c3aed' : '#374151',
                }}>
                  {op.charAt(0).toUpperCase() + op.slice(1)}
                </button>
              ))}
            </div>
          </div>

          {/* External ID for upsert */}
          {operation === 'upsert' && (
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>External ID Field</label>
              <select
                value={externalIdField}
                onChange={e => setExternalIdField(e.target.value)}
                style={{ width: '100%', maxWidth: 400, padding: '8px 10px', borderRadius: 6, border: '1px solid #d1d5db', fontSize: 13 }}
              >
                <option value="">Select external ID field...</option>
                {sfFields.filter(f => f.externalId || f.name === 'Id').map(f => (
                  <option key={f.name} value={f.name}>{f.name} ({f.label})</option>
                ))}
              </select>
            </div>
          )}

          {loadingFields && <div style={{ fontSize: 12, color: '#9ca3af' }}>Loading fields...</div>}
        </div>
      )}

      {/* Step 3: Column Mapping */}
      {step === 3 && (
        <div style={sectionStyle}>
          <h3 style={{ margin: '0 0 4px', fontSize: 15, fontWeight: 600 }}>Column Mapping</h3>
          <p style={{ fontSize: 12, color: '#6b7280', margin: '0 0 12px' }}>
            {mappedCount} of {totalCols} columns mapped to <strong>{selectedObject}</strong> fields.
            Set to "Skip" to exclude a column.
          </p>

          <div style={{ maxHeight: 400, overflow: 'auto', border: '1px solid #e5e7eb', borderRadius: 8 }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ background: '#f9fafb', position: 'sticky', top: 0, zIndex: 1 }}>
                  <th style={{ padding: '8px 12px', textAlign: 'left', borderBottom: '1px solid #e5e7eb', fontWeight: 600 }}>File Column</th>
                  <th style={{ padding: '8px 12px', textAlign: 'center', borderBottom: '1px solid #e5e7eb' }}>{'\u2192'}</th>
                  <th style={{ padding: '8px 12px', textAlign: 'left', borderBottom: '1px solid #e5e7eb', fontWeight: 600 }}>SF Field</th>
                </tr>
              </thead>
              <tbody>
                {(preview?.columns || []).map(col => {
                  const mapped = columnMapping[col] || '__skip__'
                  const isSkipped = mapped === '__skip__'
                  return (
                    <tr key={col} style={{ background: isSkipped ? '#fafafa' : '#fff' }}>
                      <td style={{ padding: '6px 12px', borderBottom: '1px solid #f3f4f6', fontFamily: 'monospace', color: isSkipped ? '#9ca3af' : '#374151' }}>
                        {col}
                      </td>
                      <td style={{ padding: '6px 4px', borderBottom: '1px solid #f3f4f6', textAlign: 'center', color: '#9ca3af' }}>{'\u2192'}</td>
                      <td style={{ padding: '4px 8px', borderBottom: '1px solid #f3f4f6' }}>
                        <select
                          value={mapped}
                          onChange={e => setColumnMapping(prev => ({ ...prev, [col]: e.target.value }))}
                          style={{
                            width: '100%', padding: '5px 8px', borderRadius: 4,
                            border: `1px solid ${isSkipped ? '#e5e7eb' : '#8b5cf6'}`,
                            fontSize: 12, background: isSkipped ? '#f9fafb' : '#faf5ff',
                            color: isSkipped ? '#9ca3af' : '#374151',
                          }}
                        >
                          <option value="__skip__">-- Skip --</option>
                          {creatableFields.map(f => (
                            <option key={f.name} value={f.name}>{f.name} ({f.label})</option>
                          ))}
                        </select>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Step 4: Execute */}
      {step === 4 && (
        <div style={sectionStyle}>
          <h3 style={{ margin: '0 0 12px', fontSize: 15, fontWeight: 600 }}>Execute Upload</h3>

          {/* Summary */}
          {!uploadState && (
            <div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
                <SummaryCard label="File" value={fileInfo?.name || ''} />
                <SummaryCard label="Rows" value={String(preview?.totalRows || 0)} />
                <SummaryCard label="Target" value={`${selectedObject} (${operation})`} />
                <SummaryCard label="Connection" value={selectedSfConn ? connectionDisplayName(selectedSfConn) : ''} />
                <SummaryCard label="Mapped Columns" value={`${mappedCount} / ${totalCols}`} />
                {operation === 'upsert' && <SummaryCard label="External ID" value={externalIdField} />}
              </div>

              {isProduction && (
                <div style={{ padding: '10px 14px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8, marginBottom: 12, fontSize: 12, color: '#dc2626' }}>
                  Warning: You are uploading to a <strong>Production</strong> org. This action cannot be easily undone.
                </div>
              )}

              <button
                onClick={handleStartUpload}
                style={{
                  padding: '10px 28px', borderRadius: 8, border: 'none',
                  background: isProduction ? '#dc2626' : '#8b5cf6', color: '#fff',
                  fontSize: 14, fontWeight: 600, cursor: 'pointer',
                }}
              >
                {isProduction ? 'Upload to Production' : 'Start Upload'}
              </button>
            </div>
          )}

          {/* Progress */}
          {uploadState && (
            <div>
              <div style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                  <span style={{ fontWeight: 500, textTransform: 'capitalize' }}>{uploadState.status}</span>
                  <span>{uploadState.progress || 0}%</span>
                </div>
                <div style={{ height: 8, background: '#e5e7eb', borderRadius: 4, overflow: 'hidden' }}>
                  <div style={{
                    height: '100%', borderRadius: 4, transition: 'width 0.3s',
                    width: `${uploadState.progress || 0}%`,
                    background: uploadState.status === 'error' ? '#ef4444'
                      : uploadState.status === 'complete' ? '#22c55e' : '#8b5cf6',
                  }} />
                </div>
              </div>

              {/* Counts */}
              <div style={{ display: 'flex', gap: 16, fontSize: 13, marginBottom: 12 }}>
                <span>Total: <strong>{uploadState.total_records || 0}</strong></span>
                <span style={{ color: '#22c55e' }}>Success: <strong>{uploadState.success_count || 0}</strong></span>
                <span style={{ color: '#ef4444' }}>Errors: <strong>{uploadState.error_count || 0}</strong></span>
              </div>

              {/* String errors */}
              {stringErrors.map((err, i) => (
                <div key={i} style={{ padding: '8px 12px', background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 6, marginBottom: 6, fontSize: 12, color: '#dc2626' }}>
                  {err}
                </div>
              ))}

              {/* Record-level errors */}
              {recordErrors.length > 0 && (
                <div style={{ marginTop: 8 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                    <span style={{ fontSize: 12, fontWeight: 600 }}>Error Details ({recordErrors.length})</span>
                    <button onClick={downloadErrorsCsv} style={{
                      padding: '4px 10px', borderRadius: 4, border: '1px solid #e5e7eb',
                      background: '#fff', fontSize: 11, cursor: 'pointer', color: '#6b7280',
                    }}>
                      Download CSV
                    </button>
                  </div>
                  <div style={{ maxHeight: 250, overflow: 'auto', border: '1px solid #e5e7eb', borderRadius: 6 }}>
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                      <thead>
                        <tr style={{ background: '#fef2f2', position: 'sticky', top: 0 }}>
                          <th style={{ padding: '6px 8px', textAlign: 'left', borderBottom: '1px solid #fecaca' }}>Row</th>
                          <th style={{ padding: '6px 8px', textAlign: 'left', borderBottom: '1px solid #fecaca' }}>Code</th>
                          <th style={{ padding: '6px 8px', textAlign: 'left', borderBottom: '1px solid #fecaca' }}>Message</th>
                        </tr>
                      </thead>
                      <tbody>
                        {recordErrors.slice(0, 100).map((err, i) => {
                          const suggestion = getErrorSuggestion(err.statusCode, err.message)
                          return (
                            <React.Fragment key={i}>
                              <tr
                                onClick={() => setExpandedRow(expandedRow === i ? null : i)}
                                style={{ cursor: 'pointer', background: i % 2 ? '#fff' : '#fffbfb' }}
                              >
                                <td style={{ padding: '5px 8px', borderBottom: '1px solid #f3f4f6' }}>{err.row}</td>
                                <td style={{ padding: '5px 8px', borderBottom: '1px solid #f3f4f6', fontFamily: 'monospace' }}>{err.statusCode}</td>
                                <td style={{ padding: '5px 8px', borderBottom: '1px solid #f3f4f6' }}>{err.message}</td>
                              </tr>
                              {expandedRow === i && suggestion && (
                                <tr>
                                  <td colSpan={3} style={{ padding: '6px 8px 6px 24px', background: '#fefce8', borderBottom: '1px solid #fef3c7', fontSize: 11 }}>
                                    <strong>Cause:</strong> {suggestion.cause}<br />
                                    <strong>Fix:</strong> {suggestion.fix}
                                  </td>
                                </tr>
                              )}
                            </React.Fragment>
                          )
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Per-record results */}
              {!uploadState.running && recordResults.length > 0 && recordErrors.length === 0 && (
                <div style={{ padding: '10px 14px', background: '#f0fdf4', border: '1px solid #bbf7d0', borderRadius: 8, fontSize: 12, color: '#16a34a', marginTop: 8 }}>
                  All {uploadState.success_count} records uploaded successfully!
                </div>
              )}

              {/* Completed actions */}
              {!uploadState.running && uploadState.status !== 'error' && (
                <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>
                  <button onClick={handleReset} style={{
                    padding: '8px 20px', borderRadius: 6, border: '1px solid #d1d5db',
                    background: '#fff', fontSize: 12, cursor: 'pointer', fontWeight: 500,
                  }}>
                    Upload Another File
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Navigation */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 'auto', paddingTop: 12 }}>
        <button
          onClick={() => setStep(Math.max(0, step - 1))}
          disabled={step === 0}
          style={{
            padding: '8px 20px', borderRadius: 6, border: '1px solid #d1d5db',
            background: '#fff', fontSize: 13, fontWeight: 500,
            cursor: step === 0 ? 'not-allowed' : 'pointer', opacity: step === 0 ? 0.4 : 1,
          }}
        >
          Back
        </button>
        {step < STEPS.length - 1 && (
          <button
            onClick={() => setStep(step + 1)}
            disabled={!canNext()}
            style={{
              padding: '8px 24px', borderRadius: 6, border: 'none',
              background: canNext() ? '#8b5cf6' : '#d1d5db', color: '#fff',
              fontSize: 13, fontWeight: 600,
              cursor: canNext() ? 'pointer' : 'not-allowed',
            }}
          >
            Next
          </button>
        )}
      </div>
    </div>
  )
}

// ── Preview Table ──

function PreviewTable({ preview, maxHeight = 300 }) {
  if (!preview?.columns?.length) return null
  return (
    <div style={{ maxHeight, overflow: 'auto', border: '1px solid #e5e7eb', borderRadius: 6 }}>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
        <thead>
          <tr style={{ background: '#f9fafb', position: 'sticky', top: 0, zIndex: 1 }}>
            {preview.columns.map(col => (
              <th key={col} style={{ padding: '6px 8px', textAlign: 'left', borderBottom: '1px solid #e5e7eb', fontWeight: 600, whiteSpace: 'nowrap' }}>
                {col}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {preview.rows.map((row, i) => (
            <tr key={i} style={{ background: i % 2 ? '#fafafa' : '#fff' }}>
              {preview.columns.map(col => (
                <td key={col} style={{ padding: '4px 8px', borderBottom: '1px solid #f3f4f6', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {row[col] ?? <span style={{ color: '#d1d5db' }}>null</span>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

// ── Summary Card ──

function SummaryCard({ label, value }) {
  return (
    <div style={{ padding: '10px 14px', background: '#f9fafb', borderRadius: 8, border: '1px solid #e5e7eb' }}>
      <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 2 }}>{label}</div>
      <div style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>{value}</div>
    </div>
  )
}
