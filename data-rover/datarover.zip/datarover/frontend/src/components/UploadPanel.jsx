import React, { useState, useEffect, useRef } from 'react'
import { connectionDisplayName } from './ConnectionModal.jsx'
import ConnectionSelect, { DatabaseSelect } from './ConnectionSelect.jsx'

// Map SF error codes/patterns to human-readable causes and fixes
function getErrorSuggestion(statusCode, message) {
  const code = (statusCode || '').toUpperCase()
  const msg = (message || '').toLowerCase()

  const suggestions = {
    'REQUIRED_FIELD_MISSING': {
      cause: 'A required field has no value.',
      fix: 'Map the missing field in column mapping or provide a default value in your source data.',
    },
    'INVALID_FIELD_FOR_INSERT_UPDATE': {
      cause: 'Trying to write to a read-only or system field.',
      fix: 'Remove the read-only field(s) from your mapping. Fields like Id, CreatedDate, LastModifiedDate, SystemModstamp are auto-managed by Salesforce.',
    },
    'DUPLICATES_DETECTED': {
      cause: 'A duplicate rule matched an existing record.',
      fix: 'Use "Upsert" operation with an External ID to update instead of insert, or de-duplicate your source data.',
    },
    'DUPLICATE_VALUE': {
      cause: 'A unique field already has this value in Salesforce.',
      fix: 'Check for duplicate values in your data. Use "Upsert" with the unique field as External ID to update existing records.',
    },
    'FIELD_CUSTOM_VALIDATION_EXCEPTION': {
      cause: 'A custom validation rule in Salesforce rejected this record.',
      fix: 'Check the error message for the validation rule details. Update your data to meet the rule requirements or temporarily disable the rule in Salesforce Setup.',
    },
    'INVALID_CROSS_REFERENCE_KEY': {
      cause: 'A lookup/reference field points to a record that doesn\'t exist.',
      fix: 'Verify that the referenced record ID exists in the target org. Load parent records before child records.',
    },
    'MALFORMED_ID': {
      cause: 'A Salesforce ID field has an invalid format.',
      fix: 'Salesforce IDs must be 15 or 18 characters. Check the ID values in your data for typos or truncation.',
    },
    'INVALID_OR_NULL_FOR_RESTRICTED_PICKLIST': {
      cause: 'A restricted picklist field has a value that isn\'t in the allowed list.',
      fix: 'Check the picklist values in Salesforce Setup and update your data to use only allowed values.',
    },
    'STRING_TOO_LONG': {
      cause: 'A text value exceeds the field\'s maximum length.',
      fix: 'Truncate the value to fit within the field length limit shown in the error.',
    },
    'INVALID_EMAIL_ADDRESS': {
      cause: 'An email field has an invalid format.',
      fix: 'Ensure email values are in valid format (e.g., user@domain.com).',
    },
    'INVALID_TYPE_ON_FIELD_IN_RECORD': {
      cause: 'The data type doesn\'t match what the field expects.',
      fix: 'Check that numbers are numeric, dates are in ISO format (YYYY-MM-DD), and booleans are true/false.',
    },
    'UNABLE_TO_LOCK_ROW': {
      cause: 'Another process is modifying the same record.',
      fix: 'Wait a moment and retry. Reduce batch size or avoid updating the same records concurrently.',
    },
    'ENTITY_IS_DELETED': {
      cause: 'The record was already deleted.',
      fix: 'Remove deleted record IDs from your data, or undelete them in Salesforce first.',
    },
    'INSUFFICIENT_ACCESS_ON_CROSS_REFERENCE_ENTITY': {
      cause: 'No permission to access a referenced record.',
      fix: 'Check sharing rules and permissions. Ensure your user has access to the parent/referenced records.',
    },
    'CANNOT_INSERT_UPDATE_ACTIVATE_ENTITY': {
      cause: 'A trigger, workflow, or process builder failed.',
      fix: 'Check the error detail for the specific trigger. You may need to fix the automation or temporarily deactivate it.',
    },
    'FIELD_INTEGRITY_EXCEPTION': {
      cause: 'Data integrity constraint violated.',
      fix: 'Check that all required relationships and field constraints are satisfied.',
    },
    'INVALID_SESSION_ID': {
      cause: 'Your Salesforce session has expired.',
      fix: 'Re-authenticate: edit your Salesforce connection and click "Login with Salesforce".',
    },
    'NUMBER_OUTSIDE_VALID_RANGE': {
      cause: 'A number value is outside the allowed range for the field.',
      fix: 'Check the field\'s precision and scale in Salesforce, and adjust your data values.',
    },
    'INVALID_FIELD': {
      cause: 'A field name in the query or record doesn\'t exist on this object.',
      fix: 'Verify field API names in your mapping match the target object\'s fields.',
    },
  }

  // Exact code match
  if (suggestions[code]) return suggestions[code]

  // Pattern matching on message for codes embedded in message
  for (const [key, val] of Object.entries(suggestions)) {
    if (msg.includes(key.toLowerCase().replace(/_/g, ' ')) || msg.includes(key.toLowerCase())) {
      return val
    }
  }

  // Generic pattern matches
  if (msg.includes('required field')) return suggestions['REQUIRED_FIELD_MISSING']
  if (msg.includes('duplicate')) return suggestions['DUPLICATES_DETECTED']
  if (msg.includes('too long') || msg.includes('too large')) return suggestions['STRING_TOO_LONG']
  if (msg.includes('read-only') || msg.includes('read only') || msg.includes('unable to create/update'))
    return suggestions['INVALID_FIELD_FOR_INSERT_UPDATE']
  if (msg.includes('invalid id') || msg.includes('malformed id')) return suggestions['MALFORMED_ID']
  if (msg.includes('validation') && msg.includes('rule')) return suggestions['FIELD_CUSTOM_VALIDATION_EXCEPTION']
  if (msg.includes('trigger') || msg.includes('workflow')) return suggestions['CANNOT_INSERT_UPDATE_ACTIVATE_ENTITY']
  if (msg.includes('permission') || msg.includes('access')) return suggestions['INSUFFICIENT_ACCESS_ON_CROSS_REFERENCE_ENTITY']
  if (msg.includes('picklist')) return suggestions['INVALID_OR_NULL_FOR_RESTRICTED_PICKLIST']

  return null
}

export default function UploadPanel({
  sfConnectionId, sfRefreshKey = 0, dbConnectionId, sfConnection,
  sfConnections = [], dbConnections = [], sourceConnections, targetConnections,
  onSetActiveSfId, onOpenSfModal, onEditSfConn,
}) {
  const allSourceConns = sourceConnections || dbConnections
  const allTargetConns = targetConnections || sfConnections
  // DB state
  const [dbTablesMap, setDbTablesMap] = useState({})
  const [dbTableCommentsMap, setDbTableCommentsMap] = useState({})
  const [selectedDbId, setSelectedDbId] = useState(dbConnectionId || '')
  const [selectedTable, setSelectedTable] = useState(null)
  const [tableSearch, setTableSearch] = useState('')

  // Database (schema) selection for Athena
  const [dbDatabases, setDbDatabases] = useState([])
  const [selectedDatabase, setSelectedDatabase] = useState('')

  // Upload confirmation modal
  const [showConfirmModal, setShowConfirmModal] = useState(false)
  const [confirmText, setConfirmText] = useState('')
  const [prodCheckbox, setProdCheckbox] = useState(false)

  // Table data preview
  const [previewData, setPreviewData] = useState(null)
  const [loadingPreview, setLoadingPreview] = useState(false)
  const [previewMaximized, setPreviewMaximized] = useState(false)

  // SF objects & fields
  const [sfObjects, setSfObjects] = useState([])
  const [selectedObject, setSelectedObject] = useState('')
  const [objectSearch, setObjectSearch] = useState(null)
  const [showObjectDropdown, setShowObjectDropdown] = useState(false)
  const [sfFields, setSfFields] = useState([])
  const [loadingFields, setLoadingFields] = useState(false)

  // Operation
  const [operation, setOperation] = useState('')
  const [externalIdField, setExternalIdField] = useState('')
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  // Column mapping
  const [columnMapping, setColumnMapping] = useState({})

  // Upload state
  const [uploadState, setUploadState] = useState(null)
  const [uploadJobId, setUploadJobId] = useState(null)
  const pollRef = useRef(null)

  // Record-level results
  const [recordResults, setRecordResults] = useState([])
  const [loadingResults, setLoadingResults] = useState(false)

  // Saved mappings
  const [hasSavedMapping, setHasSavedMapping] = useState(false)

  // Expanded error row (to show source data)
  const [expandedRow, setExpandedRow] = useState(null)

  // Right-panel tab: 'mapping' | 'results'
  const [rightTab, setRightTab] = useState('mapping')

  // Session expired flag
  const [sfNeedsReauth, setSfNeedsReauth] = useState(false)

  // Save as Step (checkbox in confirm modal)
  const [saveAsStep, setSaveAsStep] = useState(false)
  const [saveStepName, setSaveStepName] = useState('')
  const [stepSaved, setStepSaved] = useState(false)

  const saveAsStepRef = useRef({ saveAsStep: false, saveStepName: '' })
  useEffect(() => { saveAsStepRef.current = { saveAsStep, saveStepName } }, [saveAsStep, saveStepName])
  const prevUploadStatusRef = useRef(null)
  useEffect(() => {
    if (uploadState?.status === 'complete' && prevUploadStatusRef.current !== 'complete' && saveAsStepRef.current.saveAsStep && saveAsStepRef.current.saveStepName.trim()) {
      const name = saveAsStepRef.current.saveStepName.trim()
      const sfConnId = allTargetConns.find(c => c.loginUrl)?.id || sfConnectionId || ''
      const cfg = {
        dbConnectionId: selectedDbId,
        sfConnectionId: sfConnId,
        sourceDatabase: selectedDatabase || '',
        tableName: selectedTable || '',
        objectName: selectedObject || '',
        operation: operation || 'insert',
        externalIdField: externalIdField || '',
        columnMapping: columnMapping || {},
      }
      fetch('/api/saved-steps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, type: 'load', config: cfg }),
      }).then(() => setStepSaved(true)).catch(() => {})
    }
    prevUploadStatusRef.current = uploadState?.status || null
  }, [uploadState?.status])

  // Sync selectedDbId when parent changes (including clearing to '')
  useEffect(() => {
    setSelectedDbId(dbConnectionId || '')
  }, [dbConnectionId])

  // Clear selection if it's no longer in the available connections list
  useEffect(() => {
    if (selectedDbId && allSourceConns.length >= 0 && !allSourceConns.find(c => c.id === selectedDbId)) {
      setSelectedDbId('')
    }
  }, [allSourceConns, selectedDbId])

  // Fetch databases when selected connection changes
  const selectedConnObj = allSourceConns.find(c => c.id === selectedDbId)
  const isAthenaConn = selectedConnObj?.dbType === 'athena'
  const isSfSource = selectedConnObj && !selectedConnObj.dbType && selectedConnObj.loginUrl

  // Fetch SF objects when an SF connection is selected as source
  useEffect(() => {
    if (!selectedDbId || !isSfSource) return
    fetch(`/api/salesforce/${selectedDbId}/objects`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) {
          setDbTablesMap(prev => ({ ...prev, [selectedDbId]: data.map(o => o.apiName || o.name || o) }))
        } else {
          setDbTablesMap(prev => ({ ...prev, [selectedDbId]: [] }))
        }
      })
      .catch(() => setDbTablesMap(prev => ({ ...prev, [selectedDbId]: [] })))
  }, [selectedDbId, isSfSource])

  useEffect(() => {
    if (!selectedDbId || isSfSource) { setDbDatabases([]); setSelectedDatabase(''); if (!selectedDbId) setDbTablesMap(prev => ({ ...prev, [selectedDbId]: [] })); return }
    fetch(`/api/database/${selectedDbId}/databases`)
      .then(r => r.json())
      .then(data => {
        const dbs = data.databases || []
        setDbDatabases(dbs)
        // For non-Athena with single DB, auto-select; otherwise reset
        if (dbs.length === 1) {
          setSelectedDatabase(dbs[0])
        } else {
          setSelectedDatabase('')
          setDbTablesMap(prev => ({ ...prev, [selectedDbId]: [] }))
        }
      })
      .catch(() => { setDbDatabases([]); setSelectedDatabase('') })
  }, [selectedDbId])

  // Fetch tables when database is selected (or immediately for single-db connections)
  useEffect(() => {
    if (!selectedDbId || isSfSource) { return }
    // Wait for databases list to load, and if multiple, wait for selection
    if (!selectedDatabase) {
      setDbTablesMap(prev => ({ ...prev, [selectedDbId]: [] }))
      return
    }
    const url = selectedDatabase
      ? `/api/database/${selectedDbId}/tables?database=${encodeURIComponent(selectedDatabase)}`
      : `/api/database/${selectedDbId}/tables`
    fetch(url)
      .then(r => r.json())
      .then(data => {
        setDbTablesMap(prev => ({ ...prev, [selectedDbId]: data.tables || [] }))
        if (data.tableComments) setDbTableCommentsMap(prev => ({ ...prev, [selectedDbId]: data.tableComments }))
      })
      .catch(() => setDbTablesMap(prev => ({ ...prev, [selectedDbId]: [] })))
  }, [selectedDbId, selectedDatabase, dbDatabases])

  // Fetch SF objects
  useEffect(() => {
    if (!sfConnectionId) { setSfObjects([]); setSfNeedsReauth(false); return }
    setSfNeedsReauth(false)
    fetch(`/api/salesforce/${sfConnectionId}/objects`)
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) { setSfObjects(data); setSfNeedsReauth(false) }
        else if (data.needsReauth) { setSfObjects([]); setSfNeedsReauth(true) }
        else setSfObjects([])
      })
      .catch(() => setSfObjects([]))
  }, [sfConnectionId, sfRefreshKey])

  // Clear stale upload errors when SF connection is refreshed
  useEffect(() => {
    if (sfRefreshKey > 0 && uploadState && !uploadState.running) {
      setUploadState(null)
      setRecordResults([])
      setRightTab('mapping')
    }
  }, [sfRefreshKey])

  // Auto-suggest object name from table name
  useEffect(() => {
    if (!selectedTable) return
    const normalized = selectedTable.replace(/^sf_/i, '')
    const suggested = normalized.charAt(0).toUpperCase() + normalized.slice(1)
    const match = sfObjects.find(o =>
      o.apiName.toLowerCase() === suggested.toLowerCase() ||
      o.apiName.toLowerCase() === normalized.toLowerCase()
    )
    setSelectedObject(match ? match.apiName : '')
  }, [selectedTable, sfObjects])

  // Fetch preview when table selected
  useEffect(() => {
    if (!selectedDbId || !selectedTable) { setPreviewData(null); return }
    setLoadingPreview(true)
    if (isSfSource) {
      // For SF source, run a SOQL query to get preview data
      fetch(`/api/salesforce/${selectedDbId}/soql`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ soql: `SELECT Id, Name FROM ${selectedTable} LIMIT 25` }),
      })
        .then(r => r.json())
        .then(data => {
          if (data.columns && data.rows) {
            setPreviewData({ columns: data.columns, rows: data.rows, totalRows: data.rowCount || data.rows.length })
          } else {
            setPreviewData(null)
          }
        })
        .catch(() => setPreviewData(null))
        .finally(() => setLoadingPreview(false))
    } else {
      fetch(`/api/database/${selectedDbId}/tables/${selectedTable}/sample`)
        .then(r => r.json())
        .then(data => setPreviewData(data))
        .catch(() => setPreviewData(null))
        .finally(() => setLoadingPreview(false))
    }
  }, [selectedDbId, selectedTable, isSfSource])

  // Fetch SF fields when object selected
  useEffect(() => {
    if (!sfConnectionId || !selectedObject) { setSfFields([]); return }
    setLoadingFields(true)
    fetch(`/api/salesforce/${sfConnectionId}/describe/${selectedObject}`)
      .then(r => r.json())
      .then(data => setSfFields(data.fields || []))
      .catch(() => setSfFields([]))
      .finally(() => setLoadingFields(false))
  }, [sfConnectionId, selectedObject])

  // Auto-map columns (skip read-only/system fields)
  useEffect(() => {
    if (!previewData?.columns || sfFields.length === 0) return
    const mapping = {}
    for (const dbCol of previewData.columns) {
      const normalizedDb = dbCol.toLowerCase().replace(/^sf_/, '')
      const match = sfFields.find(f => f.name.toLowerCase() === normalizedDb)
      if (!match) {
        mapping[dbCol] = '__skip__'
      } else if (operation === 'delete') {
        // For delete, only map Id
        mapping[dbCol] = match.name === 'Id' ? 'Id' : '__skip__'
      } else if (operation === 'insert' && !match.createable) {
        mapping[dbCol] = '__skip__'
      } else if (operation && operation !== 'insert' && !match.updateable && match.name !== 'Id') {
        mapping[dbCol] = '__skip__'
      } else {
        mapping[dbCol] = match.name
      }
    }
    setColumnMapping(mapping)
  }, [previewData?.columns, sfFields, operation])

  // Reset external ID field when operation changes
  useEffect(() => {
    if (operation !== 'upsert') setExternalIdField('')
  }, [operation])

  // Check for saved mapping
  useEffect(() => {
    if (!selectedTable || !selectedObject) { setHasSavedMapping(false); return }
    const key = `${selectedTable}_${selectedObject}`
    fetch(`/api/mappings/${key}`)
      .then(r => { if (r.ok) setHasSavedMapping(true); else setHasSavedMapping(false) })
      .catch(() => setHasSavedMapping(false))
  }, [selectedTable, selectedObject])

  // Derived values
  const tables = dbTablesMap[selectedDbId] || []
  const filteredTables = tableSearch
    ? tables.filter(t => t.toLowerCase().includes(tableSearch.toLowerCase()))
    : tables

  const mappedCount = Object.values(columnMapping).filter(v => v && v !== '__skip__').length
  const totalCols = previewData?.columns?.length || 0
  const showMapping = selectedObject && sfFields.length > 0 && previewData?.columns

  const externalIdFields = sfFields
  const creatableFields = operation === 'delete'
    ? sfFields.filter(f => f.name === 'Id')
    : operation === 'insert'
      ? sfFields.filter(f => f.createable)
      : sfFields.filter(f => f.createable || f.updateable || f.name === 'Id')

  const isProduction = sfConnection?.loginUrl
    ? !sfConnection.loginUrl.includes('test.salesforce.com')
    : false
  const instanceName = sfConnection?.name || ''

  const recordErrors = uploadState?.errors?.filter(e => typeof e === 'object' && e.row) || []
  const hasRecordErrors = recordErrors.length > 0

  // String errors (connection failures, InvalidSessionId, etc.)
  const stringErrors = uploadState?.errors?.filter(e => typeof e === 'string') || []

  // Mismatch warning
  const getMismatchWarning = () => {
    if (!selectedTable || !selectedObject) return null
    // Strip sf_<instancename>_ prefix (or just sf_) to extract the object portion
    const sfPrefix = sfConnection?.name
      ? `sf_${sfConnection.name.toLowerCase().replace(/[^a-z0-9]/g, '_')}_`
      : 'sf_'
    let normalized = selectedTable.toLowerCase()
    if (normalized.startsWith(sfPrefix)) {
      normalized = normalized.slice(sfPrefix.length)
    } else if (normalized.startsWith('sf_')) {
      normalized = normalized.slice(3)
    }
    if (normalized !== selectedObject.toLowerCase()) {
      return `Table "${selectedTable}" may not match SF object "${selectedObject}".`
    }
    return null
  }
  const mismatchWarning = getMismatchWarning()

  // Handlers
  const handleMappingChange = (dbCol, sfFieldName) => {
    setColumnMapping(prev => ({ ...prev, [dbCol]: sfFieldName }))
  }

  const handleSaveMapping = () => {
    if (!selectedTable || !selectedObject) return
    const key = `${selectedTable}_${selectedObject}`
    fetch('/api/mappings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key, mapping: columnMapping }),
    })
      .then(r => r.json())
      .then(() => setHasSavedMapping(true))
      .catch(() => {})
  }

  const handleLoadMapping = () => {
    if (!selectedTable || !selectedObject) return
    const key = `${selectedTable}_${selectedObject}`
    fetch(`/api/mappings/${key}`)
      .then(r => r.json())
      .then(data => { if (data.mapping) setColumnMapping(data.mapping) })
      .catch(() => {})
  }

  const handleUploadClick = () => {
    if (!sfConnectionId || !selectedDbId || !selectedTable || !selectedObject) return
    if (operation === 'upsert' && !externalIdField) return
    setConfirmText('')
    setProdCheckbox(false)
    setShowConfirmModal(true)
  }

  const isConfirmValid = () => {
    if (confirmText.trim().toLowerCase() !== instanceName.trim().toLowerCase()) return false
    if (isProduction && !prodCheckbox) return false
    return true
  }

  const handleUpload = () => {
    setShowConfirmModal(false)
    setConfirmText('')
    setProdCheckbox(false)
    if (!sfConnectionId || !selectedDbId || !selectedTable || !selectedObject) return
    if (operation === 'upsert' && !externalIdField) return

    const activeMapping = {}
    for (const [dbCol, sfField] of Object.entries(columnMapping)) {
      if (sfField && sfField !== '__skip__') activeMapping[dbCol] = sfField
    }

    setUploadState({ running: true, status: 'starting', progress: 0, total_records: 0, success_count: 0, error_count: 0, errors: [] })
    setRecordResults([])
    setRightTab('results')  // Auto-switch to Results tab

    fetch('/api/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sfConnectionId,
        dbConnectionId: selectedDbId,
        tableName: selectedTable,
        objectName: selectedObject,
        operation,
        columnMapping: activeMapping,
        externalIdField: operation === 'upsert' ? externalIdField : undefined,
      }),
    })
      .then(r => r.json())
      .then(({ jobId }) => {
        setUploadJobId(jobId)
        pollRef.current = setInterval(() => {
          fetch(`/api/upload/${jobId}/status`)
            .then(r => r.json())
            .then(s => {
              setUploadState(s)
              if (!s.running) {
                clearInterval(pollRef.current)
                pollRef.current = null
                // Auto-fetch per-record results when complete
                if (s.has_record_results) {
                  fetch(`/api/upload/${jobId}/results`)
                    .then(r => r.json())
                    .then(data => setRecordResults(data.record_results || []))
                    .catch(() => {})
                }
              }
            })
            .catch(() => {})
        }, 1000)
      })
      .catch(err => {
        setUploadState({ running: false, status: 'error', progress: 0, errors: [err.message] })
      })
  }

  const handleDownloadResults = () => {
    if (recordResults.length === 0) return
    const header = 'Row,Success,SF Id,Status Code,Error Message'
    const rows = recordResults.map(r =>
      [
        r.row,
        r.success ? 'true' : 'false',
        r.id || '',
        r.statusCode || '',
        (r.message || '').includes(',') || (r.message || '').includes('"') || (r.message || '').includes('\n')
          ? `"${(r.message || '').replace(/"/g, '""')}"`
          : (r.message || ''),
      ].join(',')
    )
    const csv = [header, ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `upload_results_${selectedObject || 'unknown'}_${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  const handleDownloadErrors = () => {
    const errorRows = recordResults.filter(r => !r.success)
    if (errorRows.length === 0) return
    // Collect all data field keys from error rows
    const dataKeys = []
    const dataKeysSet = new Set()
    for (const r of errorRows) {
      if (r.data) {
        for (const k of Object.keys(r.data)) {
          if (!dataKeysSet.has(k)) { dataKeysSet.add(k); dataKeys.push(k) }
        }
      }
    }
    const csvEscape = (val) => {
      const s = val === null || val === undefined ? '' : String(val)
      return s.includes(',') || s.includes('"') || s.includes('\n') ? `"${s.replace(/"/g, '""')}"` : s
    }
    const header = ['Row', 'Status Code', 'Error Message', ...dataKeys].join(',')
    const rows = errorRows.map(r =>
      [
        r.row,
        csvEscape(r.statusCode || ''),
        csvEscape(r.message || ''),
        ...dataKeys.map(k => csvEscape(r.data?.[k])),
      ].join(',')
    )
    const csv = [header, ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `upload_errors_${selectedObject || 'unknown'}_${new Date().toISOString().slice(0, 10)}.csv`
    a.click()
    URL.revokeObjectURL(url)
  }

  // Cleanup poll on unmount
  useEffect(() => {
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [])

  // Has any results or errors to show?
  const hasResultsContent = uploadState != null

  const sourceHeader = (
    <div style={{ padding: '8px 10px', borderBottom: '1px solid #e5e7eb', background: '#fafbfc' }}>
      <div style={{ fontSize: 10, fontWeight: 600, color: '#f59e0b', marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Source</div>
      <ConnectionSelect
        connections={allSourceConns}
        value={selectedDbId}
        onChange={id => { setSelectedDbId(id); setSelectedTable(null); setSelectedDatabase('') }}
        placeholder="Select source connection..."
      />
    </div>
  )

  const targetHeader = (
    <div style={{ padding: '8px 10px', borderBottom: '1px solid #e5e7eb', background: '#fafbfc' }}>
      <div style={{ fontSize: 10, fontWeight: 600, color: '#10b981', marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Target</div>
      <div style={{ display: 'flex', gap: 4 }}>
        <ConnectionSelect
          connections={allTargetConns}
          value={sfConnectionId}
          onChange={id => onSetActiveSfId && onSetActiveSfId(id)}
          placeholder="Select target connection..."
        />
        {onEditSfConn && sfConnection && (
          <button className="btn-inline-edit" style={{ width: 24, height: 24, fontSize: 12, flexShrink: 0 }} onClick={() => onEditSfConn(sfConnection)} title="Edit connection">&#9998;</button>
        )}
      </div>
    </div>
  )

  return (
    <div className="upload-panel">
      <div className="upload-split-layout">
        {/* ===== LEFT: Source ===== */}
        <div className="upload-left-panel">
          {sourceHeader}

          {dbDatabases.length > 1 && (
            <div style={{ padding: '8px 12px', borderBottom: '1px solid #e5e7eb' }}>
              <DatabaseSelect
                databases={dbDatabases}
                value={selectedDatabase}
                onChange={db => { setSelectedDatabase(db); setSelectedTable(null) }}
              />
            </div>
          )}

          <div style={{ padding: '8px 12px', borderBottom: '1px solid #e5e7eb' }}>
            <input
              className="search-input"
              placeholder="Search tables..."
              value={tableSearch}
              onChange={e => setTableSearch(e.target.value)}
              style={{ width: '100%', fontSize: 12, padding: '6px 10px' }}
            />
          </div>

          <div className="upload-table-scroll">
            {!selectedDbId && (
              <div className="upload-empty-hint">Select a database connection</div>
            )}
            {selectedDbId && dbDatabases.length > 1 && !selectedDatabase && (
              <div className="upload-empty-hint">Select a database above</div>
            )}
            {selectedDbId && (dbDatabases.length <= 1 || selectedDatabase) && filteredTables.length === 0 && (
              <div className="upload-empty-hint">
                {tables.length === 0 ? 'No tables found' : 'No matches'}
              </div>
            )}
            {filteredTables.map(t => {
              const comments = dbTableCommentsMap[selectedDbId] || {}
              let sourceLabel = null
              try {
                const meta = comments[t] ? JSON.parse(comments[t]) : null
                if (meta?.type) sourceLabel = meta.type === 'Salesforce' ? `SF: ${meta.connection}` : meta.type === 'CSV' ? `CSV: ${meta.file}` : `DB: ${meta.connection}`
              } catch {}
              return (
                <div
                  key={t}
                  className={`upload-table-item ${selectedTable === t ? 'active' : ''}`}
                  onClick={() => setSelectedTable(t)}
                >
                  <span>{t}</span>
                  {sourceLabel && <span style={{ display: 'block', fontSize: 9, color: '#9ca3af', lineHeight: 1.2, marginTop: 1 }}>{sourceLabel}</span>}
                </div>
              )
            })}
          </div>

          {selectedTable && previewData && previewData.rows && previewData.rows.length > 0 && (
            <div className="upload-preview-section">
              <div className="upload-preview-header">
                <span style={{ fontSize: 11, fontWeight: 600, color: '#6b7280' }}>
                  Preview: {selectedTable}
                </span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span style={{ fontSize: 10, color: '#9ca3af' }}>
                    {previewData.totalRows} total rows
                  </span>
                  <button
                    onClick={() => setPreviewMaximized(true)}
                    title="Maximize"
                    style={{
                      background: 'none', border: '1px solid #d1d5db', borderRadius: 4,
                      cursor: 'pointer', padding: '2px 6px', fontSize: 12, color: '#6b7280',
                      lineHeight: 1, display: 'flex', alignItems: 'center',
                    }}
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"/>
                    </svg>
                  </button>
                </div>
              </div>
              <div className="upload-preview-scroll">
                <table className="results-table">
                  <thead>
                    <tr>
                      {previewData.columns.map(col => (
                        <th key={col}>{col}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {previewData.rows.map((row, i) => (
                      <tr key={i}>
                        {previewData.columns.map(col => (
                          <td key={col}>{row[col] ?? <span style={{ color: '#d1d5db' }}>null</span>}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          {loadingPreview && (
            <div className="upload-empty-hint">Loading preview...</div>
          )}
        </div>

        {/* ===== RIGHT: Target ===== */}
        <div className="upload-right-panel">
          {targetHeader}
          <div className="upload-right-content">
            {sfNeedsReauth && (
              <div style={{
                background: '#fffbeb', border: '1px solid #fbbf24', borderRadius: 8,
                padding: '12px 16px', margin: '0 0 12px 0', display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <span style={{ fontSize: 13, color: '#92400e', flex: 1 }}>
                  Session expired. Please re-authenticate to continue.
                </span>
                {onEditSfConn && sfConnection && (
                  <button
                    className="btn btn-primary"
                    style={{ padding: '6px 16px', fontSize: 12, flexShrink: 0 }}
                    onClick={() => onEditSfConn(sfConnection)}
                  >
                    Login with Salesforce
                  </button>
                )}
              </div>
            )}
            {!selectedTable ? (
              <div className="upload-placeholder">
                Select a database table from the left to begin
              </div>
            ) : (
              <>
                {/* SF Object + Operation + Execute — always visible */}
                <div style={{
                  display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap',
                  padding: '0 0 12px 0', borderBottom: '1px solid #e5e7eb',
                }}>
                  <div style={{ flex: '1 1 200px', position: 'relative' }}>
                    <label className="upload-label" style={{ marginBottom: 4 }}>Target Object</label>
                    <input
                      className="config-select"
                      value={objectSearch != null ? objectSearch : selectedObject}
                      onChange={e => { setObjectSearch(e.target.value); setShowObjectDropdown(true) }}
                      onFocus={() => setShowObjectDropdown(true)}
                      placeholder="Search objects..."
                      style={{ fontSize: 13, padding: '8px 10px', width: '100%' }}
                      autoComplete="off"
                    />
                    {showObjectDropdown && sfObjects.length > 0 && (
                      <>
                        <div style={{ position: 'fixed', inset: 0, zIndex: 9 }} onClick={() => { setShowObjectDropdown(false); setObjectSearch(null) }} />
                        <div style={{
                          position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 10,
                          background: '#fff', border: '1px solid #d1d5db', borderRadius: 6,
                          maxHeight: 220, overflow: 'auto', boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                        }}>
                          {sfObjects
                            .filter(o => {
                              const q = (objectSearch ?? '').toLowerCase()
                              return !q || o.apiName.toLowerCase().includes(q) || o.name.toLowerCase().includes(q)
                            })
                            .map(o => (
                              <div
                                key={o.apiName}
                                onClick={() => { setSelectedObject(o.apiName); setObjectSearch(null); setShowObjectDropdown(false) }}
                                style={{
                                  padding: '6px 10px', fontSize: 12, cursor: 'pointer',
                                  background: o.apiName === selectedObject ? '#eff6ff' : 'transparent',
                                }}
                                onMouseEnter={e => e.currentTarget.style.background = '#f0f4ff'}
                                onMouseLeave={e => e.currentTarget.style.background = o.apiName === selectedObject ? '#eff6ff' : 'transparent'}
                              >
                                <span style={{ fontWeight: 500 }}>{o.apiName}</span>
                                <span style={{ color: '#9ca3af', marginLeft: 6 }}>{o.name}</span>
                              </div>
                            ))
                          }
                        </div>
                      </>
                    )}
                    {loadingFields && (
                      <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 2 }}>Loading fields...</div>
                    )}
                    {!loadingFields && sfFields.length > 0 && (
                      <div style={{ fontSize: 10, color: '#059669', marginTop: 2 }}>{sfFields.length} fields loaded</div>
                    )}
                  </div>

                  <div style={{ flexShrink: 0 }}>
                    <label className="upload-label" style={{ marginBottom: 4 }}>Operation</label>
                    <div className="upload-radio-group">
                      {['insert', 'update', 'upsert', 'delete'].map(op => (
                        <label key={op} className={`upload-radio ${operation === op ? 'active' : ''} ${op === 'delete' ? 'upload-radio-delete' : ''}`} style={{ padding: '7px 14px', fontSize: 12 }}>
                          <input type="radio" name="operation" value={op} checked={operation === op}
                            onChange={e => {
                              if (e.target.value === 'delete') {
                                setShowDeleteConfirm(true)
                              } else {
                                setOperation(e.target.value)
                              }
                            }} style={{ display: 'none' }} />
                          {op.charAt(0).toUpperCase() + op.slice(1)}
                        </label>
                      ))}
                    </div>
                  </div>

                  {operation === 'upsert' && (
                    <div style={{ flex: '0 1 160px' }}>
                      <label className="upload-label" style={{ marginBottom: 4 }}>External ID</label>
                      <select className="config-select" value={externalIdField}
                        onChange={e => setExternalIdField(e.target.value)}
                        style={{ fontSize: 12, padding: '7px 10px' }}>
                        <option value="">Select...</option>
                        {externalIdFields.map(f => (
                          <option key={f.name} value={f.name}>{f.name}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  <button
                    className="btn-download"
                    style={{ flexShrink: 0, padding: '8px 20px', fontSize: 13 }}
                    disabled={
                      !selectedObject || !operation || mappedCount === 0 ||
                      (operation === 'upsert' && !externalIdField) ||
                      uploadState?.running
                    }
                    onClick={handleUploadClick}
                  >
                    {uploadState?.running ? (
                      <>&#9203; Updating...</>
                    ) : (
                      <>&#11014; Update to Salesforce</>
                    )}
                  </button>
                </div>

                {operation === 'update' && (
                  <div className="upload-hint" style={{ marginTop: 4, marginBottom: 0 }}>Data must contain the Salesforce Id column to update existing records.</div>
                )}
                {operation === 'delete' && (
                  <div className="upload-warning" style={{ marginTop: 4, marginBottom: 0, background: '#fef2f2', borderColor: '#fecaca', color: '#991b1b' }}>Data must contain the Salesforce Id column. Matching records will be permanently deleted.</div>
                )}
                {mismatchWarning && (
                  <div className="upload-warning" style={{ marginTop: 8 }}>{mismatchWarning}</div>
                )}

                {/* Mapping / Results tabs */}
                <div className="upload-inner-tabs">
                  <button
                    className={`upload-inner-tab ${rightTab === 'mapping' ? 'active' : ''}`}
                    onClick={() => setRightTab('mapping')}
                  >
                    Mapping
                    {showMapping && <span className="upload-inner-tab-badge">{mappedCount}/{totalCols}</span>}
                  </button>
                  <button
                    className={`upload-inner-tab ${rightTab === 'results' ? 'active' : ''}`}
                    onClick={() => setRightTab('results')}
                  >
                    Results
                    {uploadState && !uploadState.running && uploadState.status === 'complete' && (
                      <span className="upload-inner-tab-badge" style={{ background: '#d1fae5', color: '#065f46' }}>
                        {uploadState.success_count}
                      </span>
                    )}
                    {uploadState && !uploadState.running && uploadState.error_count > 0 && (
                      <span className="upload-inner-tab-badge" style={{ background: '#fee2e2', color: '#dc2626' }}>
                        {uploadState.error_count} err
                      </span>
                    )}
                    {uploadState?.running && (
                      <span className="upload-inner-tab-badge" style={{ background: '#dbeafe', color: '#1d4ed8' }}>...</span>
                    )}
                  </button>
                </div>

                {/* === MAPPING TAB === */}
                {rightTab === 'mapping' && (
                  <div style={{ flex: 1, overflow: 'auto' }}>
                    {showMapping ? (
                      <div className="upload-section">
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <label className="upload-label">
                            Column Mapping
                            <span className="upload-mapping-count">{mappedCount} / {totalCols} mapped</span>
                          </label>
                          <div style={{ display: 'flex', gap: 6 }}>
                            {hasSavedMapping && (
                              <button className="btn btn-secondary" style={{ padding: '2px 10px', fontSize: 11 }} onClick={handleLoadMapping}>Load</button>
                            )}
                            <button className="btn btn-secondary" style={{ padding: '2px 10px', fontSize: 11 }} onClick={handleSaveMapping}>Save</button>
                          </div>
                        </div>
                        <div className="upload-mapping-table-wrapper">
                          <table className="upload-mapping-table">
                            <thead>
                              <tr>
                                <th>DB Column</th>
                                <th>SF Field</th>
                              </tr>
                            </thead>
                            <tbody>
                              {previewData.columns.map(dbCol => {
                                const mappedTo = columnMapping[dbCol] || '__skip__'
                                const isSkipped = mappedTo === '__skip__'
                                const mappedField = !isSkipped ? sfFields.find(f => f.name === mappedTo) : null
                                const isReadonly = mappedField && (
                                  (operation === 'insert' && !mappedField.createable) ||
                                  (operation !== 'insert' && !mappedField.updateable && mappedField.name !== 'Id')
                                )
                                const rowClass = isSkipped ? 'skipped mapping-unmapped' : isReadonly ? 'mapping-readonly' : ''
                                return (
                                <tr key={dbCol} className={rowClass}>
                                  <td className="upload-mapping-db-col">{dbCol}</td>
                                  <td>
                                    <select
                                      className={`upload-mapping-select ${isSkipped ? 'select-unmapped' : ''} ${isReadonly ? 'select-readonly' : ''}`}
                                      value={mappedTo}
                                      onChange={e => handleMappingChange(dbCol, e.target.value)}
                                    >
                                      <option value="__skip__">-- Skip --</option>
                                      {creatableFields.map(f => {
                                        const ro = (operation === 'insert' && !f.createable) || (operation !== 'insert' && !f.updateable && f.name !== 'Id')
                                        return <option key={f.name} value={f.name}>{f.name} ({f.type}){ro ? ' [readonly]' : ''}</option>
                                      })}
                                    </select>
                                  </td>
                                </tr>
                                )
                              })}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    ) : (
                      <div className="upload-empty-hint">
                        {!selectedObject ? 'Select a Salesforce object to see column mapping' :
                         loadingFields ? 'Loading fields...' :
                         sfFields.length === 0 ? 'No fields found for this object' :
                         'Loading table data...'}
                      </div>
                    )}
                  </div>
                )}

                {/* === RESULTS TAB === */}
                {rightTab === 'results' && (
                  <div style={{ flex: 1, overflow: 'auto' }}>
                    {!hasResultsContent ? (
                      <div className="upload-empty-hint">
                        No results yet. Click "Update to Salesforce" to execute.
                      </div>
                    ) : (
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                        {/* Progress */}
                        <div className="upload-progress-section">
                          <div className="upload-progress-header">
                            <span className={`badge status-${uploadState.status === 'complete' ? 'complete' : uploadState.status === 'error' ? 'error' : 'downloading'}`}>
                              {uploadState.status === 'reading' ? 'Reading data...' :
                               uploadState.status === 'uploading' ? 'Uploading...' :
                               uploadState.status === 'refreshing session' ? 'Refreshing session...' :
                               uploadState.status === 'complete' ? 'Complete' :
                               uploadState.status === 'error' ? 'Error' :
                               'Starting...'}
                            </span>
                            <span style={{ fontSize: 12, color: '#6b7280' }}>
                              {uploadState.total_records > 0 && `${uploadState.success_count + uploadState.error_count} / ${uploadState.total_records} records`}
                            </span>
                          </div>
                          <div className="progress-bar-container" style={{ width: '100%', height: 8 }}>
                            <div
                              className={`progress-bar ${uploadState.status === 'complete' ? 'complete' : uploadState.status === 'error' ? 'error' : 'downloading'}`}
                              style={{ width: `${uploadState.progress}%` }}
                            />
                          </div>

                          {(uploadState.status === 'complete' || (uploadState.status === 'error' && uploadState.total_records > 0)) && (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <div className="upload-results">
                                  <span className="upload-result-success">{uploadState.success_count} succeeded</span>
                                  {uploadState.error_count > 0 && (
                                    <span className="upload-result-error">{uploadState.error_count} failed</span>
                                  )}
                                </div>
                                <div style={{ display: 'flex', gap: 6 }}>
                                  {recordResults.some(r => !r.success) && (
                                    <button className="btn btn-secondary" style={{ padding: '3px 10px', fontSize: 11, color: '#dc2626', borderColor: '#fca5a5' }} onClick={handleDownloadErrors}>
                                      Download Errors
                                    </button>
                                  )}
                                  {recordResults.length > 0 && (
                                    <button className="btn btn-secondary" style={{ padding: '3px 10px', fontSize: 11 }} onClick={handleDownloadResults}>
                                      Download All
                                    </button>
                                  )}
                                </div>
                              </div>
                              {uploadState.status === 'complete' && stepSaved && (
                                <div style={{ fontSize: 11, color: '#059669', fontWeight: 500, textAlign: 'center', padding: '4px 0' }}>Step saved to Orchestrator</div>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Error messages (string errors like InvalidSessionId, connection errors) */}
                        {stringErrors.length > 0 && (
                          <div className="upload-error-detail">
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                              <span style={{ fontSize: 11, fontWeight: 600, color: '#991b1b' }}>Error Details</span>
                              {!uploadState?.running && (
                                <button
                                  className="btn btn-secondary"
                                  style={{ padding: '2px 8px', fontSize: 10 }}
                                  onClick={() => { setUploadState(null); setRecordResults([]) }}
                                >Dismiss</button>
                              )}
                            </div>
                            {stringErrors.map((err, i) => {
                              const suggestion = getErrorSuggestion('', err)
                              return (
                                <div key={i} style={{ marginBottom: 8 }}>
                                  <div style={{ fontSize: 12, color: '#dc2626', wordBreak: 'break-word' }}>{err}</div>
                                  {suggestion && (
                                    <div className="error-suggestion" style={{ marginTop: 6 }}>
                                      <div className="error-suggestion-cause"><strong>Cause:</strong> {suggestion.cause}</div>
                                      <div className="error-suggestion-fix"><strong>Fix:</strong> {suggestion.fix}</div>
                                    </div>
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        )}

                        {/* Per-record results table */}
                        {recordResults.length > 0 && (
                          <div>
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
                              <span style={{ fontSize: 11, fontWeight: 600, color: '#374151' }}>
                                Per-Record Results ({recordResults.length})
                              </span>
                            </div>
                            <div style={{ maxHeight: 400, overflow: 'auto', border: '1px solid #e5e7eb', borderRadius: 6 }}>
                              <table className="results-table" style={{ fontSize: 11 }}>
                                <thead>
                                  <tr>
                                    <th style={{ width: 50 }}>Row</th>
                                    <th style={{ width: 60 }}>Status</th>
                                    <th style={{ width: 180 }}>SF Id</th>
                                    <th>Message</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {recordResults.map((r, i) => (
                                    <React.Fragment key={i}>
                                      <tr
                                        style={!r.success && r.data ? { cursor: 'pointer' } : {}}
                                        onClick={() => {
                                          if (!r.success && r.data) setExpandedRow(expandedRow === i ? null : i)
                                        }}
                                      >
                                        <td>
                                          {!r.success && r.data && (
                                            <span style={{ marginRight: 4, fontSize: 9, color: '#9ca3af' }}>
                                              {expandedRow === i ? '\u25BC' : '\u25B6'}
                                            </span>
                                          )}
                                          {r.row}
                                        </td>
                                        <td>{r.success
                                          ? <span style={{ color: '#059669', fontWeight: 500 }}>Success</span>
                                          : <span style={{ color: '#dc2626', fontWeight: 500 }}>Failed</span>}
                                        </td>
                                        <td style={{ fontFamily: 'monospace', fontSize: 10, color: '#374151' }}>{r.id || '\u2014'}</td>
                                        <td style={{ color: r.success ? '#6b7280' : '#991b1b', whiteSpace: 'normal', maxWidth: 400 }}>
                                          {r.success ? '' : (
                                            <div>
                                              <div>{r.statusCode ? r.statusCode + ': ' : ''}{r.message}</div>
                                              {(() => {
                                                const suggestion = !r.success ? getErrorSuggestion(r.statusCode, r.message) : null
                                                return suggestion ? (
                                                  <div className="error-suggestion">
                                                    <div className="error-suggestion-cause"><strong>Cause:</strong> {suggestion.cause}</div>
                                                    <div className="error-suggestion-fix"><strong>Fix:</strong> {suggestion.fix}</div>
                                                  </div>
                                                ) : null
                                              })()}
                                            </div>
                                          )}
                                        </td>
                                      </tr>
                                      {expandedRow === i && r.data && (
                                        <tr>
                                          <td colSpan={4} style={{ padding: 0 }}>
                                            <div className="error-data-panel">
                                              <div style={{ fontSize: 10, fontWeight: 600, color: '#6b7280', marginBottom: 6 }}>Record Data</div>
                                              <div className="error-data-grid">
                                                {Object.entries(r.data).map(([key, val]) => (
                                                  <div key={key} className="error-data-row">
                                                    <span className="error-data-key">{key}</span>
                                                    <span className="error-data-val">{val === null ? <em style={{ color: '#d1d5db' }}>null</em> : String(val)}</span>
                                                  </div>
                                                ))}
                                              </div>
                                            </div>
                                          </td>
                                        </tr>
                                      )}
                                    </React.Fragment>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}

                        {/* Per-record errors from polling (before full results loaded) */}
                        {recordResults.length === 0 && hasRecordErrors && (
                          <div>
                            <div style={{ fontSize: 11, fontWeight: 600, color: '#991b1b', marginBottom: 4 }}>
                              Errors ({recordErrors.length})
                            </div>
                            <div style={{ maxHeight: 300, overflow: 'auto', border: '1px solid #fecaca', borderRadius: 6 }}>
                              <table className="results-table" style={{ fontSize: 11 }}>
                                <thead>
                                  <tr>
                                    <th style={{ width: 50 }}>Row #</th>
                                    <th style={{ width: 120 }}>Status Code</th>
                                    <th>Error Message</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {recordErrors.map((err, i) => (
                                    <tr key={i}>
                                      <td style={{ color: '#dc2626' }}>{err.row}</td>
                                      <td style={{ fontFamily: 'monospace', fontSize: 10 }}>{err.statusCode}</td>
                                      <td style={{ color: '#991b1b', whiteSpace: 'normal', maxWidth: 300 }}>{err.message}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      {/* Upload Confirmation Modal */}
      {showConfirmModal && (
        <div className="modal-overlay" onClick={() => setShowConfirmModal(false)}>
          <div className="modal" style={{ width: 440 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Confirm Update</h2>
              <button className="btn-close" onClick={() => setShowConfirmModal(false)}>&times;</button>
            </div>
            <div className="modal-body">
              <div style={{ marginBottom: 16 }}>
                <div style={{ fontSize: 13, color: '#374151', marginBottom: 8 }}>
                  You are about to <strong>{operation}</strong> records into:
                </div>
                <div style={{
                  background: '#f9fafb', border: '1px solid #e5e7eb', borderRadius: 8,
                  padding: 12, display: 'flex', flexDirection: 'column', gap: 6,
                }}>
                  <div style={{ fontSize: 13 }}>
                    <span style={{ color: '#6b7280' }}>Salesforce Instance: </span>
                    <strong style={{ color: isProduction ? '#dc2626' : '#059669' }}>
                      {sfConnection?.name || 'Unknown'}
                      {isProduction
                        ? <span style={{ marginLeft: 6, background: '#fef2f2', color: '#dc2626', padding: '1px 8px', borderRadius: 10, fontSize: 11, fontWeight: 600 }}>PRODUCTION</span>
                        : <span style={{ marginLeft: 6, background: '#ecfdf5', color: '#059669', padding: '1px 8px', borderRadius: 10, fontSize: 11, fontWeight: 600 }}>SANDBOX</span>
                      }
                    </strong>
                  </div>
                  <div style={{ fontSize: 13 }}>
                    <span style={{ color: '#6b7280' }}>Target Object: </span>
                    <strong>{selectedObject}</strong>
                  </div>
                  <div style={{ fontSize: 13 }}>
                    <span style={{ color: '#6b7280' }}>Source Table: </span>
                    <strong>{selectedTable}</strong>
                    {previewData?.totalRows != null && (
                      <span style={{ color: '#6b7280', marginLeft: 4 }}>({previewData.totalRows} rows)</span>
                    )}
                  </div>
                  {sfConnection?.loginUrl && (
                    <div style={{ fontSize: 11, color: '#9ca3af', fontFamily: 'monospace' }}>
                      {sfConnection.instanceUrl || sfConnection.loginUrl}
                    </div>
                  )}
                </div>
              </div>

              <div style={{ marginBottom: isProduction ? 12 : 0 }}>
                <div style={{ fontSize: 12, color: '#374151', marginBottom: 6 }}>
                  Type the instance name <strong>"{instanceName}"</strong> to confirm:
                </div>
                <input className="form-input" value={confirmText}
                  onChange={e => setConfirmText(e.target.value)} placeholder={instanceName} autoFocus />
              </div>

              {isProduction && (
                <div style={{
                  background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8,
                  padding: 12, marginTop: 12,
                }}>
                  <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer' }}>
                    <input type="checkbox" checked={prodCheckbox}
                      onChange={e => setProdCheckbox(e.target.checked)}
                      style={{ marginTop: 2, width: 16, height: 16, flexShrink: 0, accentColor: '#dc2626' }} />
                    <span style={{ fontSize: 12, color: '#991b1b' }}>
                      I confirm this is a <strong>production</strong> environment and I understand the records will be modified in the live Salesforce org.
                    </span>
                  </label>
                </div>
              )}
            </div>
            <div style={{ margin: '0 20px 12px', padding: '10px 12px', background: '#f8fafc', borderRadius: 8, border: '1px solid #e2e8f0' }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 12, fontWeight: 500, color: '#374151' }}>
                <input type="checkbox" checked={saveAsStep} onChange={e => { setSaveAsStep(e.target.checked); setStepSaved(false) }} style={{ accentColor: '#10b981' }} />
                Save as reusable step in Orchestrator
              </label>
              {saveAsStep && (
                <input
                  value={saveStepName} onChange={e => setSaveStepName(e.target.value)}
                  placeholder="Step name, e.g. Load Leads"
                  style={{ marginTop: 8, width: '100%', padding: '7px 10px', fontSize: 12, border: '1.5px solid #d1d5db', borderRadius: 6, outline: 'none' }}
                  onFocus={e => e.target.style.borderColor = '#10b981'} onBlur={e => e.target.style.borderColor = '#d1d5db'}
                />
              )}
            </div>
            <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-secondary" onClick={() => setShowConfirmModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleUpload}
                disabled={!isConfirmValid() || (saveAsStep && !saveStepName.trim())}
                style={isProduction || operation === 'delete' ? { background: '#dc2626' } : {}}>
                {operation === 'delete' ? 'Confirm Delete' : isProduction ? 'Execute in Production' : 'Confirm Update'}
              </button>
            </div>
          </div>
        </div>
      )}

      {showDeleteConfirm && (
        <div className="modal-overlay" onClick={() => setShowDeleteConfirm(false)}>
          <div className="modal" style={{ width: 420 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2 style={{ color: '#dc2626' }}>Confirm Delete Operation</h2>
              <button className="btn-close" onClick={() => setShowDeleteConfirm(false)}>&times;</button>
            </div>
            <div className="modal-body">
              <div style={{
                background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8,
                padding: 16, marginBottom: 16,
              }}>
                <div style={{ fontSize: 13, color: '#991b1b', fontWeight: 600, marginBottom: 8 }}>
                  Warning: This operation will permanently delete records from Salesforce.
                </div>
                <div style={{ fontSize: 12, color: '#7f1d1d' }}>
                  Records matching the Id column in your source data will be deleted from <strong>{selectedObject || 'the target object'}</strong>.
                  This action cannot be undone.
                </div>
              </div>
              <div style={{ fontSize: 13, color: '#374151' }}>
                Are you sure you want to select the <strong>Delete</strong> operation?
              </div>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-secondary" onClick={() => setShowDeleteConfirm(false)}>Cancel</button>
              <button className="btn btn-primary" style={{ background: '#dc2626' }}
                onClick={() => { setOperation('delete'); setShowDeleteConfirm(false) }}>
                Yes, Use Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Maximized preview overlay */}
      {previewMaximized && previewData && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 1000,
          background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setPreviewMaximized(false)}>
          <div style={{
            background: '#fff', borderRadius: 12, width: '92vw', height: '88vh',
            display: 'flex', flexDirection: 'column', overflow: 'hidden',
            boxShadow: '0 25px 50px rgba(0,0,0,0.25)',
          }} onClick={e => e.stopPropagation()}>
            <div style={{
              padding: '12px 20px', borderBottom: '1px solid #e5e7eb',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: '#fafbfc', borderRadius: '12px 12px 0 0',
            }}>
              <div>
                <span style={{ fontSize: 14, fontWeight: 600, color: '#1f2937' }}>
                  {selectedTable}
                </span>
                <span style={{ fontSize: 12, color: '#9ca3af', marginLeft: 12 }}>
                  {previewData.totalRows} total rows &middot; {previewData.columns.length} columns
                </span>
              </div>
              <button
                onClick={() => setPreviewMaximized(false)}
                style={{
                  background: 'none', border: 'none', cursor: 'pointer',
                  fontSize: 20, color: '#6b7280', lineHeight: 1, padding: '4px 8px',
                }}
                title="Close"
              >&times;</button>
            </div>
            <div style={{ flex: 1, overflow: 'auto' }}>
              <table className="results-table" style={{ fontSize: 12 }}>
                <thead>
                  <tr>
                    {previewData.columns.map(col => (
                      <th key={col} style={{ position: 'sticky', top: 0, background: '#f9fafb', zIndex: 1 }}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {previewData.rows.map((row, i) => (
                    <tr key={i}>
                      {previewData.columns.map(col => (
                        <td key={col}>{row[col] ?? <span style={{ color: '#d1d5db' }}>null</span>}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

    </div>
  )
}
