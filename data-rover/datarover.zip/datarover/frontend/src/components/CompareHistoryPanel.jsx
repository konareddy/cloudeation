import React, { useState } from 'react'
import ConnectionSelect, { DatabaseSelect } from './ConnectionSelect.jsx'
import { connectionDisplayName } from './ConnectionModal.jsx'

const downloadCSV = async (type, data) => {
  const res = await fetch('/api/compare/export', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  })
  const blob = await res.blob()
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `compare_${type}_${new Date().toISOString().slice(0, 10)}.csv`
  a.click()
  URL.revokeObjectURL(url)
}

export default function CompareHistoryPanel({ history = [], setHistory, sfConnections = [], dbConnections = [] }) {
  const [expandedId, setExpandedId] = useState(null)
  const [importConnId, setImportConnId] = useState('')
  const [importDatabase, setImportDatabase] = useState('')
  const [importTableName, setImportTableName] = useState('')
  const [importDatabases, setImportDatabases] = useState([])
  const [importStatus, setImportStatus] = useState('')
  const [importing, setImporting] = useState(false)

  // Filter out athena/redshift for import
  const importableConnections = dbConnections.filter(c => c.dbType !== 'athena' && c.dbType !== 'redshift')

  const handleDeleteEntry = async (entryId, e) => {
    e.stopPropagation()
    try {
      await fetch(`/api/compare/history/${entryId}`, { method: 'DELETE' })
      setHistory(prev => prev.filter(h => h.id !== entryId))
    } catch (err) {
      console.error('Failed to delete history entry', err)
    }
  }

  const handleClearAll = async () => {
    await fetch('/api/compare/history', { method: 'DELETE' })
    setHistory([])
  }

  const handleToggleExpand = (entry) => {
    if (expandedId === entry.id) {
      setExpandedId(null)
    } else {
      setExpandedId(entry.id)
      setImportConnId('')
      setImportDatabase('')
      setImportDatabases([])
      setImportStatus('')
      const ts = new Date(entry.ranAt).toISOString().replace(/[^0-9]/g, '').slice(0, 14)
      const obj = (entry.sourceObject || 'compare').replace(/[^a-zA-Z0-9_]/g, '_')
      setImportTableName(`compare_missing_${obj}_${ts}`)
    }
  }

  const handleImportConnChange = async (connId) => {
    setImportConnId(connId)
    setImportDatabase('')
    setImportDatabases([])
    if (!connId) return
    try {
      const res = await fetch(`/api/database/${connId}/databases`)
      const data = await res.json()
      if (Array.isArray(data.databases) && data.databases.length > 0) {
        setImportDatabases(data.databases)
      }
    } catch (e) { /* ignore */ }
  }

  const handleImport = async (entry, importType) => {
    if (!importConnId || !importTableName) return
    setImporting(true)
    setImportStatus('')
    try {
      const payload = {
        connId: importConnId,
        database: importDatabase || undefined,
        tableName: importTableName,
        type: importType,
      }
      if (importType === 'differences') {
        payload.differences = entry._differences || []
      } else {
        payload.keys = entry._missingKeys || []
      }
      const res = await fetch('/api/compare/import-to-db', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (data.success) {
        setImportStatus(`Imported ${data.rowCount} rows into ${importTableName}`)
      } else {
        setImportStatus(`Error: ${data.error}`)
      }
    } catch (e) {
      setImportStatus(`Error: ${e.message}`)
    } finally {
      setImporting(false)
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      {/* Top bar */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <span style={{ fontWeight: 700, fontSize: 15 }}>Comparison History</span>
        {history.length > 0 && (
          <button
            onClick={handleClearAll}
            style={{
              fontSize: 11, color: '#ef4444', background: 'none', border: '1px solid #fecaca',
              borderRadius: 5, padding: '4px 12px', cursor: 'pointer',
            }}
          >Clear All</button>
        )}
      </div>

      {history.length === 0 && (
        <div style={{ textAlign: 'center', color: '#9ca3af', padding: 40, fontSize: 13 }}>
          No comparison history yet. Run a comparison to see results here.
        </div>
      )}

      {history.length > 0 && (
        <div style={{ background: '#fff', borderRadius: 10, border: '1px solid #e5e7eb', overflow: 'hidden' }}>
          <div style={{ maxHeight: 600, overflowY: 'auto' }}>
            <table style={{ width: '100%', fontSize: 11, borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: '#f9fafb', position: 'sticky', top: 0, zIndex: 1 }}>
                  <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600 }}>Date/Time</th>
                  <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600 }}>Type</th>
                  <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600 }}>Source</th>
                  <th style={{ textAlign: 'left', padding: '6px 8px', fontWeight: 600 }}>Destination</th>
                  <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600 }}>Src Count</th>
                  <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600 }}>Dest Count</th>
                  <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600 }}>Matched</th>
                  <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600 }}>Missing in Dest</th>
                  <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600 }}>Missing in Src</th>
                  <th style={{ textAlign: 'right', padding: '6px 8px', fontWeight: 600 }}>Duration</th>
                  <th style={{ textAlign: 'center', padding: '6px 8px', fontWeight: 600 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {history.map(h => {
                  const dt = new Date(h.ranAt)
                  const dateStr = dt.toLocaleDateString() + ' ' + dt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                  const missingInDest = h.type === 'counts' ? (h.missingInDest || 0) : (h.sourceOnly || 0)
                  const missingInSrc = h.type === 'counts' ? (h.missingInSource || 0) : (h.destOnly || 0)
                  const isExpanded = expandedId === h.id

                  return (
                    <React.Fragment key={h.id}>
                      <tr
                        onClick={() => handleToggleExpand(h)}
                        style={{
                          borderBottom: '1px solid #f3f4f6', cursor: 'pointer',
                          background: isExpanded ? '#f0f9ff' : 'transparent',
                        }}
                        onMouseEnter={e => { if (!isExpanded) e.currentTarget.style.background = '#f9fafb' }}
                        onMouseLeave={e => { if (!isExpanded) e.currentTarget.style.background = 'transparent' }}
                      >
                        <td style={{ padding: '5px 8px', whiteSpace: 'nowrap' }}>{dateStr}</td>
                        <td style={{ padding: '5px 8px' }}>
                          <span style={{
                            padding: '1px 8px', borderRadius: 3, fontSize: 10, fontWeight: 600,
                            background: h.type === 'counts' ? '#f5f3ff' : '#eff6ff',
                            color: h.type === 'counts' ? '#7c3aed' : '#2563eb',
                          }}>{h.type === 'counts' ? 'Counts' : 'Fields'}</span>
                        </td>
                        <td style={{ padding: '5px 8px' }}>
                          <div style={{ fontWeight: 500 }}>{h.sourceObject}</div>
                          {h.sourceDatabase && <div style={{ fontSize: 10, color: '#6b7280' }}>db: {h.sourceDatabase}</div>}
                        </td>
                        <td style={{ padding: '5px 8px' }}>
                          <div style={{ fontWeight: 500 }}>{h.destObject}</div>
                          {h.destDatabase && <div style={{ fontSize: 10, color: '#6b7280' }}>db: {h.destDatabase}</div>}
                        </td>
                        <td style={{ padding: '5px 8px', textAlign: 'right' }}>{(h.sourceCount ?? h.totalSource ?? 0).toLocaleString()}</td>
                        <td style={{ padding: '5px 8px', textAlign: 'right' }}>{(h.destCount ?? h.totalDest ?? 0).toLocaleString()}</td>
                        <td style={{ padding: '5px 8px', textAlign: 'right', color: '#10b981' }}>{(h.matched || 0).toLocaleString()}</td>
                        <td style={{ padding: '5px 8px', textAlign: 'right', color: missingInDest > 0 ? '#ef4444' : '#10b981', fontWeight: missingInDest > 0 ? 600 : 400 }}>
                          {missingInDest.toLocaleString()}
                        </td>
                        <td style={{ padding: '5px 8px', textAlign: 'right', color: missingInSrc > 0 ? '#f59e0b' : '#10b981', fontWeight: missingInSrc > 0 ? 600 : 400 }}>
                          {missingInSrc.toLocaleString()}
                        </td>
                        <td style={{ padding: '5px 8px', textAlign: 'right', color: '#6b7280' }}>{h.elapsedSeconds}s</td>
                        <td style={{ padding: '5px 8px', textAlign: 'center' }}>
                          <button
                            onClick={(e) => handleDeleteEntry(h.id, e)}
                            title="Delete"
                            style={{
                              background: 'none', border: 'none', cursor: 'pointer', padding: '2px 6px',
                              color: '#9ca3af', fontSize: 14,
                            }}
                            onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
                            onMouseLeave={e => e.currentTarget.style.color = '#9ca3af'}
                          >
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <polyline points="3 6 5 6 21 6" />
                              <path d="M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2" />
                            </svg>
                          </button>
                        </td>
                      </tr>

                      {/* Expanded detail */}
                      {isExpanded && (
                        <tr>
                          <td colSpan={11} style={{ padding: 0 }}>
                            <div style={{ padding: '14px 16px', background: '#f8fafc', borderTop: '1px solid #e5e7eb', borderBottom: '1px solid #e5e7eb' }}>
                              {/* Summary cards */}
                              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8, marginBottom: 14 }}>
                                {[
                                  { label: 'Source Records', value: h.sourceCount ?? h.totalSource ?? 0, color: '#0d9488', bg: '#f0fdfa' },
                                  { label: 'Dest Records', value: h.destCount ?? h.totalDest ?? 0, color: '#7c3aed', bg: '#f5f3ff' },
                                  { label: 'Matched', value: h.matched || 0, color: '#10b981', bg: '#ecfdf5' },
                                  { label: 'Missing in Dest', value: missingInDest, color: '#ef4444', bg: '#fef2f2' },
                                  { label: 'Missing in Source', value: missingInSrc, color: '#f59e0b', bg: '#fffbeb' },
                                ].map(c => (
                                  <div key={c.label} style={{
                                    background: c.bg, borderRadius: 8, padding: '8px 10px', textAlign: 'center',
                                    border: `1px solid ${c.color}22`,
                                  }}>
                                    <div style={{ fontSize: 18, fontWeight: 700, color: c.color }}>{c.value.toLocaleString()}</div>
                                    <div style={{ fontSize: 10, color: c.color, fontWeight: 500 }}>{c.label}</div>
                                  </div>
                                ))}
                              </div>

                              {/* Export buttons */}
                              <div style={{ display: 'flex', gap: 8, marginBottom: 14, flexWrap: 'wrap' }}>
                                <button
                                  onClick={() => downloadCSV('missingInDest', { type: 'missingInDest', keys: h._missingInDestKeys || [] })}
                                  disabled={!h._missingInDestKeys || h._missingInDestKeys.length === 0}
                                  className="btn"
                                  style={{
                                    fontSize: 11, padding: '5px 14px', display: 'flex', alignItems: 'center', gap: 4,
                                    opacity: (!h._missingInDestKeys || h._missingInDestKeys.length === 0) ? 0.4 : 1,
                                  }}
                                >
                                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                  Export Missing Keys (CSV)
                                </button>
                                {h.type === 'fields' && (
                                  <button
                                    onClick={() => downloadCSV('differences', { type: 'differences', differences: h._differences || [] })}
                                    disabled={!h._differences || h._differences.length === 0}
                                    className="btn"
                                    style={{
                                      fontSize: 11, padding: '5px 14px', display: 'flex', alignItems: 'center', gap: 4,
                                      opacity: (!h._differences || h._differences.length === 0) ? 0.4 : 1,
                                    }}
                                  >
                                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                    Export Differences (CSV)
                                  </button>
                                )}
                              </div>

                              {/* Import to DB section */}
                              <div style={{ background: '#fff', borderRadius: 8, padding: 12, border: '1px solid #e5e7eb' }}>
                                <div style={{ fontWeight: 600, fontSize: 12, marginBottom: 8 }}>Import to Database</div>
                                <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
                                  <div style={{ minWidth: 180 }}>
                                    <label style={{ fontSize: 10, fontWeight: 500, color: '#6b7280', display: 'block', marginBottom: 2 }}>Connection</label>
                                    <ConnectionSelect
                                      connections={importableConnections}
                                      value={importConnId}
                                      onChange={handleImportConnChange}
                                      placeholder="Select DB..."
                                    />
                                  </div>
                                  {importDatabases.length > 0 && (
                                    <div style={{ minWidth: 140 }}>
                                      <label style={{ fontSize: 10, fontWeight: 500, color: '#6b7280', display: 'block', marginBottom: 2 }}>Database</label>
                                      <DatabaseSelect
                                        databases={importDatabases}
                                        value={importDatabase}
                                        onChange={setImportDatabase}
                                        placeholder="Select database..."
                                      />
                                    </div>
                                  )}
                                  <div style={{ minWidth: 200 }}>
                                    <label style={{ fontSize: 10, fontWeight: 500, color: '#6b7280', display: 'block', marginBottom: 2 }}>Table Name</label>
                                    <input
                                      value={importTableName}
                                      onChange={e => setImportTableName(e.target.value)}
                                      style={{ width: '100%', padding: '5px 8px', borderRadius: 5, border: '1px solid #d1d5db', fontSize: 12 }}
                                    />
                                  </div>
                                  <button
                                    onClick={() => handleImport(h, 'missingKeys')}
                                    disabled={!importConnId || !importTableName || importing}
                                    className="btn"
                                    style={{
                                      fontSize: 11, padding: '5px 14px', whiteSpace: 'nowrap',
                                      opacity: (!importConnId || !importTableName || importing) ? 0.5 : 1,
                                    }}
                                  >Import Missing Keys</button>
                                  {h.type === 'fields' && (
                                    <button
                                      onClick={() => handleImport(h, 'differences')}
                                      disabled={!importConnId || !importTableName || importing}
                                      className="btn"
                                      style={{
                                        fontSize: 11, padding: '5px 14px', whiteSpace: 'nowrap',
                                        opacity: (!importConnId || !importTableName || importing) ? 0.5 : 1,
                                      }}
                                    >Import Differences</button>
                                  )}
                                </div>
                                {importStatus && (
                                  <div style={{
                                    marginTop: 8, fontSize: 11, padding: '4px 8px', borderRadius: 4,
                                    background: importStatus.startsWith('Error') ? '#fef2f2' : '#ecfdf5',
                                    color: importStatus.startsWith('Error') ? '#ef4444' : '#10b981',
                                  }}>{importStatus}</div>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}
