import React, { useState, useEffect, useCallback, useRef, forwardRef, useImperativeHandle } from 'react'

function SandboxSeedingPanel({ sfConnections = [] }, ref) {
  // Separate abort controllers: objects list vs sample/describe fetches
  const objectsAbortRef = useRef(null)
  const sampleAbortRef = useRef(null)
  // Connection
  const [connId, setConnId] = useState('')
  const [destConnId, setDestConnId] = useState('')
  const [mappingTable, setMappingTable] = useState('')
  // Objects list
  const [objects, setObjects] = useState([])
  const [objectsLoading, setObjectsLoading] = useState(false)
  const [objectSearch, setObjectSearch] = useState(null)
  const [showObjectDropdown, setShowObjectDropdown] = useState(false)
  // Selected object
  const [selectedObj, setSelectedObj] = useState(null)
  // Sample records for selected object
  const [sampleRows, setSampleRows] = useState([])
  const [sampleCols, setSampleCols] = useState([])
  const [sampleLoading, setSampleLoading] = useState(false)
  // Lookup fields for selected object
  const [lookupFields, setLookupFields] = useState([])
  const [lookupCounts, setLookupCounts] = useState({})
  const [lookupCountsLoading, setLookupCountsLoading] = useState(false)
  // Selected lookups
  const [selectedLookups, setSelectedLookups] = useState({})
  // Filter / WHERE clause
  const [whereClause, setWhereClause] = useState('')
  const [sampleSize, setSampleSize] = useState(10)
  const [recordLoadOptions, setRecordLoadOptions] = useState([10, 25, 50, 100, 200, 500, 1000, 2000])
  // All fields from describe (for filter field picker)
  const [allFields, setAllFields] = useState([])
  // User-selected display fields (field names chosen via field picker)
  const [selectedFields, setSelectedFields] = useState([])
  const [requiredFields, setRequiredFields] = useState(new Set())
  // Field picker modal
  const [showFieldPicker, setShowFieldPicker] = useState(false)
  const [fieldPickerSearch, setFieldPickerSearch] = useState('')
  const [fieldPickerSelectedSearch, setFieldPickerSelectedSearch] = useState('')
  // Templates
  const [templates, setTemplates] = useState([])
  const [activeTemplateId, setActiveTemplateId] = useState(null)
  const [showSaveTemplate, setShowSaveTemplate] = useState(false)
  const [templateName, setTemplateName] = useState('')
  const [templateSaveStatus, setTemplateSaveStatus] = useState('') // '' | 'saving' | 'saved' | 'error'
  // Lookup preview data
  const [lookupPreviews, setLookupPreviews] = useState({})
  const [lookupPreviewLoading, setLookupPreviewLoading] = useState({})
  // Dependency object fields & selections: keyed by parent field name
  const [depAllFields, setDepAllFields] = useState({})       // { fieldName: [field descriptors] }
  const [depSelectedFields, setDepSelectedFields] = useState({}) // { fieldName: [field names] }
  const [depRequiredFields, setDepRequiredFields] = useState({}) // { fieldName: Set([required field names]) }
  // Field picker for dependency objects
  const [showDepFieldPicker, setShowDepFieldPicker] = useState(null) // field name or null
  const [depFieldPickerSearch, setDepFieldPickerSearch] = useState('')
  const [depFieldPickerSelectedSearch, setDepFieldPickerSelectedSearch] = useState('')

  // Data masking state
  const [maskingRules, setMaskingRules] = useState({}) // { fieldName: { technique, options } }
  const [showMaskingPanel, setShowMaskingPanel] = useState(false)
  const [maskingSearch, setMaskingSearch] = useState('')
  const [maskingFilter, setMaskingFilter] = useState('all') // 'all' | 'masked' | 'unmasked'

  // Dependencies panel
  const [showDepsPanel, setShowDepsPanel] = useState(false)
  const [depsSearch, setDepsSearch] = useState('')
  const [depsFilter, setDepsFilter] = useState('all')
  // Nested deps panel for dependency objects (value = parent field name like 'AccountId')
  const [showDepDepsPanel, setShowDepDepsPanel] = useState(null)

  // Pagination
  const [currentPage, setCurrentPage] = useState(1)
  const [depCurrentPage, setDepCurrentPage] = useState({}) // { fieldName: page }
  const PAGE_SIZE = 50
  // Reset page when rows change
  useEffect(() => { setCurrentPage(1) }, [sampleRows])

  // Dirty tracking — snapshot of last saved/loaded state
  const cleanSnapshotRef = useRef(null)
  const makeSnapshot = () => JSON.stringify({
    connId, destConnId, selectedObj, whereClause, sampleSize,
    selectedFields, selectedLookups: Object.keys(selectedLookups).sort(),
    depSelectedFields, maskingRules,
  })
  const currentSnapshot = makeSnapshot()
  const isDirty = !!(activeTemplateId && cleanSnapshotRef.current !== null && cleanSnapshotRef.current !== currentSnapshot)

  // Update snapshot after save succeeds
  useEffect(() => {
    if (templateSaveStatus === 'saved') {
      cleanSnapshotRef.current = makeSnapshot()
    }
  }, [templateSaveStatus])

  // Set snapshot after template load completes (loading finishes)
  const pendingSnapshotRef = useRef(false)
  useEffect(() => {
    if (pendingSnapshotRef.current && !sampleLoading && activeTemplateId) {
      // Delay one tick so state is fully settled
      setTimeout(() => { cleanSnapshotRef.current = makeSnapshot() }, 0)
      pendingSnapshotRef.current = false
    }
  }, [sampleLoading, activeTemplateId])

  // Unsaved changes modal
  const [unsavedModal, setUnsavedModal] = useState(null) // { action: fn, save: fn }
  const pendingActionRef = useRef(null)

  const guardUnsaved = (action) => {
    if (!isDirty) { action(); return }
    pendingActionRef.current = action
    setUnsavedModal(true)
  }
  const handleUnsavedDiscard = () => {
    const action = pendingActionRef.current
    pendingActionRef.current = null
    cleanSnapshotRef.current = null
    setUnsavedModal(null)
    if (action) action()
  }
  const handleUnsavedSave = () => {
    saveTemplate()
    const action = pendingActionRef.current
    pendingActionRef.current = null
    setUnsavedModal(null)
    // Execute after a tick so save state updates
    if (action) setTimeout(action, 100)
  }
  const handleUnsavedCancel = () => {
    pendingActionRef.current = null
    setUnsavedModal(null)
  }

  // Expose dirty state + guard to parent via ref
  useImperativeHandle(ref, () => ({
    isDirty: () => !!(activeTemplateId && cleanSnapshotRef.current !== null && cleanSnapshotRef.current !== makeSnapshot()),
    guardUnsaved,
  }))

  // Browser beforeunload warning
  useEffect(() => {
    if (!isDirty) return
    const handler = (e) => { e.preventDefault(); e.returnValue = '' }
    window.addEventListener('beforeunload', handler)
    return () => window.removeEventListener('beforeunload', handler)
  }, [isDirty])

  // Seeding state: tracks push status per object (main + deps)
  const [seedingStatus, setSeedingStatus] = useState({})  // { objectName: { loading, inserted, updated, errors, done } }

  // Loading overlay message
  const [loadingMessage, setLoadingMessage] = useState(null) // null = hidden, string = message

  const cancelLoading = useCallback(() => {
    if (objectsAbortRef.current) { objectsAbortRef.current.abort(); objectsAbortRef.current = null }
    if (sampleAbortRef.current) { sampleAbortRef.current.abort(); sampleAbortRef.current = null }
    setLoadingMessage(null)
    setObjectsLoading(false)
    setSampleLoading(false)
  }, [])

  // Fields to exclude from field lists
  const EXCLUDED_FIELDS = new Set()
  // System reference fields — never show as dependencies
  const SYSTEM_REF_FIELDS = new Set([
    'OwnerId', 'CreatedById', 'LastModifiedById', 'ProfileId',
    'UserRoleId', 'DelegatedApproverId', 'ManagerId', 'RecordTypeId',
  ])

  const sourceConns = sfConnections.filter(c => {
    const u = c.usage || []
    return u.includes('source') || u.includes('extract') || u.length === 0
  })
  const destConns = sfConnections.filter(c => {
    const u = c.usage || []
    return u.includes('target') || u.includes('load') || u.length === 0
  })

  // Load record load options from seed settings
  useEffect(() => {
    fetch('/api/seed/settings')
      .then(r => r.json())
      .then(data => {
        if (data.recordLoadOptions && Array.isArray(data.recordLoadOptions) && data.recordLoadOptions.length > 0) {
          setRecordLoadOptions(data.recordLoadOptions.sort((a, b) => a - b))
        }
      })
      .catch(() => {})
  }, [])

  // Create mapping table when both source and dest orgs are selected
  useEffect(() => {
    if (!connId || !destConnId) { setMappingTable(''); return }
    const srcConn = sfConnections.find(c => c.id === connId)
    const dstConn = sfConnections.find(c => c.id === destConnId)
    if (!srcConn || !dstConn) return
    const srcName = (srcConn.name || 'source').replace(/\s+/g, '_')
    const dstName = (dstConn.name || 'dest').replace(/\s+/g, '_')
    fetch('/api/seed/mapping-table', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sourceName: srcName, destName: dstName }),
    })
      .then(r => r.json())
      .then(data => { if (data.table) setMappingTable(data.table) })
      .catch(() => {})
  }, [connId, destConnId, sfConnections])

  // Load templates on mount
  useEffect(() => {
    fetch('/api/seed/templates').then(r => r.json()).then(data => {
      setTemplates(Array.isArray(data) ? data : [])
    }).catch(() => {})
  }, [])

  // Save current selections as template (quick save uses existing name)
  const saveTemplate = useCallback(() => {
    const name = templateName.trim() || (activeTemplateId ? (templates.find(t => t.id === activeTemplateId)?.name || '') : '')
    if (!name || !selectedObj) return
    setTemplateSaveStatus('saving')
    const tpl = {
      id: activeTemplateId || undefined,
      name,
      connId,
      destConnId,
      selectedObj,
      whereClause,
      sampleSize,
      selectedFields,
      depSelectedFields: { ...depSelectedFields },
      selectedLookups: Object.entries(selectedLookups).reduce((acc, [k, v]) => {
        acc[k] = { name: v.name, label: v.label, referenceTo: v.referenceTo, relationshipName: v.relationshipName }
        return acc
      }, {}),
    }
    fetch('/api/seed/templates', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tpl),
    })
      .then(r => r.json())
      .then(saved => {
        setTemplates(prev => {
          const idx = prev.findIndex(t => t.id === saved.id)
          if (idx >= 0) { const n = [...prev]; n[idx] = saved; return n }
          return [...prev, saved]
        })
        setActiveTemplateId(saved.id)
        setShowSaveTemplate(false)
        setTemplateName('')
        setTemplateSaveStatus('saved')
        setTimeout(() => setTemplateSaveStatus(''), 2500)
      })
      .catch(() => { setTemplateSaveStatus('error'); setTimeout(() => setTemplateSaveStatus(''), 2500) })
  }, [templateName, activeTemplateId, connId, destConnId, selectedObj, whereClause, sampleSize, selectedLookups, selectedFields, depSelectedFields, templates])

  // Load a template — restore all selections
  const loadTemplate = useCallback((tpl) => {
    pendingSnapshotRef.current = true
    setActiveTemplateId(tpl.id)
    setDestConnId(tpl.destConnId || '')
    setWhereClause(tpl.whereClause || '')
    setSampleSize(tpl.sampleSize || 10)
    // Set connection first, object selection happens after objects load
    if (tpl.connId && tpl.connId !== connId) {
      setConnId(tpl.connId)
      // Wait for objects to load, then select the object
      const waitAndSelect = () => {
        // We store the pending template to apply after objects load
        setPendingTemplate(tpl)
      }
      waitAndSelect()
    } else if (tpl.selectedObj) {
      applyTemplateObject(tpl)
    }
  }, [connId])

  const [pendingTemplate, setPendingTemplate] = useState(null)

  // When objects finish loading, apply pending template
  useEffect(() => {
    if (pendingTemplate && objects.length > 0 && !objectsLoading) {
      applyTemplateObject(pendingTemplate)
      setPendingTemplate(null)
    }
  }, [objects, objectsLoading, pendingTemplate])

  // Apply template object selection + lookups
  const applyTemplateObject = useCallback((tpl) => {
    if (!tpl.selectedObj || !tpl.connId) return
    const cid = tpl.connId
    setSelectedObj(tpl.selectedObj)
    setSampleRows([])
    setSampleCols([])
    setLookupFields([])
    setLookupCounts({})
    setLookupPreviews({})
    setWhereClause(tpl.whereClause || '')
    setSampleSize(tpl.sampleSize || 10)
    const restoredFields = tpl.selectedFields || []
    setSelectedFields(restoredFields)
    setMaskingRules(tpl.maskingRules || {})
    if (tpl.depSelectedFields) {
      setDepSelectedFields(tpl.depSelectedFields)
    }

    if (sampleAbortRef.current) sampleAbortRef.current.abort()
    const ctrl = new AbortController()
    sampleAbortRef.current = ctrl
    setSampleLoading(true)
    setLoadingMessage(`Loading ${tpl.selectedObj} template...`)
    fetch(`/api/salesforce/${cid}/describe/${tpl.selectedObj}`, { signal: ctrl.signal })
      .then(r => r.json())
      .then(data => {
        const fields = data.fields || []
        setAllFields(fields)
        // Set required fields from describe
        const required = fields
          .filter(f => !f.nillable && !f.defaultedOnCreate && f.createable && !EXCLUDED_FIELDS.has(f.name))
          .map(f => f.name)
        setRequiredFields(new Set(required))
        const refs = fields.filter(f =>
          f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0 &&
          !SYSTEM_REF_FIELDS.has(f.name)
        ).map(f => ({
          name: f.name, label: f.label,
          referenceTo: f.referenceTo, relationshipName: f.relationshipName,
        }))
        setLookupFields(refs)

        // Restore selected lookups from template
        const savedLookups = tpl.selectedLookups || {}
        const restored = {}
        for (const [fname, fdata] of Object.entries(savedLookups)) {
          const match = refs.find(r => r.name === fname) || fdata
          if (match) restored[fname] = match
        }
        setSelectedLookups(restored)

        setLoadingMessage(`Fetching ${tpl.selectedObj} sample records...`)
        // Build sample query with restored fields + lookups
        const displayFields = restoredFields.length > 0
          ? restoredFields
          : fields.filter(f => ['Name', 'FirstName', 'LastName', 'Subject', 'Title', 'CaseNumber'].includes(f.name)).map(f => f.name)
        const selectedNames = Object.keys(restored)
        const selectFields = ['Id', ...displayFields, ...selectedNames]
        const unique = [...new Set(selectFields)].slice(0, 50)
        const tplClause = (tpl.whereClause || '').trim()
        const tplStartsKw = /^(ORDER\s+BY|GROUP\s+BY|HAVING|LIMIT)\s/i.test(tplClause)
        const whereStr = tplClause ? (tplStartsKw ? ` ${tplClause}` : ` WHERE ${tplClause}`) : ''
        const limit = tpl.sampleSize || 10
        return fetch(`/api/salesforce/${cid}/soql`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ soql: `SELECT ${unique.join(', ')} FROM ${tpl.selectedObj}${whereStr}${/\bLIMIT\s+\d+/i.test(whereStr) ? '' : ` LIMIT ${limit}`}` }),
          signal: ctrl.signal,
        }).then(r => r.json()).then(sData => {
          if (!sData.error) {
            setSampleCols(sData.columns || [])
            setSampleRows(sData.rows || [])
          }
        })
      })
      .catch(e => { if (e.name === 'AbortError') return })
      .finally(() => { setSampleLoading(false); setLoadingMessage(null); sampleAbortRef.current = null })
  }, [])

  // Delete a template
  const deleteTemplate = useCallback((id) => {
    fetch(`/api/seed/templates/${id}`, { method: 'DELETE' })
      .then(() => {
        setTemplates(prev => prev.filter(t => t.id !== id))
        if (activeTemplateId === id) setActiveTemplateId(null)
      })
      .catch(() => {})
  }, [activeTemplateId])

  // Load objects when connection changes
  useEffect(() => {
    if (!connId) { setObjects([]); return }
    if (objectsAbortRef.current) objectsAbortRef.current.abort()
    const ctrl = new AbortController()
    objectsAbortRef.current = ctrl
    setObjectsLoading(true)
    setLoadingMessage('Loading objects...')
    setSelectedObj(null)
    setSampleRows([])
    setSampleCols([])
    setLookupFields([])
    setSelectedLookups({})
    setLookupPreviews({})
    fetch(`/api/salesforce/${connId}/objects`, { signal: ctrl.signal })
      .then(r => r.json())
      .then(data => {
        if (Array.isArray(data)) {
          setObjects(data.sort((a, b) => (a.label || a.name).localeCompare(b.label || b.name)))
        } else {
          setObjects([])
        }
      })
      .catch(e => { if (e.name !== 'AbortError') setObjects([]) })
      .finally(() => { setObjectsLoading(false); if (!sampleAbortRef.current) setLoadingMessage(null); objectsAbortRef.current = null })
  }, [connId])

  // Load sample records — includes user-selected fields + selected lookup fields
  const loadSampleRecords = useCallback((objName, selected, where, limit) => {
    if (!objName || !connId) return
    if (sampleAbortRef.current) sampleAbortRef.current.abort()
    const ctrl = new AbortController()
    sampleAbortRef.current = ctrl
    setSampleLoading(true)
    setLoadingMessage(`Querying ${objName} records...`)
    setSeedingStatus({})
    const displayFields = selectedFields.length > 0
      ? selectedFields
      : (allFields.length > 0
        ? allFields.filter(f => ['Name', 'FirstName', 'LastName', 'Subject', 'Title', 'CaseNumber'].includes(f.name)).map(f => f.name)
        : ['Name'])
    const selectedNames = Object.keys(selected || selectedLookups)
    const selectFields = ['Id', ...displayFields, ...selectedNames]
    const unique = [...new Set(selectFields)].slice(0, 50)
    const clauseStr = where?.trim() || ''
    const startsWithKeyword = /^(ORDER\s+BY|GROUP\s+BY|HAVING|LIMIT)\s/i.test(clauseStr)
    const whereStr = clauseStr ? (startsWithKeyword ? ` ${clauseStr}` : ` WHERE ${clauseStr}`) : ''
    const hasLimit = /\bLIMIT\s+\d+/i.test(whereStr)
    const soql = `SELECT ${unique.join(', ')} FROM ${objName}${whereStr}${hasLimit ? '' : ` LIMIT ${limit || sampleSize}`}`
    fetch(`/api/salesforce/${connId}/soql`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ soql }),
      signal: ctrl.signal,
    })
      .then(r => r.json())
      .then(data => {
        if (!data.error) {
          setSampleCols(data.columns || [])
          setSampleRows(data.rows || [])
        } else {
          setSampleCols([])
          setSampleRows([])
        }
      })
      .catch(e => { if (e.name === 'AbortError') return })
      .finally(() => { setSampleLoading(false); setLoadingMessage(null); sampleAbortRef.current = null })
  }, [connId, allFields, selectedLookups, selectedFields, sampleSize])

  // Fetch count for a single lookup field
  const fetchSingleCount = useCallback((fieldName) => {
    if (!selectedObj || !connId) return
    setLookupCounts(prev => ({ ...prev, [fieldName]: 'loading' }))
    fetch(`/api/salesforce/${connId}/fieldcounts/${selectedObj}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields: [fieldName] }),
    })
      .then(r => r.json())
      .then(d => {
        setLookupCounts(prev => ({ ...prev, ...d.counts }))
      })
      .catch(() => setLookupCounts(prev => ({ ...prev, [fieldName]: '?' })))
  }, [connId, selectedObj])

  // Fetch counts for ALL lookup fields
  const fetchAllCounts = useCallback(() => {
    if (!selectedObj || !connId || lookupFields.length === 0) return
    setLookupCountsLoading(true)
    const fieldNames = lookupFields.map(f => f.name)
    // Mark all as loading
    setLookupCounts(prev => {
      const next = { ...prev }
      fieldNames.forEach(fn => { next[fn] = 'loading' })
      return next
    })
    fetch(`/api/salesforce/${connId}/fieldcounts/${selectedObj}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fields: fieldNames }),
    })
      .then(r => r.json())
      .then(d => setLookupCounts(prev => ({ ...prev, ...d.counts })))
      .catch(() => {})
      .finally(() => setLookupCountsLoading(false))
  }, [connId, selectedObj, lookupFields])

  // When an object is selected, fetch describe + lookup fields + initial sample
  const handleSelectObject = useCallback((objName) => {
    if (selectedObj === objName) return
    setSelectedObj(objName)
    setSampleRows([])
    setSampleCols([])
    setLookupFields([])
    setLookupCounts({})
    setSelectedLookups({})
    setLookupPreviews({})
    setWhereClause('')
    setAllFields([])
    setSelectedFields([])
    setDepAllFields({})
    setDepSelectedFields({})
    setSeedingStatus({})
    setDepRequiredFields({})
    if (!objName || !connId) return

    if (sampleAbortRef.current) sampleAbortRef.current.abort()
    const ctrl = new AbortController()
    sampleAbortRef.current = ctrl
    setSampleLoading(true)
    setLoadingMessage(`Loading ${objName} fields...`)
    fetch(`/api/salesforce/${connId}/describe/${objName}`, { signal: ctrl.signal })
      .then(r => r.json())
      .then(data => {
        const fields = data.fields || []
        setAllFields(fields)

        // Auto-select required fields
        const required = fields
          .filter(f => !f.nillable && !f.defaultedOnCreate && f.createable && !EXCLUDED_FIELDS.has(f.name))
          .map(f => f.name)
        setRequiredFields(new Set(required))
        // Default: select all non-reference fields
        const nonRefFields = fields
          .filter(f => !EXCLUDED_FIELDS.has(f.name) && f.type !== 'reference')
          .map(f => f.name)
          .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))
        setSelectedFields(nonRefFields)

        const refs = fields.filter(f =>
          f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0 &&
          !SYSTEM_REF_FIELDS.has(f.name)
        ).map(f => ({
          name: f.name,
          label: f.label,
          referenceTo: f.referenceTo,
          relationshipName: f.relationshipName,
        }))
        setLookupFields(refs)

        setLoadingMessage(`Fetching ${objName} sample records...`)
        // Build initial sample query with required fields
        const selectFields = ['Id', ...required]
        const unique = [...new Set(selectFields)].slice(0, 50)
        return fetch(`/api/salesforce/${connId}/soql`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ soql: `SELECT ${unique.join(', ')} FROM ${objName} LIMIT 10` }),
          signal: ctrl.signal,
        }).then(r => r.json()).then(sData => {
          if (!sData.error) {
            setSampleCols(sData.columns || [])
            setSampleRows(sData.rows || [])
          }
        })
      })
      .catch(e => { if (e.name === 'AbortError') return })
      .finally(() => { setSampleLoading(false); setLoadingMessage(null); sampleAbortRef.current = null })
  }, [connId, selectedObj])

  // Toggle a lookup field — refresh sample + load target preview
  const toggleLookup = useCallback((field) => {
    setSelectedLookups(prev => {
      const next = { ...prev }
      if (next[field.name]) {
        delete next[field.name]
        setLookupPreviews(p => { const n = { ...p }; delete n[field.name]; return n })
        // Remove from selectedFields
        setSelectedFields(sf => sf.filter(f => f !== field.name))
      } else {
        next[field.name] = field
        // Add to selectedFields if not already there
        setSelectedFields(sf => sf.includes(field.name) ? sf : [...sf, field.name].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })))
        // Load preview for target object
        const targetObj = field.referenceTo[0]
        setLookupPreviewLoading(p => ({ ...p, [field.name]: true }))
        fetch(`/api/salesforce/${connId}/soql`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ soql: `SELECT Id, Name FROM ${targetObj} LIMIT 10` }),
        })
          .then(r => r.json())
          .then(data => {
            if (data.error) {
              return fetch(`/api/salesforce/${connId}/soql`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ soql: `SELECT Id FROM ${targetObj} LIMIT 10` }),
              }).then(r => r.json())
            }
            return data
          })
          .then(data => {
            setLookupPreviews(p => ({
              ...p,
              [field.name]: { targetObj, cols: data.columns || [], rows: data.rows || [] }
            }))
          })
          .catch(() => {})
          .finally(() => setLookupPreviewLoading(p => ({ ...p, [field.name]: false })))
      }
      // Refresh sample records with updated selection
      setTimeout(() => loadSampleRecords(selectedObj, next, whereClause, sampleSize), 0)
      return next
    })
  }, [connId, selectedObj, whereClause, sampleSize, loadSampleRecords])

  // Auto-load dependency describes when selected reference fields change
  useEffect(() => {
    if (!connId || !selectedObj || allFields.length === 0) return
    const refFields = selectedFields
      .map(fname => allFields.find(f => f.name === fname))
      .filter(f => f && f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0 && !EXCLUDED_FIELDS.has(f.name) && !SYSTEM_REF_FIELDS.has(f.name))
    // Load describe for newly selected ref fields
    refFields.forEach(field => {
      const targetObj = field.referenceTo[0]
      if (!depAllFields[field.name]) {
        fetch(`/api/salesforce/${connId}/describe/${targetObj}`)
          .then(r => r.json())
          .then(data => {
            const fields = data.fields || []
            setDepAllFields(p => ({ ...p, [field.name]: fields }))
            const req = fields
              .filter(f => !f.nillable && !f.defaultedOnCreate && f.createable && !EXCLUDED_FIELDS.has(f.name))
              .map(f => f.name)
            setDepRequiredFields(p => ({ ...p, [field.name]: new Set(req) }))
            if (!depSelectedFields[field.name]) {
              const nonRef = fields
                .filter(f => !EXCLUDED_FIELDS.has(f.name) && f.type !== 'reference')
                .map(f => f.name)
                .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))
              setDepSelectedFields(p => ({ ...p, [field.name]: nonRef }))
            }
          })
          .catch(() => {})
      }
    })
    // Clean up previews only for fields that are no longer in selectedFields at all
    const refNames = new Set(refFields.map(f => f.name))
    const selectedSet = new Set(selectedFields)
    setLookupPreviews(prev => {
      const next = {}
      for (const k of Object.keys(prev)) {
        const topKey = k.includes('>') ? k.split('>')[0] : k
        // Keep if it's a current ref field OR still in selectedFields (being loaded)
        if (refNames.has(topKey) || selectedSet.has(topKey)) {
          next[k] = prev[k]
        } else {
          console.log('[CLEANUP] Removing preview for', k, 'refNames:', [...refNames], 'selectedSet:', [...selectedSet])
        }
      }
      console.log('[CLEANUP] Before:', Object.keys(prev), 'After:', Object.keys(next))
      return next
    })
  }, [selectedFields, connId, selectedObj, allFields])

  // Nested dependency detection: when dep selected fields include reference fields,
  // create sub-dependency entries (e.g. AccountId>ParentId for Account->Account)
  useEffect(() => {
    if (!connId) return
    // For each first-level dependency that has fields loaded
    Object.entries(depAllFields).forEach(([parentKey, fields]) => {
      if (parentKey.includes('>')) return // skip already-nested keys
      const depSel = depSelectedFields[parentKey] || []
      // Find reference fields in the dep's selected fields
      const depRefFields = depSel
        .map(fname => fields.find(f => f.name === fname))
        .filter(f => f && f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0
          && !SYSTEM_REF_FIELDS.has(f.name)
          && !EXCLUDED_FIELDS.has(f.name))
      depRefFields.forEach(field => {
        const nestedKey = `${parentKey}>${field.name}`
        const targetObj = field.referenceTo[0]
        if (!depAllFields[nestedKey]) {
          fetch(`/api/salesforce/${connId}/describe/${targetObj}`)
            .then(r => r.json())
            .then(data => {
              const nfields = data.fields || []
              setDepAllFields(p => ({ ...p, [nestedKey]: nfields }))
              const req = nfields
                .filter(f => !f.nillable && !f.defaultedOnCreate && f.createable && !EXCLUDED_FIELDS.has(f.name))
                .map(f => f.name)
              setDepRequiredFields(p => ({ ...p, [nestedKey]: new Set(req) }))
              if (!depSelectedFields[nestedKey]) {
                const nonRef = nfields
                  .filter(f => !EXCLUDED_FIELDS.has(f.name) && f.type !== 'reference')
                  .map(f => f.name)
                  .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))
                setDepSelectedFields(p => ({ ...p, [nestedKey]: nonRef }))
              }
            })
            .catch(() => {})
        }
      })
      // Clean up nested keys whose parent field was deselected
      const depRefNames = new Set(depRefFields.map(f => `${parentKey}>${f.name}`))
      Object.keys(depAllFields).forEach(k => {
        if (k.startsWith(`${parentKey}>`) && !depRefNames.has(k)) {
          setDepAllFields(p => { const n = { ...p }; delete n[k]; return n })
          setDepSelectedFields(p => { const n = { ...p }; delete n[k]; return n })
          setDepRequiredFields(p => { const n = { ...p }; delete n[k]; return n })
          setLookupPreviews(p => { const n = { ...p }; delete n[k]; return n })
        }
      })
    })
  }, [depSelectedFields, depAllFields, connId])

  // Load nested dependency previews using IDs from parent dependency rows
  useEffect(() => {
    if (!connId) return
    Object.entries(depAllFields).forEach(([nestedKey]) => {
      if (!nestedKey.includes('>')) return // only nested keys
      const [parentKey, fieldName] = nestedKey.split('>')
      const parentPreview = lookupPreviews[parentKey]
      if (!parentPreview || !parentPreview.rows || parentPreview.rows.length === 0) return
      const parentField = (depAllFields[parentKey] || []).find(f => f.name === fieldName)
      const targetObj = parentField?.referenceTo?.[0] || ''
      if (!targetObj) return
      // Collect IDs from parent preview rows
      const ids = [...new Set(
        parentPreview.rows.map(r => r[fieldName]).filter(v => v && v !== '')
      )]
      // Check if we already loaded with these exact IDs
      const existing = lookupPreviews[nestedKey]
      const existingIdStr = existing?.ids ? [...existing.ids].sort().join(',') : ''
      const newIdStr = [...ids].sort().join(',')
      if (existing && existingIdStr === newIdStr && newIdStr !== '') return
      if (ids.length === 0) {
        setLookupPreviews(p => ({ ...p, [nestedKey]: { targetObj, cols: [], rows: [], ids: [] } }))
        return
      }
      const depSel = depSelectedFields[nestedKey] || []
      const selectCols = depSel.length > 0 ? ['Id', ...depSel] : ['Id', 'Name']
      const unique = [...new Set(selectCols)].filter(c => !EXCLUDED_FIELDS.has(c)).slice(0, 50)
      const idList = ids.map(id => `'${id}'`).join(',')
      const soql = `SELECT ${unique.join(', ')} FROM ${targetObj} WHERE Id IN (${idList})`
      setLookupPreviewLoading(p => ({ ...p, [nestedKey]: true }))
      fetch(`/api/salesforce/${connId}/soql`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ soql }),
      })
        .then(r => r.json())
        .then(data => {
          if (!data.error) {
            setLookupPreviews(p => ({
              ...p,
              [nestedKey]: { targetObj, cols: data.columns || [], rows: data.rows || [], ids }
            }))
          }
        })
        .catch(() => {})
        .finally(() => setLookupPreviewLoading(p => ({ ...p, [nestedKey]: false })))
    })
  }, [depAllFields, depSelectedFields, lookupPreviews, connId])

  // Load dependency previews using actual lookup IDs from main object sample rows
  useEffect(() => {
    if (!connId || !selectedObj || sampleRows.length === 0 || allFields.length === 0) return
    const refFields = selectedFields
      .map(fname => allFields.find(f => f.name === fname))
      .filter(f => f && f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0 && !EXCLUDED_FIELDS.has(f.name) && !SYSTEM_REF_FIELDS.has(f.name))
    refFields.forEach(field => {
      // Collect unique non-null lookup IDs from the main object's rows
      const ids = [...new Set(
        sampleRows.map(r => r[field.name]).filter(v => v && v !== '')
      )]
      const targetObj = field.referenceTo[0]

      // Skip if preview already loaded with same IDs
      const existing = lookupPreviews[field.name]
      const existingIdStr = existing?.ids ? [...existing.ids].sort().join(',') : ''
      const newIdStr = [...ids].sort().join(',')
      console.log('[DEP-LOAD]', field.name, 'ids:', ids.length, 'existing:', !!existing, 'same?', existingIdStr === newIdStr)
      if (existing && existingIdStr === newIdStr && newIdStr !== '') return

      const depSel = depSelectedFields[field.name] || []
      const selectCols = depSel.length > 0 ? ['Id', ...depSel] : ['Id', 'Name']
      const unique = [...new Set(selectCols)].filter(c => !EXCLUDED_FIELDS.has(c)).slice(0, 50)

      const loadDepPreview = (resolvedIds) => {
        if (resolvedIds.length === 0) {
          setLookupPreviews(p => ({ ...p, [field.name]: { targetObj, cols: [], rows: [], ids: [] } }))
          setLookupPreviewLoading(p => ({ ...p, [field.name]: false }))
          return
        }
        const idList = resolvedIds.map(id => `'${id}'`).join(',')
        const soql = `SELECT ${unique.join(', ')} FROM ${targetObj} WHERE Id IN (${idList})`
        fetch(`/api/salesforce/${connId}/soql`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ soql }),
        })
          .then(r => r.json())
          .then(data => {
            if (data.error) {
              return fetch(`/api/salesforce/${connId}/soql`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ soql: `SELECT Id FROM ${targetObj} WHERE Id IN (${idList})` }),
              }).then(r => r.json())
            }
            return data
          })
          .then(data => {
            console.log('[DEP-LOADED]', field.name, 'cols:', (data.columns||[]).length, 'rows:', (data.rows||[]).length, 'error:', data.error)
            setLookupPreviews(p => ({
              ...p,
              [field.name]: { targetObj, cols: data.columns || [], rows: data.rows || [], ids: resolvedIds }
            }))
          })
          .catch(err => { console.error('[DEP-ERROR]', field.name, err) })
          .finally(() => setLookupPreviewLoading(p => ({ ...p, [field.name]: false })))
      }

      setLookupPreviewLoading(p => ({ ...p, [field.name]: true }))

      console.log('[DEP-LOAD] Starting', field.name, '→', targetObj, 'idsFromSample:', ids.length)
      if (ids.length > 0) {
        loadDepPreview(ids)
      } else {
        // Sample rows don't have IDs for this field — query source object for non-null values
        // Respect the current WHERE/ORDER BY clause
        const clauseStr = (whereClause || '').trim()
        const startsKw = /^(ORDER\s+BY|GROUP\s+BY|HAVING|LIMIT)\s/i.test(clauseStr)
        const notNullCond = `${field.name} != null`
        let fbWhere
        if (!clauseStr) {
          fbWhere = ` WHERE ${notNullCond}`
        } else if (startsKw) {
          fbWhere = ` WHERE ${notNullCond} ${clauseStr}`
        } else {
          fbWhere = ` WHERE (${clauseStr}) AND ${notNullCond}`
        }
        const fbHasLimit = /\bLIMIT\s+\d+/i.test(fbWhere)
        const fallbackSoql = `SELECT ${field.name} FROM ${selectedObj}${fbWhere}${fbHasLimit ? '' : ' LIMIT 200'}`
        fetch(`/api/salesforce/${connId}/soql`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ soql: fallbackSoql }),
        })
          .then(r => r.json())
          .then(data => {
            const fallbackIds = [...new Set(
              (data.rows || []).map(r => r[field.name]).filter(v => v && v !== '')
            )]
            loadDepPreview(fallbackIds)
          })
          .catch(() => {
            setLookupPreviews(p => ({ ...p, [field.name]: { targetObj, cols: [], rows: [], ids: [] } }))
            setLookupPreviewLoading(p => ({ ...p, [field.name]: false }))
          })
      }
    })
  }, [sampleRows, selectedFields, connId, selectedObj, allFields, whereClause])

  // Refresh dependency preview when its selected fields change
  const refreshDepPreview = useCallback((fieldName) => {
    const depFields = depAllFields[fieldName]
    const depSel = depSelectedFields[fieldName] || []
    const preview = lookupPreviews[fieldName]
    if (!depFields || !preview || !connId) return
    const targetObj = preview.targetObj
    // Use IDs from main object rows
    const ids = [...new Set(
      sampleRows.map(r => r[fieldName]).filter(v => v && v !== '')
    )]
    const selectCols = depSel.length > 0 ? ['Id', ...depSel] : ['Id', 'Name']
    const unique = [...new Set(selectCols)].filter(c => !EXCLUDED_FIELDS.has(c)).slice(0, 50)
    let soql
    if (ids.length > 0) {
      const idList = ids.map(id => `'${id}'`).join(',')
      soql = `SELECT ${unique.join(', ')} FROM ${targetObj} WHERE Id IN (${idList})`
    } else {
      soql = `SELECT ${unique.join(', ')} FROM ${targetObj} LIMIT 10`
    }
    setLookupPreviewLoading(p => ({ ...p, [fieldName]: true }))
    fetch(`/api/salesforce/${connId}/soql`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ soql }),
    })
      .then(r => r.json())
      .then(data => {
        if (!data.error) {
          setLookupPreviews(p => ({
            ...p,
            [fieldName]: { targetObj, cols: data.columns || [], rows: data.rows || [], ids }
          }))
        }
      })
      .catch(() => {})
      .finally(() => setLookupPreviewLoading(p => ({ ...p, [fieldName]: false })))
  }, [depAllFields, depSelectedFields, lookupPreviews, connId, sampleRows])

  // Refresh whole template: re-fetch main object + all deps
  const refreshAll = useCallback(() => {
    if (!selectedObj || !connId) return
    setSeedingStatus({})
    // Re-load main object sample
    loadSampleRecords(selectedObj, selectedLookups, whereClause, sampleSize)
    // Re-fetch all dep describes + previews
    Object.keys(depAllFields).forEach(key => {
      if (key.includes('>')) return // nested keys will reload via their parent
      setDepAllFields(p => { const n = { ...p }; delete n[key]; return n })
    })
    // Clear nested keys too
    Object.keys(depAllFields).forEach(key => {
      if (key.includes('>')) {
        setDepAllFields(p => { const n = { ...p }; delete n[key]; return n })
        setLookupPreviews(p => { const n = { ...p }; delete n[key]; return n })
      }
    })
  }, [selectedObj, connId, selectedLookups, whereClause, sampleSize, depAllFields, loadSampleRecords])

  // Seed results modal state
  const [seedResultsModal, setSeedResultsModal] = useState(null) // { objectName, tab: 'insert'|'update'|'errors' }

  // Seed records for a given object to the destination org
  const seedObject = useCallback((objectName, sourceIds, fields, isDep = false, statusKey = null) => {
    if (!connId || !destConnId || !mappingTable || !objectName || sourceIds.length === 0) return
    const key = statusKey || objectName
    setSeedingStatus(p => ({ ...p, [key]: { loading: true, inserted: 0, updated: 0, errors: [], done: false } }))
    fetch('/api/seed/push', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sourceConnId: connId,
        destConnId,
        mappingTable,
        objectName,
        sourceIds,
        fields: fields.filter(f => f !== 'Id'),
        maskingRules: isDep ? {} : maskingRules,
      }),
    })
      .then(r => r.json())
      .then(data => {
        setSeedingStatus(p => ({
          ...p,
          [key]: {
            loading: false,
            inserted: data.inserted || 0,
            updated: data.updated || 0,
            errors: data.errors || [],
            error: data.error || null,
            insertResults: data.insert_results || [],
            updateResults: data.update_results || [],
            done: true,
          },
        }))
      })
      .catch(err => {
        setSeedingStatus(p => ({
          ...p,
          [key]: { loading: false, inserted: 0, updated: 0, errors: [err.message], error: err.message, done: true, insertResults: [], updateResults: [] },
        }))
      })
  }, [connId, destConnId, mappingTable, maskingRules])

  // ── Data Masking Techniques by field type ──
  const MASKING_TECHNIQUES = {
    string: [
      { id: 'none', label: 'No Masking' },
      { id: 'redact', label: 'Redact', desc: 'Replace with "XXXXX"' },
      { id: 'partial_mask', label: 'Partial Mask', desc: 'Show first/last N chars, mask middle' },
      { id: 'hash', label: 'Hash (SHA-256)', desc: 'One-way hash — irreversible but consistent' },
      { id: 'fake_name', label: 'Fake Name', desc: 'Replace with random first/last name' },
      { id: 'random_string', label: 'Random String', desc: 'Replace with random alphanumeric text' },
      { id: 'prefix', label: 'Add Prefix', desc: 'Prepend a fixed string' },
      { id: 'suffix', label: 'Add Suffix', desc: 'Append a fixed string' },
      { id: 'constant', label: 'Fixed Value', desc: 'Replace with a constant value' },
      { id: 'shuffle', label: 'Shuffle Characters', desc: 'Randomly rearrange characters' },
      { id: 'null_out', label: 'Null / Clear', desc: 'Set value to null' },
    ],
    email: [
      { id: 'none', label: 'No Masking' },
      { id: 'fake_email', label: 'Fake Email', desc: 'Replace with random@example.com' },
      { id: 'domain_replace', label: 'Replace Domain', desc: 'Keep username, change domain' },
      { id: 'hash_email', label: 'Hash Username', desc: 'Hash the part before @' },
      { id: 'prefix', label: 'Prepend', desc: 'Add text before the email' },
      { id: 'suffix', label: 'Append', desc: 'Add text after the email' },
      { id: 'constant', label: 'Fixed Value', desc: 'Replace with a constant email' },
      { id: 'null_out', label: 'Null / Clear', desc: 'Set value to null' },
    ],
    phone: [
      { id: 'none', label: 'No Masking' },
      { id: 'partial_mask', label: 'Partial Mask', desc: 'Show last 4 digits, mask rest' },
      { id: 'random_phone', label: 'Random Phone', desc: 'Replace with random phone number' },
      { id: 'redact', label: 'Redact', desc: 'Replace with "000-000-0000"' },
      { id: 'prefix', label: 'Prepend', desc: 'Add text before the number' },
      { id: 'suffix', label: 'Append', desc: 'Add text after the number' },
      { id: 'random_digits', label: 'Random Digits', desc: 'Replace with N random digits' },
      { id: 'constant', label: 'Fixed Value', desc: 'Replace with a constant value' },
      { id: 'null_out', label: 'Null / Clear', desc: 'Set value to null' },
    ],
    number: [
      { id: 'none', label: 'No Masking' },
      { id: 'round', label: 'Round', desc: 'Round to nearest 10, 100, etc.' },
      { id: 'range_random', label: 'Randomize Range', desc: 'Replace with random number in range' },
      { id: 'add_noise', label: 'Add Noise', desc: 'Add/subtract random percentage' },
      { id: 'random_digits', label: 'Random Digits', desc: 'Replace with N random digits' },
      { id: 'prefix', label: 'Prepend', desc: 'Add text before the number' },
      { id: 'suffix', label: 'Append', desc: 'Add text after the number' },
      { id: 'zero', label: 'Zero Out', desc: 'Set to 0' },
      { id: 'constant', label: 'Fixed Value', desc: 'Replace with a constant number' },
      { id: 'null_out', label: 'Null / Clear', desc: 'Set value to null' },
    ],
    date: [
      { id: 'none', label: 'No Masking' },
      { id: 'date_shift', label: 'Date Shift', desc: 'Shift by N days (keeps relative order)' },
      { id: 'year_only', label: 'Year Only', desc: 'Keep year, set to Jan 1' },
      { id: 'random_date', label: 'Random Date', desc: 'Replace with random date in range' },
      { id: 'null_out', label: 'Null / Clear', desc: 'Set value to null' },
    ],
    boolean: [
      { id: 'none', label: 'No Masking' },
      { id: 'randomize', label: 'Randomize', desc: 'Random true/false' },
      { id: 'always_true', label: 'Always True', desc: 'Set to true' },
      { id: 'always_false', label: 'Always False', desc: 'Set to false' },
    ],
  }

  // Map SF field types to masking categories
  const getMaskingCategory = (sfType) => {
    if (!sfType) return 'string'
    const t = sfType.toLowerCase()
    if (t === 'email') return 'email'
    if (t === 'phone') return 'phone'
    if (['double', 'currency', 'percent', 'int', 'integer', 'long'].includes(t)) return 'number'
    if (['date', 'datetime', 'time'].includes(t)) return 'date'
    if (t === 'boolean') return 'boolean'
    return 'string'
  }

  const setMaskingRule = (fieldName, technique, options = {}) => {
    setMaskingRules(prev => {
      if (technique === 'none') {
        const next = { ...prev }
        delete next[fieldName]
        return next
      }
      return { ...prev, [fieldName]: { technique, ...options } }
    })
  }

  const maskedFieldCount = Object.keys(maskingRules).length

  const filteredObjects = objects.filter(o => {
    if (!objectSearch) return true
    const s = objectSearch.toLowerCase()
    return (o.name || '').toLowerCase().includes(s) || (o.label || '').toLowerCase().includes(s)
  })

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden', position: 'relative' }}>
      {/* Loading overlay */}
      {loadingMessage && (
        <div style={{
          position: 'absolute', inset: 0, zIndex: 900,
          background: 'rgba(255,255,255,0.85)', backdropFilter: 'blur(2px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <div style={{
            background: '#fff', borderRadius: 12, padding: '28px 40px',
            boxShadow: '0 8px 32px rgba(0,0,0,0.12)', textAlign: 'center',
            minWidth: 260,
          }}>
            <div style={{
              width: 36, height: 36, margin: '0 auto 14px',
              border: '3px solid #e5e7eb', borderTopColor: '#6366f1',
              borderRadius: '50%',
              animation: 'spin 0.8s linear infinite',
            }} />
            <div style={{ fontSize: 14, fontWeight: 600, color: '#1f2937', marginBottom: 6 }}>
              {loadingMessage}
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginBottom: 16 }}>
              Please wait...
            </div>
            <button
              onClick={cancelLoading}
              style={{
                padding: '6px 20px', borderRadius: 6, border: '1px solid #d1d5db',
                background: '#fff', fontSize: 12, cursor: 'pointer', color: '#dc2626',
                fontWeight: 600,
              }}
              onMouseEnter={e => e.currentTarget.style.background = '#fef2f2'}
              onMouseLeave={e => e.currentTarget.style.background = '#fff'}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      <style>{`@keyframes spin { to { transform: rotate(360deg) } }`}</style>

      {/* Unsaved changes modal */}
      {unsavedModal && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 1100,
          background: 'rgba(0,0,0,0.35)', backdropFilter: 'blur(2px)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={handleUnsavedCancel}>
          <div style={{
            background: '#fff', borderRadius: 12, boxShadow: '0 8px 40px rgba(0,0,0,0.18)',
            width: 400, overflow: 'hidden',
          }} onClick={e => e.stopPropagation()}>
            <div style={{
              padding: '18px 22px 14px', borderBottom: '1px solid #e5e7eb',
              display: 'flex', alignItems: 'center', gap: 10,
            }}>
              <div style={{
                width: 32, height: 32, borderRadius: 8, background: '#fef3c7',
                display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              }}>
                <svg width="18" height="18" viewBox="0 0 20 20" fill="#f59e0b"><path d="M10 2L1.5 17h17L10 2zm0 3.5l5.5 9.5h-11L10 5.5z"/><rect x="9" y="9" width="2" height="3.5" rx="0.5"/><circle cx="10" cy="14" r="1"/></svg>
              </div>
              <div>
                <div style={{ fontWeight: 700, fontSize: 15, color: '#1f2937' }}>Unsaved Changes</div>
                <div style={{ fontSize: 12, color: '#6b7280', marginTop: 2 }}>
                  You have unsaved changes to this template. What would you like to do?
                </div>
              </div>
            </div>
            <div style={{
              padding: '14px 22px', display: 'flex', justifyContent: 'flex-end', gap: 8,
              background: '#fafbfc',
            }}>
              <button
                onClick={handleUnsavedCancel}
                style={{
                  padding: '7px 18px', borderRadius: 6, border: '1px solid #d1d5db',
                  background: '#fff', fontSize: 12, cursor: 'pointer', color: '#374151', fontWeight: 500,
                }}
              >Cancel</button>
              <button
                onClick={handleUnsavedDiscard}
                style={{
                  padding: '7px 18px', borderRadius: 6, border: '1px solid #fca5a5',
                  background: '#fff', fontSize: 12, cursor: 'pointer', color: '#dc2626', fontWeight: 600,
                }}
              >Discard</button>
              <button
                onClick={handleUnsavedSave}
                style={{
                  padding: '7px 18px', borderRadius: 6, border: 'none',
                  background: '#6366f1', fontSize: 12, cursor: 'pointer', color: '#fff', fontWeight: 600,
                }}
              >Save & Continue</button>
            </div>
          </div>
        </div>
      )}

      {/* Connection bar + Templates */}
      <div style={{ borderBottom: '1px solid #e5e7eb', background: '#f9fafb' }}>
        {/* Row 1: Template + actions (centered) */}
        <div data-tour="seed-template-bar" style={{
          padding: '10px 16px 6px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
        }}>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', whiteSpace: 'nowrap', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Template</label>
          <select
            value={activeTemplateId || ''}
            onChange={e => {
              const val = e.target.value
              const tpl = templates.find(t => t.id === val)
              const doSwitch = () => {
                if (tpl) loadTemplate(tpl)
                else { cleanSnapshotRef.current = null; setActiveTemplateId(null) }
              }
              if (isDirty) { e.target.value = activeTemplateId || ''; guardUnsaved(doSwitch); return }
              doSwitch()
            }}
            style={{
              padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db',
              fontSize: 12, minWidth: 200, background: '#fff',
            }}
          >
            <option value="">No template</option>
            {templates.map(t => (
              <option key={t.id} value={t.id}>{t.name}</option>
            ))}
          </select>
          {mappingTable && (
            <span style={{ fontSize: 10, color: '#059669', fontWeight: 500, background: '#ecfdf5', padding: '2px 8px', borderRadius: 4 }} title={`Mapping table: ${mappingTable}`}>
              {mappingTable}
            </span>
          )}
            <button
              onClick={() => {
                const doNew = () => {
                  cleanSnapshotRef.current = null
                  setActiveTemplateId(null)
                  setTemplateName('')
                  setSelectedObj(null)
                  setSampleRows([])
                  setSampleCols([])
                  setLookupFields([])
                  setSelectedLookups({})
                  setLookupPreviews({})
                  setAllFields([])
                  setSelectedFields([])
                  setWhereClause('')
                  setSampleSize(10)
                  setSeedingStatus({})
                }
                guardUnsaved(doNew)
              }}
              title="Start a new template from scratch"
              style={{
                padding: '5px 14px', borderRadius: 6, border: 'none',
                background: '#059669', fontSize: 11, cursor: 'pointer',
                color: '#fff', fontWeight: 600, letterSpacing: '0.02em',
              }}
            >
              New
            </button>
            <button
              onClick={() => {
                if (activeTemplateId) {
                  saveTemplate()
                } else {
                  setTemplateName('')
                  setShowSaveTemplate('save')
                }
              }}
              disabled={!selectedObj || templateSaveStatus === 'saving'}
              title={activeTemplateId ? 'Update the selected template' : 'Save as a new template'}
              style={{
                padding: '5px 14px', borderRadius: 6, border: isDirty ? '2px solid #f59e0b' : 'none',
                background: templateSaveStatus === 'saved' ? '#059669' : templateSaveStatus === 'error' ? '#ef4444' : isDirty ? '#f59e0b' : selectedObj ? '#6366f1' : '#e5e7eb',
                fontSize: 11,
                cursor: selectedObj && templateSaveStatus !== 'saving' ? 'pointer' : 'default',
                color: selectedObj || templateSaveStatus || isDirty ? '#fff' : '#9ca3af', fontWeight: 600, letterSpacing: '0.02em',
                transition: 'background 0.2s',
                minWidth: 60,
              }}
            >
              {templateSaveStatus === 'saving' ? 'Saving...' : templateSaveStatus === 'saved' ? 'Saved ✓' : templateSaveStatus === 'error' ? 'Error!' : isDirty ? 'Save *' : 'Save'}
            </button>
            <button
              onClick={() => {
                setTemplateName('')
                setShowSaveTemplate('saveAs')
              }}
              disabled={!selectedObj}
              title="Save current selections as a new template"
              style={{
                padding: '5px 14px', borderRadius: 6, border: '1px solid #c7d2fe',
                background: '#fff', fontSize: 11, cursor: selectedObj ? 'pointer' : 'default',
                color: selectedObj ? '#6366f1' : '#9ca3af', fontWeight: 600, letterSpacing: '0.02em',
                opacity: selectedObj ? 1 : 0.5,
              }}
            >
              Save As
            </button>
            {activeTemplateId && (
              <button
                onClick={() => { if (confirm('Delete this template?')) deleteTemplate(activeTemplateId) }}
                title="Delete selected template"
                style={{
                  padding: '5px 14px', borderRadius: 6, border: '1px solid #fca5a5',
                  background: '#fff', fontSize: 11, cursor: 'pointer', color: '#dc2626', fontWeight: 600,
                }}
              >
                Delete
              </button>
            )}
            {selectedObj && (
              <>
                <div style={{ width: 1, height: 22, background: '#e5e7eb' }} />
                <button
                  onClick={refreshAll}
                  title="Refresh all sections"
                  style={{
                    padding: '5px 14px', borderRadius: 6, border: 'none',
                    background: '#2563eb', fontSize: 11, cursor: 'pointer', color: '#fff', fontWeight: 600,
                    display: 'flex', alignItems: 'center', gap: 4,
                  }}
                >
                  <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M1 1v5h5"/><path d="M3.51 10a6 6 0 1 0 .49-5.5L1 6"/></svg>
                  Refresh
                </button>
              </>
            )}
        </div>

        {/* Row 2: Source / Object / Destination */}
        <div data-tour="seed-connection-bar" style={{
          padding: '4px 16px 10px', display: 'flex', alignItems: 'center', gap: 10,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 0 }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', whiteSpace: 'nowrap', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Source</label>
            <select
              value={connId}
              onChange={e => setConnId(e.target.value)}
              style={{
                padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db',
                fontSize: 12, flex: 1, minWidth: 0, background: '#fff',
              }}
            >
              <option value="">Select connection...</option>
              {sourceConns.map(c => (
                <option key={c.id} value={c.id}>{c.name || c.loginUrl}</option>
              ))}
            </select>
          </div>

          <div style={{ width: 1, height: 28, background: '#e5e7eb', flexShrink: 0 }} />

          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1.5, minWidth: 0, position: 'relative' }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', whiteSpace: 'nowrap', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Object</label>
            <div style={{ position: 'relative', flex: 1, minWidth: 0 }}>
              <input
                type="text"
                value={objectSearch !== null && showObjectDropdown ? objectSearch : (selectedObj ? `${objects.find(o => o.name === selectedObj)?.label || selectedObj} (${selectedObj})` : '')}
                onChange={e => { setObjectSearch(e.target.value); setShowObjectDropdown(true) }}
                onFocus={e => { setObjectSearch(''); setShowObjectDropdown(true); e.target.select() }}
                placeholder={objectsLoading ? 'Loading...' : connId ? 'Search objects...' : 'Select org first'}
                disabled={!connId}
                style={{
                  padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db',
                  fontSize: 12, width: '100%', background: '#fff', boxSizing: 'border-box',
                }}
              />
              {showObjectDropdown && connId && !objectsLoading && (
                <div style={{
                  position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 100,
                  background: '#fff', border: '1px solid #d1d5db', borderRadius: '0 0 6px 6px',
                  maxHeight: 300, overflowY: 'auto', boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                }}>
                  {filteredObjects.length === 0 ? (
                    <div style={{ padding: '8px 12px', color: '#9ca3af', fontSize: 12 }}>No objects found</div>
                  ) : (
                    filteredObjects.slice(0, 100).map(o => (
                      <div
                        key={o.name}
                        onClick={() => { handleSelectObject(o.name); setObjectSearch(null); setShowObjectDropdown(false) }}
                        style={{
                          padding: '6px 12px', cursor: 'pointer', fontSize: 12,
                          background: selectedObj === o.name ? '#eff6ff' : 'transparent',
                          borderBottom: '1px solid #f3f4f6',
                        }}
                        onMouseEnter={e => { if (selectedObj !== o.name) e.currentTarget.style.background = '#f9fafb' }}
                        onMouseLeave={e => { if (selectedObj !== o.name) e.currentTarget.style.background = 'transparent' }}
                      >
                        <span style={{ fontWeight: selectedObj === o.name ? 600 : 400, color: '#1f2937' }}>
                          {o.label || o.name}
                        </span>
                        <span style={{ color: '#9ca3af', marginLeft: 6, fontSize: 10 }}>{o.name}</span>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>

          <div style={{ width: 1, height: 28, background: '#e5e7eb', flexShrink: 0 }} />

          <div style={{ display: 'flex', alignItems: 'center', gap: 6, flex: 1, minWidth: 0 }}>
            <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', whiteSpace: 'nowrap', textTransform: 'uppercase', letterSpacing: '0.04em' }}>Destination</label>
            <select
              value={destConnId}
              onChange={e => setDestConnId(e.target.value)}
              style={{
                padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db',
                fontSize: 12, flex: 1, minWidth: 0, background: '#fff',
              }}
            >
              <option value="">Select destination...</option>
              {destConns.filter(c => c.id !== connId).map(c => (
                <option key={c.id} value={c.id}>{c.name || c.loginUrl}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Save Template Modal */}
      {showSaveTemplate && (() => {
        const isSaveAs = showSaveTemplate === 'saveAs'
        const effectiveId = isSaveAs ? null : activeTemplateId
        const handleSave = () => {
          if (!templateName.trim() || !selectedObj) return
          const tpl = {
            id: effectiveId || undefined,
            name: templateName.trim(),
            connId,
            destConnId,
            selectedObj,
            whereClause,
            sampleSize,
            selectedFields,
            maskingRules: { ...maskingRules },
            depSelectedFields: { ...depSelectedFields },
            selectedLookups: Object.entries(selectedLookups).reduce((acc, [k, v]) => {
              acc[k] = { name: v.name, label: v.label, referenceTo: v.referenceTo, relationshipName: v.relationshipName }
              return acc
            }, {}),
          }
          fetch('/api/seed/templates', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(tpl),
          })
            .then(r => r.json())
            .then(saved => {
              setTemplates(prev => {
                const idx = prev.findIndex(t => t.id === saved.id)
                if (idx >= 0) { const n = [...prev]; n[idx] = saved; return n }
                return [...prev, saved]
              })
              setActiveTemplateId(saved.id)
              setShowSaveTemplate(false)
              setTemplateName('')
            })
            .catch(() => {})
        }
        return (
          <div style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', zIndex: 1000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }} onClick={() => setShowSaveTemplate(false)}>
            <div style={{
              background: '#fff', borderRadius: 10, padding: 24, minWidth: 360,
              boxShadow: '0 10px 40px rgba(0,0,0,0.15)',
            }} onClick={e => e.stopPropagation()}>
              <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 14, color: '#1f2937' }}>
                {isSaveAs ? 'Save As New Template' : (effectiveId ? 'Update Template' : 'Save Template')}
              </div>
              <input
                type="text"
                value={templateName}
                onChange={e => setTemplateName(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleSave() }}
                placeholder="Template name..."
                autoFocus
                style={{
                  width: '100%', padding: '8px 12px', borderRadius: 6,
                  border: '1px solid #d1d5db', fontSize: 13, boxSizing: 'border-box',
                  marginBottom: 10,
                }}
              />
              <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 14 }}>
                Saves: connection, object ({selectedObj}), WHERE clause, limit, {selectedFields.length} display fields
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <button
                  onClick={() => setShowSaveTemplate(false)}
                  style={{
                    padding: '7px 16px', borderRadius: 6, border: '1px solid #d1d5db',
                    background: '#fff', fontSize: 12, cursor: 'pointer', color: '#374151',
                  }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  disabled={!templateName.trim()}
                  style={{
                    padding: '7px 16px', borderRadius: 6, border: 'none',
                    background: '#6366f1', color: '#fff', fontWeight: 600, fontSize: 12,
                    cursor: templateName.trim() ? 'pointer' : 'default',
                    opacity: templateName.trim() ? 1 : 0.5,
                  }}
                >
                  {isSaveAs ? 'Save As New' : (effectiveId ? 'Update' : 'Save')}
                </button>
              </div>
            </div>
          </div>
        )
      })()}

      {/* Dependencies Panel */}
      {showDepsPanel && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.3)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowDepsPanel(false)}>
          <div style={{
            background: '#fff', borderRadius: 12, boxShadow: '0 8px 40px rgba(0,0,0,0.2)',
            width: '70%', maxWidth: 650, height: '80vh', display: 'flex', flexDirection: 'column',
            overflow: 'hidden',
          }} onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div style={{
              padding: '14px 18px', borderBottom: '1px solid #e5e7eb',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: '#fafbfc',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="#7c3aed" strokeWidth="1.5">
                  <path d="M4 3h3v2.5H4zM9 3h3v2.5H9zM5.5 5.5v2H8M10.5 5.5v2H8M8 7.5v1" strokeLinecap="round" strokeLinejoin="round"/>
                  <path d="M5 10h6v2.5H5z" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
                <span style={{ fontWeight: 700, fontSize: 15, color: '#1f2937' }}>
                  Dependencies — {selectedObj}
                </span>
                {Object.keys(selectedLookups).length > 0 && (
                  <span style={{
                    fontSize: 11, fontWeight: 600, background: '#f3f0ff', color: '#7c3aed',
                    padding: '2px 8px', borderRadius: 10,
                  }}>
                    {Object.keys(selectedLookups).length} active
                  </span>
                )}
              </div>
              <button
                onClick={() => setShowDepsPanel(false)}
                style={{
                  background: 'none', border: 'none', fontSize: 20, cursor: 'pointer',
                  color: '#6b7280', lineHeight: 1, padding: '0 4px',
                }}
              >&times;</button>
            </div>

            {/* Search + Filter */}
            <div style={{ padding: '8px 18px', borderBottom: '1px solid #f0f0f0', display: 'flex', gap: 10, alignItems: 'center' }}>
              {/* Filter toggle */}
              <div style={{ display: 'flex', borderRadius: 6, overflow: 'hidden', border: '1px solid #e5e7eb', flexShrink: 0 }}>
                {[
                  { id: 'all', label: 'All' },
                  { id: 'active', label: `Active (${Object.keys(selectedLookups).length})` },
                  { id: 'inactive', label: 'Inactive' },
                ].map(f => (
                  <button
                    key={f.id}
                    onClick={() => setDepsFilter(f.id)}
                    style={{
                      padding: '4px 10px', border: 'none', fontSize: 11, fontWeight: 600, cursor: 'pointer',
                      background: depsFilter === f.id ? '#7c3aed' : '#fff',
                      color: depsFilter === f.id ? '#fff' : '#6b7280',
                    }}
                  >{f.label}</button>
                ))}
              </div>
              <div style={{ flex: 1, position: 'relative' }}>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Search lookup fields..."
                  value={depsSearch}
                  onChange={e => setDepsSearch(e.target.value)}
                  style={{ width: '100%', fontSize: 12, padding: '7px 10px', paddingRight: 28 }}
                />
                {depsSearch && (
                  <span
                    onClick={() => setDepsSearch('')}
                    style={{
                      position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)',
                      cursor: 'pointer', color: '#9ca3af', fontSize: 16, fontWeight: 700, lineHeight: 1,
                    }}
                  >&times;</span>
                )}
              </div>
            </div>

            {/* Lookup fields list */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
              {(() => {
                const lookups = lookupFields
                  .filter(f => {
                    if (depsFilter === 'active' && !selectedLookups[f.name]) return false
                    if (depsFilter === 'inactive' && selectedLookups[f.name]) return false
                    if (!depsSearch) return true
                    const s = depsSearch.toLowerCase()
                    return f.name.toLowerCase().includes(s) || (f.label || '').toLowerCase().includes(s) || (f.referenceTo?.[0] || '').toLowerCase().includes(s)
                  })
                  .sort((a, b) => {
                    const aOn = selectedLookups[a.name] ? 0 : 1
                    const bOn = selectedLookups[b.name] ? 0 : 1
                    if (aOn !== bOn) return aOn - bOn
                    return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
                  })

                if (lookups.length === 0) {
                  return <div style={{ padding: 20, textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>
                    {lookupFields.length === 0 ? 'No lookup fields detected. Select an object first.' : 'No matches found.'}
                  </div>
                }

                return lookups.map(field => {
                  const isActive = !!selectedLookups[field.name]
                  const targetObj = field.referenceTo?.[0] || '?'
                  const preview = lookupPreviews[field.name]
                  const loading = lookupPreviewLoading[field.name]

                  return (
                    <div key={field.name} style={{
                      padding: '10px 18px',
                      borderBottom: '1px solid #f5f5f5',
                      background: isActive ? '#f5f3ff' : 'transparent',
                      transition: 'background 0.15s',
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                        {/* Toggle switch */}
                        <div
                          onClick={() => toggleLookup(field)}
                          style={{
                            position: 'relative', width: 40, height: 22, borderRadius: 11,
                            background: isActive ? '#7c3aed' : '#d1d5db',
                            cursor: 'pointer', flexShrink: 0, transition: 'background 0.15s',
                          }}
                        >
                          <span style={{
                            position: 'absolute', top: 2,
                            left: isActive ? 20 : 2,
                            width: 18, height: 18, borderRadius: '50%', background: '#fff',
                            boxShadow: '0 1px 3px rgba(0,0,0,0.25)', transition: 'left 0.15s',
                          }} />
                        </div>

                        {/* Field info */}
                        <div style={{ flex: 1, minWidth: 0 }}>
                          <div style={{ fontSize: 13, fontWeight: 600, color: '#1f2937' }}>
                            {field.name}
                            <span style={{ fontWeight: 400, color: '#6b7280', marginLeft: 6, fontSize: 11 }}>
                              {field.label && field.label !== field.name ? field.label : ''}
                            </span>
                          </div>
                          <div style={{ fontSize: 11, color: '#7c3aed', marginTop: 2, display: 'flex', alignItems: 'center', gap: 4 }}>
                            <span>&rarr;</span> <span style={{ fontWeight: 600 }}>{targetObj}</span>
                            {loading && <span style={{ color: '#f59e0b', marginLeft: 8 }}>Loading...</span>}
                            {isActive && preview && preview.rows && (
                              <span style={{ color: '#6b7280', marginLeft: 8 }}>{preview.rows.length} record{preview.rows.length !== 1 ? 's' : ''} found</span>
                            )}
                          </div>
                        </div>

                        {/* Record count badge */}
                        {isActive && lookupCounts[field.name] !== undefined && (
                          <span style={{
                            fontSize: 10, fontWeight: 600, background: '#ede9fe', color: '#7c3aed',
                            padding: '2px 8px', borderRadius: 8, flexShrink: 0,
                          }}>
                            {lookupCounts[field.name]} refs
                          </span>
                        )}
                      </div>
                    </div>
                  )
                })
              })()}
            </div>

            {/* Footer */}
            <div style={{
              padding: '12px 18px', borderTop: '1px solid #e5e7eb',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: '#fafbfc',
            }}>
              <div style={{ fontSize: 11, color: '#6b7280' }}>
                Toggle lookups to include their parent records as dependencies. They appear as sections below the preview.
              </div>
              <button
                onClick={() => setShowDepsPanel(false)}
                className="btn btn-primary"
                style={{ fontSize: 12, padding: '6px 20px' }}
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Nested Dependencies Panel (for dependency objects) */}
      {showDepDepsPanel && (() => {
        const parentFieldName = showDepDepsPanel
        const depFields = depAllFields[parentFieldName] || []
        const depLookups = depFields.filter(f =>
          f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0 &&
          !SYSTEM_REF_FIELDS.has(f.name)
        )
        const currentDepSel = depSelectedFields[parentFieldName] || []
        const parentField = allFields.find(f => f.name === parentFieldName) || {}
        const parentTargetObj = parentField.referenceTo?.[0] || parentFieldName

        const toggleDepLookup = (lf) => {
          const fname = lf.name
          setDepSelectedFields(prev => {
            const current = prev[parentFieldName] || []
            if (current.includes(fname)) {
              return { ...prev, [parentFieldName]: current.filter(f => f !== fname) }
            } else {
              return { ...prev, [parentFieldName]: [...current, fname].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })) }
            }
          })
        }

        const activeLookups = depLookups.filter(f => currentDepSel.includes(f.name))

        return (
          <div style={{
            position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
            background: 'rgba(0,0,0,0.3)', zIndex: 1001, display: 'flex', alignItems: 'center', justifyContent: 'center',
          }} onClick={() => setShowDepDepsPanel(null)}>
            <div style={{
              background: '#fff', borderRadius: 12, boxShadow: '0 8px 40px rgba(0,0,0,0.2)',
              width: '65%', maxWidth: 600, height: '75vh', display: 'flex', flexDirection: 'column',
              overflow: 'hidden',
            }} onClick={e => e.stopPropagation()}>
              {/* Header */}
              <div style={{
                padding: '14px 18px', borderBottom: '1px solid #e5e7eb',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                background: '#fafbfc',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <svg width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="#7c3aed" strokeWidth="1.5">
                    <path d="M4 3h3v2.5H4zM9 3h3v2.5H9zM5.5 5.5v2H8M10.5 5.5v2H8M8 7.5v1" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M5 10h6v2.5H5z" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  <span style={{ fontWeight: 700, fontSize: 14, color: '#1f2937' }}>
                    Dependencies — {parentTargetObj}
                  </span>
                  {activeLookups.length > 0 && (
                    <span style={{
                      fontSize: 11, fontWeight: 600, background: '#f3f0ff', color: '#7c3aed',
                      padding: '2px 8px', borderRadius: 10,
                    }}>
                      {activeLookups.length} active
                    </span>
                  )}
                </div>
                <button
                  onClick={() => setShowDepDepsPanel(null)}
                  style={{
                    background: 'none', border: 'none', fontSize: 20, cursor: 'pointer',
                    color: '#6b7280', lineHeight: 1, padding: '0 4px',
                  }}
                >&times;</button>
              </div>

              {/* Active summary */}
              {activeLookups.length > 0 && (
                <div style={{
                  padding: '8px 18px', borderBottom: '1px solid #c4b5fd',
                  background: '#f5f3ff', display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center',
                }}>
                  <span style={{ fontSize: 11, fontWeight: 600, color: '#7c3aed', marginRight: 4 }}>Active:</span>
                  {activeLookups.map(lf => (
                    <span key={lf.name} style={{
                      display: 'inline-flex', alignItems: 'center', gap: 4,
                      fontSize: 11, background: '#fff', border: '1px solid #c4b5fd',
                      borderRadius: 12, padding: '2px 8px 2px 10px', color: '#5b21b6', fontWeight: 500,
                    }}>
                      {lf.name} <span style={{ color: '#7c3aed', fontSize: 10, fontWeight: 400 }}>&rarr; {lf.referenceTo?.[0]}</span>
                      <span
                        onClick={() => toggleDepLookup(lf)}
                        style={{ cursor: 'pointer', color: '#9ca3af', fontWeight: 700, fontSize: 13, marginLeft: 2 }}
                      >&times;</span>
                    </span>
                  ))}
                </div>
              )}

              {/* Search */}
              <div style={{ padding: '8px 18px', borderBottom: '1px solid #f0f0f0' }}>
                <div style={{ position: 'relative' }}>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="Search lookup fields..."
                    value={depsSearch}
                    onChange={e => setDepsSearch(e.target.value)}
                    style={{ width: '100%', fontSize: 12, padding: '7px 10px', paddingRight: 28 }}
                  />
                  {depsSearch && (
                    <span
                      onClick={() => setDepsSearch('')}
                      style={{
                        position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)',
                        cursor: 'pointer', color: '#9ca3af', fontSize: 16, fontWeight: 700, lineHeight: 1,
                      }}
                    >&times;</span>
                  )}
                </div>
              </div>

              {/* List */}
              <div style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
                {depLookups
                  .filter(f => {
                    if (!depsSearch) return true
                    const s = depsSearch.toLowerCase()
                    return f.name.toLowerCase().includes(s) || (f.label || '').toLowerCase().includes(s) || (f.referenceTo?.[0] || '').toLowerCase().includes(s)
                  })
                  .sort((a, b) => {
                    const aOn = currentDepSel.includes(a.name) ? 0 : 1
                    const bOn = currentDepSel.includes(b.name) ? 0 : 1
                    if (aOn !== bOn) return aOn - bOn
                    return a.name.localeCompare(b.name, undefined, { sensitivity: 'base' })
                  })
                  .map(lf => {
                    const isActive = currentDepSel.includes(lf.name)
                    const targetObj = lf.referenceTo?.[0] || '?'
                    return (
                      <div key={lf.name} style={{
                        padding: '10px 18px', borderBottom: '1px solid #f5f5f5',
                        background: isActive ? '#f5f3ff' : 'transparent', transition: 'background 0.15s',
                      }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                          <div
                            onClick={() => toggleDepLookup(lf)}
                            style={{
                              position: 'relative', width: 40, height: 22, borderRadius: 11,
                              background: isActive ? '#7c3aed' : '#d1d5db',
                              cursor: 'pointer', flexShrink: 0, transition: 'background 0.15s',
                            }}
                          >
                            <span style={{
                              position: 'absolute', top: 2, left: isActive ? 20 : 2,
                              width: 18, height: 18, borderRadius: '50%', background: '#fff',
                              boxShadow: '0 1px 3px rgba(0,0,0,0.25)', transition: 'left 0.15s',
                            }} />
                          </div>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ fontSize: 13, fontWeight: 600, color: '#1f2937' }}>
                              {lf.name}
                              <span style={{ fontWeight: 400, color: '#6b7280', marginLeft: 6, fontSize: 11 }}>
                                {lf.label && lf.label !== lf.name ? lf.label : ''}
                              </span>
                            </div>
                            <div style={{ fontSize: 11, color: '#7c3aed', marginTop: 2 }}>
                              <span>&rarr;</span> <span style={{ fontWeight: 600 }}>{targetObj}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )
                  })
                }
                {depLookups.length === 0 && (
                  <div style={{ padding: 20, textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>
                    No lookup fields found on {parentTargetObj}.
                  </div>
                )}
              </div>

              {/* Footer */}
              <div style={{
                padding: '12px 18px', borderTop: '1px solid #e5e7eb',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center', background: '#fafbfc',
              }}>
                <div style={{ fontSize: 11, color: '#6b7280' }}>
                  Toggle lookups to add nested dependencies for {parentTargetObj}.
                </div>
                <button
                  onClick={() => setShowDepDepsPanel(null)}
                  className="btn btn-primary"
                  style={{ fontSize: 12, padding: '6px 20px' }}
                >Done</button>
              </div>
            </div>
          </div>
        )
      })()}

      {/* Data Masking Panel */}
      {showMaskingPanel && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.3)', zIndex: 1000, display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowMaskingPanel(false)}>
          <div style={{
            background: '#fff', borderRadius: 12, boxShadow: '0 8px 40px rgba(0,0,0,0.2)',
            width: '80%', maxWidth: 800, height: '85vh', display: 'flex', flexDirection: 'column',
            overflow: 'hidden',
          }} onClick={e => e.stopPropagation()}>
            {/* Header */}
            <div style={{
              padding: '14px 18px', borderBottom: '1px solid #e5e7eb',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: '#fafbfc',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <svg width="18" height="18" viewBox="0 0 16 16" fill="none" stroke="#dc2626" strokeWidth="1.5">
                  <path d="M8 3C4 3 1.5 8 1.5 8s2.5 5 6.5 5 6.5-5 6.5-5S12 3 8 3z" strokeLinecap="round" strokeLinejoin="round"/>
                  <circle cx="8" cy="8" r="2"/>
                  <path d="M2 14L14 2" strokeWidth="1.8" strokeLinecap="round"/>
                </svg>
                <span style={{ fontWeight: 700, fontSize: 15, color: '#1f2937' }}>
                  Data Masking — {selectedObj}
                </span>
                {maskedFieldCount > 0 && (
                  <span style={{
                    fontSize: 11, fontWeight: 600, background: '#fef2f2', color: '#dc2626',
                    padding: '2px 8px', borderRadius: 10,
                  }}>
                    {maskedFieldCount} field{maskedFieldCount !== 1 ? 's' : ''} masked
                  </span>
                )}
              </div>
              <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                {maskedFieldCount > 0 && (
                  <button
                    onClick={() => setMaskingRules({})}
                    style={{
                      fontSize: 11, padding: '4px 12px', borderRadius: 5,
                      border: '1px solid #fca5a5', background: '#fff', color: '#dc2626',
                      cursor: 'pointer', fontWeight: 600,
                    }}
                  >
                    Clear All
                  </button>
                )}
                <button
                  onClick={() => setShowMaskingPanel(false)}
                  style={{
                    background: 'none', border: 'none', fontSize: 20, cursor: 'pointer',
                    color: '#6b7280', lineHeight: 1, padding: '0 4px',
                  }}
                >&times;</button>
              </div>
            </div>

            {/* Masked fields summary strip */}
            {maskedFieldCount > 0 && (
              <div style={{
                padding: '8px 18px', borderBottom: '1px solid #fca5a5',
                background: '#fef2f2', display: 'flex', flexWrap: 'wrap', gap: 6, alignItems: 'center',
              }}>
                <span style={{ fontSize: 11, fontWeight: 600, color: '#dc2626', marginRight: 4 }}>Masked:</span>
                {Object.entries(maskingRules).map(([fname, rule]) => {
                  const tech = rule.technique
                  return (
                    <span key={fname} style={{
                      display: 'inline-flex', alignItems: 'center', gap: 4,
                      fontSize: 11, background: '#fff', border: '1px solid #fca5a5',
                      borderRadius: 12, padding: '2px 8px 2px 10px', color: '#991b1b',
                      fontWeight: 500,
                    }}>
                      {fname} <span style={{ color: '#dc2626', fontSize: 10, fontWeight: 400 }}>({tech})</span>
                      <span
                        onClick={() => setMaskingRule(fname, 'none')}
                        style={{ cursor: 'pointer', color: '#9ca3af', fontWeight: 700, fontSize: 13, marginLeft: 2 }}
                      >&times;</span>
                    </span>
                  )
                })}
              </div>
            )}

            {/* Search + Filter */}
            <div style={{ padding: '8px 18px', borderBottom: '1px solid #f0f0f0', display: 'flex', gap: 10, alignItems: 'center' }}>
              <div style={{ flex: 1, position: 'relative' }}>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Search fields..."
                  value={maskingSearch}
                  onChange={e => setMaskingSearch(e.target.value)}
                  style={{ width: '100%', fontSize: 12, padding: '7px 10px', paddingRight: 28 }}
                />
                {maskingSearch && (
                  <span
                    onClick={() => setMaskingSearch('')}
                    style={{
                      position: 'absolute', right: 8, top: '50%', transform: 'translateY(-50%)',
                      cursor: 'pointer', color: '#9ca3af', fontSize: 16, fontWeight: 700, lineHeight: 1,
                    }}
                  >&times;</span>
                )}
              </div>
              <div style={{ display: 'flex', borderRadius: 6, overflow: 'hidden', border: '1px solid #d1d5db', flexShrink: 0 }}>
                {[
                  { id: 'all', label: 'All' },
                  { id: 'masked', label: 'Masked' },
                  { id: 'unmasked', label: 'Unmasked' },
                ].map(f => (
                  <button
                    key={f.id}
                    onClick={() => setMaskingFilter(f.id)}
                    style={{
                      fontSize: 11, padding: '4px 10px', border: 'none', cursor: 'pointer',
                      fontWeight: maskingFilter === f.id ? 600 : 400,
                      background: maskingFilter === f.id ? '#2563eb' : '#fff',
                      color: maskingFilter === f.id ? '#fff' : '#6b7280',
                    }}
                  >{f.label}</button>
                ))}
              </div>
            </div>

            {/* Field list */}
            <div style={{ flex: 1, overflowY: 'auto', padding: '6px 0' }}>
              {(() => {
                const displayFields = allFields.map(f => f.name)
                  .filter(fname => {
                    if (fname === 'Id') return false
                    if (maskingFilter === 'masked' && !maskingRules[fname]) return false
                    if (maskingFilter === 'unmasked' && maskingRules[fname]) return false
                    if (!maskingSearch) return true
                    return fname.toLowerCase().includes(maskingSearch.toLowerCase())
                  })
                  .sort((a, b) => {
                    // Masked fields first
                    const aM = maskingRules[a] ? 0 : 1
                    const bM = maskingRules[b] ? 0 : 1
                    if (aM !== bM) return aM - bM
                    return a.localeCompare(b, undefined, { sensitivity: 'base' })
                  })

                if (displayFields.length === 0) {
                  return <div style={{ padding: 20, textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>No fields to mask. Select fields first using the Fields picker.</div>
                }

                return displayFields.map(fname => {
                  const fieldMeta = allFields.find(f => f.name === fname) || {}
                  const category = getMaskingCategory(fieldMeta.type)
                  const techniques = MASKING_TECHNIQUES[category] || MASKING_TECHNIQUES.string
                  const currentRule = maskingRules[fname]
                  const currentTechnique = currentRule?.technique || 'none'

                  return (
                    <div key={fname} style={{
                      padding: '8px 18px',
                      borderBottom: '1px solid #f5f5f5',
                      background: currentRule ? '#fef2f2' : 'transparent',
                      display: 'flex', alignItems: 'center', gap: 12,
                      transition: 'background 0.15s',
                    }}>
                      {/* Field name & type */}
                      <div style={{ width: 200, flexShrink: 0 }}>
                        <div style={{ fontSize: 13, fontWeight: 600, color: '#1f2937' }}>{fname}</div>
                        <div style={{ fontSize: 10, color: '#9ca3af' }}>{fieldMeta.type || 'string'} {fieldMeta.label && fieldMeta.label !== fname ? `— ${fieldMeta.label}` : ''}</div>
                      </div>

                      {/* Technique select */}
                      <select
                        className="form-input"
                        value={currentTechnique}
                        onChange={e => setMaskingRule(fname, e.target.value)}
                        style={{
                          fontSize: 12, padding: '5px 8px', width: 180, flexShrink: 0,
                          borderColor: currentRule ? '#fca5a5' : '#d1d5db',
                        }}
                      >
                        {techniques.map(t => (
                          <option key={t.id} value={t.id}>{t.label}</option>
                        ))}
                      </select>

                      {/* Options based on technique */}
                      <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
                        {(currentTechnique === 'prefix' || currentTechnique === 'suffix' || currentTechnique === 'constant') && (
                          <input
                            type="text"
                            className="form-input"
                            placeholder={currentTechnique === 'prefix' ? 'Prefix text...' : currentTechnique === 'suffix' ? 'Suffix text...' : 'Fixed value...'}
                            value={currentRule?.value || ''}
                            onChange={e => setMaskingRule(fname, currentTechnique, { value: e.target.value })}
                            style={{ fontSize: 11, padding: '4px 8px', flex: 1 }}
                          />
                        )}
                        {currentTechnique === 'domain_replace' && (
                          <input
                            type="text"
                            className="form-input"
                            placeholder="example.com"
                            value={currentRule?.value || 'example.com'}
                            onChange={e => setMaskingRule(fname, currentTechnique, { value: e.target.value })}
                            style={{ fontSize: 11, padding: '4px 8px', flex: 1 }}
                          />
                        )}
                        {currentTechnique === 'random_digits' && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <input
                              type="number"
                              className="form-input"
                              value={currentRule?.length || 10}
                              onChange={e => setMaskingRule(fname, currentTechnique, { length: parseInt(e.target.value) || 10 })}
                              min={1} max={20}
                              style={{ fontSize: 11, padding: '4px 6px', width: 50 }}
                            />
                            <span style={{ fontSize: 11, color: '#6b7280' }}>digits</span>
                          </div>
                        )}
                        {currentTechnique === 'partial_mask' && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <span style={{ fontSize: 11, color: '#6b7280' }}>Show</span>
                            <input
                              type="number"
                              className="form-input"
                              value={currentRule?.showChars || 2}
                              onChange={e => setMaskingRule(fname, currentTechnique, { showChars: parseInt(e.target.value) || 2 })}
                              min={0} max={20}
                              style={{ fontSize: 11, padding: '4px 6px', width: 50 }}
                            />
                            <span style={{ fontSize: 11, color: '#6b7280' }}>chars</span>
                          </div>
                        )}
                        {currentTechnique === 'round' && (
                          <select
                            className="form-input"
                            value={currentRule?.precision || 10}
                            onChange={e => setMaskingRule(fname, currentTechnique, { precision: parseInt(e.target.value) })}
                            style={{ fontSize: 11, padding: '4px 8px', width: 120 }}
                          >
                            <option value={10}>Nearest 10</option>
                            <option value={100}>Nearest 100</option>
                            <option value={1000}>Nearest 1,000</option>
                          </select>
                        )}
                        {currentTechnique === 'range_random' && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <input
                              type="number"
                              className="form-input"
                              placeholder="Min"
                              value={currentRule?.min ?? 0}
                              onChange={e => setMaskingRule(fname, currentTechnique, { min: parseFloat(e.target.value) || 0, max: currentRule?.max ?? 100 })}
                              style={{ fontSize: 11, padding: '4px 6px', width: 70 }}
                            />
                            <span style={{ fontSize: 11, color: '#6b7280' }}>to</span>
                            <input
                              type="number"
                              className="form-input"
                              placeholder="Max"
                              value={currentRule?.max ?? 100}
                              onChange={e => setMaskingRule(fname, currentTechnique, { max: parseFloat(e.target.value) || 100, min: currentRule?.min ?? 0 })}
                              style={{ fontSize: 11, padding: '4px 6px', width: 70 }}
                            />
                          </div>
                        )}
                        {currentTechnique === 'add_noise' && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <span style={{ fontSize: 11, color: '#6b7280' }}>±</span>
                            <input
                              type="number"
                              className="form-input"
                              value={currentRule?.percent || 10}
                              onChange={e => setMaskingRule(fname, currentTechnique, { percent: parseInt(e.target.value) || 10 })}
                              min={1} max={100}
                              style={{ fontSize: 11, padding: '4px 6px', width: 60 }}
                            />
                            <span style={{ fontSize: 11, color: '#6b7280' }}>%</span>
                          </div>
                        )}
                        {currentTechnique === 'date_shift' && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <span style={{ fontSize: 11, color: '#6b7280' }}>Shift</span>
                            <input
                              type="number"
                              className="form-input"
                              value={currentRule?.days || 30}
                              onChange={e => setMaskingRule(fname, currentTechnique, { days: parseInt(e.target.value) || 30 })}
                              style={{ fontSize: 11, padding: '4px 6px', width: 60 }}
                            />
                            <span style={{ fontSize: 11, color: '#6b7280' }}>days</span>
                          </div>
                        )}
                        {currentTechnique === 'random_date' && (
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                            <input
                              type="date"
                              className="form-input"
                              value={currentRule?.startDate || '2020-01-01'}
                              onChange={e => setMaskingRule(fname, currentTechnique, { startDate: e.target.value, endDate: currentRule?.endDate || '2025-12-31' })}
                              style={{ fontSize: 11, padding: '4px 6px' }}
                            />
                            <span style={{ fontSize: 11, color: '#6b7280' }}>to</span>
                            <input
                              type="date"
                              className="form-input"
                              value={currentRule?.endDate || '2025-12-31'}
                              onChange={e => setMaskingRule(fname, currentTechnique, { endDate: e.target.value, startDate: currentRule?.startDate || '2020-01-01' })}
                              style={{ fontSize: 11, padding: '4px 6px' }}
                            />
                          </div>
                        )}

                        {/* Description hint */}
                        {currentTechnique !== 'none' && (() => {
                          const tech = techniques.find(t => t.id === currentTechnique)
                          if (tech && !['prefix', 'suffix', 'constant', 'domain_replace', 'partial_mask', 'round', 'range_random', 'add_noise', 'date_shift', 'random_date', 'random_digits'].includes(currentTechnique)) {
                            return <span style={{ fontSize: 10, color: '#9ca3af', fontStyle: 'italic' }}>{tech.desc}</span>
                          }
                          return null
                        })()}
                      </div>

                      {/* Clear button */}
                      {currentRule && (
                        <button
                          onClick={() => setMaskingRule(fname, 'none')}
                          style={{
                            background: 'none', border: 'none', cursor: 'pointer',
                            color: '#9ca3af', fontSize: 16, padding: '0 4px', flexShrink: 0,
                          }}
                          title="Remove masking"
                        >&times;</button>
                      )}
                    </div>
                  )
                })
              })()}
            </div>

            {/* Footer */}
            <div style={{
              padding: '12px 18px', borderTop: '1px solid #e5e7eb',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: '#fafbfc',
            }}>
              <div style={{ fontSize: 11, color: '#6b7280' }}>
                Masking is applied server-side before records are pushed to the destination org.
              </div>
              <button
                onClick={() => setShowMaskingPanel(false)}
                className="btn btn-primary"
                style={{ fontSize: 12, padding: '6px 20px' }}
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Field Picker Modal */}
      {showFieldPicker && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', zIndex: 1000,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setShowFieldPicker(false)}>
          <div style={{
            background: '#fff', borderRadius: 10, padding: 20, width: 700, maxWidth: '90vw',
            maxHeight: '80vh', display: 'flex', flexDirection: 'column',
            boxShadow: '0 10px 40px rgba(0,0,0,0.15)', resize: 'both', overflow: 'hidden',
          }} onClick={e => e.stopPropagation()}>
            <div style={{
              fontWeight: 700, fontSize: 15, marginBottom: 12, color: '#1f2937',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
            }}>
              <span>{selectedObj} — Select Fields</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{ fontSize: 11, fontWeight: 400, color: '#6b7280' }}>
                  {selectedFields.filter(f => { const fm = allFields.find(af => af.name === f); return !fm || fm.type !== 'reference' }).length} selected
                </span>
                <button
                  onClick={() => setShowFieldPicker(false)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 18, color: '#9ca3af', lineHeight: 1, padding: '0 2px' }}
                  title="Close"
                >&times;</button>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 12, flex: 1, minHeight: 0, overflow: 'hidden' }}>
              {/* Available fields (left) */}
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden' }}>
                <div style={{ padding: '6px 10px', background: '#f9fafb', borderBottom: '1px solid #e5e7eb', fontSize: 12, fontWeight: 600, color: '#374151' }}>
                  Available Fields
                </div>
                <div style={{ padding: '6px 8px', borderBottom: '1px solid #f3f4f6' }}>
                  <input
                    type="text"
                    placeholder="Search..."
                    value={fieldPickerSearch}
                    onChange={e => setFieldPickerSearch(e.target.value)}
                    style={{ width: '100%', padding: '4px 8px', borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11, boxSizing: 'border-box' }}
                  />
                </div>
                <div style={{ flex: 1, overflowY: 'auto' }}>
                  {allFields
                    .filter(f => !EXCLUDED_FIELDS.has(f.name) && f.type !== 'reference')
                    .filter(f => !selectedFields.includes(f.name))
                    .filter(f => {
                      if (!fieldPickerSearch) return true
                      const s = fieldPickerSearch.toLowerCase()
                      return f.name.toLowerCase().includes(s) || (f.label || '').toLowerCase().includes(s)
                    })
                    .sort((a, b) => (a.label || a.name).localeCompare(b.label || b.name, undefined, { sensitivity: 'base' }))
                    .map(f => (
                      <div
                        key={f.name}
                        onClick={() => setSelectedFields(prev => [...prev, f.name].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })))}
                        style={{
                          padding: '5px 10px', cursor: 'pointer', fontSize: 11,
                          borderBottom: '1px solid #f3f4f6', display: 'flex', alignItems: 'center', gap: 6,
                        }}
                        onMouseEnter={e => e.currentTarget.style.background = '#eef2ff'}
                        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                      >
                        <span style={{ color: '#6366f1', flexShrink: 0, fontSize: 14, fontWeight: 700 }}>+</span>
                        <div style={{ minWidth: 0 }}>
                          <span style={{ fontWeight: 600, color: '#1f2937' }}>{f.label || f.name}</span>
                          {f.label && f.label !== f.name && (
                            <span style={{ color: '#6b7280', marginLeft: 6, fontSize: 10 }}>{f.name}</span>
                          )}
                          <span style={{ color: '#9ca3af', marginLeft: 6, fontSize: 10 }}>{f.type}</span>
                        </div>
                      </div>
                    ))
                  }
                </div>
              </div>

              {/* Move buttons */}
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 8 }}>
                <button
                  onClick={() => setSelectedFields(allFields.map(f => f.name).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })))}
                  title="Add all"
                  style={{ padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db', background: '#fff', cursor: 'pointer', fontSize: 12, fontWeight: 600, color: '#6366f1' }}
                >&gt;&gt;</button>
                <button
                  onClick={() => setSelectedFields([...requiredFields].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })))}
                  title="Remove all (keeps required)"
                  style={{ padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db', background: '#fff', cursor: 'pointer', fontSize: 12, fontWeight: 600, color: '#dc2626' }}
                >&lt;&lt;</button>
              </div>

              {/* Selected fields (right) */}
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', border: '1px solid #c7d2fe', borderRadius: 8, overflow: 'hidden' }}>
                <div style={{ padding: '6px 10px', background: '#eef2ff', borderBottom: '1px solid #c7d2fe', fontSize: 12, fontWeight: 600, color: '#3730a3' }}>
                  Selected Fields
                </div>
                <div style={{ padding: '6px 8px', borderBottom: '1px solid #f3f4f6' }}>
                  <input
                    type="text"
                    placeholder="Search..."
                    value={fieldPickerSelectedSearch}
                    onChange={e => setFieldPickerSelectedSearch(e.target.value)}
                    style={{ width: '100%', padding: '4px 8px', borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11, boxSizing: 'border-box' }}
                  />
                </div>
                <div style={{ flex: 1, overflowY: 'auto' }}>
                  {selectedFields.length === 0 ? (
                    <div style={{ padding: 14, color: '#9ca3af', fontSize: 11, textAlign: 'center' }}>
                      No fields selected — defaults to Id + Name
                    </div>
                  ) : (
                    selectedFields
                      .filter(fname => {
                        // Hide reference fields — those are managed via the Deps panel
                        const f = allFields.find(af => af.name === fname)
                        if (f && f.type === 'reference') return false
                        if (!fieldPickerSelectedSearch) return true
                        const s = fieldPickerSelectedSearch.toLowerCase()
                        return fname.toLowerCase().includes(s) || (f?.label || '').toLowerCase().includes(s)
                      })
                      .map((fname, idx) => {
                        const f = allFields.find(af => af.name === fname)
                        const isRequired = requiredFields.has(fname)
                        return (
                          <div
                            key={fname}
                            style={{
                              padding: '5px 10px', fontSize: 11,
                              borderBottom: '1px solid #f9fafb', display: 'flex', alignItems: 'center', gap: 6,
                              background: isRequired ? '#fef9c3' : 'transparent',
                            }}
                          >
                            <span
                              onClick={() => setSelectedFields(prev => prev.filter(n => n !== fname))}
                              style={{ color: isRequired ? '#a16207' : '#dc2626', cursor: 'pointer', flexShrink: 0, fontSize: 13, fontWeight: 700 }}
                              title={isRequired ? 'Remove (required for insert)' : 'Remove'}
                            >{isRequired ? '*' : '×'}</span>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <span style={{ fontWeight: 500, color: '#1f2937' }}>{f?.label || fname}</span>
                              {f?.label && f.label !== fname && (
                                <span style={{ color: '#9ca3af', marginLeft: 6, fontSize: 10 }}>{fname}</span>
                              )}
                              {isRequired && <span style={{ color: '#a16207', marginLeft: 6, fontSize: 9 }}>required</span>}
                            </div>
                          </div>
                        )
                      })
                  )}
                </div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 14 }}>
              <button
                onClick={() => { const refFields = selectedFields.filter(f => { const fm = allFields.find(af => af.name === f); return fm && fm.type === 'reference' }); setSelectedFields([...new Set([...requiredFields, ...refFields])].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' }))); setShowFieldPicker(false); setTimeout(() => loadSampleRecords(selectedObj, {}, whereClause, sampleSize), 0) }}
                style={{
                  padding: '7px 16px', borderRadius: 6, border: '1px solid #d1d5db',
                  background: '#fff', fontSize: 12, cursor: 'pointer', color: '#374151',
                }}
              >
                Reset to Required Only
              </button>
              <button
                onClick={() => {
                  setShowFieldPicker(false)
                  loadSampleRecords(selectedObj, selectedLookups, whereClause, sampleSize)
                }}
                style={{
                  padding: '7px 16px', borderRadius: 6, border: 'none',
                  background: '#6366f1', color: '#fff', fontWeight: 600, fontSize: 12, cursor: 'pointer',
                }}
              >
                Apply ({selectedFields.filter(f => { const fm = allFields.find(af => af.name === f); return !fm || fm.type !== 'reference' }).length || 'default'})
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main content area */}
      <div style={{ flex: 1, minHeight: 0, overflow: 'auto', background: '#fafbfc' }}
        onClick={() => setShowObjectDropdown(false)}
      >
          {!selectedObj ? (
            <div style={{
              flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#9ca3af', fontSize: 14,
            }}>
              Select an object to preview records and lookup dependencies
            </div>
          ) : (
            <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
              {/* Filter criteria */}
              <div data-tour="seed-filter" style={{
                border: '1px solid #e1e5eb', borderRadius: 8, overflow: 'hidden', background: '#fff',
              }}>
                <div style={{
                  padding: '8px 14px', background: '#f9fafb', borderBottom: '1px solid #e1e5eb',
                  fontWeight: 600, fontSize: 13, color: '#1f2937',
                }}>
                  {selectedObj} — Filter Criteria
                </div>
                <div style={{ padding: '10px 14px', display: 'flex', gap: 10, alignItems: 'flex-end' }}>
                  <div style={{ flex: 1 }}>
                    <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>
                      WHERE / ORDER BY clause
                    </label>
                    <input
                      type="text"
                      value={whereClause}
                      onChange={e => setWhereClause(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter') loadSampleRecords(selectedObj, selectedLookups, whereClause, sampleSize) }}
                      placeholder={`e.g. Industry = 'Technology' ORDER BY CreatedDate DESC`}
                      style={{
                        width: '100%', padding: '7px 10px', borderRadius: 6,
                        border: '1px solid #d1d5db', fontSize: 12, boxSizing: 'border-box',
                        fontFamily: 'ui-monospace, monospace',
                      }}
                    />
                  </div>
                  <div>
                    <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', display: 'block', marginBottom: 3 }}>
                      Records to Load
                    </label>
                    <select
                      value={recordLoadOptions.includes(sampleSize) ? sampleSize : 'custom'}
                      onChange={e => {
                        if (e.target.value === 'custom') return
                        setSampleSize(parseInt(e.target.value))
                      }}
                      style={{
                        padding: '7px 10px', borderRadius: 6,
                        border: '1px solid #d1d5db', fontSize: 12, background: '#fff',
                      }}
                    >
                      {recordLoadOptions.sort((a, b) => a - b).map(n => (
                        <option key={n} value={n}>{n.toLocaleString()}</option>
                      ))}
                      {!recordLoadOptions.includes(sampleSize) && (
                        <option value={sampleSize}>{sampleSize.toLocaleString()}</option>
                      )}
                    </select>
                  </div>
                  <button
                    onClick={() => loadSampleRecords(selectedObj, selectedLookups, whereClause, sampleSize)}
                    disabled={sampleLoading}
                    style={{
                      padding: '7px 18px', borderRadius: 6, border: 'none',
                      background: '#6366f1', color: '#fff', fontWeight: 600, fontSize: 12,
                      cursor: sampleLoading ? 'default' : 'pointer',
                      opacity: sampleLoading ? 0.6 : 1, whiteSpace: 'nowrap',
                    }}
                  >
                    {sampleLoading ? 'Loading...' : 'Apply Filter'}
                  </button>
                </div>
              </div>

              {/* Preview table */}
              <div data-tour="seed-preview" style={{
                border: '1px solid #e1e5eb', borderRadius: 8, overflow: 'hidden', background: '#fff',
              }}>
                <div style={{
                  padding: '8px 14px', background: '#f9fafb', borderBottom: '1px solid #e1e5eb',
                  fontWeight: 600, fontSize: 13, color: '#1f2937',
                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                }}>
                  <span>{selectedObj} — Preview</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    {sampleLoading && <span style={{ fontWeight: 400, color: '#6366f1', fontSize: 11 }}>Loading...</span>}
                    <span
                      onClick={() => loadSampleRecords(selectedObj, selectedLookups, whereClause, sampleSize)}
                      style={{ fontSize: 13, color: '#6366f1', cursor: 'pointer', fontWeight: 600 }}
                      title="Refresh preview"
                    >&#8635;</span>
                    <span
                      onClick={() => {
                        setFieldPickerSearch(''); setFieldPickerSelectedSearch(''); setShowFieldPicker(true)
                        // Auto-select all non-reference fields that aren't already selected
                        if (allFields.length > 0) {
                          const currentSet = new Set(selectedFields)
                          const nonRefToAdd = allFields
                            .filter(f => !EXCLUDED_FIELDS.has(f.name) && f.type !== 'reference' && !currentSet.has(f.name))
                            .map(f => f.name)
                          if (nonRefToAdd.length > 0) {
                            setSelectedFields(prev => [...prev, ...nonRefToAdd].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })))
                          }
                        }
                        // Re-fetch describe if allFields is empty (can happen after template load race condition)
                        if (allFields.length === 0 && selectedObj && connId) {
                          fetch(`/api/salesforce/${connId}/describe/${selectedObj}`)
                            .then(r => r.json())
                            .then(data => { if (data.fields) setAllFields(data.fields) })
                            .catch(() => {})
                        }
                      }}
                      style={{ fontSize: 12, color: '#6366f1', fontWeight: 600, cursor: 'pointer' }}
                    >
                      Fields{selectedFields.length > 0 ? ` (${selectedFields.filter(f => { const fm = allFields.find(af => af.name === f); return !fm || fm.type !== 'reference' }).length})` : ''}
                    </span>
                    <span
                      onClick={() => setShowMaskingPanel(true)}
                      style={{
                        fontSize: 12, fontWeight: 600, cursor: 'pointer',
                        color: maskedFieldCount > 0 ? '#dc2626' : '#6366f1',
                        display: 'flex', alignItems: 'center', gap: 4,
                      }}
                      title="Configure data masking rules"
                    >
                      <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
                        <path d="M8 3C4 3 1.5 8 1.5 8s2.5 5 6.5 5 6.5-5 6.5-5S12 3 8 3z" strokeLinecap="round" strokeLinejoin="round"/>
                        <circle cx="8" cy="8" r="2" strokeLinecap="round"/>
                        {maskedFieldCount > 0 && <path d="M2 14L14 2" strokeWidth="1.8" strokeLinecap="round"/>}
                      </svg>
                      Masking{maskedFieldCount > 0 ? ` (${maskedFieldCount})` : ''}
                    </span>
                    <span
                      onClick={() => { setDepsSearch(''); setShowDepsPanel(true) }}
                      style={{
                        fontSize: 12, fontWeight: 600, cursor: 'pointer',
                        color: Object.keys(selectedLookups).length > 0 ? '#7c3aed' : '#6366f1',
                        display: 'flex', alignItems: 'center', gap: 4,
                      }}
                      title="Manage lookup dependencies"
                    >
                      <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4">
                        <path d="M4 3h3v2.5H4zM9 3h3v2.5H9zM5.5 5.5v2H8M10.5 5.5v2H8M8 7.5v1" strokeLinecap="round" strokeLinejoin="round"/>
                        <path d="M5 10h6v2.5H5z" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                      Deps{Object.keys(selectedLookups).length > 0 ? ` (${Object.keys(selectedLookups).length})` : ''}
                    </span>
                    {destConnId && sampleRows.length > 0 && (() => {
                      const st = seedingStatus[selectedObj]
                      if (!st) return (
                        <button
                          onClick={() => seedObject(selectedObj, sampleRows.map(r => r.Id), selectedFields)}
                          style={{
                            padding: '3px 12px', borderRadius: 5, border: 'none',
                            background: '#059669', color: '#fff', fontWeight: 600, fontSize: 11,
                            cursor: 'pointer',
                          }}
                        >Seed</button>
                      )
                      if (st.loading) return <span style={{ fontSize: 11, color: '#f59e0b', fontWeight: 600 }}>Seeding...</span>
                      return (
                        <span style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, fontWeight: 600 }}>
                          {st.error && !st.insertResults?.length && !st.updateResults?.length && (
                            <span style={{ color: '#ef4444', cursor: 'pointer' }}
                              onClick={() => setSeedResultsModal({ objectName: selectedObj, tab: 'errors' })}
                            >Error: {st.error}</span>
                          )}
                          {st.inserted > 0 && (
                            <span style={{ color: '#059669', cursor: 'pointer', textDecoration: 'underline' }}
                              onClick={() => setSeedResultsModal({ objectName: selectedObj, tab: 'insert' })}
                            >{st.inserted} ins</span>
                          )}
                          {st.updated > 0 && (
                            <span style={{ color: '#2563eb', cursor: 'pointer', textDecoration: 'underline' }}
                              onClick={() => setSeedResultsModal({ objectName: selectedObj, tab: 'update' })}
                            >{st.updated} upd</span>
                          )}
                          {(st.insertResults?.some(r => !r.success) || st.updateResults?.some(r => !r.success) || st.errors?.length > 0) && (
                            <span style={{ color: '#ef4444', cursor: 'pointer', textDecoration: 'underline' }}
                              onClick={() => setSeedResultsModal({ objectName: selectedObj, tab: 'errors' })}
                            >{(st.insertResults?.filter(r => !r.success).length || 0) + (st.updateResults?.filter(r => !r.success).length || 0) + (st.errors?.length || 0)} err</span>
                          )}
                          <button
                            onClick={() => seedObject(selectedObj, sampleRows.map(r => r.Id), selectedFields)}
                            style={{
                              padding: '3px 12px', borderRadius: 5, border: 'none',
                              background: '#059669', color: '#fff', fontWeight: 600, fontSize: 11,
                              cursor: 'pointer',
                            }}
                          >Seed</button>
                        </span>
                      )
                    })()}
                  </div>
                  </div>
                  <div style={{ maxHeight: 300, overflowX: 'auto', overflowY: 'auto', flex: 1 }}>
                    {sampleCols.length > 0 && sampleRows.length > 0 ? (
                      <><table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                        <thead>
                          <tr style={{ background: '#f3f4f6', position: 'sticky', top: 0 }}>
                            {sampleCols.map(c => (
                              <th key={c} style={{
                                padding: '5px 10px', textAlign: 'left', fontWeight: 600,
                                whiteSpace: 'nowrap', borderBottom: '1px solid #e5e7eb', background: '#f3f4f6',
                              }}>
                                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                                  {c}
                                  {c !== 'Id' && (
                                    <span
                                      onClick={() => {
                                        setSelectedFields(prev => prev.filter(f => f !== c))
                                        setSampleCols(prev => prev.filter(col => col !== c))
                                      }}
                                      style={{
                                        color: '#d1d5db', cursor: 'pointer', fontSize: 11, fontWeight: 700,
                                        lineHeight: 1, padding: '0 2px', borderRadius: 3,
                                      }}
                                      onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
                                      onMouseLeave={e => e.currentTarget.style.color = '#d1d5db'}
                                      title={`Remove ${c}`}
                                    >×</span>
                                  )}
                                </span>
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {sampleRows.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE).map((row, i) => (
                            <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                              {sampleCols.map(c => (
                                <td key={c} style={{
                                  padding: '4px 10px', maxWidth: 200, overflow: 'hidden',
                                  textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#374151',
                                }}>
                                  {row[c] ?? ''}
                                </td>
                              ))}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                      {sampleRows.length > PAGE_SIZE && (
                        <div style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          padding: '6px 10px', borderTop: '1px solid #e5e7eb', background: '#fafbfc', fontSize: 11,
                        }}>
                          <span style={{ color: '#6b7280' }}>
                            {((currentPage - 1) * PAGE_SIZE) + 1}–{Math.min(currentPage * PAGE_SIZE, sampleRows.length)} of {sampleRows.length.toLocaleString()}
                          </span>
                          <div style={{ display: 'flex', gap: 4 }}>
                            <button
                              onClick={() => setCurrentPage(1)}
                              disabled={currentPage === 1}
                              style={{ padding: '2px 6px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: currentPage === 1 ? 'default' : 'pointer', opacity: currentPage === 1 ? 0.4 : 1, fontSize: 11 }}
                            >«</button>
                            <button
                              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                              disabled={currentPage === 1}
                              style={{ padding: '2px 8px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: currentPage === 1 ? 'default' : 'pointer', opacity: currentPage === 1 ? 0.4 : 1, fontSize: 11 }}
                            >‹ Prev</button>
                            <span style={{ padding: '2px 8px', color: '#374151', fontWeight: 600 }}>
                              {currentPage} / {Math.ceil(sampleRows.length / PAGE_SIZE)}
                            </span>
                            <button
                              onClick={() => setCurrentPage(p => Math.min(Math.ceil(sampleRows.length / PAGE_SIZE), p + 1))}
                              disabled={currentPage >= Math.ceil(sampleRows.length / PAGE_SIZE)}
                              style={{ padding: '2px 8px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: currentPage >= Math.ceil(sampleRows.length / PAGE_SIZE) ? 'default' : 'pointer', opacity: currentPage >= Math.ceil(sampleRows.length / PAGE_SIZE) ? 0.4 : 1, fontSize: 11 }}
                            >Next ›</button>
                            <button
                              onClick={() => setCurrentPage(Math.ceil(sampleRows.length / PAGE_SIZE))}
                              disabled={currentPage >= Math.ceil(sampleRows.length / PAGE_SIZE)}
                              style={{ padding: '2px 6px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: currentPage >= Math.ceil(sampleRows.length / PAGE_SIZE) ? 'default' : 'pointer', opacity: currentPage >= Math.ceil(sampleRows.length / PAGE_SIZE) ? 0.4 : 1, fontSize: 11 }}
                            >»</button>
                          </div>
                        </div>
                      )}
                      </>
                    ) : !sampleLoading ? (
                      <div style={{ padding: 14, color: '#9ca3af', fontSize: 12 }}>No records found</div>
                    ) : null}
                  </div>
              </div>

              {/* Dependency object previews — auto-detected from selected reference fields */}
              {(() => {
                const refFields = selectedFields
                  .map(fname => allFields.find(f => f.name === fname))
                  .filter(f => f && f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0 && !EXCLUDED_FIELDS.has(f.name) && !SYSTEM_REF_FIELDS.has(f.name))
                if (refFields.length === 0) return null
                return (
                  <div data-tour="seed-dependencies" style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
                    {refFields.map(field => {
                      const preview = lookupPreviews[field.name]
                      const loading = lookupPreviewLoading[field.name]
                      const targetObj = field.referenceTo[0]
                      const depSel = depSelectedFields[field.name] || []
                      return (
                        <React.Fragment key={field.name}>
                        <div style={{
                          border: '1px solid #c7d2fe', borderRadius: 8, overflow: 'hidden', background: '#fff',
                        }}>
                          <div style={{
                            padding: '8px 14px', background: '#eef2ff', borderBottom: '1px solid #c7d2fe',
                            fontWeight: 600, fontSize: 12, color: '#3730a3',
                            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                          }}>
                            <span>{field.label} ({field.name}) &rarr; {targetObj}</span>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                              {loading && <span style={{ fontWeight: 400, color: '#6366f1', fontSize: 11 }}>Loading...</span>}
                              <span
                                onClick={() => refreshDepPreview(field.name)}
                                style={{ fontSize: 13, color: '#6366f1', cursor: 'pointer', fontWeight: 600 }}
                                title="Refresh this section"
                              >&#8635;</span>
                              <span
                                onClick={() => { setDepFieldPickerSearch(''); setDepFieldPickerSelectedSearch(''); setShowDepFieldPicker(field.name) }}
                                style={{ fontSize: 11, color: '#6366f1', fontWeight: 600, cursor: 'pointer' }}
                              >
                                Fields{depSel.length > 0 ? ` (${depSel.length})` : ''}
                              </span>
                              {/* Deps link for dependency objects */}
                              {(() => {
                                const depFields = depAllFields[field.name] || []
                                const depLookups = depFields.filter(f =>
                                  f.type === 'reference' && f.referenceTo && f.referenceTo.length > 0 &&
                                  !SYSTEM_REF_FIELDS.has(f.name)
                                )
                                if (depLookups.length === 0) return null
                                const activeCount = depSel.filter(fname => depLookups.some(l => l.name === fname)).length
                                return (
                                  <span
                                    onClick={() => { setDepsSearch(''); setShowDepDepsPanel(field.name) }}
                                    style={{
                                      fontSize: 11, fontWeight: 600, cursor: 'pointer',
                                      color: activeCount > 0 ? '#7c3aed' : '#6366f1',
                                      display: 'flex', alignItems: 'center', gap: 3,
                                    }}
                                    title="Manage nested dependencies"
                                  >
                                    <svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
                                      <path d="M4 3h3v2.5H4zM9 3h3v2.5H9zM5.5 5.5v2H8M10.5 5.5v2H8M8 7.5v1" strokeLinecap="round" strokeLinejoin="round"/>
                                      <path d="M5 10h6v2.5H5z" strokeLinecap="round" strokeLinejoin="round"/>
                                    </svg>
                                    Deps{activeCount > 0 ? ` (${activeCount})` : ''}
                                  </span>
                                )
                              })()}
                              {destConnId && preview && preview.rows && preview.rows.length > 0 && (() => {
                                const seedKey = field.name  // unique per dep (AccountId, ContactId, etc.)
                                const st = seedingStatus[seedKey]
                                if (!st) return (
                                  <button
                                    onClick={() => seedObject(targetObj, preview.rows.map(r => r.Id), depSel, true, seedKey)}
                                    style={{
                                      padding: '3px 10px', borderRadius: 5, border: 'none',
                                      background: '#059669', color: '#fff', fontWeight: 600, fontSize: 10,
                                      cursor: 'pointer',
                                    }}
                                  >Seed</button>
                                )
                                if (st.loading) return <span style={{ fontSize: 11, color: '#f59e0b', fontWeight: 600 }}>Seeding...</span>
                                return (
                                  <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, fontWeight: 600 }}>
                                    {st.error && !st.insertResults?.length && !st.updateResults?.length && (
                                      <span style={{ color: '#ef4444', cursor: 'pointer' }}
                                        onClick={() => setSeedResultsModal({ objectName: seedKey, tab: 'errors' })}
                                      >Error</span>
                                    )}
                                    {st.inserted > 0 && (
                                      <span style={{ color: '#059669', cursor: 'pointer', textDecoration: 'underline' }}
                                        onClick={() => setSeedResultsModal({ objectName: seedKey, tab: 'insert' })}
                                      >{st.inserted} ins</span>
                                    )}
                                    {st.updated > 0 && (
                                      <span style={{ color: '#2563eb', cursor: 'pointer', textDecoration: 'underline' }}
                                        onClick={() => setSeedResultsModal({ objectName: seedKey, tab: 'update' })}
                                      >{st.updated} upd</span>
                                    )}
                                    {(st.insertResults?.some(r => !r.success) || st.updateResults?.some(r => !r.success) || st.errors?.length > 0) && (
                                      <span style={{ color: '#ef4444', cursor: 'pointer', textDecoration: 'underline' }}
                                        onClick={() => setSeedResultsModal({ objectName: seedKey, tab: 'errors' })}
                                      >{(st.insertResults?.filter(r => !r.success).length || 0) + (st.updateResults?.filter(r => !r.success).length || 0) + (st.errors?.length || 0)} err</span>
                                    )}
                                    <button
                                      onClick={() => seedObject(targetObj, preview.rows.map(r => r.Id), depSel, true, seedKey)}
                                      style={{
                                        padding: '2px 10px', borderRadius: 5, border: 'none',
                                        background: '#059669', color: '#fff', fontWeight: 600, fontSize: 10,
                                        cursor: 'pointer',
                                      }}
                                    >Seed</button>
                                  </span>
                                )
                              })()}
                            </div>
                          </div>
                          <div style={{ maxHeight: 180, overflowX: 'auto', overflowY: 'auto' }}>
                            {preview && preview.cols.length > 0 ? (
                              <><table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                                <thead>
                                  <tr style={{ background: '#f5f3ff', position: 'sticky', top: 0 }}>
                                    {preview.cols.map(c => (
                                      <th key={c} style={{
                                        padding: '5px 10px', textAlign: 'left', fontWeight: 600,
                                        whiteSpace: 'nowrap', borderBottom: '1px solid #e5e7eb', background: '#f5f3ff',
                                      }}>
                                        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                                          {c}
                                          {c !== 'Id' && (
                                            <span
                                              onClick={() => {
                                                setDepSelectedFields(p => ({ ...p, [field.name]: (p[field.name] || []).filter(f => f !== c) }))
                                                setLookupPreviews(p => {
                                                  const prev = p[field.name]
                                                  if (!prev) return p
                                                  return { ...p, [field.name]: { ...prev, cols: prev.cols.filter(col => col !== c) } }
                                                })
                                              }}
                                              style={{
                                                color: '#d1d5db', cursor: 'pointer', fontSize: 11, fontWeight: 700,
                                                lineHeight: 1, padding: '0 2px', borderRadius: 3,
                                              }}
                                              onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
                                              onMouseLeave={e => e.currentTarget.style.color = '#d1d5db'}
                                              title={`Remove ${c}`}
                                            >×</span>
                                          )}
                                        </span>
                                      </th>
                                    ))}
                                  </tr>
                                </thead>
                                <tbody>
                                  {(() => {
                                    const depPage = depCurrentPage[field.name] || 1
                                    return preview.rows.slice((depPage - 1) * PAGE_SIZE, depPage * PAGE_SIZE).map((row, i) => (
                                      <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                                        {preview.cols.map(c => (
                                          <td key={c} style={{
                                            padding: '4px 10px', maxWidth: 200, overflow: 'hidden',
                                            textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#374151',
                                          }}>
                                            {row[c] ?? ''}
                                          </td>
                                        ))}
                                      </tr>
                                    ))
                                  })()}
                                </tbody>
                              </table>
                              {preview.rows.length > PAGE_SIZE && (() => {
                                const depPage = depCurrentPage[field.name] || 1
                                const totalPages = Math.ceil(preview.rows.length / PAGE_SIZE)
                                const setPage = (p) => setDepCurrentPage(prev => ({ ...prev, [field.name]: p }))
                                return (
                                  <div style={{
                                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                    padding: '6px 10px', borderTop: '1px solid #e5e7eb', background: '#fafbfc', fontSize: 11,
                                  }}>
                                    <span style={{ color: '#6b7280' }}>
                                      {((depPage - 1) * PAGE_SIZE) + 1}–{Math.min(depPage * PAGE_SIZE, preview.rows.length)} of {preview.rows.length.toLocaleString()}
                                    </span>
                                    <div style={{ display: 'flex', gap: 4 }}>
                                      <button onClick={() => setPage(1)} disabled={depPage === 1}
                                        style={{ padding: '2px 6px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: depPage === 1 ? 'default' : 'pointer', opacity: depPage === 1 ? 0.4 : 1, fontSize: 11 }}
                                      >«</button>
                                      <button onClick={() => setPage(Math.max(1, depPage - 1))} disabled={depPage === 1}
                                        style={{ padding: '2px 8px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: depPage === 1 ? 'default' : 'pointer', opacity: depPage === 1 ? 0.4 : 1, fontSize: 11 }}
                                      >‹ Prev</button>
                                      <span style={{ padding: '2px 8px', color: '#374151', fontWeight: 600 }}>{depPage} / {totalPages}</span>
                                      <button onClick={() => setPage(Math.min(totalPages, depPage + 1))} disabled={depPage >= totalPages}
                                        style={{ padding: '2px 8px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: depPage >= totalPages ? 'default' : 'pointer', opacity: depPage >= totalPages ? 0.4 : 1, fontSize: 11 }}
                                      >Next ›</button>
                                      <button onClick={() => setPage(totalPages)} disabled={depPage >= totalPages}
                                        style={{ padding: '2px 6px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: depPage >= totalPages ? 'default' : 'pointer', opacity: depPage >= totalPages ? 0.4 : 1, fontSize: 11 }}
                                      >»</button>
                                    </div>
                                  </div>
                                )
                              })()}
                              </>
                            ) : !loading ? (
                              <div style={{ padding: 14, color: '#9ca3af', fontSize: 12 }}>No records found</div>
                            ) : null}
                          </div>
                        </div>
                        {/* Nested (2nd-level) deps for THIS parent */}
                        {(() => {
                          const nestedKeys = Object.keys(depAllFields).filter(k => k.startsWith(`${field.name}>`))
                          if (nestedKeys.length === 0) return null
                          return nestedKeys.map(nestedKey => {
                            const [, childFieldName] = nestedKey.split('>')
                            const nParentField = (depAllFields[field.name] || []).find(f => f.name === childFieldName)
                            if (!nParentField) return null
                            const nestedTargetObj = nParentField.referenceTo[0]
                            const nestedPreview = lookupPreviews[nestedKey]
                            const nestedLoading = lookupPreviewLoading[nestedKey]
                            const nestedDepSel = depSelectedFields[nestedKey] || []
                            return (
                              <div key={nestedKey} style={{
                                border: '1px solid #a5b4fc', borderRadius: 8, overflow: 'hidden', background: '#fff',
                                marginLeft: 16,
                              }}>
                                <div style={{
                                  padding: '8px 14px', background: '#e0e7ff', borderBottom: '1px solid #a5b4fc',
                                  fontWeight: 600, fontSize: 12, color: '#312e81',
                                  display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                                }}>
                                  <span>{nParentField.label} ({childFieldName}) &rarr; {nestedTargetObj}</span>
                                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                                    {nestedLoading && <span style={{ fontWeight: 400, color: '#6366f1', fontSize: 11 }}>Loading...</span>}
                                    <span
                                      onClick={() => { setDepFieldPickerSearch(''); setDepFieldPickerSelectedSearch(''); setShowDepFieldPicker(nestedKey) }}
                                      style={{ fontSize: 11, color: '#6366f1', fontWeight: 600, cursor: 'pointer' }}
                                    >
                                      Fields{nestedDepSel.length > 0 ? ` (${nestedDepSel.length})` : ''}
                                    </span>
                                    {destConnId && nestedPreview && nestedPreview.rows && nestedPreview.rows.length > 0 && (() => {
                                      const st = seedingStatus[nestedKey]
                                      if (!st) return (
                                        <button
                                          onClick={() => seedObject(nestedTargetObj, nestedPreview.rows.map(r => r.Id), nestedDepSel, true, nestedKey)}
                                          style={{
                                            padding: '3px 10px', borderRadius: 5, border: 'none',
                                            background: '#059669', color: '#fff', fontWeight: 600, fontSize: 10,
                                            cursor: 'pointer',
                                          }}
                                        >Seed</button>
                                      )
                                      if (st.loading) return <span style={{ fontSize: 11, color: '#f59e0b', fontWeight: 600 }}>Seeding...</span>
                                      return (
                                        <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, fontWeight: 600 }}>
                                          {st.inserted > 0 && (
                                            <span style={{ color: '#059669', cursor: 'pointer', textDecoration: 'underline' }}
                                              onClick={() => setSeedResultsModal({ objectName: nestedTargetObj, tab: 'insert' })}
                                            >{st.inserted} ins</span>
                                          )}
                                          {st.updated > 0 && (
                                            <span style={{ color: '#2563eb', cursor: 'pointer', textDecoration: 'underline' }}
                                              onClick={() => setSeedResultsModal({ objectName: nestedTargetObj, tab: 'update' })}
                                            >{st.updated} upd</span>
                                          )}
                                          <button
                                            onClick={() => seedObject(nestedTargetObj, nestedPreview.rows.map(r => r.Id), nestedDepSel, true, nestedKey)}
                                            style={{
                                              padding: '2px 10px', borderRadius: 5, border: 'none',
                                              background: '#059669', color: '#fff', fontWeight: 600, fontSize: 10,
                                              cursor: 'pointer',
                                            }}
                                          >Seed</button>
                                        </span>
                                      )
                                    })()}
                                  </div>
                                </div>
                                <div style={{ maxHeight: 180, overflowX: 'auto', overflowY: 'auto' }}>
                                  {nestedPreview && nestedPreview.cols.length > 0 ? (
                                    <><table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                                      <thead>
                                        <tr style={{ background: '#ede9fe', position: 'sticky', top: 0 }}>
                                          {nestedPreview.cols.map(c => (
                                            <th key={c} style={{
                                              padding: '5px 10px', textAlign: 'left', fontWeight: 600,
                                              whiteSpace: 'nowrap', borderBottom: '1px solid #e5e7eb', background: '#ede9fe',
                                            }}>
                                              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
                                                {c}
                                                {c !== 'Id' && (
                                                  <span
                                                    onClick={() => {
                                                      setDepSelectedFields(p => ({ ...p, [nestedKey]: (p[nestedKey] || []).filter(f => f !== c) }))
                                                      setLookupPreviews(p => {
                                                        const prev = p[nestedKey]
                                                        if (!prev) return p
                                                        return { ...p, [nestedKey]: { ...prev, cols: prev.cols.filter(col => col !== c) } }
                                                      })
                                                    }}
                                                    style={{
                                                      color: '#d1d5db', cursor: 'pointer', fontSize: 11, fontWeight: 700,
                                                      lineHeight: 1, padding: '0 2px', borderRadius: 3,
                                                    }}
                                                    onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
                                                    onMouseLeave={e => e.currentTarget.style.color = '#d1d5db'}
                                                    title={`Remove ${c}`}
                                                  >×</span>
                                                )}
                                              </span>
                                            </th>
                                          ))}
                                        </tr>
                                      </thead>
                                      <tbody>
                                        {(() => {
                                          const nPage = depCurrentPage[nestedKey] || 1
                                          return nestedPreview.rows.slice((nPage - 1) * PAGE_SIZE, nPage * PAGE_SIZE).map((row, i) => (
                                            <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                                              {nestedPreview.cols.map(c => (
                                                <td key={c} style={{
                                                  padding: '4px 10px', maxWidth: 200, overflow: 'hidden',
                                                  textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#374151',
                                                }}>
                                                  {row[c] ?? ''}
                                                </td>
                                              ))}
                                            </tr>
                                          ))
                                        })()}
                                      </tbody>
                                    </table>
                                    {nestedPreview.rows.length > PAGE_SIZE && (() => {
                                      const nPage = depCurrentPage[nestedKey] || 1
                                      const totalPages = Math.ceil(nestedPreview.rows.length / PAGE_SIZE)
                                      const setPage = (p) => setDepCurrentPage(prev => ({ ...prev, [nestedKey]: p }))
                                      return (
                                        <div style={{
                                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                                          padding: '6px 10px', borderTop: '1px solid #e5e7eb', background: '#fafbfc', fontSize: 11,
                                        }}>
                                          <span style={{ color: '#6b7280' }}>
                                            {((nPage - 1) * PAGE_SIZE) + 1}–{Math.min(nPage * PAGE_SIZE, nestedPreview.rows.length)} of {nestedPreview.rows.length.toLocaleString()}
                                          </span>
                                          <div style={{ display: 'flex', gap: 4 }}>
                                            <button onClick={() => setPage(1)} disabled={nPage === 1}
                                              style={{ padding: '2px 6px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: nPage === 1 ? 'default' : 'pointer', opacity: nPage === 1 ? 0.4 : 1, fontSize: 11 }}
                                            >«</button>
                                            <button onClick={() => setPage(Math.max(1, nPage - 1))} disabled={nPage === 1}
                                              style={{ padding: '2px 8px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: nPage === 1 ? 'default' : 'pointer', opacity: nPage === 1 ? 0.4 : 1, fontSize: 11 }}
                                            >‹ Prev</button>
                                            <span style={{ padding: '2px 8px', color: '#374151', fontWeight: 600 }}>{nPage} / {totalPages}</span>
                                            <button onClick={() => setPage(Math.min(totalPages, nPage + 1))} disabled={nPage >= totalPages}
                                              style={{ padding: '2px 8px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: nPage >= totalPages ? 'default' : 'pointer', opacity: nPage >= totalPages ? 0.4 : 1, fontSize: 11 }}
                                            >Next ›</button>
                                            <button onClick={() => setPage(totalPages)} disabled={nPage >= totalPages}
                                              style={{ padding: '2px 6px', borderRadius: 4, border: '1px solid #d1d5db', background: '#fff', cursor: nPage >= totalPages ? 'default' : 'pointer', opacity: nPage >= totalPages ? 0.4 : 1, fontSize: 11 }}
                                            >»</button>
                                          </div>
                                        </div>
                                      )
                                    })()}
                                    </>
                                  ) : !nestedLoading ? (
                                    <div style={{ padding: 14, color: '#9ca3af', fontSize: 12 }}>No records found</div>
                                  ) : null}
                                </div>
                              </div>
                            )
                          })
                        })()}
                        </React.Fragment>
                      )
                    })}
                  </div>
                )
              })()}
            </div>
          )}
      </div>

      {/* Dependency Field Picker Modal */}
      {showDepFieldPicker && (() => {
        const fname = showDepFieldPicker
        let fields = depAllFields[fname] || []
        const selected = depSelectedFields[fname] || []
        const reqSet = depRequiredFields[fname] || new Set()
        const preview = lookupPreviews[fname]
        // Resolve targetObj: for nested keys like "AccountId>ParentId", look up from parent's fields
        let targetObj = preview?.targetObj || ''
        if (!targetObj && fname.includes('>')) {
          const [parentKey, childField] = fname.split('>')
          const pf = (depAllFields[parentKey] || []).find(f => f.name === childField)
          if (pf) targetObj = pf.referenceTo[0]
        }
        // Re-fetch describe if fields are empty
        if (fields.length === 0 && targetObj && connId) {
          fetch(`/api/salesforce/${connId}/describe/${targetObj}`)
            .then(r => r.json())
            .then(data => {
              const f = data.fields || []
              setDepAllFields(p => ({ ...p, [fname]: f }))
              const req = f.filter(fl => !fl.nillable && !fl.defaultedOnCreate && fl.createable && !EXCLUDED_FIELDS.has(fl.name)).map(fl => fl.name)
              setDepRequiredFields(p => ({ ...p, [fname]: new Set(req) }))
            })
            .catch(() => {})
        }
        return (
          <div style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.3)', zIndex: 1000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }} onClick={() => setShowDepFieldPicker(null)}>
            <div style={{
              background: '#fff', borderRadius: 10, padding: 20, width: 700, maxWidth: '90vw',
              maxHeight: '80vh', display: 'flex', flexDirection: 'column',
              boxShadow: '0 10px 40px rgba(0,0,0,0.15)', resize: 'both', overflow: 'hidden',
            }} onClick={e => e.stopPropagation()}>
              <div style={{
                fontWeight: 700, fontSize: 15, marginBottom: 12, color: '#1f2937',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <span>{targetObj} — Select Fields</span>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <span style={{ fontSize: 11, fontWeight: 400, color: '#6b7280' }}>
                    {selected.length} selected
                  </span>
                  <button
                    onClick={() => setShowDepFieldPicker(null)}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 18, color: '#9ca3af', lineHeight: 1, padding: '0 2px' }}
                    title="Close"
                  >&times;</button>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 12, flex: 1, minHeight: 0, overflow: 'hidden' }}>
                {/* Available */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ padding: '6px 10px', background: '#f9fafb', borderBottom: '1px solid #e5e7eb', fontSize: 12, fontWeight: 600, color: '#374151' }}>
                    Available Fields
                  </div>
                  <div style={{ padding: '6px 8px', borderBottom: '1px solid #f3f4f6' }}>
                    <input
                      type="text" placeholder="Search..."
                      value={depFieldPickerSearch} onChange={e => setDepFieldPickerSearch(e.target.value)}
                      style={{ width: '100%', padding: '4px 8px', borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11, boxSizing: 'border-box' }}
                    />
                  </div>
                  <div style={{ flex: 1, overflowY: 'auto' }}>
                    {fields
                      .filter(f => !EXCLUDED_FIELDS.has(f.name))
                      .filter(f => !selected.includes(f.name))
                      .filter(f => {
                        if (!depFieldPickerSearch) return true
                        const s = depFieldPickerSearch.toLowerCase()
                        return f.name.toLowerCase().includes(s) || (f.label || '').toLowerCase().includes(s)
                      })
                      .sort((a, b) => (a.label || a.name).localeCompare(b.label || b.name, undefined, { sensitivity: 'base' }))
                      .map(f => (
                        <div key={f.name}
                          onClick={() => setDepSelectedFields(p => ({ ...p, [fname]: [...(p[fname] || []), f.name].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })) }))}
                          style={{ padding: '5px 10px', cursor: 'pointer', fontSize: 11, borderBottom: '1px solid #f3f4f6', display: 'flex', alignItems: 'center', gap: 6 }}
                          onMouseEnter={e => e.currentTarget.style.background = '#eef2ff'}
                          onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                        >
                          <span style={{ color: '#6366f1', flexShrink: 0, fontSize: 14, fontWeight: 700 }}>+</span>
                          <div style={{ minWidth: 0 }}>
                            <span style={{ fontWeight: 600, color: '#1f2937' }}>{f.label || f.name}</span>
                            {f.label && f.label !== f.name && <span style={{ color: '#6b7280', marginLeft: 6, fontSize: 10 }}>{f.name}</span>}
                            <span style={{ color: '#9ca3af', marginLeft: 6, fontSize: 10 }}>{f.type}</span>
                          </div>
                        </div>
                      ))
                    }
                  </div>
                </div>
                {/* Buttons */}
                <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 8 }}>
                  <button onClick={() => setDepSelectedFields(p => ({ ...p, [fname]: fields.filter(f => !EXCLUDED_FIELDS.has(f.name)).map(f => f.name).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })) }))}
                    style={{ padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db', background: '#fff', cursor: 'pointer', fontSize: 12, fontWeight: 600, color: '#6366f1' }}
                  >&gt;&gt;</button>
                  <button onClick={() => setDepSelectedFields(p => ({ ...p, [fname]: [...reqSet].sort((a, b) => a.localeCompare(b, undefined, { sensitivity: 'base' })) }))}
                    style={{ padding: '6px 10px', borderRadius: 6, border: '1px solid #d1d5db', background: '#fff', cursor: 'pointer', fontSize: 12, fontWeight: 600, color: '#dc2626' }}
                  >&lt;&lt;</button>
                </div>
                {/* Selected */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', border: '1px solid #c7d2fe', borderRadius: 8, overflow: 'hidden' }}>
                  <div style={{ padding: '6px 10px', background: '#eef2ff', borderBottom: '1px solid #c7d2fe', fontSize: 12, fontWeight: 600, color: '#3730a3' }}>
                    Selected Fields
                  </div>
                  <div style={{ padding: '6px 8px', borderBottom: '1px solid #f3f4f6' }}>
                    <input
                      type="text" placeholder="Search..."
                      value={depFieldPickerSelectedSearch} onChange={e => setDepFieldPickerSelectedSearch(e.target.value)}
                      style={{ width: '100%', padding: '4px 8px', borderRadius: 4, border: '1px solid #d1d5db', fontSize: 11, boxSizing: 'border-box' }}
                    />
                  </div>
                  <div style={{ flex: 1, overflowY: 'auto' }}>
                    {selected.length === 0 ? (
                      <div style={{ padding: 14, color: '#9ca3af', fontSize: 11, textAlign: 'center' }}>No fields selected</div>
                    ) : (
                      selected
                        .filter(fn => {
                          if (!depFieldPickerSelectedSearch) return true
                          const s = depFieldPickerSelectedSearch.toLowerCase()
                          const f = fields.find(af => af.name === fn)
                          return fn.toLowerCase().includes(s) || (f?.label || '').toLowerCase().includes(s)
                        })
                        .map(fn => {
                          const f = fields.find(af => af.name === fn)
                          const isReq = reqSet.has(fn)
                          return (
                            <div key={fn} style={{
                              padding: '5px 10px', fontSize: 11, borderBottom: '1px solid #f9fafb',
                              display: 'flex', alignItems: 'center', gap: 6,
                              background: isReq ? '#fef9c3' : 'transparent',
                            }}>
                              <span
                                onClick={() => setDepSelectedFields(p => ({ ...p, [fname]: (p[fname] || []).filter(n => n !== fn) }))}
                                style={{ color: isReq ? '#a16207' : '#dc2626', cursor: 'pointer', flexShrink: 0, fontSize: 13, fontWeight: 700 }}
                                title={isReq ? 'Remove (required for insert)' : 'Remove'}
                              >{isReq ? '*' : '×'}</span>
                              <div style={{ flex: 1, minWidth: 0 }}>
                                <span style={{ fontWeight: 500, color: '#1f2937' }}>{f?.label || fn}</span>
                                {f?.label && f.label !== fn && <span style={{ color: '#9ca3af', marginLeft: 6, fontSize: 10 }}>{fn}</span>}
                                {isReq && <span style={{ color: '#a16207', marginLeft: 6, fontSize: 9 }}>required</span>}
                              </div>
                            </div>
                          )
                        })
                    )}
                  </div>
                </div>
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end', marginTop: 14 }}>
                <button
                  onClick={() => { setDepSelectedFields(p => ({ ...p, [fname]: [...reqSet] })); setShowDepFieldPicker(null); refreshDepPreview(fname) }}
                  style={{ padding: '7px 16px', borderRadius: 6, border: '1px solid #d1d5db', background: '#fff', fontSize: 12, cursor: 'pointer', color: '#374151' }}
                >Reset to Required Only</button>
                <button
                  onClick={() => { setShowDepFieldPicker(null); refreshDepPreview(fname) }}
                  style={{ padding: '7px 16px', borderRadius: 6, border: 'none', background: '#6366f1', color: '#fff', fontWeight: 600, fontSize: 12, cursor: 'pointer' }}
                >Apply ({selected.length || 'default'})</button>
              </div>
            </div>
          </div>
        )
      })()}

      {/* Seed Results Modal */}
      {seedResultsModal && (() => {
        const { objectName, tab } = seedResultsModal
        const st = seedingStatus[objectName]
        if (!st) return null
        const insertResults = st.insertResults || []
        const updateResults = st.updateResults || []
        const errorRecords = [
          ...(st.error ? [{ operation: 'Error', message: typeof st.error === 'string' ? st.error : JSON.stringify(st.error), sourceId: '', destId: '', key: 'top_error' }] : []),
          ...insertResults.filter(r => !r.success).map(r => ({ ...r, operation: 'Insert' })),
          ...updateResults.filter(r => !r.success).map(r => ({ ...r, operation: 'Update' })),
          ...(st.errors || []).map((e, i) => ({ operation: 'Error', message: typeof e === 'string' ? e : e.message || JSON.stringify(e), sourceId: '', destId: '', key: `e${i}` })),
        ]
        const successInserts = insertResults.filter(r => r.success)
        const successUpdates = updateResults.filter(r => r.success)
        const activeTab = tab
        return (
          <div style={{
            position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.35)', zIndex: 1000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }} onClick={() => setSeedResultsModal(null)}>
            <div style={{
              background: '#fff', borderRadius: 10, padding: 0, width: 800, maxWidth: '92vw',
              maxHeight: '80vh', display: 'flex', flexDirection: 'column',
              boxShadow: '0 10px 40px rgba(0,0,0,0.2)',
            }} onClick={e => e.stopPropagation()}>
              {/* Header */}
              <div style={{
                padding: '14px 18px', borderBottom: '1px solid #e5e7eb',
                display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              }}>
                <span style={{ fontWeight: 700, fontSize: 15, color: '#1f2937' }}>
                  {objectName} — Seed Results
                </span>
                <span
                  onClick={() => setSeedResultsModal(null)}
                  style={{ cursor: 'pointer', fontSize: 18, color: '#9ca3af', fontWeight: 700, lineHeight: 1 }}
                >&times;</span>
              </div>
              {/* Tabs */}
              <div style={{ display: 'flex', borderBottom: '1px solid #e5e7eb' }}>
                {[
                  { key: 'insert', label: `Inserted (${successInserts.length})`, color: '#059669' },
                  { key: 'update', label: `Updated (${successUpdates.length})`, color: '#2563eb' },
                  { key: 'errors', label: `Errors (${errorRecords.length})`, color: '#ef4444' },
                ].map(t => (
                  <div
                    key={t.key}
                    onClick={() => setSeedResultsModal(p => ({ ...p, tab: t.key }))}
                    style={{
                      padding: '10px 20px', cursor: 'pointer', fontSize: 12, fontWeight: 600,
                      color: activeTab === t.key ? t.color : '#6b7280',
                      borderBottom: activeTab === t.key ? `2px solid ${t.color}` : '2px solid transparent',
                    }}
                  >{t.label}</div>
                ))}
              </div>
              {/* Content */}
              <div style={{ flex: 1, overflowY: 'auto', height: 400, minHeight: 400 }}>
                {activeTab === 'insert' && (
                  successInserts.length > 0 ? (
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                      <thead>
                        <tr style={{ background: '#f0fdf4', position: 'sticky', top: 0 }}>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>#</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Source Id</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Destination Id</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {successInserts.map((r, i) => (
                          <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                            <td style={{ padding: '5px 12px', color: '#6b7280' }}>{i + 1}</td>
                            <td style={{ padding: '5px 12px', fontFamily: 'monospace', color: '#374151' }}>{r.sourceId}</td>
                            <td style={{ padding: '5px 12px', fontFamily: 'monospace', color: '#059669' }}>{r.destId}</td>
                            <td style={{ padding: '5px 12px', color: '#059669', fontWeight: 600 }}>Created</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : <div style={{ padding: 20, color: '#9ca3af', fontSize: 12 }}>No records inserted</div>
                )}
                {activeTab === 'update' && (
                  successUpdates.length > 0 ? (
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                      <thead>
                        <tr style={{ background: '#eff6ff', position: 'sticky', top: 0 }}>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>#</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Source Id</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Destination Id</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {successUpdates.map((r, i) => (
                          <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                            <td style={{ padding: '5px 12px', color: '#6b7280' }}>{i + 1}</td>
                            <td style={{ padding: '5px 12px', fontFamily: 'monospace', color: '#374151' }}>{r.sourceId}</td>
                            <td style={{ padding: '5px 12px', fontFamily: 'monospace', color: '#2563eb' }}>{r.destId}</td>
                            <td style={{ padding: '5px 12px', color: '#2563eb', fontWeight: 600 }}>Updated</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : <div style={{ padding: 20, color: '#9ca3af', fontSize: 12 }}>No records updated</div>
                )}
                {activeTab === 'errors' && (
                  errorRecords.length > 0 ? (
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                      <thead>
                        <tr style={{ background: '#fef2f2', position: 'sticky', top: 0 }}>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>#</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Operation</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Source Id</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Status Code</th>
                          <th style={{ padding: '6px 12px', textAlign: 'left', fontWeight: 600, borderBottom: '1px solid #e5e7eb' }}>Error Message</th>
                        </tr>
                      </thead>
                      <tbody>
                        {errorRecords.map((r, i) => (
                          <tr key={r.key || i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                            <td style={{ padding: '5px 12px', color: '#6b7280' }}>{i + 1}</td>
                            <td style={{ padding: '5px 12px', color: '#374151', fontWeight: 600 }}>{r.operation}</td>
                            <td style={{ padding: '5px 12px', fontFamily: 'monospace', color: '#374151' }}>{r.sourceId || '—'}</td>
                            <td style={{ padding: '5px 12px', color: '#ef4444', fontFamily: 'monospace' }}>{r.statusCode || '—'}</td>
                            <td style={{ padding: '5px 12px', color: '#ef4444', maxWidth: 350, wordBreak: 'break-word' }}>{r.message}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : <div style={{ padding: 20, color: '#9ca3af', fontSize: 12 }}>No errors</div>
                )}
              </div>
            </div>
          </div>
        )
      })()}
    </div>
  )
}

export default forwardRef(SandboxSeedingPanel)
