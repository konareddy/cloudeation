import React, { useState, useRef, useCallback, useEffect } from 'react'
import { getConnectionIcon } from './ConnectionSelect.jsx'
import { connectionDisplayName } from './ConnectionModal.jsx'
import { THEMES, FONTS, FONT_LABELS, DEFAULT_SETTINGS } from './SettingsPanel.jsx'

const USAGE_TOGGLES = [
  { value: 'extract', label: 'Extract', color: '#3b82f6' },
  { value: 'transform', label: 'Transform', color: '#8b5cf6' },
  { value: 'source', label: 'Source', color: '#f59e0b' },
  { value: 'target', label: 'Target', color: '#10b981' },
]

// Default usage when field is missing or not an array
export function getUsage(conn) {
  if (Array.isArray(conn.usage)) return conn.usage
  return ['extract', 'transform', 'source', 'target']
}

const CONFIG_TABS = [
  { id: 'connections', label: 'Connections', icon: <svg width="15" height="15" viewBox="0 0 14 14" fill="none"><circle cx="4" cy="4" r="2" stroke="currentColor" strokeWidth="1.3"/><circle cx="10" cy="10" r="2" stroke="currentColor" strokeWidth="1.3"/><path d="M5.5 5.5l3 3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg> },
  { id: 'ai', label: 'AI Assistant', icon: <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M8 1v3M8 12v3M1 8h3M12 8h3M3.05 3.05l2.12 2.12M10.83 10.83l2.12 2.12M3.05 12.95l2.12-2.12M10.83 5.17l2.12-2.12"/></svg> },
  { id: 'bulk', label: 'Bulk Operations', icon: <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3"><path d="M2 3h12M2 8h12M2 13h12" strokeLinecap="round"/></svg> },
  { id: 'seed', label: 'Sandbox Seeding', icon: <svg width="15" height="15" viewBox="0 0 14 14" fill="none"><path d="M7 1v3M5 3.5l2 1 2-1" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M3 6.5c0 0 1-1 4-1s4 1 4 1v4c0 1-1.5 2.5-4 2.5S3 11.5 3 10.5v-4z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg> },
  { id: 'appearance', label: 'Appearance', icon: <svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3"><path d="M8 1a7 7 0 100 14 3.5 3.5 0 003.5-3.5c0-.73-.22-1.41-.6-1.97A1.5 1.5 0 0112 8h1.5A5.5 5.5 0 008 2.5" strokeLinecap="round"/><circle cx="5" cy="5.5" r="1" fill="currentColor" stroke="none"/><circle cx="8.5" cy="4" r="1" fill="currentColor" stroke="none"/><circle cx="11" cy="6.5" r="1" fill="currentColor" stroke="none"/><circle cx="5" cy="9" r="1" fill="currentColor" stroke="none"/></svg> },
]

const BULK_DEFAULTS = {
  sfUploadBatchSize: 200,
  dbInsertBatchSize: 500,
  bulkApiThreshold: 250,
  pkChunkSize: 50000,
  requestTimeout: 300,
  errorDisplayLimit: 200,
  parallelWorkers: 2,
}

export default function ConnectionsPanel({
  sfConnections, dbConnections,
  onEdit, onDeleteSf, onDeleteDb, onAdd,
  onUpdateUsage, onUpdateTablePrefix,
  settings, onUpdateSettings,
}) {
  const [configTab, setConfigTab] = useState('connections')
  const [confirmDelete, setConfirmDelete] = useState(null)
  const [localPrefixes, setLocalPrefixes] = useState({})
  const prefixTimerRef = useRef({})

  // AI Settings state
  const [aiKey, setAiKey] = useState('')
  const [aiModel, setAiModel] = useState('gemini-2.0-flash')
  const [showAiKey, setShowAiKey] = useState(false)
  const [hasAiKey, setHasAiKey] = useState(false)
  const [aiSaving, setAiSaving] = useState(false)
  const [aiSaved, setAiSaved] = useState(false)
  const [maskedAiKey, setMaskedAiKey] = useState('')

  // Bulk settings state
  const [bulkSettings, setBulkSettings] = useState(BULK_DEFAULTS)
  const [bulkSaving, setBulkSaving] = useState(false)
  const [bulkSaved, setBulkSaved] = useState(false)

  // Seed settings state
  const [seedSettings, setSeedSettings] = useState({ emailSuffix: '.drseed', skipSystemRefs: true, includeRecordTypeId: true, recordLoadOptions: [10, 25, 50, 100, 200, 500, 1000, 2000] })
  const [newLoadOption, setNewLoadOption] = useState('')
  const [seedSaving, setSeedSaving] = useState(false)
  const [seedSaved, setSeedSaved] = useState(false)

  useEffect(() => {
    fetch('/api/ai/settings')
      .then(r => r.json())
      .then(data => {
        setHasAiKey(!!data.hasKey)
        setAiModel(data.model || 'gemini-2.0-flash')
        if (data.hasKey) setMaskedAiKey(data.apiKey || '****')
      })
      .catch(() => {})
    fetch('/api/bulk-settings')
      .then(r => r.json())
      .then(data => setBulkSettings(prev => ({ ...prev, ...data })))
      .catch(() => {})
    fetch('/api/seed/settings')
      .then(r => r.json())
      .then(data => setSeedSettings(prev => ({ ...prev, ...data })))
      .catch(() => {})
  }, [])

  const handleSaveAiSettings = async () => {
    setAiSaving(true)
    setAiSaved(false)
    const payload = { model: aiModel }
    if (aiKey.trim()) payload.apiKey = aiKey.trim()
    try {
      await fetch('/api/ai/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (aiKey.trim()) { setHasAiKey(true); setMaskedAiKey('****' + aiKey.slice(-4)); setAiKey('') }
      setAiSaved(true)
      setTimeout(() => setAiSaved(false), 2000)
    } catch { /* ignore */ }
    setAiSaving(false)
  }

  const handleSaveBulkSettings = async () => {
    setBulkSaving(true)
    setBulkSaved(false)
    try {
      await fetch('/api/bulk-settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bulkSettings),
      })
      setBulkSaved(true)
      setTimeout(() => setBulkSaved(false), 2000)
    } catch { /* ignore */ }
    setBulkSaving(false)
  }

  const handleSaveSeedSettings = async () => {
    setSeedSaving(true)
    setSeedSaved(false)
    try {
      await fetch('/api/seed/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(seedSettings),
      })
      setSeedSaved(true)
      setTimeout(() => setSeedSaved(false), 2000)
    } catch { /* ignore */ }
    setSeedSaving(false)
  }

  const updateBulk = (key, value) => {
    setBulkSettings(prev => ({ ...prev, [key]: value === '' ? '' : parseInt(value) || 0 }))
  }

  const handlePrefixChange = useCallback((conn, value) => {
    setLocalPrefixes(prev => ({ ...prev, [conn.id]: value }))
    clearTimeout(prefixTimerRef.current[conn.id])
    prefixTimerRef.current[conn.id] = setTimeout(() => {
      onUpdateTablePrefix(conn, value)
    }, 500)
  }, [onUpdateTablePrefix])

  const getPrefixValue = (conn) => {
    return conn.id in localPrefixes ? localPrefixes[conn.id] : (conn.tablePrefix || '')
  }

  const getSubtitle = (conn) => {
    if (conn.loginUrl) return conn.loginUrl
    if (conn.dbType === 'athena') return `${conn.region || ''} / ${conn.database || ''}`
    return `${conn.host || ''}:${conn.port || ''}/${conn.database || ''}`
  }

  const toggleUsage = (conn, flag) => {
    const current = getUsage(conn)
    let next
    if (current.includes(flag)) {
      next = current.filter(f => f !== flag)
    } else {
      next = [...current, flag]
    }
    onUpdateUsage(conn, next)
  }

  const renderToggle = (conn, opt, current) => {
    const on = current.includes(opt.value)
    return (
      <div
        key={opt.value}
        title={opt.label}
        onClick={() => toggleUsage(conn, opt.value)}
        style={{
          display: 'flex', alignItems: 'center', gap: 6,
          cursor: 'pointer',
        }}
      >
        <span
          style={{
            position: 'relative',
            width: 36,
            height: 20,
            borderRadius: 10,
            background: on ? opt.color : '#d1d5db',
            transition: 'background 0.15s',
            display: 'inline-block',
            flexShrink: 0,
          }}
        >
          <span style={{
            position: 'absolute',
            top: 2,
            left: on ? 18 : 2,
            width: 16,
            height: 16,
            borderRadius: '50%',
            background: '#fff',
            boxShadow: '0 1px 3px rgba(0,0,0,0.25)',
            transition: 'left 0.15s',
          }} />
        </span>
        <span style={{ fontSize: 11, fontWeight: 600, color: on ? opt.color : '#9ca3af', userSelect: 'none' }}>
          {opt.label}
        </span>
      </div>
    )
  }

  const renderUsageToggles = (conn) => {
    const current = getUsage(conn)
    const hasExtract = current.includes('extract')
    const extractOpt = USAGE_TOGGLES.find(o => o.value === 'extract')
    const transformOpt = USAGE_TOGGLES.find(o => o.value === 'transform')
    const sourceOpt = USAGE_TOGGLES.find(o => o.value === 'source')
    const targetOpt = USAGE_TOGGLES.find(o => o.value === 'target')
    return (
      <div style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }} onClick={e => e.stopPropagation()}>
        {/* Extract toggle — fixed width slot */}
        <div style={{ width: 90, flexShrink: 0 }}>
          {renderToggle(conn, extractOpt, current)}
        </div>
        {/* Prefix input — fixed width slot, always takes space for alignment */}
        <div style={{ width: 220, flexShrink: 0, display: 'flex', alignItems: 'center', gap: 6 }} onClick={e => e.stopPropagation()}>
          {hasExtract && (
            <>
              <input
                className="form-input"
                value={getPrefixValue(conn)}
                onChange={e => handlePrefixChange(conn, e.target.value)}
                placeholder="table prefix"
                title="Prefix prepended to table names when importing to a database"
                style={{ width: 100, padding: '2px 6px', fontSize: 11, height: 22, borderRadius: 4 }}
              />
              {getPrefixValue(conn) && (
                <span style={{ fontSize: 10, color: '#64748b', fontFamily: 'monospace', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                  {getPrefixValue(conn)}account
                </span>
              )}
            </>
          )}
        </div>
        {/* Transform toggle — fixed width slot */}
        <div style={{ width: 110, flexShrink: 0 }}>
          {renderToggle(conn, transformOpt, current)}
        </div>
        {/* Load section */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 6,
          borderLeft: '1px solid #e5e7eb',
          paddingLeft: 10, flexShrink: 0,
        }}>
          <span style={{ fontSize: 11, fontWeight: 700, color: '#6b7280', userSelect: 'none', marginRight: 2 }}>Load</span>
          {renderToggle(conn, sourceOpt, current)}
          {renderToggle(conn, targetOpt, current)}
        </div>
      </div>
    )
  }

  const renderCard = (conn, deleteFn) => {
    return (
      <div
        key={conn.id}
        className="conn-card"
        style={{
          border: '1px solid #e5e7eb',
          borderRadius: 10,
          padding: '14px 16px',
          background: '#fff',
          display: 'flex',
          alignItems: 'center',
          gap: 12,
          transition: 'all 0.15s',
        }}
      >
        <span style={{ display: 'flex', alignItems: 'center', flexShrink: 0 }}>
          {getConnectionIcon(conn)}
        </span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: 13, color: '#1f2937' }}>
            {conn.name}
          </div>
          <div style={{ fontSize: 11, color: '#6b7280', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {getSubtitle(conn)}
          </div>
        </div>
        {renderUsageToggles(conn)}
        <div style={{ display: 'flex', gap: 6, flexShrink: 0, alignItems: 'center', position: 'relative' }}>
          <button
            onClick={() => onEdit(conn)}
            title="Edit"
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, borderRadius: 6, display: 'flex', alignItems: 'center', color: '#6b7280', transition: 'color 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.color = '#2563eb'}
            onMouseLeave={e => e.currentTarget.style.color = '#6b7280'}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M11.5 2.5a1.41 1.41 0 0 1 2 2L5.17 12.83l-2.83.67.67-2.83L11.5 2.5z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          <button
            onClick={() => setConfirmDelete(confirmDelete === conn.id ? null : conn.id)}
            title="Delete"
            style={{ background: 'none', border: 'none', cursor: 'pointer', padding: 4, borderRadius: 6, display: 'flex', alignItems: 'center', color: confirmDelete === conn.id ? '#ef4444' : '#9ca3af', transition: 'color 0.15s' }}
            onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
            onMouseLeave={e => { if (confirmDelete !== conn.id) e.currentTarget.style.color = '#9ca3af' }}
          >
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 4h12M5.33 4V2.67a1.33 1.33 0 0 1 1.34-1.34h2.66a1.33 1.33 0 0 1 1.34 1.34V4M6.67 7.33v4M9.33 7.33v4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M3.33 4h9.34l-.67 9.33a1.33 1.33 0 0 1-1.33 1.34H5.33A1.33 1.33 0 0 1 4 13.33L3.33 4z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </button>
          {confirmDelete === conn.id && (
            <div
              style={{
                position: 'absolute', top: '100%', right: 0, marginTop: 6, zIndex: 100,
                background: '#fff', borderRadius: 10, padding: '14px 18px',
                boxShadow: '0 4px 20px rgba(0,0,0,0.15)', border: '1px solid #e5e7eb',
                whiteSpace: 'nowrap', display: 'flex', flexDirection: 'column', gap: 10, minWidth: 200,
              }}
              onClick={e => e.stopPropagation()}
            >
              <div style={{ fontSize: 13, fontWeight: 600, color: '#1f2937' }}>Delete connection?</div>
              <div style={{ fontSize: 12, color: '#6b7280' }}>
                This will remove <strong>{conn.name}</strong> permanently.
              </div>
              <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
                <button
                  onClick={() => setConfirmDelete(null)}
                  style={{ padding: '5px 14px', fontSize: 12, borderRadius: 6, border: '1px solid #d1d5db', background: '#fff', color: '#374151', cursor: 'pointer', fontWeight: 500 }}
                >
                  Cancel
                </button>
                <button
                  onClick={() => { deleteFn(conn.id); setConfirmDelete(null) }}
                  style={{ padding: '5px 14px', fontSize: 12, borderRadius: 6, border: 'none', background: '#ef4444', color: '#fff', cursor: 'pointer', fontWeight: 600 }}
                >
                  Delete
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  // Group DB connections by product
  const dbGroups = [
    { key: 'postgres', label: 'PostgreSQL', conns: dbConnections.filter(c => !c.dbType || c.dbType === 'postgres') },
    { key: 'mysql', label: 'MySQL', conns: dbConnections.filter(c => c.dbType === 'mysql') },
    { key: 'athena', label: 'Athena', conns: dbConnections.filter(c => c.dbType === 'athena') },
    { key: 'redshift', label: 'Redshift', conns: dbConnections.filter(c => c.dbType === 'redshift') },
  ].filter(g => g.conns.length > 0)

  const sectionHeader = (label) => (
    <h3 style={{ fontSize: 13, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 10 }}>
      {label}
    </h3>
  )

  // ── Save button (consistent style) ──
  const renderSaveBtn = (onClick, saving, saved, extra) => (
    <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
      <button
        className="btn btn-primary"
        onClick={onClick}
        disabled={saving}
        style={{ fontSize: 12, padding: '6px 20px' }}
      >
        {saving ? 'Saving...' : saved ? 'Saved!' : 'Save Settings'}
      </button>
      {extra}
    </div>
  )

  // ── Connections content ──
  const connectionsContent = (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, fontSize: 11, color: '#6b7280' }}>
          <span style={{ fontWeight: 600 }}>Show in:</span>
          <span style={{ color: '#3b82f6', fontWeight: 700 }}>Extract</span>
          <span style={{ color: '#8b5cf6', fontWeight: 700 }}>Transform</span>
          <span style={{ borderLeft: '1px solid #d1d5db', paddingLeft: 12, display: 'flex', gap: 10, alignItems: 'center' }}>
            <span style={{ fontWeight: 700, color: '#374151' }}>Load:</span>
            <span><span style={{ color: '#f59e0b', fontWeight: 700 }}>Source</span></span>
            <span><span style={{ color: '#10b981', fontWeight: 700 }}>Target</span></span>
          </span>
        </div>
        <button className="btn btn-primary" style={{ fontSize: 12, padding: '6px 14px' }} onClick={onAdd}>
          + Add Connection
        </button>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', minHeight: 0 }}>
        {/* Salesforce */}
        <div style={{ marginBottom: 20 }}>
          {sectionHeader('Salesforce')}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {sfConnections.length > 0
              ? sfConnections.map(c => renderCard(c, onDeleteSf))
              : <div style={{ padding: '16px 0', textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>No Salesforce connections yet.</div>
            }
          </div>
        </div>
        {/* DB groups by product */}
        {dbGroups.map(group => (
          <div key={group.key} style={{ marginBottom: 20 }}>
            {sectionHeader(group.label)}
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {group.conns.map(c => renderCard(c, onDeleteDb))}
            </div>
          </div>
        ))}
        {dbConnections.length === 0 && (
          <div>
            {sectionHeader('Database')}
            <div style={{ padding: '16px 0', textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>No database connections yet.</div>
          </div>
        )}
      </div>
    </div>
  )

  // ── AI content ──
  const aiContent = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span style={{
          width: 8, height: 8, borderRadius: '50%', display: 'inline-block',
          background: hasAiKey ? '#10b981' : '#ef4444',
        }} />
        <span style={{ fontSize: 12, color: hasAiKey ? '#10b981' : '#6b7280', fontWeight: 600 }}>
          {hasAiKey ? 'API Key Configured' : 'API Key Not Configured'}
        </span>
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
          Gemini API Key {hasAiKey && <span style={{ color: '#9ca3af', fontWeight: 400 }}>({maskedAiKey})</span>}
        </label>
        <div style={{ display: 'flex', gap: 6 }}>
          <input
            type={showAiKey ? 'text' : 'password'}
            className="form-input"
            value={aiKey}
            onChange={e => setAiKey(e.target.value)}
            placeholder={hasAiKey ? 'Enter new key to replace...' : 'Paste your Gemini API key'}
            style={{ flex: 1, fontSize: 12, padding: '7px 10px' }}
          />
          <button
            onClick={() => setShowAiKey(p => !p)}
            style={{ background: '#fff', border: '1px solid #d1d5db', borderRadius: 4, cursor: 'pointer', padding: '0 10px', fontSize: 11, color: '#6b7280' }}
          >{showAiKey ? 'Hide' : 'Show'}</button>
        </div>
        <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 6 }}>
          Free API key from <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener noreferrer" style={{ color: '#2563eb' }}>Google AI Studio</a>. Powers the AI SQL assistant in Transform tab.
        </div>
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Model</label>
        <select className="form-input" value={aiModel} onChange={e => setAiModel(e.target.value)} style={{ fontSize: 12, padding: '7px 10px', maxWidth: 300 }}>
          <option value="gemini-2.0-flash">Gemini 2.0 Flash (Fast)</option>
          <option value="gemini-2.0-flash-lite">Gemini 2.0 Flash Lite (Fastest)</option>
          <option value="gemini-1.5-pro">Gemini 1.5 Pro (Most capable)</option>
        </select>
      </div>

      {renderSaveBtn(handleSaveAiSettings, aiSaving, aiSaved)}
    </div>
  )

  // ── Bulk operations content ──
  const bulkField = (label, key, desc, min, max) => (
    <div>
      <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>{label}</label>
      <input
        type="number"
        className="form-input"
        value={bulkSettings[key]}
        onChange={e => updateBulk(key, e.target.value)}
        min={min} max={max}
        style={{ width: '100%', fontSize: 12, padding: '7px 10px' }}
      />
      <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 3 }}>{desc}</div>
    </div>
  )

  const bulkContent = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ fontSize: 12, color: '#6b7280' }}>
        These settings control how data is batched during extract and load operations. Changes apply to the next operation.
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px 24px' }}>
        {bulkField('SF Upload Batch Size', 'sfUploadBatchSize', `Records per batch when loading to Salesforce (default: ${BULK_DEFAULTS.sfUploadBatchSize})`, 1, 10000)}
        {bulkField('DB Insert Batch Size', 'dbInsertBatchSize', `Records per batch when inserting into database (default: ${BULK_DEFAULTS.dbInsertBatchSize})`, 1, 50000)}
        {bulkField('Bulk API Threshold', 'bulkApiThreshold', `Use Salesforce Bulk API when record count exceeds this value. Below it, REST API is used (default: ${BULK_DEFAULTS.bulkApiThreshold})`, 0, 100000)}
        {bulkField('PK Chunk Size', 'pkChunkSize', `Records per PK Chunking batch. Salesforce splits large queries into parallel chunks of this size. Use 25K-50K for wide objects, 50K-100K for narrow ones (default: ${BULK_DEFAULTS.pkChunkSize.toLocaleString()})`, 2000, 250000)}
        {bulkField('Request Timeout (seconds)', 'requestTimeout', `Maximum wait time per request for file download/upload operations (default: ${BULK_DEFAULTS.requestTimeout})`, 30, 3600)}
        {bulkField('Error Display Limit', 'errorDisplayLimit', `Maximum number of error details retained in job results (default: ${BULK_DEFAULTS.errorDisplayLimit})`, 10, 10000)}
        {bulkField('Parallel Workers', 'parallelWorkers', `Number of objects extracted in parallel during SF Extract jobs (default: ${BULK_DEFAULTS.parallelWorkers})`, 1, 8)}
      </div>

      {renderSaveBtn(handleSaveBulkSettings, bulkSaving, bulkSaved,
        <button
          className="btn btn-secondary"
          onClick={() => setBulkSettings({ ...BULK_DEFAULTS })}
          style={{ fontSize: 12, padding: '6px 14px' }}
        >
          Reset Defaults
        </button>
      )}
    </div>
  )

  // ── Seed settings content ──
  const seedContent = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div style={{ fontSize: 12, color: '#6b7280' }}>
        Configure how sandbox seeding handles email fields and record types.
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Email Suffix</label>
        <input
          type="text"
          className="form-input"
          value={seedSettings.emailSuffix}
          onChange={e => setSeedSettings(prev => ({ ...prev, emailSuffix: e.target.value }))}
          placeholder=".drseed"
          style={{ width: '100%', maxWidth: 300, fontSize: 12, padding: '7px 10px' }}
        />
        <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 3 }}>
          Appended to email fields during seeding to prevent real email delivery (default: .drseed)
        </div>
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={seedSettings.skipSystemRefs}
            onChange={e => setSeedSettings(prev => ({ ...prev, skipSystemRefs: e.target.checked }))}
          />
          Skip system reference fields
        </label>
        <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 3, marginLeft: 24 }}>
          Hide dependencies for OwnerId, CreatedById, LastModifiedById, ProfileId, etc.
        </div>
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
          <input
            type="checkbox"
            checked={seedSettings.includeRecordTypeId}
            onChange={e => setSeedSettings(prev => ({ ...prev, includeRecordTypeId: e.target.checked }))}
          />
          Include RecordTypeId in all seed operations
        </label>
        <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 3, marginLeft: 24 }}>
          Automatically include RecordTypeId when seeding records
        </div>
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 6 }}>Records to Load Options</label>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 8 }}>
          {(seedSettings.recordLoadOptions || []).sort((a, b) => a - b).map(n => (
            <span key={n} style={{
              display: 'inline-flex', alignItems: 'center', gap: 4,
              fontSize: 12, background: '#f3f4f6', border: '1px solid #e5e7eb',
              borderRadius: 6, padding: '3px 8px 3px 10px', color: '#374151', fontWeight: 500,
            }}>
              {n.toLocaleString()}
              <span
                onClick={() => setSeedSettings(prev => ({ ...prev, recordLoadOptions: (prev.recordLoadOptions || []).filter(v => v !== n) }))}
                style={{ cursor: 'pointer', color: '#9ca3af', fontWeight: 700, fontSize: 14, lineHeight: 1, marginLeft: 2 }}
                onMouseEnter={e => e.currentTarget.style.color = '#ef4444'}
                onMouseLeave={e => e.currentTarget.style.color = '#9ca3af'}
              >&times;</span>
            </span>
          ))}
        </div>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          <input
            type="number"
            className="form-input"
            value={newLoadOption}
            onChange={e => setNewLoadOption(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && newLoadOption.trim()) {
                const num = parseInt(newLoadOption)
                if (num > 0 && !(seedSettings.recordLoadOptions || []).includes(num)) {
                  setSeedSettings(prev => ({ ...prev, recordLoadOptions: [...(prev.recordLoadOptions || []), num] }))
                }
                setNewLoadOption('')
              }
            }}
            placeholder="e.g. 5000"
            style={{ width: 120, fontSize: 12, padding: '6px 10px' }}
            min="1"
          />
          <button
            onClick={() => {
              const num = parseInt(newLoadOption)
              if (num > 0 && !(seedSettings.recordLoadOptions || []).includes(num)) {
                setSeedSettings(prev => ({ ...prev, recordLoadOptions: [...(prev.recordLoadOptions || []), num] }))
              }
              setNewLoadOption('')
            }}
            style={{
              padding: '6px 14px', borderRadius: 6, border: '1px solid #d1d5db',
              background: '#fff', fontSize: 12, cursor: 'pointer', color: '#374151', fontWeight: 500,
            }}
          >Add</button>
        </div>
        <div style={{ fontSize: 10, color: '#9ca3af', marginTop: 4 }}>
          These values appear in the "Records to Load" dropdown on the Sandbox Seeding tab
        </div>
      </div>

      {renderSaveBtn(handleSaveSeedSettings, seedSaving, seedSaved,
        <button
          className="btn btn-secondary"
          onClick={() => { setSeedSettings({ emailSuffix: '.drseed', skipSystemRefs: true, includeRecordTypeId: true, recordLoadOptions: [10, 25, 50, 100, 200, 500, 1000, 2000] }); setNewLoadOption('') }}
          style={{ fontSize: 12, padding: '6px 14px' }}
        >
          Reset Defaults
        </button>
      )}
    </div>
  )

  // ── Appearance content ──
  const appearanceContent = settings ? (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 8 }}>Theme</label>
        <div style={{ display: 'flex', gap: 8 }}>
          {THEMES.map(t => (
            <button
              key={t.id}
              onClick={() => onUpdateSettings({ theme: t.id })}
              style={{
                flex: 1, padding: '10px 4px',
                border: settings.theme === t.id ? '2px solid #2563eb' : '1px solid #d1d5db',
                borderRadius: 8, cursor: 'pointer', background: t.bg, color: t.text,
                fontSize: 12, fontWeight: 500, maxWidth: 120,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>Font Family</label>
        <select
          className="form-input"
          value={settings.fontFamily}
          onChange={e => onUpdateSettings({ fontFamily: e.target.value })}
          style={{ fontSize: 12, padding: '7px 10px', maxWidth: 300 }}
        >
          {FONTS.map((f, i) => <option key={f} value={f} style={{ fontFamily: f }}>{FONT_LABELS[i]}</option>)}
        </select>
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
          UI Font Size: {settings.fontSize}px
        </label>
        <input type="range" min="11" max="20" value={settings.fontSize}
          onChange={e => onUpdateSettings({ fontSize: parseInt(e.target.value) })}
          style={{ width: '100%', maxWidth: 300 }}
        />
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
          Editor Font Size: {settings.editorFontSize}px
        </label>
        <input type="range" min="10" max="22" value={settings.editorFontSize}
          onChange={e => onUpdateSettings({ editorFontSize: parseInt(e.target.value) })}
          style={{ width: '100%', maxWidth: 300 }}
        />
      </div>

      <div>
        <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
          Table Font Size: {settings.tableFontSize}px
        </label>
        <input type="range" min="9" max="18" value={settings.tableFontSize}
          onChange={e => onUpdateSettings({ tableFontSize: parseInt(e.target.value) })}
          style={{ width: '100%', maxWidth: 300 }}
        />
      </div>

      <div>
        <button
          className="btn btn-secondary"
          onClick={() => onUpdateSettings({ ...DEFAULT_SETTINGS })}
          style={{ fontSize: 12, padding: '6px 14px' }}
        >
          Reset to Defaults
        </button>
      </div>
    </div>
  ) : (
    <div style={{ fontSize: 12, color: '#9ca3af' }}>Settings not available.</div>
  )

  const tabContent = {
    connections: connectionsContent,
    ai: aiContent,
    bulk: bulkContent,
    seed: seedContent,
    appearance: appearanceContent,
  }

  return (
    <div style={{ display: 'flex', flex: 1, minHeight: 0, overflow: 'hidden' }}>
      {/* Left sidebar nav */}
      <div style={{
        width: 190, flexShrink: 0, borderRight: '1px solid #e5e7eb',
        padding: '16px 0', display: 'flex', flexDirection: 'column', gap: 2,
        background: '#fafbfc',
      }}>
        <div style={{ padding: '0 16px 12px', fontSize: 15, fontWeight: 700, color: '#1f2937' }}>
          Configuration
        </div>
        {CONFIG_TABS.map(tab => {
          const active = configTab === tab.id
          return (
            <button
              key={tab.id}
              data-tour={tab.id === 'ai' ? 'config-ai-tab' : tab.id === 'bulk' ? 'config-bulk-tab' : undefined}
              onClick={() => setConfigTab(tab.id)}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '8px 16px', fontSize: 12, fontWeight: active ? 600 : 500,
                background: active ? '#fff' : 'transparent',
                color: active ? '#2563eb' : '#4b5563',
                border: 'none', borderRight: active ? '2px solid #2563eb' : '2px solid transparent',
                borderLeft: 'none', cursor: 'pointer', textAlign: 'left',
                transition: 'all 0.1s',
              }}
            >
              <span style={{ color: active ? '#2563eb' : '#9ca3af', display: 'flex', flexShrink: 0 }}>{tab.icon}</span>
              {tab.label}
              {tab.id === 'ai' && (
                <span style={{
                  width: 6, height: 6, borderRadius: '50%', marginLeft: 'auto', flexShrink: 0,
                  background: hasAiKey ? '#10b981' : '#ef4444',
                }} />
              )}
            </button>
          )
        })}
      </div>

      {/* Right content area */}
      <div style={{ flex: 1, padding: 20, overflowY: 'auto', minHeight: 0 }}>
        {tabContent[configTab]}
      </div>
    </div>
  )
}
