import React, { useState, useEffect, useCallback, useRef } from 'react'
import ReactDOM from 'react-dom'

const TOUR_STEPS = [
  {
    target: 'header',
    title: 'Welcome to Cloudeation Data Rover',
    description: 'Your all-in-one ETL tool for Salesforce and database operations. Let\'s take a quick tour of the key features.',
    placement: 'bottom',
  },
  {
    target: 'tabs',
    title: 'Navigation Tabs',
    description: 'Switch between Extract (Salesforce), Transform (databases), Load (to Salesforce), Files (attachments), and Monitoring (active tasks). Configuration is on the right.',
    placement: 'bottom',
  },
  {
    target: 'connection-select',
    title: 'Choose Your Connection',
    description: 'Select a Salesforce org or database connection from the dropdown. You can add new connections with the "+" button.',
    placement: 'right',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'search-objects',
    title: 'Search Objects & Tables',
    description: 'Quickly filter through Salesforce objects or database tables by typing a name. The sidebar list updates as you type.',
    placement: 'right',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'objects-list',
    title: 'Objects / Tables List',
    description: 'Browse all available objects or tables. Click one to auto-generate a SELECT query. Use the arrow icon to import directly to a database.',
    placement: 'right',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'query-editor',
    title: 'Query Editor',
    description: 'Write SOQL or SQL queries here. Enjoy autocomplete for object names and fields as you type.',
    placement: 'bottom',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'run-button',
    title: 'Run Your Query',
    description: 'Click Run (or press Ctrl+Enter) to execute your query and see results below.',
    placement: 'bottom',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'export-buttons',
    title: 'Export & Import Data',
    description: 'Export all records for the current object as CSV or Excel, or import them directly into a connected database.',
    placement: 'bottom',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'fields-tab',
    title: 'Fields Tab',
    description: 'View all fields for the selected object or table. Click a field name to add it to your query. Use "SELECT *" to add all fields at once.',
    placement: 'top',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'results-tab',
    title: 'Results Tab',
    description: 'Switch here after running a query to see your data. Results include record counts, elapsed time, and column details.',
    placement: 'top',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'results-area',
    title: 'Results Panel',
    description: 'View query results with pagination, resizable columns, and inline search. Scroll through your data right here.',
    placement: 'top',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
  },
  {
    target: 'results-toolbar',
    title: 'Search & Export Results',
    description: 'Search within results to filter rows. Export the current result set as CSV, Excel, or import it directly into a database.',
    placement: 'top',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
    optional: true,
  },
  {
    target: 'search-fields',
    title: 'Search Fields',
    description: 'Filter the fields list by name or type. Useful when working with objects that have hundreds of fields.',
    placement: 'top',
    onBeforeStep: (helpers) => helpers.setActiveTab('salesforce'),
    optional: true,
  },
  {
    target: 'ai-button',
    title: 'AI SQL Assistant',
    description: 'Click the AI button to open the AI assistant. Describe what you want in plain English and it generates the SQL query for you. Powered by Google Gemini (free).',
    placement: 'bottom',
    onBeforeStep: (helpers) => helpers.setActiveTab('database'),
    optional: true,
  },
  {
    target: 'config-tab',
    title: 'Configuration',
    description: 'Manage all your settings in one place: connections, AI assistant API key, and bulk operation parameters.',
    placement: 'bottom',
    onBeforeStep: (helpers) => helpers.setActiveTab('connections'),
  },
  {
    target: 'config-ai-tab',
    title: 'AI Assistant Settings',
    description: 'Configure your free Gemini API key here to enable the AI SQL assistant in the Transform tab. Choose between different Gemini models.',
    placement: 'right',
    onBeforeStep: (helpers) => helpers.setActiveTab('connections'),
    optional: true,
  },
  {
    target: 'config-bulk-tab',
    title: 'Bulk Operation Settings',
    description: 'Fine-tune batch sizes, API thresholds, and timeouts for data import/export operations. Adjust these to optimize performance for your use case.',
    placement: 'right',
    onBeforeStep: (helpers) => helpers.setActiveTab('connections'),
    optional: true,
  },
  {
    target: 'help-button',
    title: 'Replay This Tour',
    description: 'Click the "?" button anytime to replay this guided tour. Happy querying!',
    placement: 'bottom',
  },
]

const SANDBOX_STEPS = [
  {
    target: 'seed-template-bar',
    title: 'Templates',
    description: 'Create, save, and load seeding templates. Templates remember your object, connections, field selections, filters, and dependency configurations so you can reuse them.',
    placement: 'bottom',
  },
  {
    target: 'seed-connection-bar',
    title: 'Source & Destination',
    description: 'Select a Source org to read records from and a Destination org to seed records into. The Object dropdown lets you search and pick any Salesforce object.',
    placement: 'bottom',
  },
  {
    target: 'seed-filter',
    title: 'Filter Criteria',
    description: 'Use a WHERE clause to narrow down which records to seed (e.g. "Status = \'Active\'"). Set the number of records to load, then click Apply Filter to preview.',
    placement: 'bottom',
  },
  {
    target: 'seed-preview',
    title: 'Record Preview & Field Picker',
    description: 'Preview source records before seeding. Click "Fields" to open the field picker — all non-lookup fields are selected by default. Lookup fields stay on the left until you add them, which auto-detects dependencies.',
    placement: 'top',
  },
  {
    target: 'seed-dependencies',
    title: 'Auto-Detected Dependencies',
    description: 'When you include lookup fields (e.g. AccountId, ContactId), their parent objects appear here automatically. Nested dependencies are detected too (e.g. Account → Parent Account). Each dependency can be seeded independently.',
    placement: 'top',
    optional: true,
  },
  {
    target: 'seed-template-bar',
    title: 'Seeding Records',
    description: 'Click the green "Seed" button on any section to push records to the destination org. Email fields are automatically appended with a suffix (configurable in Settings) to prevent real email delivery. System fields like OwnerId are skipped.',
    placement: 'bottom',
  },
]

function getTooltipPosition(targetRect, placement) {
  const gap = 14
  const tooltipWidth = 320
  const tooltipHeight = 180 // estimated

  let top, left

  switch (placement) {
    case 'bottom':
      top = targetRect.bottom + gap
      left = targetRect.left + targetRect.width / 2 - tooltipWidth / 2
      break
    case 'top':
      top = targetRect.top - tooltipHeight - gap
      left = targetRect.left + targetRect.width / 2 - tooltipWidth / 2
      break
    case 'left':
      top = targetRect.top + targetRect.height / 2 - tooltipHeight / 2
      left = targetRect.left - tooltipWidth - gap
      break
    case 'right':
      top = targetRect.top + targetRect.height / 2 - tooltipHeight / 2
      left = targetRect.right + gap
      break
    default:
      top = targetRect.bottom + gap
      left = targetRect.left + targetRect.width / 2 - tooltipWidth / 2
  }

  // Clamp to viewport
  const margin = 12
  left = Math.max(margin, Math.min(left, window.innerWidth - tooltipWidth - margin))
  top = Math.max(margin, Math.min(top, window.innerHeight - tooltipHeight - margin))

  return { top, left }
}

function getArrowStyle(placement, targetRect, tooltipLeft) {
  const arrow = { position: 'absolute', width: 12, height: 12 }
  const arrowCenter = targetRect.left + targetRect.width / 2 - tooltipLeft - 6

  switch (placement) {
    case 'bottom':
      return { ...arrow, top: -6, left: Math.max(16, Math.min(arrowCenter, 320 - 28)), transform: 'rotate(45deg)' }
    case 'top':
      return { ...arrow, bottom: -6, left: Math.max(16, Math.min(arrowCenter, 320 - 28)), transform: 'rotate(45deg)' }
    case 'left':
      return { ...arrow, right: -6, top: '50%', marginTop: -6, transform: 'rotate(45deg)' }
    case 'right':
      return { ...arrow, left: -6, top: '50%', marginTop: -6, transform: 'rotate(45deg)' }
    default:
      return { ...arrow, top: -6, left: Math.max(16, Math.min(arrowCenter, 320 - 28)), transform: 'rotate(45deg)' }
  }
}

export default function GuidedTour({ isOpen, onClose, helpers, activeTab }) {
  const [currentStep, setCurrentStep] = useState(0)
  const [targetRect, setTargetRect] = useState(null)
  const rafRef = useRef(null)

  const steps = activeTab === 'sandbox' ? SANDBOX_STEPS : TOUR_STEPS
  const step = steps[currentStep]

  const updateTargetRect = useCallback(() => {
    if (!isOpen || !step) return
    const el = document.querySelector(`[data-tour="${step.target}"]`)
    if (el) {
      const rect = el.getBoundingClientRect()
      setTargetRect({ top: rect.top, left: rect.left, width: rect.width, height: rect.height, bottom: rect.bottom, right: rect.right })
    }
  }, [isOpen, step])

  const goToStep = useCallback((nextIdx, direction = 1) => {
    let idx = Math.max(0, Math.min(nextIdx, steps.length - 1))
    // Skip optional steps whose target element doesn't exist
    while (idx > 0 && idx < steps.length - 1) {
      const s = steps[idx]
      if (s.onBeforeStep) s.onBeforeStep(helpers)
      const el = document.querySelector(`[data-tour="${s.target}"]`)
      if (el || !s.optional) break
      idx += direction
    }
    setCurrentStep(Math.max(0, Math.min(idx, steps.length - 1)))
  }, [helpers, steps])

  // Run onBeforeStep and update rect when step changes
  useEffect(() => {
    if (!isOpen) return
    const s = steps[currentStep]
    if (s && s.onBeforeStep) {
      s.onBeforeStep(helpers)
    }
    // Small delay to allow DOM to update after tab switch, then check visibility
    const timer = setTimeout(() => {
      const el = document.querySelector(`[data-tour="${s.target}"]`)
      if (!el && s.optional) {
        // Skip this optional step
        setCurrentStep(prev => {
          const next = prev + 1
          return next < steps.length ? next : Math.max(prev - 1, 0)
        })
      } else {
        updateTargetRect()
      }
    }, 100)
    return () => clearTimeout(timer)
  }, [isOpen, currentStep, helpers, updateTargetRect, steps])

  // Continuously track target element position for resize/scroll
  useEffect(() => {
    if (!isOpen) return
    const tick = () => {
      updateTargetRect()
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [isOpen, updateTargetRect])

  // Reset step when tour opens
  useEffect(() => {
    if (isOpen) setCurrentStep(0)
  }, [isOpen])

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return
    const handleKey = (e) => {
      if (e.key === 'Escape') {
        onClose()
      } else if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
        e.preventDefault()
        goToStep(currentStep + 1, 1)
      } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
        e.preventDefault()
        goToStep(currentStep - 1, -1)
      }
    }
    window.addEventListener('keydown', handleKey)
    return () => window.removeEventListener('keydown', handleKey)
  }, [isOpen, onClose, currentStep, goToStep])

  if (!isOpen || !targetRect) return null

  const tooltipPos = getTooltipPosition(targetRect, step.placement)
  const arrowStyle = getArrowStyle(step.placement, targetRect, tooltipPos.left)
  const isLast = currentStep === steps.length - 1
  const isFirst = currentStep === 0
  const padding = 6

  return ReactDOM.createPortal(
    <div className="tour-overlay">
      {/* Spotlight */}
      <div
        className="tour-spotlight"
        style={{
          top: targetRect.top - padding,
          left: targetRect.left - padding,
          width: targetRect.width + padding * 2,
          height: targetRect.height + padding * 2,
        }}
        onClick={(e) => e.stopPropagation()}
      />

      {/* Click-away backdrop */}
      <div className="tour-backdrop" onClick={onClose} />

      {/* Tooltip */}
      <div className="tour-tooltip" style={{ top: tooltipPos.top, left: tooltipPos.left }}>
        <div className="tour-arrow" style={arrowStyle} />
        <div className="tour-tooltip-header">
          <span className="tour-step-badge">{currentStep + 1} / {steps.length}</span>
          <button className="tour-close-btn" onClick={onClose} title="Close tour">&times;</button>
        </div>
        <div className="tour-tooltip-body">
          <h3 className="tour-tooltip-title">{step.title}</h3>
          <p className="tour-tooltip-desc">{step.description}</p>
        </div>
        <div className="tour-tooltip-footer">
          {!isFirst ? (
            <button className="tour-btn tour-btn-secondary" onClick={() => goToStep(currentStep - 1, -1)}>Back</button>
          ) : <span />}
          {isLast ? (
            <button className="tour-btn tour-btn-primary" onClick={onClose}>Done</button>
          ) : (
            <button className="tour-btn tour-btn-primary" onClick={() => goToStep(currentStep + 1, 1)}>Next</button>
          )}
        </div>
      </div>
    </div>,
    document.body
  )
}
