import React from 'react'

export default function Sidebar({
  sfConnections, dbConnections,
  activeSfId, activeDbId,
  onSelectSf, onSelectDb,
  onAddSf, onAddDb,
  onEditSf, onEditDb,
  onDeleteSf, onDeleteDb,
}) {
  return (
    <aside className="sidebar">
      <div className="sidebar-section">
        <div className="sidebar-section-header">
          <h3>Salesforce</h3>
          <button className="btn-add" onClick={onAddSf} title="Add Salesforce connection">+</button>
        </div>
        {sfConnections.map(conn => (
          <div
            key={conn.id}
            className={`connection-item ${activeSfId === conn.id ? 'active' : ''}`}
            onClick={() => onSelectSf(conn.id)}
          >
            <span className={`connection-dot sf ${activeSfId === conn.id ? '' : 'inactive'}`} />
            <span className="connection-name">{conn.name}</span>
            <span className="connection-actions">
              <button className="btn-icon" onClick={e => { e.stopPropagation(); onEditSf(conn) }} title="Edit">&#9998;</button>
              <button className="btn-icon delete" onClick={e => { e.stopPropagation(); onDeleteSf(conn.id) }} title="Delete">&times;</button>
            </span>
          </div>
        ))}
        {sfConnections.length === 0 && (
          <div style={{ fontSize: 13, color: '#9ca3af', padding: '4px 10px' }}>No connections</div>
        )}
      </div>

      <div className="sidebar-section">
        <div className="sidebar-section-header">
          <h3>Databases</h3>
          <button className="btn-add" onClick={onAddDb} title="Add database connection">+</button>
        </div>
        {dbConnections.map(conn => (
          <div
            key={conn.id}
            className={`connection-item ${activeDbId === conn.id ? 'active' : ''}`}
            onClick={() => onSelectDb(conn.id)}
          >
            <span className={`connection-dot db ${activeDbId === conn.id ? '' : 'inactive'}`} />
            <span className="connection-name">{conn.name}</span>
            <span className="connection-actions">
              <button className="btn-icon" onClick={e => { e.stopPropagation(); onEditDb(conn) }} title="Edit">&#9998;</button>
              <button className="btn-icon delete" onClick={e => { e.stopPropagation(); onDeleteDb(conn.id) }} title="Delete">&times;</button>
            </span>
          </div>
        ))}
        {dbConnections.length === 0 && (
          <div style={{ fontSize: 13, color: '#9ca3af', padding: '4px 10px' }}>No connections</div>
        )}
      </div>
    </aside>
  )
}
