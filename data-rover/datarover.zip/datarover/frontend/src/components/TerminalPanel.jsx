import React, { useState, useRef, useEffect, useCallback } from 'react'

export default function TerminalPanel({
  sfConnections = [],
  dbConnections = [],
  activeSfId,
  activeDbId,
  activeDatabase,
  onSetActiveSfId,
  onSetActiveDbId,
  isFullScreen = false,
  onClose,
  onFullScreen,
}) {
  const [history, setHistory] = useState([
    { type: 'text', content: 'Data Rover Terminal. Type "help" for commands, "connections" to list connections, "databases" to list available databases.' },
  ])
  const [inputValue, setInputValue] = useState('')
  const [commandHistory, setCommandHistory] = useState([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const [isLoading, setIsLoading] = useState(false)
  const [completions, setCompletions] = useState([])
  const [completionIndex, setCompletionIndex] = useState(-1)
  const [localSfId, setLocalSfId] = useState(activeSfId)
  const [localDbId, setLocalDbId] = useState(activeDbId)
  const [localDatabase, setLocalDatabase] = useState(activeDatabase || '')

  const outputRef = useRef(null)
  const inputRef = useRef(null)
  const completionOriginal = useRef('')

  // Sync from props
  useEffect(() => { setLocalSfId(activeSfId) }, [activeSfId])
  useEffect(() => { setLocalDbId(activeDbId) }, [activeDbId])
  useEffect(() => { setLocalDatabase(activeDatabase || '') }, [activeDatabase])

  // Auto-scroll to bottom
  useEffect(() => {
    if (outputRef.current) {
      outputRef.current.scrollTop = outputRef.current.scrollHeight
    }
  }, [history])

  // Focus input on mount and after each command completes
  useEffect(() => {
    inputRef.current?.focus()
  }, [history, isLoading])

  const getContext = useCallback(() => ({
    sfConnectionId: localSfId || '',
    dbConnectionId: localDbId || '',
    database: localDatabase || '',
  }), [localSfId, localDbId, localDatabase])

  const addHistory = useCallback((entry) => {
    setHistory(prev => [...prev, entry])
  }, [])

  const handleSubmit = useCallback(async () => {
    const cmd = inputValue.trim()
    if (!cmd) return

    // Add to command history
    setCommandHistory(prev => {
      const filtered = prev.filter(c => c !== cmd)
      return [...filtered, cmd]
    })
    setHistoryIndex(-1)
    setCompletions([])

    // Add input to display
    addHistory({ type: 'input', content: cmd })
    setInputValue('')

    // Handle 'clear' locally
    if (cmd.toLowerCase() === 'clear') {
      setHistory([])
      return
    }

    setIsLoading(true)
    try {
      const resp = await fetch('/api/cli', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd, context: getContext() }),
      })
      const data = await resp.json()

      // Handle connection switching
      if (data.setConnection) {
        const { type, id } = data.setConnection
        if (type === 'sf') {
          setLocalSfId(id)
          onSetActiveSfId?.(id)
        } else if (type === 'db') {
          setLocalDbId(id)
          onSetActiveDbId?.(id)
        }
      }
      // Handle database switching
      if (data.setDatabase) {
        setLocalDatabase(data.setDatabase)
      }

      if (data.type === 'table') {
        addHistory({
          type: 'table',
          content: data.output || '',
          columns: data.columns || [],
          rows: data.rows || [],
        })
      } else if (data.type === 'error') {
        addHistory({ type: 'error', content: data.output || 'Error' })
      } else {
        addHistory({ type: 'text', content: data.output || '' })
      }
    } catch (err) {
      addHistory({ type: 'error', content: `Request failed: ${err.message}` })
    } finally {
      setIsLoading(false)
    }
  }, [inputValue, getContext, addHistory, onSetActiveSfId, onSetActiveDbId])

  const handleKeyDown = useCallback((e) => {
    if (e.key === 'Enter') {
      e.preventDefault()
      handleSubmit()
      return
    }

    if (e.key === 'ArrowUp') {
      e.preventDefault()
      if (commandHistory.length === 0) return
      const newIndex = historyIndex === -1
        ? commandHistory.length - 1
        : Math.max(0, historyIndex - 1)
      setHistoryIndex(newIndex)
      setInputValue(commandHistory[newIndex])
      setCompletions([])
      return
    }

    if (e.key === 'ArrowDown') {
      e.preventDefault()
      if (historyIndex === -1) return
      const newIndex = historyIndex + 1
      if (newIndex >= commandHistory.length) {
        setHistoryIndex(-1)
        setInputValue('')
      } else {
        setHistoryIndex(newIndex)
        setInputValue(commandHistory[newIndex])
      }
      setCompletions([])
      return
    }

    if (e.key === 'Tab') {
      e.preventDefault()
      handleTabCompletion()
      return
    }

    // Reset completions on any other key
    if (completions.length > 0 && e.key !== 'Shift') {
      setCompletions([])
      setCompletionIndex(-1)
    }
  }, [handleSubmit, commandHistory, historyIndex, completions])

  const handleTabCompletion = useCallback(async () => {
    if (completions.length > 0) {
      // Cycle through existing completions
      const nextIndex = (completionIndex + 1) % completions.length
      setCompletionIndex(nextIndex)
      const parts = completionOriginal.current.trim().split(/\s+/)
      if (parts.length <= 1) {
        setInputValue(completions[nextIndex] + ' ')
      } else {
        parts[parts.length - 1] = completions[nextIndex]
        setInputValue(parts.join(' ') + ' ')
      }
      return
    }

    // Fetch new completions
    completionOriginal.current = inputValue
    try {
      const resp = await fetch('/api/cli/completions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ partial: inputValue, context: getContext() }),
      })
      const data = await resp.json()
      const suggestions = data.suggestions || []
      if (suggestions.length === 0) return
      if (suggestions.length === 1) {
        const parts = inputValue.trim().split(/\s+/)
        if (parts.length <= 1) {
          setInputValue(suggestions[0] + ' ')
        } else {
          parts[parts.length - 1] = suggestions[0]
          setInputValue(parts.join(' ') + ' ')
        }
        return
      }
      setCompletions(suggestions)
      setCompletionIndex(0)
      const parts = inputValue.trim().split(/\s+/)
      if (parts.length <= 1) {
        setInputValue(suggestions[0] + ' ')
      } else {
        parts[parts.length - 1] = suggestions[0]
        setInputValue(parts.join(' ') + ' ')
      }
    } catch {
      // ignore
    }
  }, [inputValue, completions, completionIndex, getContext])

  // Resolve active connection names for the prompt
  const sfName = sfConnections.find(c => c.id === localSfId)?.name
  const dbName = dbConnections.find(c => c.id === localDbId)?.name
  const promptParts = []
  if (sfName) promptParts.push(`sf:${sfName}`)
  if (dbName) {
    const dbLabel = localDatabase ? `db:${dbName}/${localDatabase}` : `db:${dbName}`
    promptParts.push(dbLabel)
  }
  const prompt = promptParts.length > 0 ? `[${promptParts.join(' | ')}] >` : '>'

  return (
    <div className={`terminal-panel ${isFullScreen ? 'terminal-fullscreen' : ''}`} onClick={() => inputRef.current?.focus()}>
      <div className="terminal-header">
        <span className="terminal-title">Terminal</span>
        {completions.length > 1 && (
          <span className="terminal-completions">
            {completions.map((c, i) => (
              <span key={c} className={i === completionIndex ? 'terminal-completion-active' : 'terminal-completion'}>{c}</span>
            ))}
          </span>
        )}
        <div className="terminal-actions">
          {!isFullScreen && onFullScreen && (
            <button onClick={(e) => { e.stopPropagation(); onFullScreen() }} title="Open as tab" className="terminal-btn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="15 3 21 3 21 9" /><polyline points="9 21 3 21 3 15" />
                <line x1="21" y1="3" x2="14" y2="10" /><line x1="3" y1="21" x2="10" y2="14" />
              </svg>
            </button>
          )}
          <button onClick={(e) => { e.stopPropagation(); setHistory([]) }} title="Clear" className="terminal-btn">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2m3 0v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6h14" />
            </svg>
          </button>
          {onClose && (
            <button onClick={(e) => { e.stopPropagation(); onClose() }} title="Close" className="terminal-btn">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
              </svg>
            </button>
          )}
        </div>
      </div>
      <div className="terminal-output" ref={outputRef}>
        {history.map((entry, i) => (
          <TerminalLine key={i} entry={entry} />
        ))}
        {isLoading && <div className="terminal-line terminal-line-text" style={{ opacity: 0.5 }}>Running...</div>}
      </div>
      <div className="terminal-input-line">
        <span className="terminal-prompt">{prompt}</span>
        <input
          ref={inputRef}
          className="terminal-input"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type a command..."
          spellCheck={false}
          autoComplete="off"
          disabled={isLoading}
        />
      </div>
    </div>
  )
}

function TerminalLine({ entry }) {
  if (entry.type === 'input') {
    return <div className="terminal-line terminal-line-input">&gt; {entry.content}</div>
  }
  if (entry.type === 'error') {
    return <div className="terminal-line terminal-line-error">{entry.content}</div>
  }
  if (entry.type === 'table') {
    return (
      <div className="terminal-line">
        {entry.content && <div className="terminal-line-text">{entry.content}</div>}
        {entry.columns?.length > 0 && (
          <div className="terminal-table-wrapper">
            <table className="terminal-table">
              <thead>
                <tr>
                  {entry.columns.map(col => <th key={col}>{col}</th>)}
                </tr>
              </thead>
              <tbody>
                {entry.rows.slice(0, 100).map((row, i) => (
                  <tr key={i}>
                    {entry.columns.map(col => {
                      const val = row[col] ?? ''
                      const isId = col === 'ID' || col === '#'
                      return (
                        <td
                          key={col}
                          className={isId ? 'terminal-clickable' : ''}
                          onClick={isId ? () => {
                            navigator.clipboard.writeText(col === '#' ? `job ${val}` : val)
                          } : undefined}
                          title={isId ? 'Click to copy' : undefined}
                        >{val}</td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
            {entry.rows.length > 100 && (
              <div className="terminal-line-text" style={{ opacity: 0.6, marginTop: 4 }}>
                ... {entry.rows.length - 100} more rows
              </div>
            )}
          </div>
        )}
      </div>
    )
  }
  // text
  return <div className="terminal-line terminal-line-text">{entry.content}</div>
}
