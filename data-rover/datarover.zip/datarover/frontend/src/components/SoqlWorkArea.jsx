import React, { useState, useEffect, useRef } from 'react'
import ResizablePanel from './ResizablePanel.jsx'
import { ResizablePanelV } from './ResizablePanel.jsx'
import { connectionDisplayName } from './ConnectionModal.jsx'
import ConnectionSelect, { CsvIcon, DatabaseSelect, DbIcon, getConnectionIcon } from './ConnectionSelect.jsx'

// Color for the type-indicator bullet shown next to each field
const FIELD_TYPE_COLORS = {
  string: '#6366f1', phone: '#6366f1', email: '#6366f1', url: '#6366f1',
  encryptedstring: '#6366f1', combobox: '#6366f1',
  picklist: '#8b5cf6', multipicklist: '#8b5cf6',
  textarea: '#818cf8',
  id: '#3b82f6', reference: '#3b82f6',
  'double': '#22c55e', currency: '#22c55e', percent: '#22c55e', 'int': '#22c55e',
  'long': '#22c55e',
  boolean: '#f59e0b',
  date: '#f97316', datetime: '#f97316', time: '#f97316',
  address: '#9ca3af', location: '#9ca3af',
}
function fieldTypeColor(type) {
  return FIELD_TYPE_COLORS[(type || '').toLowerCase()] || '#d1d5db'
}

// Extract all object/table names from SOQL query (FROM clause)
function parseObjectsFromSoql(soql) {
  const match = soql.match(/\bFROM\s+([\s\S]+?)(?:\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
  if (!match) return []
  return match[1]
    .split(',')
    .map(part => part.trim().split(/\s+/)[0])
    .filter(name => name && /^\w+$/.test(name))
}

function parseObjectFromSoql(soql) {
  return parseObjectsFromSoql(soql)[0] || null
}

// Parse alias → table name mapping from FROM clause (e.g. "Account a" → { a: 'Account' })
function parseAliasesFromSoql(soql) {
  const match = soql.match(/\bFROM\s+([\s\S]+?)(?:\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
  if (!match) return {}
  const aliases = {}
  match[1].split(',').forEach(part => {
    const tokens = part.trim().split(/\s+/)
    if (tokens.length >= 2 && /^\w+$/.test(tokens[0]) && /^\w+$/.test(tokens[1])) {
      aliases[tokens[1].toLowerCase()] = tokens[0]
    }
    // Also map the table name to itself for direct references
    if (tokens[0] && /^\w+$/.test(tokens[0])) {
      aliases[tokens[0].toLowerCase()] = tokens[0]
    }
  })
  return aliases
}

// Detect SQL-only syntax that is not valid SOQL
function detectSqlInSoql(soql) {
  if (!soql || !soql.trim()) return null
  const s = soql.replace(/'[^']*'/g, '') // strip string literals
  if (/\bINNER\s+JOIN\b/i.test(s) || /\bLEFT\s+(OUTER\s+)?JOIN\b/i.test(s) || /\bRIGHT\s+(OUTER\s+)?JOIN\b/i.test(s) || /\bFULL\s+(OUTER\s+)?JOIN\b/i.test(s) || /\bCROSS\s+JOIN\b/i.test(s))
    return 'JOIN is not supported in SOQL. Use relationship queries (e.g. SELECT Account.Name, Name FROM Contact) instead.'
  if (/\bUNION\b/i.test(s) || /\bINTERSECT\b/i.test(s) || /\bEXCEPT\b/i.test(s))
    return 'UNION / INTERSECT / EXCEPT are not supported in SOQL.'
  // Multiple tables in FROM clause (comma-separated)
  const fromMatch = s.match(/\bFROM\s+([\s\S]+?)(?:\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
  if (fromMatch && fromMatch[1].includes(','))
    return 'Multiple tables in FROM clause are not supported in SOQL. Use relationship queries (e.g. SELECT Account.Name, Name FROM Contact) instead.'
  if (/\bGROUP\s+BY\b/i.test(s) && /\bHAVING\b/i.test(s) && /\bCOUNT\s*\(\s*\*\s*\)/i.test(s))
    return null // COUNT(*) with GROUP BY HAVING is actually valid in SOQL aggregate queries
  if (/\bINSERT\s+INTO\b/i.test(s) || /\bUPDATE\s+\w+\s+SET\b/i.test(s) || /\bDELETE\s+FROM\b/i.test(s) || /\bDROP\s+/i.test(s) || /\bCREATE\s+TABLE\b/i.test(s) || /\bALTER\s+TABLE\b/i.test(s))
    return 'DML/DDL statements (INSERT, UPDATE, DELETE, DROP, CREATE, ALTER) are not supported in SOQL. SOQL is a read-only query language.'
  return null
}

export default function SoqlWorkArea({ sfConnectionId, sfConnectionName = '', dbConnectionId, dbConnections = [], targetDbConnections = [], sfRefreshKey = 0, sfConnections = [], activeSfId = '', onSetActiveSfId, onOpenModal, onEditConn, onNavigateToJobs, tablePrefix = '' }) {
  // Multi-tab query state
  const queryTabCounterRef = useRef(1)
  const [queryTabs, setQueryTabs] = useState([
    { id: 1, name: 'Query 1', sql: 'SELECT Id, Name, Industry, AnnualRevenue FROM Account LIMIT 25', result: null, error: null }
  ])
  const [activeQueryTabId, setActiveQueryTabId] = useState(1)

  const activeQTab = queryTabs.find(t => t.id === activeQueryTabId) || queryTabs[0]
  const soql = activeQTab?.sql || ''
  const result = activeQTab?.result || null
  const error = activeQTab?.error || null

  const setSoql = (valOrFn) => {
    setQueryTabs(prev => prev.map(t => t.id === activeQueryTabId
      ? { ...t, sql: typeof valOrFn === 'function' ? valOrFn(t.sql) : valOrFn }
      : t
    ))
  }
  const setResult = (val) => {
    setQueryTabs(prev => prev.map(t => t.id === activeQueryTabId ? { ...t, result: val } : t))
  }
  const setError = (val) => {
    setQueryTabs(prev => prev.map(t => t.id === activeQueryTabId ? { ...t, error: val } : t))
  }

  const addQueryTab = () => {
    queryTabCounterRef.current++
    const newTab = { id: queryTabCounterRef.current, name: `Query ${queryTabCounterRef.current}`, sql: '', result: null, error: null }
    setQueryTabs(prev => [...prev, newTab])
    setActiveQueryTabId(newTab.id)
    setBottomTab('fields')
  }

  const closeQueryTab = (tabId) => {
    setQueryTabs(prev => {
      if (prev.length <= 1) return prev
      const next = prev.filter(t => t.id !== tabId)
      if (activeQueryTabId === tabId) setActiveQueryTabId(next[next.length - 1].id)
      return next
    })
  }

  // Column resize state
  const [columnWidths, setColumnWidths] = useState({})
  const colResizing = useRef(null)

  const handleColResizeStart = (col, e) => {
    e.preventDefault()
    e.stopPropagation()
    const startX = e.clientX
    const th = e.target.closest('th')
    const startWidth = th ? th.offsetWidth : 150
    colResizing.current = { col, startX, startWidth }

    const onMouseMove = (ev) => {
      if (!colResizing.current) return
      const diff = ev.clientX - colResizing.current.startX
      const minChars = Math.max(10, colResizing.current.col.length)
      const minWidth = minChars * 8 + 20 // ~8px per char + padding
      const newWidth = Math.max(minWidth, colResizing.current.startWidth + diff)
      setColumnWidths(prev => ({ ...prev, [colResizing.current.col]: newWidth }))
    }
    const onMouseUp = () => {
      colResizing.current = null
      document.removeEventListener('mousemove', onMouseMove)
      document.removeEventListener('mouseup', onMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'
    document.addEventListener('mousemove', onMouseMove)
    document.addEventListener('mouseup', onMouseUp)
  }

  const [running, setRunning] = useState(false)
  const [objects, setObjects] = useState([])
  const [objectsLoading, setObjectsLoading] = useState(false)
  const [objectSearch, setObjectSearch] = useState('')
  const [fields, setFields] = useState([])
  const [fieldsLoading, setFieldsLoading] = useState(false)
  const [fieldsRefreshKey, setFieldsRefreshKey] = useState(0)
  const [fieldSearch, setFieldSearch] = useState('')
  const [history, setHistory] = useState([])
  const [detectedObject, setDetectedObject] = useState(null)
  const [detectedObjects, setDetectedObjects] = useState([])
  const [recordCount, setRecordCount] = useState(null)
  const [fieldsObjectFilter, setFieldsObjectFilter] = useState('') // '' = all objects
  const [showActionsMenu, setShowActionsMenu] = useState(false)
  const [resultsMaximized, setResultsMaximized] = useState(false)

  // DB mode state (when a database connection is selected in sidebar)
  const [activeDbConnId, setActiveDbConnId] = useState('')
  const [dbTables, setDbTables] = useState([])
  const [dbTableComments, setDbTableComments] = useState({})
  const [dbTablesLoading, setDbTablesLoading] = useState(false)
  const isDbMode = !!activeDbConnId

  // Database (schema) selection for Athena
  const [dbDatabases, setDbDatabases] = useState([])
  const [selectedDatabase, setSelectedDatabase] = useState('')

  // Bottom panel tab: 'fields' or 'results'
  const [bottomTab, setBottomTab] = useState('fields')

  // File (CSV) mode
  const [isFileMode, setIsFileMode] = useState(false)
  const [csvFile, setCsvFile] = useState(null)
  const [csvPreview, setCsvPreview] = useState(null)
  const [csvTableName, setCsvTableName] = useState('')
  const [csvTargetDbId, setCsvTargetDbId] = useState('')
  const [csvImporting, setCsvImporting] = useState(false)
  const [csvImportJob, setCsvImportJob] = useState(null)
  const [csvDragOver, setCsvDragOver] = useState(false)
  const csvFileInputRef = useRef(null)
  const csvPollRef = useRef(null)

  // Pagination
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(100)

  // Results search
  const [resultSearch, setResultSearch] = useState('')

  // Import to DB state
  const [showImportModal, setShowImportModal] = useState(false)
  const [importTableName, setImportTableName] = useState('')
  const [importObjectName, setImportObjectName] = useState('')  // actual SF API name
  const [importSoql, setImportSoql] = useState('')
  const [importJob, setImportJob] = useState(null)
  const importPollRef = useRef(null)
  const [importTargetDbId, setImportTargetDbId] = useState(null)
  const [importTargetSelectedDb, setImportTargetSelectedDb] = useState('') // target database/schema name

  // Object-level download state
  const [downloadingCsv, setDownloadingCsv] = useState(false)
  const downloadPollRef = useRef(null)

  // Import icon popovers
  const [showDbPopover, setShowDbPopover] = useState(false)
  const [showResultsDbPopover, setShowResultsDbPopover] = useState(false)
  const [showHistory, setShowHistory] = useState(false)

  // Textarea cell popup
  const [textCellPopup, setTextCellPopup] = useState(null) // { column, value }

  // Sidebar item import popover
  const [sidebarImportItem, setSidebarImportItem] = useState(null) // objectName to show popover for
  const [sidebarImportPos, setSidebarImportPos] = useState({ top: 0, left: 0 }) // fixed position for popover
  const [importConnDatabases, setImportConnDatabases] = useState({}) // connId -> [db names]
  const [expandedImportConn, setExpandedImportConn] = useState(null) // connId currently expanded
  const [createDbInput, setCreateDbInput] = useState({ connId: null, name: '', loading: false, error: '' })

  // Save as Step (checkbox in import modal)
  const [saveAsStep, setSaveAsStep] = useState(false)
  const [saveStepName, setSaveStepName] = useState('')
  const [stepSaved, setStepSaved] = useState(false)

  // Auto-save step when import completes successfully
  const saveAsStepRef = useRef({ saveAsStep: false, saveStepName: '' })
  useEffect(() => { saveAsStepRef.current = { saveAsStep, saveStepName } }, [saveAsStep, saveStepName])
  const prevImportStatusRef = useRef(null)
  useEffect(() => {
    if (importJob?.status === 'complete' && prevImportStatusRef.current !== 'complete' && saveAsStepRef.current.saveAsStep && saveAsStepRef.current.saveStepName.trim()) {
      const name = saveAsStepRef.current.saveStepName.trim()
      const effectiveDbId = importTargetDbId || dbConnectionId
      const cfg = {}
      if (isDbMode) {
        cfg.sourceType = 'database'
        cfg.sourceDbConnectionId = activeDbConnId
        cfg.dbConnectionId = effectiveDbId
        cfg.sql = importSoql || soql
        cfg.tableName = importTableName || detectedObject || 'query_result'
        cfg.sourceDatabase = selectedDatabase || ''
        cfg.targetDatabase = importTargetSelectedDb || ''
      } else {
        cfg.sourceType = 'salesforce'
        cfg.sfConnectionId = sfConnectionId || activeSfId
        cfg.dbConnectionId = effectiveDbId
        cfg.targetDatabase = importTargetSelectedDb || ''
        if (importSoql) {
          cfg.soql = importSoql
          cfg.tableName = importTableName || ''
          cfg.objects = [importObjectName || detectedObject || '']
        } else {
          cfg.objects = [importObjectName || detectedObject || '']
          cfg.tableNames = { [importObjectName || detectedObject || '']: importTableName || '' }
        }
      }
      fetch('/api/saved-steps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, type: 'extract', config: cfg }),
      }).then(() => setStepSaved(true)).catch(() => {})
    }
    prevImportStatusRef.current = importJob?.status || null
  }, [importJob?.status])

  // Autocomplete state
  const [autoComplete, setAutoComplete] = useState({ show: false, items: [], selectedIdx: 0 })
  const [acPosition, setAcPosition] = useState({ top: 0, left: 0 })
  const textareaRef = useRef(null)

  useEffect(() => {
    if (!sfConnectionId) { setObjects([]); return }
    setObjects([])
    setObjectsLoading(true)
    setResult(null)
    setError(null)
    setDetectedObject(null)
    setDetectedObjects([])
    setRecordCount(null)
    setFields([])
    fetch(`/api/salesforce/${sfConnectionId}/objects`)
      .then(r => r.json())
      .then(data => { if (Array.isArray(data)) setObjects(data) })
      .catch(() => {})
      .finally(() => setObjectsLoading(false))
  }, [sfConnectionId, sfRefreshKey])

  // Fetch databases when a DB connection is selected in sidebar
  useEffect(() => {
    if (!activeDbConnId) { setDbDatabases([]); setSelectedDatabase(''); setDbTables([]); return }
    setDbDatabases([])
    setSelectedDatabase('')
    setDbTables([])
    setResult(null)
    setError(null)
    setDetectedObject(null)
    setDetectedObjects([])
    setRecordCount(null)
    setFields([])
    fetch(`/api/database/${activeDbConnId}/databases`)
      .then(r => r.json())
      .then(data => {
        const dbs = data.databases || []
        setDbDatabases(dbs)
        if (dbs.length === 1) setSelectedDatabase(dbs[0])
      })
      .catch(() => {})
  }, [activeDbConnId])

  // Fetch tables when database is selected
  useEffect(() => {
    if (!activeDbConnId) return
    if (dbDatabases.length > 1 && !selectedDatabase) { setDbTables([]); return }
    setDbTables([])
    setDbTablesLoading(true)
    const url = selectedDatabase
      ? `/api/database/${activeDbConnId}/tables?database=${encodeURIComponent(selectedDatabase)}`
      : `/api/database/${activeDbConnId}/tables`
    fetch(url)
      .then(r => r.json())
      .then(data => { if (!data.error) { setDbTables(data.tables || []); setDbTableComments(data.tableComments || {}) } })
      .catch(() => {})
      .finally(() => setDbTablesLoading(false))
  }, [activeDbConnId, selectedDatabase, dbDatabases])

  // Auto-detect object/table from query and load fields + record count
  useEffect(() => {
    const allObjects = parseObjectsFromSoql(soql)
    const objName = allObjects[0] || null
    const objListKey = allObjects.join(',')
    const prevListKey = detectedObjects.join(',')
    const changed = objListKey !== prevListKey || fieldsRefreshKey > 0

    if (isDbMode) {
      // DB mode: track table names and fetch columns
      if (allObjects.length > 0 && changed) {
        setDetectedObject(objName)
        setDetectedObjects(allObjects)
        setRecordCount(null)
        setFieldsLoading(true)
        setFieldSearch('')
        setFieldsObjectFilter('')
        const dbParam = selectedDatabase ? `?database=${encodeURIComponent(selectedDatabase)}` : ''
        const fetches = allObjects.map(name =>
          fetch(`/api/database/${activeDbConnId}/tables/${name}/columns${dbParam}`)
            .then(r => r.json())
            .then(data => ({ name, columns: data.columns || [] }))
            .catch(() => ({ name, columns: [] }))
        )
        Promise.all(fetches).then(results => {
          let merged = []
          if (allObjects.length === 1) {
            merged = results[0].columns.map(c => ({ name: c.name, type: c.type, label: c.type }))
          } else {
            results.forEach(r => {
              r.columns.forEach(c => {
                merged.push({ name: `${r.name}.${c.name}`, type: c.type, label: c.type, _objectName: r.name })
              })
            })
          }
          setFields(merged)
        }).finally(() => setFieldsLoading(false))
      } else if (allObjects.length === 0) {
        setDetectedObject(null)
        setDetectedObjects([])
        setFieldsObjectFilter('')
        setRecordCount(null)
        setFields([])
      }
      return
    }
    // SF mode: describe fields + record count
    if (allObjects.length > 0 && changed && sfConnectionId) {
      setDetectedObject(objName)
      setDetectedObjects(allObjects)
      setRecordCount(null)
      setFieldsLoading(true)
      setFieldSearch('')
      setFieldsObjectFilter('')
      const fetches = allObjects.map(name =>
        fetch(`/api/salesforce/${sfConnectionId}/describe/${name}`)
          .then(r => r.json())
          .then(data => ({ name, fields: data.fields || [] }))
          .catch(() => ({ name, fields: [] }))
      )
      Promise.all(fetches).then(results => {
        let merged = []
        if (allObjects.length === 1) {
          merged = results[0].fields
        } else {
          results.forEach(r => {
            r.fields.forEach(f => {
              merged.push({ ...f, name: `${r.name}.${f.name}`, label: `${r.name}.${f.label || f.name}`, _objectName: r.name })
            })
          })
        }
        setFields(merged)
      }).finally(() => setFieldsLoading(false))
      // Record count only for the primary (first) object
      fetch(`/api/salesforce/${sfConnectionId}/recordcount/${objName}`)
        .then(r => r.json())
        .then(data => { if (data.count != null) setRecordCount(data.count) })
        .catch(() => {})
    } else if (allObjects.length === 0) {
      setDetectedObject(null)
      setDetectedObjects([])
      setFieldsObjectFilter('')
      setRecordCount(null)
      setFields([])
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [soql, sfConnectionId, isDbMode, fieldsRefreshKey])

  useEffect(() => {
    return () => {
      if (importPollRef.current) clearInterval(importPollRef.current)
      if (downloadPollRef.current) clearInterval(downloadPollRef.current)
      if (csvPollRef.current) clearInterval(csvPollRef.current)
    }
  }, [])

  // Uploaded files list
  const [uploadedFiles, setUploadedFiles] = useState([])
  // CSV pagination
  const [csvPage, setCsvPage] = useState(1)
  const [csvPageSize, setCsvPageSize] = useState(100)

  // Auto-select first target DB for CSV mode
  useEffect(() => {
    if (targetDbConnections.length > 0 && !csvTargetDbId) {
      setCsvTargetDbId(targetDbConnections[0].id)
    }
  }, [targetDbConnections])

  // Fetch uploaded files list when entering file mode
  const fetchUploadedFiles = () => {
    fetch('/api/uploads').then(r => r.json()).then(setUploadedFiles).catch(() => {})
  }
  useEffect(() => { if (isFileMode) fetchUploadedFiles() }, [isFileMode])

  const parseCsvText = (text) => {
    const lines = text.split('\n').filter(l => l.trim())
    if (lines.length === 0) return null
    const parseLine = (line) => {
      const cells = []; let current = '', inQuotes = false
      for (let i = 0; i < line.length; i++) {
        const ch = line[i]
        if (ch === '"') { inQuotes = !inQuotes }
        else if (ch === ',' && !inQuotes) { cells.push(current.trim()); current = '' }
        else { current += ch }
      }
      cells.push(current.trim()); return cells
    }
    const columns = parseLine(lines[0])
    const rows = lines.slice(1).map(line => {
      const cells = parseLine(line); const row = {}
      columns.forEach((col, i) => { row[col] = cells[i] || '' }); return row
    })
    return { columns, rows, totalRows: rows.length }
  }

  const handleCsvFile = (f) => {
    if (!f || !f.name.toLowerCase().endsWith('.csv')) return
    setCsvFile(f)
    setCsvImportJob(null)
    setCsvPage(1)
    setCsvTableName(f.name.replace(/\.csv$/i, '').toLowerCase().replace(/[^a-z0-9_]/g, '_'))
    const reader = new FileReader()
    reader.onload = (e) => { setCsvPreview(parseCsvText(e.target.result)) }
    reader.readAsText(f)
    // Also upload to server for future reference
    const formData = new FormData()
    formData.append('file', f)
    fetch('/api/uploads', { method: 'POST', body: formData })
      .then(() => fetchUploadedFiles())
      .catch(() => {})
  }

  const handleLoadUploadedFile = (filename) => {
    fetch(`/api/uploads/${encodeURIComponent(filename)}`)
      .then(r => r.text())
      .then(text => {
        setCsvPreview(parseCsvText(text))
        setCsvPage(1)
        setCsvImportJob(null)
        setCsvTableName(filename.replace(/\.csv$/i, '').toLowerCase().replace(/[^a-z0-9_]/g, '_'))
        // Create a File object so import still works
        const blob = new Blob([text], { type: 'text/csv' })
        const file = new File([blob], filename, { type: 'text/csv' })
        setCsvFile(file)
      })
      .catch(() => {})
  }

  const handleDeleteUploadedFile = (filename, e) => {
    e.stopPropagation()
    fetch(`/api/uploads/${encodeURIComponent(filename)}`, { method: 'DELETE' })
      .then(() => {
        setUploadedFiles(prev => prev.filter(f => f.name !== filename))
        if (csvFile && csvFile.name === filename) handleCsvClear()
      })
      .catch(() => {})
  }

  const handleCsvImport = () => {
    if (!csvFile || !csvTargetDbId || !csvTableName) return
    setCsvImporting(true)
    setCsvImportJob({ status: 'starting', progress: 0, message: 'Uploading CSV...' })
    const formData = new FormData()
    formData.append('file', csvFile)
    formData.append('targetDbConnectionId', csvTargetDbId)
    formData.append('tableName', csvTableName)
    fetch('/api/import-csv', { method: 'POST', body: formData })
      .then(r => r.json())
      .then(data => {
        if (data.error) { setCsvImportJob({ status: 'error', progress: 0, message: data.error }); setCsvImporting(false); return }
        csvPollRef.current = setInterval(() => {
          fetch(`/api/import-csv/${data.jobId}/status`).then(r => r.json()).then(s => {
            setCsvImportJob(s)
            if (!s.running) { clearInterval(csvPollRef.current); csvPollRef.current = null; setCsvImporting(false) }
          }).catch(() => {})
        }, 1000)
      })
      .catch(err => { setCsvImportJob({ status: 'error', progress: 0, message: err.message }); setCsvImporting(false) })
  }

  const handleCsvClear = () => {
    setCsvFile(null); setCsvPreview(null); setCsvImportJob(null); setCsvTableName(''); setCsvPage(1)
  }

  useEffect(() => { setPage(1); setResultSearch('') }, [result])

  const filteredObjects = objectSearch
    ? objects.filter(o =>
        o.name.toLowerCase().includes(objectSearch.toLowerCase()) ||
        o.apiName.toLowerCase().includes(objectSearch.toLowerCase())
      )
    : objects

  // Parse fields already in the SELECT clause
  const selectedFieldNames = (() => {
    const upper = soql.toUpperCase()
    const selectIdx = upper.indexOf('SELECT ')
    const fromIdx = upper.indexOf(' FROM ')
    if (selectIdx < 0 || fromIdx < 0) return new Set()
    const fieldsPart = soql.substring(selectIdx + 7, fromIdx)
    return new Set(fieldsPart.split(',').map(f => f.trim().toLowerCase()).filter(Boolean))
  })()

  const filteredFields = fields
    .filter(f => !fieldsObjectFilter || f._objectName === fieldsObjectFilter)
    .filter(f => !selectedFieldNames.has(f.name.toLowerCase()))
    .filter(f => !fieldSearch ||
      f.name.toLowerCase().includes(fieldSearch.toLowerCase()) ||
      f.label.toLowerCase().includes(fieldSearch.toLowerCase())
    )

  // Warn when SQL syntax is used in a Salesforce connection
  const soqlWarning = !isDbMode && sfConnectionId ? detectSqlInSoql(soql) : null

  const handleSelectObject = (apiName) => {
    setFieldSearch('')
    setResult(null)
    setError(null)
    setBottomTab('fields')
    setSoql(prev => {
      const trimmed = prev.trim()
      if (!trimmed) {
        return isDbMode ? `SELECT * FROM ${apiName} LIMIT 25` : `SELECT Id, Name FROM ${apiName} LIMIT 25`
      }
      const upper = trimmed.toUpperCase()
      const fromIdx = upper.indexOf(' FROM ')
      if (fromIdx < 0) {
        // Has SELECT but no FROM yet — append FROM <table>
        return trimmed + ` FROM ${apiName} LIMIT 25`
      }
      // In DB mode, always reset to SELECT * when picking a new table
      if (isDbMode) {
        return `SELECT * FROM ${apiName} LIMIT 25`
      }
      // In SF mode, if query has SELECT * (from DB mode), reset to Id, Name
      const selectFields = trimmed.substring(upper.indexOf('SELECT ') + 7, fromIdx).trim()
      if (selectFields === '*') {
        return `SELECT Id, Name FROM ${apiName} LIMIT 25`
      }
      // Replace the object name in the FROM clause
      const afterFrom = trimmed.substring(fromIdx + 6)
      const endMatch = afterFrom.match(/^[\s\S]+?(?=\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
      const beforeFrom = trimmed.substring(0, fromIdx + 6)
      const rest = endMatch ? afterFrom.substring(endMatch[0].length) : ''
      return beforeFrom + apiName + rest
    })
  }

  const handleFieldClick = (fieldName) => {
    setSoql(prev => {
      // If field has a table prefix (multi-object mode), resolve to alias
      let insertName = fieldName
      const dotPos = fieldName.indexOf('.')
      if (dotPos >= 0) {
        const tablePart = fieldName.substring(0, dotPos)
        const colPart = fieldName.substring(dotPos + 1)
        const fromMatch = prev.match(/\bFROM\s+([\s\S]+?)(?:\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
        if (fromMatch) {
          let bestAlias = tablePart
          fromMatch[1].split(',').forEach(part => {
            const tokens = part.trim().split(/\s+/)
            if (tokens[0] && tokens[0].toLowerCase() === tablePart.toLowerCase() && tokens.length >= 2 && /^\w+$/.test(tokens[1])) {
              bestAlias = tokens[1]
            }
          })
          insertName = bestAlias + '.' + colPart
        }
      }

      const upper = prev.toUpperCase()
      const fromIdx = upper.indexOf(' FROM ')
      if (fromIdx > 0) {
        const beforeFrom = prev.substring(0, fromIdx).trimEnd()
        const afterFrom = prev.substring(fromIdx)
        const selectIdx = upper.indexOf('SELECT ')
        const between = beforeFrom.substring(selectIdx + 7).trim()
        if (!between || between === '*') {
          return prev.substring(0, selectIdx + 7) + insertName + afterFrom
        }
        return beforeFrom + ', ' + insertName + afterFrom
      }
      return prev + ' ' + insertName
    })
  }

  const handleSelectAllFields = () => {
    if (!detectedObject || fields.length === 0) return
    const fieldNames = fields.map(f => f.name).join(', ')
    setSoql(`SELECT ${fieldNames} FROM ${detectedObject} LIMIT 25`)
  }

  const handleRun = () => {
    if (!soql.trim()) return
    if (!isDbMode && !sfConnectionId) return
    if (isDbMode && !activeDbConnId) return
    if (soqlWarning) {
      setError('Invalid query: For Salesforce connections, you must use SOQL queries. ' + soqlWarning)
      setBottomTab('results')
      return
    }
    setRunning(true)
    setResult(null)
    setError(null)
    setBottomTab('results')
    const startTime = Date.now()
    const url = isDbMode
      ? `/api/database/${activeDbConnId}/query`
      : `/api/salesforce/${sfConnectionId}/soql`
    const body = isDbMode
      ? { sql: soql.trim(), database: selectedDatabase || undefined }
      : { soql: soql.trim() }
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
      .then(r => r.json())
      .then(data => {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1)
        if (data.error) {
          setError(data.error)
        } else {
          setResult({ ...data, elapsed })
          const activeDbConn = dbConnections.find(c => c.id === activeDbConnId)
          const connName = isDbMode
            ? (activeDbConn ? connectionDisplayName(activeDbConn) : activeDbConnId)
            : (sfConnectionName || 'Salesforce')
          setHistory(prev => [{
            soql: soql.trim(),
            time: new Date().toLocaleTimeString(),
            rows: data.rowCount,
            connection: connName,
            database: isDbMode ? (selectedDatabase || '') : '',
            table: detectedObject || '',
            mode: isDbMode ? 'db' : 'sf',
          }, ...prev].slice(0, 50))
        }
      })
      .catch(err => setError(err.message))
      .finally(() => setRunning(false))
  }

  // Autocomplete helpers
  const getAutocompleteContext = (text, cursorPos) => {
    const upper = text.toUpperCase()
    const selectIdx = upper.indexOf('SELECT ')
    if (selectIdx < 0) return null
    const fromIdx = upper.indexOf(' FROM ')

    // Find word boundary at cursor (include dots so we capture tablename.field tokens)
    let wordStart = cursorPos
    while (wordStart > 0) {
      const ch = text[wordStart - 1]
      if (ch === ',' || ch === ' ' || ch === '\n' || ch === '\t') break
      wordStart--
    }
    while (wordStart < cursorPos && (text[wordStart] === ' ' || text[wordStart] === '\t')) wordStart++

    const partial = text.substring(wordStart, cursorPos)

    // Check for tablename.partial pattern (works anywhere in the query)
    const dotIdx = partial.indexOf('.')
    if (dotIdx >= 0) {
      const tableName = partial.substring(0, dotIdx)
      const fieldPartial = partial.substring(dotIdx + 1)
      if (tableName.length > 0) {
        return { type: 'dotfield', partial: fieldPartial, tableName, wordStart: wordStart + dotIdx + 1 }
      }
    }

    // After FROM: suggest table/object names (only within FROM clause, not in WHERE etc.)
    if (fromIdx >= 0 && cursorPos > fromIdx + 6) {
      const afterFrom = upper.substring(fromIdx + 6)
      const clauseEnd = afterFrom.match(/\b(WHERE|LIMIT|ORDER|GROUP|HAVING)\b/)
      const clauseEndPos = clauseEnd ? fromIdx + 6 + clauseEnd.index : text.length
      if (cursorPos <= clauseEndPos) {
        return { type: 'table', partial, wordStart }
      }
    }

    // After WHERE / ORDER / GROUP / HAVING: suggest fields for the current object
    if (fromIdx >= 0 && cursorPos > fromIdx) {
      const afterFrom = upper.substring(fromIdx + 6)
      const whereMatch = afterFrom.match(/\b(WHERE|ORDER|GROUP|HAVING)\b/)
      if (whereMatch) {
        const clauseStartPos = fromIdx + 6 + whereMatch.index + whereMatch[0].length
        if (cursorPos > clauseStartPos && partial.length > 0) {
          return { type: 'field', partial, wordStart }
        }
      }
      // Cursor is between FROM objects and WHERE keyword — still in FROM clause handled above
      return null
    }

    // Between SELECT and FROM: suggest fields
    if (cursorPos <= selectIdx + 7) return null
    return { type: 'field', partial, wordStart }
  }

  // Compute approximate cursor pixel position in textarea
  const computeCursorPosition = (textarea, cursorPos) => {
    const text = textarea.value.substring(0, cursorPos)
    const lines = text.split('\n')
    const lineNumber = lines.length - 1
    const colNumber = lines[lines.length - 1].length

    const style = window.getComputedStyle(textarea)
    const lineHeight = parseFloat(style.lineHeight) || parseFloat(style.fontSize) * 1.5
    const fontSize = parseFloat(style.fontSize)
    const charWidth = fontSize * 0.6 // approximate monospace char width
    const paddingTop = parseFloat(style.paddingTop) || 0
    const paddingLeft = parseFloat(style.paddingLeft) || 0

    const top = paddingTop + (lineNumber + 1) * lineHeight - textarea.scrollTop
    const left = paddingLeft + colNumber * charWidth

    return { top: Math.max(0, top), left: Math.min(left, textarea.offsetWidth - 240) }
  }

  // --- Command dropdown state for "connect" / "use" ---
  const [commandDropdown, setCommandDropdown] = useState({ show: false, type: '', items: [], selectedIdx: 0 })
  const [cmdDropdownPos, setCmdDropdownPos] = useState({ top: 0, left: 0 })
  const [useDatabases, setUseDatabases] = useState([])

  const showCommandDropdown = (type, textarea, cursorPos, extra) => {
    setCmdDropdownPos(computeCursorPosition(textarea, cursorPos))
    if (type === 'connect') {
      const allConns = [...sfConnections, ...dbConnections]
      const items = allConns.map(c => ({
        id: c.id,
        name: connectionDisplayName(c),
        type: c.loginUrl ? 'Salesforce' : (c.dbType || 'postgres'),
        icon: c,
        isSf: !!c.loginUrl,
        isActive: c.loginUrl ? c.id === sfConnectionId : c.id === activeDbConnId,
      }))
      setCommandDropdown({ show: true, type: 'connect', items, selectedIdx: 0 })
    } else if (type === 'use') {
      if (!activeDbConnId) return
      fetch(`/api/database/${activeDbConnId}/databases`)
        .then(r => r.json())
        .then(data => {
          const dbs = data.databases || []
          if (dbs.length > 0) {
            const items = dbs.map(db => ({ id: db, name: db, isActive: db === selectedDatabase }))
            setCommandDropdown({ show: true, type: 'use', items, selectedIdx: 0 })
          }
        })
        .catch(() => {})
    } else if (type === 'import-table') {
      const tableList = isDbMode ? dbTables : objects.map(o => o.apiName)
      if (tableList.length === 0) return
      const items = tableList.map(t => ({ id: t, name: t, type: 'table' }))
      setCommandDropdown({ show: true, type: 'import-table', items, selectedIdx: 0 })
    } else if (type === 'import-conn') {
      if (targetDbConnections.length === 0) return
      const items = targetDbConnections.map(c => ({
        id: c.id, name: connectionDisplayName(c), rawName: c.name, type: (c.dbType || 'postgres'), icon: c,
      }))
      setCommandDropdown({ show: true, type: 'import-conn', items, selectedIdx: 0, _importTable: extra?.table })
    } else if (type === 'import-db') {
      const connId = extra?.connId
      if (!connId) return
      fetch(`/api/database/${connId}/databases`)
        .then(r => r.json())
        .then(data => {
          const dbs = data.databases || []
          if (dbs.length > 0) {
            const items = dbs.map(db => ({ id: db, name: db }))
            setCommandDropdown({ show: true, type: 'import-db', items, selectedIdx: 0, _importTable: extra?.table, _importConnId: connId, _importConnName: extra?.connName })
          }
        })
        .catch(() => {})
    }
  }

  const selectCommandItem = (item) => {
    if (commandDropdown.type === 'connect') {
      handleConnChange(item.id)
      setSoql('')
    } else if (commandDropdown.type === 'use') {
      setSelectedDatabase(item.id)
      setDetectedObject(null)
      setDetectedObjects([])
      setResult(null)
      setError(null)
      setSoql('')
    } else if (commandDropdown.type === 'import-table') {
      setSoql(`import ${item.name} to `)
      // Don't close — the onChange will detect "to " and show connections
      setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
      return
    } else if (commandDropdown.type === 'import-conn') {
      const table = commandDropdown._importTable || ''
      setSoql(`import ${table} to ${item.rawName || item.name}.`)
      setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
      return
    } else if (commandDropdown.type === 'import-db') {
      const table = commandDropdown._importTable || ''
      const connId = commandDropdown._importConnId
      handleImportObjectToDb(table, connId, item.name)
      setSoql('')
    }
    setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
  }

  const handleSoqlChange = (e) => {
    const newVal = e.target.value
    setSoql(newVal)

    // Detect commands typed in query editor: connect, use, import
    const trimmedCmd = newVal.trim().toLowerCase()
    if (trimmedCmd === 'connect' || trimmedCmd === 'use') {
      if (textareaRef.current) showCommandDropdown(trimmedCmd, textareaRef.current, e.target.selectionStart)
      return
    }
    // import command phases
    if (trimmedCmd === 'import') {
      if (textareaRef.current) showCommandDropdown('import-table', textareaRef.current, e.target.selectionStart)
      return
    }
    const importToMatch = newVal.trim().match(/^import\s+(\S+)\s+to\s*$/i)
    if (importToMatch) {
      if (textareaRef.current) showCommandDropdown('import-conn', textareaRef.current, e.target.selectionStart, { table: importToMatch[1] })
      return
    }
    const importDotMatch = newVal.trim().match(/^import\s+(\S+)\s+to\s+(.+)\.$/i)
    if (importDotMatch) {
      const table = importDotMatch[1]
      const connName = importDotMatch[2].trim()
      const matchedConn = targetDbConnections.find(c => c.name.toLowerCase() === connName.toLowerCase())
      if (matchedConn && textareaRef.current) {
        showCommandDropdown('import-db', textareaRef.current, e.target.selectionStart, { table, connId: matchedConn.id, connName })
      }
      return
    }
    if (commandDropdown.show) {
      setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
    }

    const cursorPos = e.target.selectionStart
    const ctx = getAutocompleteContext(newVal, cursorPos)

    if (!ctx || ctx.partial.length < 1) {
      // For table mode, show all tables even with empty partial (right after FROM)
      if (ctx && ctx.type === 'table' && ctx.partial.length === 0) {
        const tableList = isDbMode ? dbTables : objects.map(o => o.apiName)
        if (tableList.length > 0) {
          const matches = tableList.slice(0, 20).map(t => ({ name: t, type: 'table' }))
          if (textareaRef.current) setAcPosition(computeCursorPosition(textareaRef.current, cursorPos))
          setAutoComplete({ show: true, items: matches, selectedIdx: 0, mode: 'table' })
          return
        }
      }
      // For dotfield mode, show all fields for that table when partial is empty (right after '.')
      if (ctx && ctx.type === 'dotfield' && ctx.partial.length === 0) {
        const aliasMap = parseAliasesFromSoql(newVal)
        const resolvedTable = aliasMap[ctx.tableName.toLowerCase()] || ctx.tableName
        const tbl = resolvedTable.toLowerCase()
        const tableFields = fields.filter(f => {
          if (f._objectName) return f._objectName.toLowerCase() === tbl
          return detectedObject && detectedObject.toLowerCase() === tbl
        })
        const matches = tableFields.slice(0, 20).map(f => {
          const baseName = f._objectName ? f.name.split('.').pop() : f.name
          return { name: baseName, type: f.type }
        })
        if (matches.length > 0) {
          if (textareaRef.current) setAcPosition(computeCursorPosition(textareaRef.current, cursorPos))
          setAutoComplete({ show: true, items: matches, selectedIdx: 0, mode: 'dotfield' })
          return
        }
      }
      if (autoComplete.show) setAutoComplete({ show: false, items: [], selectedIdx: 0 })
      return
    }

    const lowerPartial = ctx.partial.toLowerCase()
    let matches = []

    if (ctx.type === 'table') {
      // Suggest table/object names
      const tableList = isDbMode ? dbTables : objects.map(o => o.apiName)
      matches = tableList
        .filter(t => t.toLowerCase().startsWith(lowerPartial))
        .slice(0, 20)
        .map(t => ({ name: t, type: 'table' }))
    } else if (ctx.type === 'dotfield') {
      // Suggest fields for the specific table (tablename.partial)
      // Resolve alias to real table name
      const aliasMap = parseAliasesFromSoql(newVal)
      const resolvedTable = aliasMap[ctx.tableName.toLowerCase()] || ctx.tableName
      const tbl = resolvedTable.toLowerCase()
      const tableFields = fields
        .filter(f => {
          if (f._objectName) return f._objectName.toLowerCase() === tbl
          // Single-object mode: check against detectedObject
          return detectedObject && detectedObject.toLowerCase() === tbl
        })
      matches = tableFields
        .filter(f => {
          const baseName = f._objectName ? f.name.split('.').pop() : f.name
          return baseName.toLowerCase().includes(lowerPartial)
        })
        .slice(0, 20)
        .map(f => {
          const baseName = f._objectName ? f.name.split('.').pop() : f.name
          return { name: baseName, type: f.type }
        })
    } else {
      // Field mode (between SELECT and FROM)
      if (fields.length === 0) {
        if (autoComplete.show) setAutoComplete({ show: false, items: [], selectedIdx: 0 })
        return
      }
      matches = fields.filter(f => f.name.toLowerCase().startsWith(lowerPartial)).slice(0, 20)
    }

    if (matches.length > 0 && !(matches.length === 1 && matches[0].name.toLowerCase() === lowerPartial)) {
      if (textareaRef.current) setAcPosition(computeCursorPosition(textareaRef.current, cursorPos))
      setAutoComplete({ show: true, items: matches, selectedIdx: 0, mode: ctx.type })
    } else {
      setAutoComplete({ show: false, items: [], selectedIdx: 0 })
    }
  }

  const insertAutoCompleteField = (fieldName) => {
    if (!textareaRef.current) return
    const textarea = textareaRef.current
    const cursorPos = textarea.selectionStart
    const ctx = getAutocompleteContext(soql, cursorPos)
    if (!ctx) return

    const before = soql.substring(0, ctx.wordStart)
    const after = soql.substring(cursorPos)
    let newSoql, newPos

    // Determine if cursor is in the SELECT field list (comma-separated) or elsewhere (space-separated)
    const upperSoql = soql.toUpperCase()
    const fromPos = upperSoql.indexOf(' FROM ')
    const inSelectClause = ctx.type === 'field' && (fromPos < 0 || ctx.wordStart < fromPos)

    if (ctx.type === 'table') {
      // In FROM clause: add a space after
      newSoql = before + fieldName + ' ' + after
      newPos = ctx.wordStart + fieldName.length + 1
    } else if (inSelectClause) {
      // In SELECT clause: add comma + space after
      newSoql = before + fieldName + ', ' + after
      newPos = ctx.wordStart + fieldName.length + 2
    } else {
      // In WHERE / ORDER BY / etc: just add a space after
      newSoql = before + fieldName + ' ' + after
      newPos = ctx.wordStart + fieldName.length + 1
    }

    setSoql(newSoql)
    setAutoComplete({ show: false, items: [], selectedIdx: 0 })

    requestAnimationFrame(() => {
      textarea.focus()
      textarea.setSelectionRange(newPos, newPos)
    })
  }

  const handleKeyDown = (e) => {
    // Command dropdown keyboard navigation
    if (commandDropdown.show) {
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setCommandDropdown(prev => ({ ...prev, selectedIdx: Math.min(prev.selectedIdx + 1, prev.items.length - 1) }))
        return
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault()
        setCommandDropdown(prev => ({ ...prev, selectedIdx: Math.max(prev.selectedIdx - 1, 0) }))
        return
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        if (commandDropdown.items.length > 0) {
          e.preventDefault()
          selectCommandItem(commandDropdown.items[commandDropdown.selectedIdx])
          return
        }
      }
      if (e.key === 'Escape') {
        e.preventDefault()
        setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
        return
      }
    }
    if (autoComplete.show) {
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setAutoComplete(prev => ({
          ...prev,
          selectedIdx: Math.min(prev.selectedIdx + 1, prev.items.length - 1)
        }))
        return
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault()
        setAutoComplete(prev => ({
          ...prev,
          selectedIdx: Math.max(prev.selectedIdx - 1, 0)
        }))
        return
      }
      if (e.key === 'Tab' || e.key === 'Enter') {
        if (autoComplete.items.length > 0) {
          e.preventDefault()
          insertAutoCompleteField(autoComplete.items[autoComplete.selectedIdx].name)
          return
        }
      }
      if (e.key === 'Escape') {
        e.preventDefault()
        setAutoComplete({ show: false, items: [], selectedIdx: 0 })
        return
      }
    }

    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault()
      handleRun()
    }
  }

  const exportResultsCsv = () => {
    if (!result || !result.columns.length) return
    const header = result.columns.join(',')
    const rows = result.rows.map(row =>
      result.columns.map(col => {
        const val = row[col] ?? ''
        return val.includes(',') || val.includes('"') || val.includes('\n')
          ? `"${val.replace(/"/g, '""')}"` : val
      }).join(',')
    )
    const csv = [header, ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    const objName = parseObjectFromSoql(soql) || 'soql_results'
    a.href = url; a.download = `${objName}.csv`; a.click()
    URL.revokeObjectURL(url)
  }

  const exportResultsExcel = () => {
    if (!result || !result.columns.length) return
    const escXml = s => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    const objName = parseObjectFromSoql(soql) || 'soql_results'
    let xml = '<?xml version="1.0"?>\n<?mso-application progid="Excel.Sheet"?>\n'
    xml += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n'
    xml += `<Worksheet ss:Name="${escXml(objName)}"><Table>\n`
    // Header
    xml += '<Row>'
    result.columns.forEach(col => { xml += `<Cell><Data ss:Type="String">${escXml(col)}</Data></Cell>` })
    xml += '</Row>\n'
    // Data rows
    result.rows.forEach(row => {
      xml += '<Row>'
      result.columns.forEach(col => {
        const val = row[col] ?? ''
        const isNum = val && !isNaN(val) && String(val).trim() !== ''
        xml += `<Cell><Data ss:Type="${isNum ? 'Number' : 'String'}">${escXml(String(val))}</Data></Cell>`
      })
      xml += '</Row>\n'
    })
    xml += '</Table></Worksheet></Workbook>'
    const blob = new Blob([xml], { type: 'application/vnd.ms-excel' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `${objName}.xls`; a.click()
    URL.revokeObjectURL(url)
  }

  const handleDownloadObjectCsv = (objectApiName) => {
    if (!sfConnectionId) return
    setDownloadingCsv(true)
    fetch(`/api/salesforce/${sfConnectionId}/export-csv`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ objectName: objectApiName }),
    })
      .then(r => {
        if (!r.ok) return r.json().then(d => { throw new Error(d.error || 'Export failed') })
        return r.blob()
      })
      .then(blob => {
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url; a.download = `${objectApiName}.csv`; a.click()
        URL.revokeObjectURL(url)
      })
      .catch(err => setError(err.message))
      .finally(() => setDownloadingCsv(false))
  }

  const handleDownloadObjectExcel = (objectApiName) => {
    if (!sfConnectionId) return
    setDownloadingCsv(true)
    fetch(`/api/salesforce/${sfConnectionId}/export-csv`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ objectName: objectApiName }),
    })
      .then(r => {
        if (!r.ok) return r.json().then(d => { throw new Error(d.error || 'Export failed') })
        return r.blob()
      })
      .then(async blob => {
        // Convert CSV blob to simple Excel XML (Spreadsheet ML)
        const text = await blob.text()
        const rows = text.split('\n').map(line => {
          const cells = []
          let current = '', inQuotes = false
          for (let i = 0; i < line.length; i++) {
            const ch = line[i]
            if (ch === '"') { inQuotes = !inQuotes }
            else if (ch === ',' && !inQuotes) { cells.push(current); current = '' }
            else { current += ch }
          }
          cells.push(current)
          return cells
        })
        const escXml = s => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        let xml = '<?xml version="1.0"?>\n<?mso-application progid="Excel.Sheet"?>\n'
        xml += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n'
        xml += `<Worksheet ss:Name="${escXml(objectApiName)}"><Table>\n`
        rows.forEach((row, ri) => {
          xml += '<Row>'
          row.forEach(cell => {
            const isNum = cell && !isNaN(cell) && cell.trim() !== ''
            xml += `<Cell><Data ss:Type="${ri === 0 || !isNum ? 'String' : 'Number'}">${escXml(cell)}</Data></Cell>`
          })
          xml += '</Row>\n'
        })
        xml += '</Table></Worksheet></Workbook>'
        const excelBlob = new Blob([xml], { type: 'application/vnd.ms-excel' })
        const url = URL.createObjectURL(excelBlob)
        const a = document.createElement('a')
        a.href = url; a.download = `${objectApiName}.xls`; a.click()
        URL.revokeObjectURL(url)
      })
      .catch(err => setError(err.message))
      .finally(() => setDownloadingCsv(false))
  }

  const handleDownloadSoqlCsv = () => {
    if (!sfConnectionId || !soql.trim()) return
    setDownloadingCsv(true)
    fetch(`/api/salesforce/${sfConnectionId}/export-csv`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ soql: soql.trim() }),
    })
      .then(r => {
        if (!r.ok) return r.json().then(d => { throw new Error(d.error || 'Export failed') })
        return r.blob()
      })
      .then(blob => {
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        const objName = parseObjectFromSoql(soql) || 'soql_export'
        a.href = url; a.download = `${objName}.csv`; a.click()
        URL.revokeObjectURL(url)
      })
      .catch(err => setError(err.message))
      .finally(() => setDownloadingCsv(false))
  }

  const handleImportObjectToDb = (objectApiName, targetDbId, targetDatabase) => {
    setImportTableName(objectApiName.toLowerCase())
    setImportObjectName(objectApiName)
    setImportSoql(isDbMode ? `SELECT * FROM ${objectApiName}` : '')
    setImportTargetDbId(targetDbId || dbConnectionId)
    setImportTargetSelectedDb(targetDatabase || '')
    setShowImportModal(true)
  }

  const handleImportSoqlToDb = (targetDbId, targetDatabase) => {
    const objName = parseObjectFromSoql(soql)
    setImportTableName(objName ? objName.toLowerCase() : 'import')
    setImportObjectName(objName || '')
    setImportSoql(soql.trim())
    setImportTargetDbId(targetDbId || dbConnectionId)
    setImportTargetSelectedDb(targetDatabase || '')
    setShowImportModal(true)
  }

  // Fetch databases for a target connection (for import popover)
  const fetchImportConnDatabases = (connId) => {
    if (importConnDatabases[connId]) return // already fetched
    fetch(`/api/database/${connId}/databases`)
      .then(r => r.json())
      .then(data => {
        if (!data.error) {
          setImportConnDatabases(prev => ({ ...prev, [connId]: data.databases || [] }))
        }
      })
      .catch(() => {})
  }

  const handleExpandImportConn = (connId) => {
    if (expandedImportConn === connId) {
      setExpandedImportConn(null)
    } else {
      setExpandedImportConn(connId)
      fetchImportConnDatabases(connId)
    }
  }

  const handleCreateDatabase = (connId) => {
    const name = createDbInput.name.trim()
    if (!name) return
    setCreateDbInput(prev => ({ ...prev, loading: true, error: '' }))
    fetch(`/api/database/${connId}/create-database`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    })
      .then(r => {
        if (!r.ok) return r.text().then(t => { throw new Error(t.startsWith('<') ? `Server error (${r.status})` : JSON.parse(t).error || `Error ${r.status}`) })
        return r.json()
      })
      .then(data => {
        if (data.error) {
          setCreateDbInput(prev => ({ ...prev, loading: false, error: data.error }))
        } else {
          setImportConnDatabases(prev => ({ ...prev, [connId]: [...(prev[connId] || []), name].sort() }))
          setCreateDbInput({ connId: null, name: '', loading: false, error: '' })
        }
      })
      .catch(err => setCreateDbInput(prev => ({ ...prev, loading: false, error: err.message })))
  }

  // Build source metadata for table comments
  const buildSourceInfo = () => {
    if (isFileMode) return { type: 'CSV', file: csvFile?.name || 'unknown' }
    if (isDbMode) {
      const srcConn = dbConnections.find(c => c.id === activeDbConnId)
      return { type: 'Database', connection: srcConn?.name || activeDbConnId, database: selectedDatabase || '', object: importObjectName || detectedObject || '' }
    }
    const sfConn = sfConnections.find(c => c.id === sfConnectionId)
    return { type: 'Salesforce', connection: sfConn?.name || sfConnectionId, object: importObjectName || detectedObject || '' }
  }

  const [tableExistsWarning, setTableExistsWarning] = useState(null)

  const handleStartImport = () => {
    const effectiveDbId = importTargetDbId || dbConnectionId
    if (!effectiveDbId || !importTableName.trim()) return
    const dbParam = importTargetSelectedDb ? `?database=${encodeURIComponent(importTargetSelectedDb)}` : ''
    fetch(`/api/database/${effectiveDbId}/table-exists/${encodeURIComponent(importTableName.trim())}${dbParam}`)
      .then(r => r.json())
      .then(data => {
        if (data.exists) {
          setShowImportModal(false)
          setTableExistsWarning({ tableName: importTableName.trim() })
        } else {
          _doStartImport()
        }
      })
      .catch(() => _doStartImport())
  }

  const _doStartImport = () => {
    setTableExistsWarning(null)
    const effectiveDbId = importTargetDbId || dbConnectionId
    const sourceInfo = buildSourceInfo()
    setShowImportModal(false)
    if (onNavigateToJobs) onNavigateToJobs()

    // CSV file import
    if (isFileMode && csvFile) {
      if (!effectiveDbId) return
      setCsvImporting(true)
      setCsvImportJob({ status: 'starting', progress: 0, message: 'Uploading CSV...' })
      setImportJob({ status: 'starting', progress: 0, message: 'Uploading CSV...' })
      const formData = new FormData()
      formData.append('file', csvFile)
      formData.append('targetDbConnectionId', effectiveDbId)
      formData.append('tableName', importTableName)
      formData.append('sourceInfo', JSON.stringify(sourceInfo))
      fetch('/api/import-csv', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
          if (data.error) { setCsvImportJob({ status: 'error', progress: 0, message: data.error }); setImportJob({ status: 'error', progress: 0, message: data.error }); setCsvImporting(false); return }
          csvPollRef.current = setInterval(() => {
            fetch(`/api/import-csv/${data.jobId}/status`).then(r => r.json()).then(s => {
              setCsvImportJob(s)
              setImportJob(s)
              if (!s.running) { clearInterval(csvPollRef.current); csvPollRef.current = null; setCsvImporting(false) }
            }).catch(() => {})
          }, 1000)
        })
        .catch(err => { setCsvImportJob({ status: 'error', progress: 0, message: err.message }); setImportJob({ status: 'error', progress: 0, message: err.message }); setCsvImporting(false) })
      return
    }

    // DB-to-DB import (SQL mode)
    if (isDbMode) {
      if (!activeDbConnId || !effectiveDbId) return
      setImportJob({ status: 'starting', progress: 0, message: 'Starting SQL import...' })
      fetch('/api/import-sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sourceDbConnectionId: activeDbConnId, targetDbConnectionId: effectiveDbId, sql: importSoql, tableName: importTableName, sourceDatabase: selectedDatabase, targetDatabase: importTargetSelectedDb, sourceInfo }),
      })
        .then(r => r.json())
        .then(({ jobId }) => {
          importPollRef.current = setInterval(() => {
            fetch(`/api/import-sql/${jobId}/status`).then(r => r.json()).then(s => {
              setImportJob(s)
              if (!s.running) { clearInterval(importPollRef.current); importPollRef.current = null }
            }).catch(() => {})
          }, 1000)
        })
        .catch(err => setImportJob({ status: 'error', progress: 0, message: err.message }))
      return
    }

    // SF mode imports
    if (!sfConnectionId || !effectiveDbId) return

    if (importSoql) {
      setImportJob({ status: 'starting', progress: 0, message: 'Starting SOQL import...' })
      fetch('/api/import-soql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sfConnectionId, dbConnectionId: effectiveDbId, soql: importSoql, tableName: importTableName, targetDatabase: importTargetSelectedDb, sourceInfo }),
      })
        .then(r => r.json())
        .then(({ jobId }) => {
          importPollRef.current = setInterval(() => {
            fetch(`/api/import-soql/${jobId}/status`).then(r => r.json()).then(s => {
              setImportJob(s)
              if (!s.running) { clearInterval(importPollRef.current); importPollRef.current = null }
            }).catch(() => {})
          }, 1000)
        })
        .catch(err => setImportJob({ status: 'error', progress: 0, message: err.message }))
    } else {
      const apiName = importObjectName || detectedObject || 'Unknown'
      setImportJob({ status: 'starting', progress: 0, message: `Importing ${apiName} to database...` })
      fetch('/api/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sfConnectionId, dbConnectionId: effectiveDbId, objects: [apiName], tableNames: { [apiName]: importTableName }, targetDatabase: importTargetSelectedDb, sourceInfo }),
      })
        .then(r => r.json())
        .then(({ jobId }) => {
          importPollRef.current = setInterval(() => {
            fetch(`/api/download/${jobId}/status`).then(r => r.json()).then(s => {
              const objStatus = s.statuses?.[apiName] || 'pending'
              const objProgress = s.progress?.[apiName] || 0
              const objError = s.errors?.[apiName] || ''
              const objMessage = s.messages?.[apiName] || ''
              setImportJob({
                status: objStatus === 'complete' ? 'complete' : objStatus === 'error' ? 'error' : 'downloading',
                progress: objProgress,
                message: objStatus === 'complete' ? `Imported ${apiName} to ${importTableName}`
                  : objStatus === 'error' ? `Error: ${objError || 'Unknown error importing ' + apiName}`
                  : objMessage || `Downloading ${apiName}... ${objProgress}%`,
                running: s.running,
              })
              if (!s.running) { clearInterval(importPollRef.current); importPollRef.current = null }
            }).catch(() => {})
          }, 1000)
        })
        .catch(err => setImportJob({ status: 'error', progress: 0, message: err.message }))
    }
  }

  // Unified connection dropdown: show all connections
  const allConnections = [...sfConnections, ...dbConnections]
  const [selectedConnId, setSelectedConnId] = useState(activeSfId || '')

  useEffect(() => {
    if (activeSfId) setSelectedConnId(activeSfId)
  }, [activeSfId])

  const handleConnChange = (id) => {
    setSelectedConnId(id)
    if (id === '__csv_file__') {
      setIsFileMode(true)
      setActiveDbConnId('')
      return
    }
    setIsFileMode(false)
    const isSf = sfConnections.some(c => c.id === id)
    if (isSf) {
      onSetActiveSfId && onSetActiveSfId(id)
      setActiveDbConnId('')
    } else if (id) {
      setActiveDbConnId(id)
    } else {
      setActiveDbConnId('')
    }
  }

  const selectedConn = allConnections.find(c => c.id === selectedConnId)

  const sfSelector = (
    <div data-tour="connection-select" style={{ padding: '8px 8px 6px', borderBottom: '1px solid #e5e7eb' }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 4 }}>Connections</div>
      <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
        <ConnectionSelect
          connections={allConnections}
          value={selectedConnId}
          onChange={handleConnChange}
          placeholder="Select connection..."
          extraOptions={[{ value: '__csv_file__', label: 'CSV File Import', icon: <CsvIcon /> }]}
        />
        {onOpenModal && (
          <button className="btn-inline-add" style={{ width: 24, height: 24, fontSize: 13 }} onClick={onOpenModal} title="Add connection">+</button>
        )}
        {selectedConn && onEditConn && (
          <button className="btn-inline-edit" style={{ width: 24, height: 24, fontSize: 12 }} onClick={() => onEditConn(selectedConn)} title="Edit connection">&#9998;</button>
        )}
      </div>
    </div>
  )

  if (!sfConnectionId && !activeDbConnId && !isFileMode) {
    return (
      <div className="work-area" style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <div style={{ width: 280, background: '#fafbfc', borderRight: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column' }}>
          {sfSelector}
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>
            Select a connection to begin
          </div>
        </div>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 13 }}>
          Select a connection to begin
        </div>
      </div>
    )
  }

  // File mode: full left sidebar for drop + files, right for table + import (same layout as SF/DB)
  if (isFileMode) {
    const csvTotalRows = csvPreview?.rows?.length || 0
    const csvTotalPages = Math.max(1, Math.ceil(csvTotalRows / csvPageSize))
    const csvStartIdx = (csvPage - 1) * csvPageSize
    const csvEndIdx = Math.min(csvStartIdx + csvPageSize, csvTotalRows)
    const csvVisibleRows = csvPreview?.rows?.slice(csvStartIdx, csvEndIdx) || []

    const fileSidebar = (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#fafbfc' }}>
        {sfSelector}
        {/* Drop zone */}
        <div
          onDrop={e => { e.preventDefault(); setCsvDragOver(false); handleCsvFile(e.dataTransfer.files[0]) }}
          onDragOver={e => { e.preventDefault(); setCsvDragOver(true) }}
          onDragLeave={() => setCsvDragOver(false)}
          onClick={() => csvFileInputRef.current?.click()}
          className={`file-drop-zone ${csvDragOver ? 'file-drop-active' : ''} ${csvFile ? 'file-drop-has-file' : ''}`}
          style={{ margin: 8, padding: csvFile ? '8px 10px' : '20px 10px', cursor: 'pointer', flexShrink: 0 }}
        >
          <input ref={csvFileInputRef} type="file" accept=".csv" style={{ display: 'none' }} onChange={e => { handleCsvFile(e.target.files[0]); e.target.value = '' }} />
          {csvFile ? (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, width: '100%' }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" style={{ flexShrink: 0 }}>
                <rect x="3" y="1" width="18" height="22" rx="2.5" stroke="#3b82f6" strokeWidth="1.5"/>
                <text x="12" y="15" textAnchor="middle" fontSize="7" fontWeight="700" fill="#3b82f6">CSV</text>
              </svg>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 11, fontWeight: 500, color: '#1f2937', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{csvFile.name}</div>
                <div style={{ fontSize: 10, color: '#6b7280' }}>
                  {csvPreview ? `${csvPreview.totalRows.toLocaleString()} rows, ${csvPreview.columns.length} cols` : `${(csvFile.size / 1024).toFixed(1)} KB`}
                </div>
              </div>
              <button onClick={e => { e.stopPropagation(); handleCsvClear() }} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 14, padding: 0, lineHeight: 1 }} title="Clear">&times;</button>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
              <svg width="28" height="28" viewBox="0 0 36 36" fill="none">
                <rect x="6" y="3" width="24" height="30" rx="3" stroke="#d1d5db" strokeWidth="1.5"/>
                <path d="M14 18l4-4 4 4M18 14v10" stroke="#9ca3af" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
              <div style={{ fontSize: 11, color: '#6b7280', textAlign: 'center' }}>Drop CSV file here<br/>or click to browse</div>
            </div>
          )}
        </div>
        {/* Uploaded files list — same style as objects/tables list */}
        <div style={{ padding: '4px 8px', borderTop: '1px solid #e5e7eb', borderBottom: '1px solid #e5e7eb', flexShrink: 0 }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#374151' }}>
            Files {uploadedFiles.length > 0 && <span style={{ fontWeight: 400, color: '#9ca3af' }}>({uploadedFiles.length})</span>}
          </div>
        </div>
        <div style={{ flex: 1, overflow: 'auto' }}>
          {uploadedFiles.length === 0 ? (
            <div style={{ padding: 16, fontSize: 11, color: '#d1d5db', textAlign: 'center' }}>No files uploaded yet</div>
          ) : (
            uploadedFiles.map(f => (
              <div
                key={f.name}
                className={`soql-item ${csvFile?.name === f.name ? 'soql-item-active' : ''}`}
                onClick={() => handleLoadUploadedFile(f.name)}
                title={`${f.name} — ${f.rows.toLocaleString()} rows, ${f.columns} cols`}
              >
                <div style={{ flex: 1, minWidth: 0 }}>
                  <span className="soql-item-name" style={{ display: 'block', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.name}</span>
                  <span style={{ fontSize: 10, color: '#9ca3af' }}>
                    {f.rows.toLocaleString()} rows &middot; {f.columns} cols &middot; {(f.size / 1024).toFixed(1)} KB
                  </span>
                </div>
                <button
                  onClick={e => handleDeleteUploadedFile(f.name, e)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#d1d5db', fontSize: 13, padding: '0 2px', lineHeight: 1, flexShrink: 0 }}
                  title="Delete file"
                >&times;</button>
              </div>
            ))
          )}
        </div>
      </div>
    )

    const fileResults = (
      <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
        {/* Results header bar — matches SF/DB mode */}
        {csvPreview && csvPreview.columns.length > 0 && (
          <div style={{ padding: '4px 8px', fontSize: 11, color: '#6b7280', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
            <span>{csvPreview.totalRows.toLocaleString()} record{csvPreview.totalRows !== 1 ? 's' : ''} &middot; {csvPreview.columns.length} fields</span>
            <div style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
              <span style={{ fontSize: 10, color: '#9ca3af', marginRight: 2 }}>Import:</span>
              <div style={{ position: 'relative' }}>
                <button
                  className="export-icon-btn export-icon-db"
                  onClick={() => setShowDbPopover(prev => !prev)}
                  disabled={targetDbConnections.length === 0}
                  title="Import CSV data to database"
                >
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><ellipse cx="8" cy="4" rx="6" ry="2.5" stroke="currentColor" strokeWidth="1.2"/><path d="M2 4v8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5V4" stroke="currentColor" strokeWidth="1.2"/><path d="M2 8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5" stroke="currentColor" strokeWidth="1.2"/></svg>
                </button>
                {showDbPopover && (
                  <>
                    <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99 }} onClick={() => { setShowDbPopover(false); setExpandedImportConn(null) }} />
                    <div className="export-db-popover">
                      <div style={{ padding: '6px 10px', fontSize: 10, fontWeight: 600, color: '#6b7280', borderBottom: '1px solid #f3f4f6' }}>Import to Database</div>
                      {targetDbConnections.map(c => {
                        const dbs = importConnDatabases[c.id] || []
                        const isExpanded = expandedImportConn === c.id
                        const selectConn = (db) => {
                          setShowDbPopover(false); setExpandedImportConn(null)
                          setCsvTargetDbId(c.id)
                          setShowImportModal(true)
                          setImportTableName(csvTableName)
                          setImportObjectName(csvFile?.name || 'csv')
                          setImportSoql('')
                          setImportTargetDbId(c.id)
                          setImportTargetSelectedDb(db || '')
                        }
                        return (
                          <div key={c.id}>
                            <div
                              className="export-db-item"
                              onClick={() => {
                                if (dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) {
                                  handleExpandImportConn(c.id)
                                } else {
                                  selectConn(dbs[0] || '')
                                }
                              }}
                            >
                              {getConnectionIcon(c)}
                              <span style={{ flex: 1 }}>{connectionDisplayName(c)}</span>
                              {(dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) && (
                                <span style={{ fontSize: 9, color: '#9ca3af' }}>{isExpanded ? '\u25B4' : '\u25BE'}</span>
                              )}
                            </div>
                            {isExpanded && (
                              <>
                                {dbs.map(db => (
                                  <div
                                    key={db}
                                    className="export-db-item"
                                    style={{ paddingLeft: 28, fontSize: 11 }}
                                    onClick={() => selectConn(db)}
                                  >
                                    <DbIcon size={12} color="#6366f1" />
                                    <span>{db}</span>
                                  </div>
                                ))}
                                {createDbInput.connId === c.id ? (
                                  <div style={{ paddingLeft: 28, padding: '4px 8px 4px 28px', display: 'flex', alignItems: 'center', gap: 4 }}>
                                    <input
                                      autoFocus
                                      value={createDbInput.name}
                                      onChange={e => setCreateDbInput(prev => ({ ...prev, name: e.target.value, error: '' }))}
                                      onKeyDown={e => { if (e.key === 'Enter') handleCreateDatabase(c.id); if (e.key === 'Escape') setCreateDbInput({ connId: null, name: '', loading: false, error: '' }) }}
                                      onClick={e => e.stopPropagation()}
                                      placeholder="Database name"
                                      style={{ fontSize: 11, padding: '2px 6px', border: '1px solid #d1d5db', borderRadius: 4, width: 120, outline: 'none' }}
                                      disabled={createDbInput.loading}
                                    />
                                    <button onClick={(e) => { e.stopPropagation(); handleCreateDatabase(c.id) }} disabled={createDbInput.loading || !createDbInput.name.trim()} style={{ fontSize: 10, padding: '2px 6px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
                                      {createDbInput.loading ? '...' : 'Create'}
                                    </button>
                                    {createDbInput.error && <span style={{ fontSize: 9, color: '#dc2626' }}>{createDbInput.error}</span>}
                                  </div>
                                ) : (
                                  <div
                                    className="export-db-item"
                                    style={{ paddingLeft: 28, fontSize: 11, color: '#2563eb' }}
                                    onClick={(e) => { e.stopPropagation(); setCreateDbInput({ connId: c.id, name: '', loading: false, error: '' }) }}
                                  >
                                    <span style={{ fontSize: 13, lineHeight: 1 }}>+</span>
                                    <span>Create database</span>
                                  </div>
                                )}
                              </>
                            )}
                          </div>
                        )
                      })}
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Full data table */}
        {csvPreview && csvPreview.columns.length > 0 ? (
          <div style={{ flex: 1, overflow: 'auto' }}>
            <table className="results-table" style={{ width: 'max-content', minWidth: '100%' }}>
              <thead><tr>
                <th style={{ width: 28, minWidth: 28, textAlign: 'center', color: '#9ca3af' }}>#</th>
                {csvPreview.columns.map(c => {
                  const minW = Math.max(10, c.length) * 8 + 20
                  return (
                    <th key={c} style={{ width: columnWidths[c] || undefined, minWidth: minW }}>
                      {c}
                      <div className="col-resize-handle" onMouseDown={e => handleColResizeStart(c, e)} />
                    </th>
                  )
                })}
              </tr></thead>
              <tbody>
                {csvVisibleRows.map((row, i) => (
                  <tr key={csvStartIdx + i}>
                    <td style={{ textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>{csvStartIdx + i + 1}</td>
                    {csvPreview.columns.map(c => <td key={c} title={row[c] || ''}>{row[c] ?? ''}</td>)}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 13 }}>
            {csvFile ? 'Parsing file...' : 'Drop a CSV file or select one from the left panel'}
          </div>
        )}

        {/* Pagination */}
        {csvTotalRows > 0 && (
          <div style={{ padding: '4px 8px', borderTop: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0, background: '#f9fafb', fontSize: 11, color: '#6b7280' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span>Rows per page:</span>
              <select value={csvPageSize} onChange={e => { setCsvPageSize(Number(e.target.value)); setCsvPage(1) }} style={{ border: '1px solid #d1d5db', borderRadius: 4, padding: '1px 4px', fontSize: 11, background: 'white' }}>
                {[25, 50, 100, 250, 500].map(n => <option key={n} value={n}>{n}</option>)}
              </select>
            </div>
            <span>{csvStartIdx + 1}–{csvEndIdx} of {csvTotalRows} records</span>
            <div style={{ display: 'flex', gap: 4 }}>
              <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={csvPage <= 1} onClick={() => setCsvPage(1)}>First</button>
              <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={csvPage <= 1} onClick={() => setCsvPage(p => p - 1)}>Prev</button>
              <span style={{ padding: '2px 6px', fontSize: 11 }}>Page {csvPage} / {csvTotalPages}</span>
              <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={csvPage >= csvTotalPages} onClick={() => setCsvPage(p => p + 1)}>Next</button>
              <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={csvPage >= csvTotalPages} onClick={() => setCsvPage(csvTotalPages)}>Last</button>
            </div>
          </div>
        )}
      </div>
    )

    return (
      <div className="work-area">
        <ResizablePanel storageKey="csv-sidebar-width" left={fileSidebar} right={fileResults} initialLeftWidth={280} minLeft={200} minRight={300} />

        {showImportModal && (
          <div className="modal-overlay" onClick={() => setShowImportModal(false)}>
            <div className="modal" style={{ width: 400 }} onClick={e => e.stopPropagation()}>
              <div className="modal-header"><h2>Import to Database</h2><button className="btn-close" onClick={() => setShowImportModal(false)}>&times;</button></div>
              <div className="modal-body">
                {(() => {
                  const targetConn = targetDbConnections.find(c => c.id === importTargetDbId)
                  return targetConn ? (
                    <div className="form-group">
                      <label>Target Connection</label>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#374151', background: '#f9fafb', padding: 8, borderRadius: 6 }}>
                        {getConnectionIcon(targetConn)}
                        <span style={{ fontWeight: 500 }}>{connectionDisplayName(targetConn)}</span>
                        {importTargetSelectedDb && (
                          <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#6366f1' }}>
                            <DbIcon size={12} color="#6366f1" /> {importTargetSelectedDb}
                          </span>
                        )}
                      </div>
                    </div>
                  ) : null
                })()}
                <div className="form-group"><label>Target Table Name</label><input className="form-input" value={importTableName} onChange={e => setImportTableName(e.target.value)} placeholder="e.g. my_data" /><span className="field-hint">Table will be created or replaced in the target database.</span></div>
                <div className="form-group"><label>Source File</label><div style={{ fontSize: 12, color: '#6b7280', background: '#f9fafb', padding: 8, borderRadius: 6, fontFamily: 'monospace', maxHeight: 80, overflow: 'auto' }}>{csvFile?.name || 'CSV file'} ({csvPreview?.totalRows?.toLocaleString() || '?'} rows, {csvPreview?.columns?.length || '?'} columns)</div></div>
                <div style={{ marginTop: 4, padding: '10px 12px', background: '#f8fafc', borderRadius: 8, border: '1px solid #e2e8f0' }}>
                  <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 12, fontWeight: 500, color: '#374151' }}>
                    <input type="checkbox" checked={saveAsStep} onChange={e => { setSaveAsStep(e.target.checked); setStepSaved(false) }} style={{ accentColor: '#3b82f6' }} />
                    Save as reusable step in Orchestrator
                  </label>
                  {saveAsStep && (
                    <input
                      value={saveStepName} onChange={e => setSaveStepName(e.target.value)}
                      placeholder="Step name, e.g. Extract Accounts"
                      style={{ marginTop: 8, width: '100%', padding: '7px 10px', fontSize: 12, border: '1.5px solid #d1d5db', borderRadius: 6, outline: 'none' }}
                      onFocus={e => e.target.style.borderColor = '#3b82f6'} onBlur={e => e.target.style.borderColor = '#d1d5db'}
                    />
                  )}
                </div>
              </div>
              <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
                <button className="btn btn-secondary" onClick={() => setShowImportModal(false)}>Cancel</button>
                <button className="btn btn-primary" onClick={handleStartImport} disabled={!importTableName.trim() || !importTargetDbId || (saveAsStep && !saveStepName.trim())}>Start Import</button>
              </div>
            </div>
          </div>
        )}

        {importJob && (
          <div style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 200, background: 'white', borderRadius: 10, boxShadow: '0 4px 20px rgba(0,0,0,0.15)', border: '1px solid #e5e7eb', padding: '12px 16px', width: 320 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>
                {importJob.status === 'complete' ? 'Import Complete' : importJob.status === 'error' ? 'Import Failed' : 'Importing to Database...'}
              </span>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 16 }} onClick={() => setImportJob(null)}>&times;</button>
            </div>
            <div className="progress-bar-container" style={{ width: '100%', height: 6, marginBottom: 6 }}>
              <div className={`progress-bar ${importJob.status === 'complete' ? 'complete' : importJob.status === 'error' ? 'error' : 'downloading'}`} style={{ width: `${importJob.progress || 0}%` }} />
            </div>
            <div style={{ fontSize: 11, color: '#6b7280' }}>{importJob.message || importJob.status}</div>
            {importJob.status === 'complete' && stepSaved && (
              <div style={{ marginTop: 6, fontSize: 11, color: '#059669', fontWeight: 500 }}>Step saved to Orchestrator</div>
            )}
          </div>
        )}

        {tableExistsWarning && (
          <div className="modal-overlay" onClick={() => setTableExistsWarning(null)}>
            <div className="modal" style={{ width: 400 }} onClick={e => e.stopPropagation()}>
              <div className="modal-header" style={{ background: '#fef3c7', borderBottom: '1px solid #fde68a' }}>
                <h2 style={{ color: '#92400e', display: 'flex', alignItems: 'center', gap: 8 }}>
                  <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><path d="M10 2L1 18h18L10 2z" stroke="#d97706" strokeWidth="1.5" fill="#fef3c7"/><path d="M10 8v4M10 14v1" stroke="#d97706" strokeWidth="1.5" strokeLinecap="round"/></svg>
                  Table Already Exists
                </h2>
                <button className="btn-close" onClick={() => setTableExistsWarning(null)}>&times;</button>
              </div>
              <div className="modal-body">
                <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>
                  The table <strong style={{ fontFamily: 'monospace', background: '#f3f4f6', padding: '1px 6px', borderRadius: 3 }}>{tableExistsWarning.tableName}</strong> already exists and will be <strong>dropped and recreated</strong>.
                </p>
                <p style={{ fontSize: 12, color: '#6b7280', marginTop: 8 }}>All existing data in this table will be lost.</p>
              </div>
              <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
                <button className="btn btn-secondary" onClick={() => setTableExistsWarning(null)}>Cancel</button>
                <button className="btn btn-primary" style={{ background: '#d97706' }} onClick={_doStartImport}>Replace Table</button>
              </div>
            </div>
          </div>
        )}
      </div>
    )
  }

  // Search-filtered rows
  const searchFilteredRows = (() => {
    if (!result?.rows) return []
    if (!resultSearch.trim()) return result.rows
    const term = resultSearch.toLowerCase()
    return result.rows.filter(row =>
      result.columns.some(col => String(row[col] ?? '').toLowerCase().includes(term))
    )
  })()

  // Detect complex/long-text columns from field metadata
  const expandableTypes = new Set(['textarea', 'encryptedstring', 'richtext', 'richtextarea', 'longtextarea', 'html', 'address', 'location', 'complexvalue'])
  const expandableColumns = new Set(
    fields.filter(f => expandableTypes.has((f.type || '').toLowerCase())).map(f => f.name)
  )

  // Pagination (over filtered rows)
  const totalRows = searchFilteredRows.length
  const totalPages = Math.max(1, Math.ceil(totalRows / pageSize))
  const startIdx = (page - 1) * pageSize
  const endIdx = Math.min(startIdx + pageSize, totalRows)
  const visibleRows = searchFilteredRows.slice(startIdx, endIdx)

  // Filtered DB tables
  const filteredDbTables = objectSearch
    ? dbTables.filter(t => t.toLowerCase().includes(objectSearch.toLowerCase()))
    : dbTables

  // Left sidebar: objects (SF) or tables (DB)
  const sidebarContent = (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#fafbfc' }}>
      {sfSelector}
      {isDbMode && dbDatabases.length > 1 && (
        <div style={{ padding: '6px 8px', borderBottom: '1px solid #e5e7eb' }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 4 }}>Database</div>
          <DatabaseSelect
            databases={dbDatabases}
            value={selectedDatabase}
            onChange={db => { setSelectedDatabase(db); setDetectedObject(null); setDetectedObjects([]); setResult(null); setError(null) }}
          />
        </div>
      )}
      <div data-tour="search-objects" style={{ padding: '6px 8px', borderBottom: '1px solid #e5e7eb' }}>
        <input className="soql-search-input" placeholder={isDbMode ? 'Search tables...' : 'Search objects...'} value={objectSearch} onChange={e => setObjectSearch(e.target.value)} />
      </div>
      <div data-tour="objects-list" style={{ flex: 1, overflow: 'auto' }}>
        {isDbMode && dbDatabases.length > 1 && !selectedDatabase ? (
          <div style={{ padding: 12, fontSize: 11, color: '#9ca3af' }}>Select a database above</div>
        ) : isDbMode ? (
          // DB mode: show tables
          dbTablesLoading ? (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
              <div style={{ width: 20, height: 20, border: '2px solid #e5e7eb', borderTopColor: '#3b82f6', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
              <span style={{ marginLeft: 8, fontSize: 12, color: '#9ca3af' }}>Loading tables...</span>
            </div>
          ) : filteredDbTables.length === 0 ? (
            <div style={{ padding: 12, fontSize: 11, color: '#d1d5db' }}>No tables found</div>
          ) : (
            filteredDbTables.map(t => {
              let sourceLabel = null
              try {
                const meta = dbTableComments[t] ? JSON.parse(dbTableComments[t]) : null
                if (meta?.type) sourceLabel = meta.type === 'Salesforce' ? `SF: ${meta.connection}` : meta.type === 'CSV' ? `CSV: ${meta.file}` : `DB: ${meta.connection}`
              } catch {}
              return (
              <div key={t} className={`soql-item ${detectedObjects.includes(t) ? 'soql-item-active' : ''}`}>
                <div style={{ flex: 1, overflow: 'hidden' }} onClick={() => handleSelectObject(t)} title={sourceLabel ? `Source: ${sourceLabel}` : `${t} — click to generate SELECT query`}>
                  <span className="soql-item-name">{t}</span>
                  {sourceLabel && <span style={{ display: 'block', fontSize: 9, color: '#9ca3af', lineHeight: 1.2, marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{sourceLabel}</span>}
                </div>
                {targetDbConnections.length > 0 && (
                  <button
                    className="sidebar-import-btn"
                    onClick={e => {
                      e.stopPropagation()
                      const rect = e.currentTarget.getBoundingClientRect()
                      setSidebarImportPos({ top: rect.bottom + 2, left: rect.left })
                      setSidebarImportItem(sidebarImportItem === t ? null : t)
                      setExpandedImportConn(null)
                    }}
                    title="Import to database"
                  >
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M6 2v6M3.5 5.5L6 8l2.5-2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 9.5h8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
                  </button>
                )}
              </div>
            )})
          )
        ) : (
          // SF mode: show objects
          objectsLoading ? (
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24 }}>
              <div style={{ width: 20, height: 20, border: '2px solid #e5e7eb', borderTopColor: '#3b82f6', borderRadius: '50%', animation: 'spin 0.8s linear infinite' }} />
              <span style={{ marginLeft: 8, fontSize: 12, color: '#9ca3af' }}>Loading objects...</span>
            </div>
          ) : (
            filteredObjects.slice(0, 200).map(o => {
              const isActive = detectedObjects.includes(o.apiName)
              return (
                <div key={o.apiName} className={`soql-item ${isActive ? 'soql-item-active' : ''}`}>
                  <div style={{ flex: 1, overflow: 'hidden', display: 'flex', alignItems: 'baseline', gap: 6 }} onClick={() => handleSelectObject(o.apiName)} title={`${o.name} — click to generate SELECT query`}>
                    <span className="soql-item-name">{o.apiName}</span>
                    <span className="soql-item-label">{o.name}</span>
                  </div>
                  {targetDbConnections.length > 0 && (
                    <button
                      className="sidebar-import-btn"
                      onClick={e => {
                        e.stopPropagation()
                        const rect = e.currentTarget.getBoundingClientRect()
                        setSidebarImportPos({ top: rect.bottom + 2, left: rect.left })
                        setSidebarImportItem(sidebarImportItem === o.apiName ? null : o.apiName)
                        setExpandedImportConn(null)
                      }}
                      title="Import to database"
                    >
                      <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M6 2v6M3.5 5.5L6 8l2.5-2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 9.5h8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
                    </button>
                  )}
                </div>
              )
            })
          )
        )}
      </div>
    </div>
  )

  // Fields panel
  const fieldsPanel = (
    <div style={{ borderTop: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column', maxHeight: 200, overflow: 'hidden', flexShrink: 0 }}>
      <div style={{ padding: '4px 8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid #e5e7eb', flexShrink: 0 }}>
        <span style={{ fontSize: 11, fontWeight: 600, color: '#374151' }}>
          {detectedObjects.length > 0 ? `${detectedObjects.join(', ')} Fields` : 'Fields'}
          {fields.length > 0 && <span style={{ fontWeight: 400, color: '#9ca3af' }}> ({filteredFields.length}/{fields.length})</span>}
        </span>
        {fields.length > 0 && (
          <a href="#" className="field-link-action" onClick={e => { e.preventDefault(); handleSelectAllFields() }}>SELECT *</a>
        )}
      </div>
      {fields.length > 0 && (
        <div data-tour="search-fields" style={{ padding: '2px 8px', borderBottom: '1px solid #e5e7eb', flexShrink: 0 }}>
          <input className="soql-search-input" placeholder="Search fields..." value={fieldSearch} onChange={e => setFieldSearch(e.target.value)} />
        </div>
      )}
      <div style={{ flex: 1, overflow: 'auto', padding: '4px 8px' }}>
        {fieldsLoading ? (
          <div style={{ fontSize: 11, color: '#9ca3af', padding: 4 }}>Loading fields...</div>
        ) : fields.length === 0 ? (
          <div style={{ fontSize: 11, color: '#d1d5db', padding: 4 }}>
            {detectedObject ? 'No fields found' : 'Type a query with FROM clause to see fields'}
          </div>
        ) : (
          <div className="field-chips">
            {filteredFields.map(f => (
              <a key={f.name} href="#" className="field-chip field-chip-link" title={`${f.label} (${f.type}) — click to add`} onClick={e => { e.preventDefault(); handleFieldClick(f.name) }}>
                <span className="field-chip-name">{f.name}</span>
                <span className="field-chip-type">{f.type}</span>
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  )

  // Pagination controls
  const paginationBar = totalRows > 0 ? (
    <div style={{ padding: '4px 8px', borderTop: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0, background: '#f9fafb', fontSize: 11, color: '#6b7280' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span>Rows per page:</span>
        <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setPage(1) }} style={{ border: '1px solid #d1d5db', borderRadius: 4, padding: '1px 4px', fontSize: 11, background: 'white' }}>
          {[25, 50, 100, 250, 500].map(n => <option key={n} value={n}>{n}</option>)}
        </select>
      </div>
      <span>{startIdx + 1}–{endIdx} of {totalRows} records</span>
      <div style={{ display: 'flex', gap: 4 }}>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page <= 1} onClick={() => setPage(1)}>First</button>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</button>
        <span style={{ padding: '2px 6px', fontSize: 11 }}>Page {page} / {totalPages}</span>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</button>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page >= totalPages} onClick={() => setPage(totalPages)}>Last</button>
      </div>
    </div>
  ) : null

  // Editor + fields (top) and results (bottom) in vertical split
  const editorAndResults = (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
      <ResizablePanelV
        storageKey="soql-editor-height"
        initialTopHeight={180}
        minTop={100}
        minBottom={80}
        top={
          <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            {/* Query tabs */}
            {(
              <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1px solid #e5e7eb', background: '#f9fafb', flexShrink: 0, overflow: 'auto' }}>
                {queryTabs.map(tab => (
                  <div
                    key={tab.id}
                    onClick={() => setActiveQueryTabId(tab.id)}
                    style={{
                      padding: '4px 12px', fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                      borderRight: '1px solid #e5e7eb', whiteSpace: 'nowrap', flexShrink: 0,
                      background: tab.id === activeQueryTabId ? 'white' : 'transparent',
                      color: tab.id === activeQueryTabId ? '#1f2937' : '#9ca3af',
                      fontWeight: tab.id === activeQueryTabId ? 600 : 400,
                      borderBottom: tab.id === activeQueryTabId ? '2px solid #3b82f6' : '2px solid transparent',
                    }}
                  >
                    <span>{tab.name}</span>
                    {tab.result && <span style={{ fontSize: 9, color: '#10b981' }}>&#9679;</span>}
                    {queryTabs.length > 1 && (
                      <span
                        onClick={e => { e.stopPropagation(); closeQueryTab(tab.id) }}
                        style={{ fontSize: 13, color: '#d1d5db', cursor: 'pointer', lineHeight: 1 }}
                        title="Close tab"
                      >&times;</span>
                    )}
                  </div>
                ))}
                <button
                  onClick={addQueryTab}
                  style={{
                    padding: '4px 10px', fontSize: 14, cursor: 'pointer', background: 'none', border: 'none',
                    color: '#9ca3af', fontWeight: 600, flexShrink: 0,
                  }}
                  title="New query tab"
                >+</button>
              </div>
            )}
            {/* Toolbar */}
            <div style={{ padding: '4px 8px', display: 'flex', alignItems: 'center', borderBottom: '1px solid #e5e7eb', gap: 6 }}>
              <button data-tour="run-button" className="btn btn-primary" style={{ padding: '3px 12px', fontSize: 12, flexShrink: 0 }} onClick={handleRun} disabled={running || !soql.trim() || !!soqlWarning}>
                {running ? 'Running...' : 'Run'}
              </button>
              {history.length > 0 && (
                <button
                  onClick={() => setShowHistory(true)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 11, color: '#6b7280', padding: '2px 6px', flexShrink: 0, textDecoration: 'underline' }}
                  title="Query History"
                >
                  History ({history.length})
                </button>
              )}
              <span style={{ fontSize: 11, color: '#9ca3af', whiteSpace: 'nowrap' }}>
                {detectedObjects.length > 0 && (
                  <span style={{ fontWeight: 500 }}>
                    {detectedObjects.map((name, idx) => (
                      <React.Fragment key={name}>
                        {idx > 0 && <span style={{ color: '#9ca3af' }}>, </span>}
                        <span
                          style={{ color: '#2563eb', cursor: 'pointer', textDecoration: 'underline', textDecorationStyle: 'dotted', textUnderlineOffset: 2 }}
                          onClick={() => { setBottomTab('fields'); setFieldsObjectFilter(detectedObjects.length > 1 ? name : '') }}
                          title={`View ${name} fields`}
                        >{name}</span>
                      </React.Fragment>
                    ))}
                    {recordCount != null && (
                      <span style={{ fontWeight: 400, color: '#6b7280', marginLeft: 4 }}>({recordCount.toLocaleString()} records)</span>
                    )}
                  </span>
                )}
              </span>
              <div style={{ display: 'flex', gap: 4, alignItems: 'center', flexShrink: 0, marginLeft: 'auto' }}>
                {detectedObject && (
                  <div data-tour="export-buttons" style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
                    {!isDbMode && (
                      <>
                        <span style={{ fontSize: 10, color: '#6b7280', whiteSpace: 'nowrap', marginRight: 2 }}>Export:</span>
                        <button
                          className="export-icon-btn"
                          onClick={() => handleDownloadObjectCsv(detectedObject)}
                          disabled={downloadingCsv}
                          title="Download all records as CSV"
                        >
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.2"/><text x="8" y="11" textAnchor="middle" fontSize="6" fontWeight="700" fill="currentColor">CSV</text></svg>
                        </button>
                        <button
                          className="export-icon-btn export-icon-excel"
                          onClick={() => handleDownloadObjectExcel(detectedObject)}
                          disabled={downloadingCsv}
                          title="Download all records as Excel"
                        >
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.2"/><text x="8" y="11" textAnchor="middle" fontSize="6" fontWeight="700" fill="currentColor">XLS</text></svg>
                        </button>
                      </>
                    )}
                    {isDbMode && (
                      <span style={{ fontSize: 10, color: '#6b7280', whiteSpace: 'nowrap', marginRight: 2 }}>Import:</span>
                    )}
                    <div style={{ position: 'relative' }}>
                      <button
                        className="export-icon-btn export-icon-db"
                        onClick={() => setShowDbPopover(prev => !prev)}
                        disabled={downloadingCsv || targetDbConnections.length === 0}
                        title={isDbMode ? "Import all table data to another database" : "Import all records to database"}
                      >
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><ellipse cx="8" cy="4" rx="6" ry="2.5" stroke="currentColor" strokeWidth="1.2"/><path d="M2 4v8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5V4" stroke="currentColor" strokeWidth="1.2"/><path d="M2 8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5" stroke="currentColor" strokeWidth="1.2"/></svg>
                      </button>
                      {showDbPopover && (
                        <>
                          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99 }} onClick={() => { setShowDbPopover(false); setExpandedImportConn(null) }} />
                          <div className="export-db-popover">
                            <div style={{ padding: '6px 10px', fontSize: 10, fontWeight: 600, color: '#6b7280', borderBottom: '1px solid #f3f4f6' }}>Import to Database</div>
                            {targetDbConnections.map(c => {
                              const dbs = importConnDatabases[c.id] || []
                              const isExpanded = expandedImportConn === c.id
                              return (
                                <div key={c.id}>
                                  <div
                                    className="export-db-item"
                                    onClick={() => {
                                      if (dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) {
                                        handleExpandImportConn(c.id)
                                      } else {
                                        setShowDbPopover(false); setExpandedImportConn(null)
                                        handleImportObjectToDb(detectedObject, c.id, dbs[0] || '')
                                      }
                                    }}
                                  >
                                    {getConnectionIcon(c)}
                                    <span style={{ flex: 1 }}>{connectionDisplayName(c)}</span>
                                    {(dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) && (
                                      <span style={{ fontSize: 9, color: '#9ca3af' }}>{isExpanded ? '\u25B4' : '\u25BE'}</span>
                                    )}
                                  </div>
                                  {isExpanded && (
                                    <>
                                      {dbs.length > 0 && dbs.map(db => (
                                        <div
                                          key={db}
                                          className="export-db-item"
                                          style={{ paddingLeft: 28, fontSize: 11 }}
                                          onClick={() => { setShowDbPopover(false); setExpandedImportConn(null); handleImportObjectToDb(detectedObject, c.id, db) }}
                                        >
                                          <DbIcon size={12} color="#6366f1" />
                                          <span>{db}</span>
                                        </div>
                                      ))}
                                      {createDbInput.connId === c.id ? (
                                        <div style={{ paddingLeft: 28, padding: '4px 8px 4px 28px', display: 'flex', alignItems: 'center', gap: 4 }}>
                                          <input
                                            autoFocus
                                            value={createDbInput.name}
                                            onChange={e => setCreateDbInput(prev => ({ ...prev, name: e.target.value, error: '' }))}
                                            onKeyDown={e => { if (e.key === 'Enter') handleCreateDatabase(c.id); if (e.key === 'Escape') setCreateDbInput({ connId: null, name: '', loading: false, error: '' }) }}
                                            onClick={e => e.stopPropagation()}
                                            placeholder="Database name"
                                            style={{ fontSize: 11, padding: '2px 6px', border: '1px solid #d1d5db', borderRadius: 4, width: 120, outline: 'none' }}
                                            disabled={createDbInput.loading}
                                          />
                                          <button onClick={(e) => { e.stopPropagation(); handleCreateDatabase(c.id) }} disabled={createDbInput.loading || !createDbInput.name.trim()} style={{ fontSize: 10, padding: '2px 6px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
                                            {createDbInput.loading ? '...' : 'Create'}
                                          </button>
                                          {createDbInput.error && <span style={{ fontSize: 9, color: '#dc2626' }}>{createDbInput.error}</span>}
                                        </div>
                                      ) : (
                                        <div
                                          className="export-db-item"
                                          style={{ paddingLeft: 28, fontSize: 11, color: '#2563eb' }}
                                          onClick={(e) => { e.stopPropagation(); setCreateDbInput({ connId: c.id, name: '', loading: false, error: '' }) }}
                                        >
                                          <span style={{ fontSize: 13, lineHeight: 1 }}>+</span>
                                          <span>Create database</span>
                                        </div>
                                      )}
                                    </>
                                  )}
                                </div>
                              )
                            })}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
            {/* SOQL warning banner */}
            {soqlWarning && (
              <div style={{ padding: '6px 12px', background: '#fef3c7', borderBottom: '1px solid #f59e0b', display: 'flex', alignItems: 'flex-start', gap: 6, flexShrink: 0 }}>
                <span style={{ color: '#b45309', fontSize: 14, lineHeight: 1, flexShrink: 0, marginTop: 1 }}>&#9888;</span>
                <span style={{ fontSize: 11, color: '#92400e', lineHeight: 1.4 }}>
                  <strong>SQL syntax detected:</strong> For Salesforce connections you must use SOQL queries. {soqlWarning}
                </span>
              </div>
            )}
            {/* Query textarea */}
            <div data-tour="query-editor" style={{ flex: 1, minHeight: 0, position: 'relative' }}>
              <textarea
                ref={textareaRef}
                className="sql-editor"
                style={{ width: '100%', height: '100%', minHeight: 0 }}
                value={soql}
                onChange={handleSoqlChange}
                onKeyDown={handleKeyDown}
                onBlur={() => { setTimeout(() => { setAutoComplete(prev => ({ ...prev, show: false })); setCommandDropdown(prev => ({ ...prev, show: false })) }, 150) }}
                placeholder={isDbMode ? "Enter SQL query..." : "Enter SOQL query..."}
                spellCheck={false}
              />
              {autoComplete.show && autoComplete.items.length > 0 && (
                <div className="autocomplete-popup" style={{ top: acPosition.top, left: acPosition.left }}>
                  {autoComplete.items.slice(0, 8).map((f, i) => (
                    <div
                      key={f.name}
                      className={`autocomplete-item ${i === autoComplete.selectedIdx ? 'autocomplete-item-active' : ''}`}
                      onMouseDown={e => { e.preventDefault(); insertAutoCompleteField(f.name) }}
                      onMouseEnter={() => setAutoComplete(prev => ({ ...prev, selectedIdx: i }))}
                    >
                      <span className="autocomplete-field-name">{f.name}</span>
                      <span className="autocomplete-field-type">{f.type}</span>
                    </div>
                  ))}
                </div>
              )}
              {commandDropdown.show && commandDropdown.items.length > 0 && (
                <div className="autocomplete-popup" style={{ top: cmdDropdownPos.top, left: cmdDropdownPos.left, minWidth: 280 }}>
                  <div style={{ padding: '4px 10px', fontSize: 10, fontWeight: 600, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: 0.5 }}>
                    {{ connect: 'Select Connection', use: 'Select Database', 'import-table': 'Select Table to Import', 'import-conn': 'Import To Connection', 'import-db': 'Select Database' }[commandDropdown.type] || 'Select'}
                  </div>
                  {commandDropdown.items.map((item, i) => (
                    <div
                      key={item.id}
                      className={`autocomplete-item ${i === commandDropdown.selectedIdx ? 'autocomplete-item-active' : ''}`}
                      onMouseDown={e => { e.preventDefault(); selectCommandItem(item) }}
                      onMouseEnter={() => setCommandDropdown(prev => ({ ...prev, selectedIdx: i }))}
                      style={{ display: 'flex', alignItems: 'center', gap: 8 }}
                    >
                      {(commandDropdown.type === 'connect' || commandDropdown.type === 'import-conn') ? (
                        <>
                          <span style={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
                            {item.isActive ? <span style={{ color: '#22c55e', fontWeight: 700, fontSize: 14 }}>&#10003;</span> : getConnectionIcon(item.icon)}
                          </span>
                          <span className="autocomplete-field-name" style={{ flex: 1 }}>{item.name}</span>
                          <span className="autocomplete-field-type">{item.type}</span>
                        </>
                      ) : (commandDropdown.type === 'use' || commandDropdown.type === 'import-db') ? (
                        <>
                          <span style={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
                            {item.isActive ? <span style={{ color: '#22c55e', fontWeight: 700, fontSize: 14 }}>&#10003;</span> : <DbIcon size={14} color="#6366f1" />}
                          </span>
                          <span className="autocomplete-field-name" style={{ flex: 1 }}>{item.name}</span>
                        </>
                      ) : (
                        <span className="autocomplete-field-name" style={{ flex: 1 }}>{item.name}</span>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
            {/* Fields panel moved to bottom tabs */}
          </div>
        }
        bottom={
          <div data-tour="results-area" style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
            {/* Tabs: Fields / Results */}
            <div style={{ display: 'flex', borderBottom: '2px solid #e5e7eb', flexShrink: 0, background: '#fafbfc', alignItems: 'center' }}>
              <button
                data-tour="fields-tab"
                onClick={() => setBottomTab('fields')}
                style={{
                  padding: '5px 16px', fontSize: 11, fontWeight: 600, cursor: 'pointer', border: 'none', background: 'none',
                  color: bottomTab === 'fields' ? '#3b82f6' : '#9ca3af',
                  borderBottom: bottomTab === 'fields' ? '2px solid #3b82f6' : '2px solid transparent',
                  marginBottom: -2,
                }}
              >
                Fields {detectedObject && fields.length > 0 ? `(${fields.length})` : ''}
              </button>
              <button
                data-tour="results-tab"
                onClick={() => setBottomTab('results')}
                style={{
                  padding: '5px 16px', fontSize: 11, fontWeight: 600, cursor: 'pointer', border: 'none', background: 'none',
                  color: bottomTab === 'results' ? '#3b82f6' : '#9ca3af',
                  borderBottom: bottomTab === 'results' ? '2px solid #3b82f6' : '2px solid transparent',
                  marginBottom: -2,
                }}
              >
                Results {result ? `(${result.rowCount})` : ''}
              </button>
              <div style={{ flex: 1 }} />
              {detectedObject && (
                <button
                  onClick={() => setFieldsRefreshKey(k => k + 1)}
                  title="Refresh fields"
                  disabled={fieldsLoading}
                  style={{
                    background: 'none', border: 'none', cursor: fieldsLoading ? 'not-allowed' : 'pointer',
                    padding: '3px 10px', marginRight: 4, fontSize: 12, color: '#6b7280',
                    opacity: fieldsLoading ? 0.4 : 0.7, display: 'flex', alignItems: 'center',
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ animation: fieldsLoading ? 'spin 1s linear infinite' : 'none' }}>
                    <path d="M21 2v6h-6"/><path d="M3 12a9 9 0 0115.36-6.36L21 8"/>
                    <path d="M3 22v-6h6"/><path d="M21 12a9 9 0 01-15.36 6.36L3 16"/>
                  </svg>
                </button>
              )}
            </div>

            {/* Fields tab */}
            {bottomTab === 'fields' && (
              detectedObject && (fieldsLoading || fields.length > 0) ? (
                <div style={{ overflow: 'auto', padding: 12, maxHeight: 'calc(100vh - 280px)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, gap: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
                      {detectedObjects.length > 1 ? (
                        <>
                          <button
                            onClick={() => setFieldsObjectFilter('')}
                            style={{
                              padding: '2px 8px', fontSize: 11, fontWeight: 600, border: '1px solid', borderRadius: 12, cursor: 'pointer',
                              background: !fieldsObjectFilter ? '#2563eb' : '#fff',
                              color: !fieldsObjectFilter ? '#fff' : '#6b7280',
                              borderColor: !fieldsObjectFilter ? '#2563eb' : '#d1d5db',
                            }}
                          >All ({fields.length})</button>
                          {detectedObjects.map(name => {
                            const count = fields.filter(f => f._objectName === name).length
                            const active = fieldsObjectFilter === name
                            return (
                              <button
                                key={name}
                                onClick={() => setFieldsObjectFilter(active ? '' : name)}
                                style={{
                                  padding: '2px 8px', fontSize: 11, fontWeight: 600, border: '1px solid', borderRadius: 12, cursor: 'pointer',
                                  background: active ? '#2563eb' : '#fff',
                                  color: active ? '#fff' : '#374151',
                                  borderColor: active ? '#2563eb' : '#d1d5db',
                                }}
                              >{name} ({count})</button>
                            )
                          })}
                        </>
                      ) : (
                        <div style={{ fontSize: 12, fontWeight: 600, color: '#374151' }}>
                          {detectedObjects.join(', ')} <span style={{ fontWeight: 400, color: '#9ca3af' }}>({fields.length} {isDbMode ? 'columns' : 'fields'})</span>
                        </div>
                      )}
                    </div>
                    <div style={{ width: 200, flexShrink: 0 }}>
                      <input
                        className="soql-search-input"
                        placeholder="Search fields..."
                        value={fieldSearch}
                        onChange={e => setFieldSearch(e.target.value)}
                        style={{ fontSize: 11, padding: '3px 8px', width: '100%' }}
                      />
                    </div>
                  </div>
                  {fieldsLoading ? (
                    <div style={{ padding: 20, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>Loading fields...</div>
                  ) : (
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                      <thead>
                        <tr style={{ borderBottom: '2px solid #e5e7eb' }}>
                          <th style={{ textAlign: 'left', padding: '4px 8px', color: '#6b7280', fontWeight: 600, width: 40 }}>#</th>
                          <th style={{ textAlign: 'left', padding: '4px 8px', color: '#6b7280', fontWeight: 600 }}>Field</th>
                          <th style={{ textAlign: 'left', padding: '4px 8px', color: '#6b7280', fontWeight: 600, width: 140 }}>Type</th>
                          {!isDbMode && <th style={{ textAlign: 'left', padding: '4px 8px', color: '#6b7280', fontWeight: 600 }}>Label</th>}
                        </tr>
                      </thead>
                      <tbody>
                        {(() => {
                          let counter = 0
                          let lastObj = null
                          return filteredFields.map((f) => {
                            counter++
                            const showHeader = detectedObjects.length > 1 && f._objectName && f._objectName !== lastObj
                            lastObj = f._objectName || lastObj
                            const objFieldCount = showHeader ? fields.filter(x => x._objectName === f._objectName).length : 0
                            return (
                              <React.Fragment key={f.name}>
                                {showHeader && (
                                  <tr style={{ background: '#f0f4ff', borderBottom: '1px solid #e5e7eb' }}>
                                    <td colSpan={isDbMode ? 3 : 4} style={{ padding: '4px 8px', fontSize: 11, fontWeight: 600, color: '#2563eb' }}>
                                      {f._objectName} <span style={{ fontWeight: 400, color: '#9ca3af' }}>({objFieldCount} {isDbMode ? 'columns' : 'fields'})</span>
                                    </td>
                                  </tr>
                                )}
                                <tr style={{ borderBottom: '1px solid #f3f4f6' }} className="field-row-hover">
                                  <td style={{ padding: '3px 8px', color: '#9ca3af', fontSize: 11 }}>{counter}</td>
                                  <td style={{ padding: '3px 8px', color: '#1e40af', cursor: 'pointer' }} onClick={() => handleFieldClick(f.name)} title="Click to add to query">
                                    <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: 2, background: fieldTypeColor(f.type), marginRight: 6, verticalAlign: 'middle' }} />
                                    {f.name}
                                  </td>
                                  <td style={{ padding: '3px 8px', color: '#9ca3af' }}>{f.type}</td>
                                  {!isDbMode && <td style={{ padding: '3px 8px', color: '#6b7280', fontSize: 11 }}>{f.label}</td>}
                                </tr>
                              </React.Fragment>
                            )
                          })
                        })()}
                      </tbody>
                    </table>
                  )}
                </div>
              ) : (
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 12 }}>
                  {isDbMode ? 'Select a table to see its fields' : 'Select an object to see its fields'}
                </div>
              )
            )}

            {/* Results tab */}
            {bottomTab === 'results' && (
              <>
                {error && <div className="test-result test-error" style={{ margin: 8 }}>{error}</div>}
                {result && result.columns && result.columns.length > 0 && (
                  <>
                    <div data-tour="results-toolbar" style={{ padding: '4px 8px', fontSize: 11, color: '#6b7280', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
                      <span>
                        {result.rowCount} record{result.rowCount !== 1 ? 's' : ''} &middot; {result.elapsed}s &middot; {result.columns.length} fields
                        {resultSearch && totalRows !== result.rows.length && (
                          <span style={{ color: '#f59e0b', marginLeft: 6 }}>({totalRows} matched)</span>
                        )}
                      </span>
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" style={{ position: 'absolute', left: 6, pointerEvents: 'none' }}>
                            <circle cx="6.5" cy="6.5" r="5" stroke="#9ca3af" strokeWidth="1.3"/><path d="M10.5 10.5L14 14" stroke="#9ca3af" strokeWidth="1.3" strokeLinecap="round"/>
                          </svg>
                          <input
                            className="soql-search-input"
                            placeholder="Search results..."
                            value={resultSearch}
                            onChange={e => { setResultSearch(e.target.value); setPage(1) }}
                            style={{ fontSize: 11, padding: '2px 8px 2px 22px', width: 160 }}
                          />
                          {resultSearch && (
                            <button
                              onClick={() => { setResultSearch(''); setPage(1) }}
                              style={{ position: 'absolute', right: 4, background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 13, lineHeight: 1, padding: 0 }}
                              title="Clear search"
                            >&times;</button>
                          )}
                        </div>
                        <span style={{ fontSize: 10, color: '#9ca3af', marginRight: 2 }}>Export ({totalRows}):</span>
                        <button
                          className="export-icon-btn"
                          onClick={isDbMode || totalRows <= 1000 ? exportResultsCsv : handleDownloadSoqlCsv}
                          disabled={downloadingCsv}
                          title={totalRows > 1000 ? 'Download all records as CSV (server)' : 'Export results as CSV'}
                        >
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.2"/><text x="8" y="11" textAnchor="middle" fontSize="6" fontWeight="700" fill="currentColor">CSV</text></svg>
                        </button>
                        <button
                          className="export-icon-btn export-icon-excel"
                          onClick={exportResultsExcel}
                          disabled={downloadingCsv}
                          title="Export results as Excel"
                        >
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.2"/><text x="8" y="11" textAnchor="middle" fontSize="6" fontWeight="700" fill="currentColor">XLS</text></svg>
                        </button>
                        <div style={{ position: 'relative' }}>
                          <button
                            className="export-icon-btn export-icon-db"
                            onClick={() => setShowResultsDbPopover(prev => !prev)}
                            disabled={downloadingCsv || targetDbConnections.length === 0}
                            title="Import results to database"
                          >
                            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><ellipse cx="8" cy="4" rx="6" ry="2.5" stroke="currentColor" strokeWidth="1.2"/><path d="M2 4v8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5V4" stroke="currentColor" strokeWidth="1.2"/><path d="M2 8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5" stroke="currentColor" strokeWidth="1.2"/></svg>
                          </button>
                          {showResultsDbPopover && (
                            <>
                              <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99 }} onClick={() => { setShowResultsDbPopover(false); setExpandedImportConn(null) }} />
                              <div className="export-db-popover">
                                <div style={{ padding: '6px 10px', fontSize: 10, fontWeight: 600, color: '#6b7280', borderBottom: '1px solid #f3f4f6' }}>Import to Database</div>
                                {targetDbConnections.map(c => {
                                  const dbs = importConnDatabases[c.id] || []
                                  const isExpanded = expandedImportConn === c.id
                                  return (
                                    <div key={c.id}>
                                      <div
                                        className="export-db-item"
                                        onClick={() => {
                                          if (dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) {
                                            handleExpandImportConn(c.id)
                                          } else {
                                            setShowResultsDbPopover(false); setExpandedImportConn(null)
                                            handleImportSoqlToDb(c.id, dbs[0] || '')
                                          }
                                        }}
                                      >
                                        {getConnectionIcon(c)}
                                        <span style={{ flex: 1 }}>{connectionDisplayName(c)}</span>
                                        {(dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) && (
                                          <span style={{ fontSize: 9, color: '#9ca3af' }}>{isExpanded ? '\u25B4' : '\u25BE'}</span>
                                        )}
                                      </div>
                                      {isExpanded && (
                                        <>
                                          {dbs.length > 0 && dbs.map(db => (
                                            <div
                                              key={db}
                                              className="export-db-item"
                                              style={{ paddingLeft: 28, fontSize: 11 }}
                                              onClick={() => { setShowResultsDbPopover(false); setExpandedImportConn(null); handleImportSoqlToDb(c.id, db) }}
                                            >
                                              <DbIcon size={12} color="#6366f1" />
                                              <span>{db}</span>
                                            </div>
                                          ))}
                                          {createDbInput.connId === c.id ? (
                                            <div style={{ paddingLeft: 28, padding: '4px 8px 4px 28px', display: 'flex', alignItems: 'center', gap: 4 }}>
                                              <input
                                                autoFocus
                                                value={createDbInput.name}
                                                onChange={e => setCreateDbInput(prev => ({ ...prev, name: e.target.value, error: '' }))}
                                                onKeyDown={e => { if (e.key === 'Enter') handleCreateDatabase(c.id); if (e.key === 'Escape') setCreateDbInput({ connId: null, name: '', loading: false, error: '' }) }}
                                                onClick={e => e.stopPropagation()}
                                                placeholder="Database name"
                                                style={{ fontSize: 11, padding: '2px 6px', border: '1px solid #d1d5db', borderRadius: 4, width: 120, outline: 'none' }}
                                                disabled={createDbInput.loading}
                                              />
                                              <button onClick={(e) => { e.stopPropagation(); handleCreateDatabase(c.id) }} disabled={createDbInput.loading || !createDbInput.name.trim()} style={{ fontSize: 10, padding: '2px 6px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
                                                {createDbInput.loading ? '...' : 'Create'}
                                              </button>
                                              {createDbInput.error && <span style={{ fontSize: 9, color: '#dc2626' }}>{createDbInput.error}</span>}
                                            </div>
                                          ) : (
                                            <div
                                              className="export-db-item"
                                              style={{ paddingLeft: 28, fontSize: 11, color: '#2563eb' }}
                                              onClick={(e) => { e.stopPropagation(); setCreateDbInput({ connId: c.id, name: '', loading: false, error: '' }) }}
                                            >
                                              <span style={{ fontSize: 13, lineHeight: 1 }}>+</span>
                                              <span>Create database</span>
                                            </div>
                                          )}
                                        </>
                                      )}
                                    </div>
                                  )
                                })}
                              </div>
                            </>
                          )}
                        </div>
                        <button
                          onClick={() => setResultsMaximized(true)}
                          title="Maximize results"
                          style={{
                            background: 'none', border: '1px solid #d1d5db', borderRadius: 4,
                            cursor: 'pointer', padding: '2px 6px', fontSize: 12, color: '#6b7280',
                            lineHeight: 1, display: 'flex', alignItems: 'center',
                          }}
                        >
                          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                            <path d="M8 3H5a2 2 0 00-2 2v3m18 0V5a2 2 0 00-2-2h-3m0 18h3a2 2 0 002-2v-3M3 16v3a2 2 0 002 2h3"/>
                          </svg>
                        </button>
                      </div>
                    </div>
                    <div style={{ flex: 1, overflow: 'auto', minHeight: 0 }}>
                      <table className="results-table" style={{ width: 'max-content', minWidth: '100%' }}>
                        <thead><tr>
                          <th style={{ width: 28, minWidth: 28, textAlign: 'center', color: '#9ca3af' }}>#</th>
                          {result.columns.map(col => {
                            const minW = Math.max(10, col.length) * 8 + 20
                            return (
                              <th key={col} style={{ width: columnWidths[col] || undefined, minWidth: minW }}>
                                {col}
                                <div className="col-resize-handle" onMouseDown={e => handleColResizeStart(col, e)} />
                              </th>
                            )
                          })}
                        </tr></thead>
                        <tbody>
                          {visibleRows.map((row, i) => (
                            <tr key={startIdx + i}>
                              <td style={{ textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>{startIdx + i + 1}</td>
                              {result.columns.map(col => {
                                const val = row[col] ?? ''
                                const valStr = typeof val === 'object' && val !== null ? JSON.stringify(val, null, 2) : String(val)
                                const isExpandable = expandableColumns.has(col) || (typeof val === 'object' && val !== null) || (valStr.length > 100 && (valStr.startsWith('OrderedDict') || valStr.startsWith('{') || valStr.startsWith('[')))
                                if (isExpandable && val) {
                                  const preview = valStr.length > 30 ? valStr.slice(0, 30) : valStr
                                  return <td key={col} style={{ cursor: 'pointer' }} onClick={() => setTextCellPopup({ column: col, value: valStr })}>{preview}<span style={{ color: '#6366f1', fontWeight: 600 }}>...</span></td>
                                }
                                return <td key={col} title={valStr || ''}>{valStr}</td>
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {paginationBar}
                  </>
                )}
                {!error && !result && (
                  <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 12 }}>Run a query to see results</div>
                )}
              </>
            )}
          </div>
        }
      />
    </div>
  )

  return (
    <div className="work-area">
      <ResizablePanel storageKey="soql-sidebar-width" left={sidebarContent} right={editorAndResults} initialLeftWidth={280} minLeft={200} minRight={300} />

      {sidebarImportItem && (
        <>
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 199 }} onClick={() => setSidebarImportItem(null)} />
          <div className="sidebar-import-popover" style={{ position: 'fixed', top: sidebarImportPos.top, left: sidebarImportPos.left }}>
            <div style={{ padding: '6px 10px', fontSize: 10, fontWeight: 600, color: '#6b7280', borderBottom: '1px solid #f3f4f6' }}>Import "{sidebarImportItem}" to</div>
            {targetDbConnections.map(c => {
              const dbs = importConnDatabases[c.id] || []
              const isExpanded = expandedImportConn === c.id
              return (
                <div key={c.id}>
                  <div
                    className="export-db-item"
                    onClick={() => {
                      if (dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) {
                        handleExpandImportConn(c.id)
                      } else {
                        setSidebarImportItem(null)
                        handleImportObjectToDb(sidebarImportItem, c.id, dbs[0] || '')
                      }
                    }}
                  >
                    {getConnectionIcon(c)}
                    <span style={{ flex: 1 }}>{connectionDisplayName(c)}</span>
                    {(dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) && (
                      <span style={{ fontSize: 9, color: '#9ca3af' }}>{isExpanded ? '\u25B4' : '\u25BE'}</span>
                    )}
                  </div>
                  {isExpanded && (
                    <>
                      {dbs.length > 0 && dbs.map(db => (
                        <div
                          key={db}
                          className="export-db-item"
                          style={{ paddingLeft: 28, fontSize: 11 }}
                          onClick={() => { setSidebarImportItem(null); handleImportObjectToDb(sidebarImportItem, c.id, db) }}
                        >
                          <DbIcon size={12} color="#6366f1" />
                          <span>{db}</span>
                        </div>
                      ))}
                      {createDbInput.connId === c.id ? (
                        <div style={{ paddingLeft: 28, padding: '4px 8px 4px 28px', display: 'flex', alignItems: 'center', gap: 4 }}>
                          <input
                            autoFocus
                            value={createDbInput.name}
                            onChange={e => setCreateDbInput(prev => ({ ...prev, name: e.target.value, error: '' }))}
                            onKeyDown={e => { if (e.key === 'Enter') handleCreateDatabase(c.id); if (e.key === 'Escape') setCreateDbInput({ connId: null, name: '', loading: false, error: '' }) }}
                            onClick={e => e.stopPropagation()}
                            placeholder="Database name"
                            style={{ fontSize: 11, padding: '2px 6px', border: '1px solid #d1d5db', borderRadius: 4, width: 120, outline: 'none' }}
                            disabled={createDbInput.loading}
                          />
                          <button onClick={(e) => { e.stopPropagation(); handleCreateDatabase(c.id) }} disabled={createDbInput.loading || !createDbInput.name.trim()} style={{ fontSize: 10, padding: '2px 6px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
                            {createDbInput.loading ? '...' : 'Create'}
                          </button>
                          {createDbInput.error && <span style={{ fontSize: 9, color: '#dc2626' }}>{createDbInput.error}</span>}
                        </div>
                      ) : (
                        <div
                          className="export-db-item"
                          style={{ paddingLeft: 28, fontSize: 11, color: '#2563eb' }}
                          onClick={(e) => { e.stopPropagation(); setCreateDbInput({ connId: c.id, name: '', loading: false, error: '' }) }}
                        >
                          <span style={{ fontSize: 13, lineHeight: 1 }}>+</span>
                          <span>Create database</span>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </>
      )}

      {showImportModal && (
        <div className="modal-overlay" onClick={() => setShowImportModal(false)}>
          <div className="modal" style={{ width: 400 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header"><h2>Import to Database</h2><button className="btn-close" onClick={() => setShowImportModal(false)}>&times;</button></div>
            <div className="modal-body">
              {(() => {
                const targetConn = targetDbConnections.find(c => c.id === (importTargetDbId || dbConnectionId))
                return targetConn ? (
                  <div className="form-group">
                    <label>Target Connection</label>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#374151', background: '#f9fafb', padding: 8, borderRadius: 6 }}>
                      {getConnectionIcon(targetConn)}
                      <span style={{ fontWeight: 500 }}>{connectionDisplayName(targetConn)}</span>
                      {importTargetSelectedDb && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#6366f1' }}>
                          <DbIcon size={12} color="#6366f1" /> {importTargetSelectedDb}
                        </span>
                      )}
                    </div>
                  </div>
                ) : null
              })()}
              <div className="form-group"><label>Target Table Name</label><input className="form-input" value={importTableName} onChange={e => setImportTableName(e.target.value)} placeholder="e.g. sf_account" /><span className="field-hint">Table will be created or replaced in the target database.</span></div>
              <div className="form-group"><label>{isFileMode ? 'Source File' : importSoql ? (isDbMode ? 'SQL Query' : 'SOQL Query') : 'Source'}</label><div style={{ fontSize: 12, color: '#6b7280', background: '#f9fafb', padding: 8, borderRadius: 6, fontFamily: 'monospace', maxHeight: 80, overflow: 'auto' }}>{isFileMode ? `${csvFile?.name || 'CSV file'} (${csvPreview?.totalRows?.toLocaleString() || '?'} rows, ${csvPreview?.columns?.length || '?'} columns)` : importSoql || `All records from ${detectedObject} (all fields)`}</div></div>
              <div style={{ marginTop: 4, padding: '10px 12px', background: '#f8fafc', borderRadius: 8, border: '1px solid #e2e8f0' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 12, fontWeight: 500, color: '#374151' }}>
                  <input type="checkbox" checked={saveAsStep} onChange={e => { setSaveAsStep(e.target.checked); setStepSaved(false) }} style={{ accentColor: '#3b82f6' }} />
                  Save as reusable step in Orchestrator
                </label>
                {saveAsStep && (
                  <input
                    value={saveStepName} onChange={e => setSaveStepName(e.target.value)}
                    placeholder="Step name, e.g. Extract Accounts"
                    style={{ marginTop: 8, width: '100%', padding: '7px 10px', fontSize: 12, border: '1.5px solid #d1d5db', borderRadius: 6, outline: 'none' }}
                    onFocus={e => e.target.style.borderColor = '#3b82f6'} onBlur={e => e.target.style.borderColor = '#d1d5db'}
                  />
                )}
              </div>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-secondary" onClick={() => setShowImportModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleStartImport} disabled={!importTableName.trim() || !(importTargetDbId || dbConnectionId) || (saveAsStep && !saveStepName.trim())}>Start Import</button>
            </div>
          </div>
        </div>
      )}

      {tableExistsWarning && (
        <div className="modal-overlay" onClick={() => setTableExistsWarning(null)}>
          <div className="modal" style={{ width: 400 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header" style={{ background: '#fef3c7', borderBottom: '1px solid #fde68a' }}>
              <h2 style={{ color: '#92400e', display: 'flex', alignItems: 'center', gap: 8 }}>
                <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><path d="M10 2L1 18h18L10 2z" stroke="#d97706" strokeWidth="1.5" fill="#fef3c7"/><path d="M10 8v4M10 14v1" stroke="#d97706" strokeWidth="1.5" strokeLinecap="round"/></svg>
                Table Already Exists
              </h2>
              <button className="btn-close" onClick={() => setTableExistsWarning(null)}>&times;</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>
                The table <strong style={{ fontFamily: 'monospace', background: '#f3f4f6', padding: '1px 6px', borderRadius: 3 }}>{tableExistsWarning.tableName}</strong> already exists and will be <strong>dropped and recreated</strong>.
              </p>
              <p style={{ fontSize: 12, color: '#6b7280', marginTop: 8 }}>All existing data in this table will be lost.</p>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-secondary" onClick={() => setTableExistsWarning(null)}>Cancel</button>
              <button className="btn btn-primary" style={{ background: '#d97706' }} onClick={_doStartImport}>Replace Table</button>
            </div>
          </div>
        </div>
      )}

      {showHistory && (
        <div className="modal-overlay" onClick={() => setShowHistory(false)}>
          <div className="modal" style={{ width: 560 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Query History</h2>
              <button className="btn-close" onClick={() => setShowHistory(false)}>&times;</button>
            </div>
            <div className="modal-body" style={{ padding: 0, maxHeight: 400, overflow: 'auto' }}>
              {history.length === 0 ? (
                <div style={{ padding: 24, textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>No queries yet</div>
              ) : (
                history.map((h, i) => (
                  <div
                    key={i}
                    onClick={() => { setSoql(h.soql); setShowHistory(false) }}
                    style={{
                      padding: '10px 16px', borderBottom: '1px solid #f3f4f6', cursor: 'pointer',
                      display: 'flex', flexDirection: 'column', gap: 4,
                      transition: 'background 0.1s',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = '#f0f7ff'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
                      <span style={{
                        fontSize: 9, fontWeight: 600, padding: '1px 5px', borderRadius: 3,
                        background: h.mode === 'db' ? '#dbeafe' : '#fef3c7',
                        color: h.mode === 'db' ? '#1e40af' : '#92400e',
                      }}>
                        {h.mode === 'db' ? 'DB' : 'SF'}
                      </span>
                      <span style={{ fontSize: 11, fontWeight: 600, color: '#374151' }}>{h.connection || ''}</span>
                      {h.database && (
                        <span style={{ fontSize: 10, color: '#6b7280' }}>{h.database}</span>
                      )}
                      {h.table && (
                        <span style={{ fontSize: 10, color: '#2563eb' }}>{h.table}</span>
                      )}
                    </div>
                    <div style={{ fontFamily: 'monospace', fontSize: 12, color: '#1f2937', wordBreak: 'break-all', whiteSpace: 'pre-wrap', userSelect: 'text' }}>
                      {h.soql}
                    </div>
                    <div style={{ fontSize: 10, color: '#9ca3af' }}>
                      {h.rows} rows &middot; {h.time}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {importJob && (
        <div style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 200, background: 'white', borderRadius: 10, boxShadow: '0 4px 20px rgba(0,0,0,0.15)', border: '1px solid #e5e7eb', padding: '12px 16px', width: 320 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>
              {importJob.status === 'complete' ? 'Import Complete' : importJob.status === 'error' ? 'Import Failed' : 'Importing to Database...'}
            </span>
            <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 16 }} onClick={() => setImportJob(null)}>&times;</button>
          </div>
          <div className="progress-bar-container" style={{ width: '100%', height: 6, marginBottom: 6 }}>
            <div className={`progress-bar ${importJob.status === 'complete' ? 'complete' : importJob.status === 'error' ? 'error' : 'downloading'}`} style={{ width: `${importJob.progress || 0}%` }} />
          </div>
          <div style={{ fontSize: 11, color: '#6b7280' }}>{importJob.message || importJob.status}</div>
          {importJob.status === 'complete' && stepSaved && (
            <div style={{ marginTop: 6, fontSize: 11, color: '#059669', fontWeight: 500 }}>Step saved to Orchestrator</div>
          )}
        </div>
      )}

      {/* Textarea cell popup */}
      {textCellPopup && (
        <>
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.3)', zIndex: 300 }} onClick={() => setTextCellPopup(null)} />
          <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 301, background: 'white', borderRadius: 10, boxShadow: '0 8px 32px rgba(0,0,0,0.2)', border: '1px solid #e5e7eb', width: '60%', maxWidth: 700, maxHeight: '70vh', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderBottom: '1px solid #f3f4f6' }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>{textCellPopup.column}</span>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 18 }} onClick={() => setTextCellPopup(null)}>&times;</button>
            </div>
            <div style={{ padding: 16, overflow: 'auto', flex: 1, fontSize: 13, color: '#374151', whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontFamily: 'inherit', lineHeight: 1.6 }}>
              {textCellPopup.value}
            </div>
          </div>
        </>
      )}

      {/* Maximized results overlay */}
      {resultsMaximized && result && result.columns && (
        <div style={{
          position: 'fixed', inset: 0, zIndex: 1000,
          background: 'rgba(0,0,0,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center',
        }} onClick={() => setResultsMaximized(false)}>
          <div style={{
            background: '#fff', borderRadius: 12, width: '94vw', height: '90vh',
            display: 'flex', flexDirection: 'column', overflow: 'hidden',
            boxShadow: '0 25px 50px rgba(0,0,0,0.25)',
          }} onClick={e => e.stopPropagation()}>
            <div style={{
              padding: '12px 20px', borderBottom: '1px solid #e5e7eb',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              background: '#fafbfc', borderRadius: '12px 12px 0 0',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                <span style={{ fontSize: 14, fontWeight: 600, color: '#1f2937' }}>
                  Results
                </span>
                <span style={{ fontSize: 12, color: '#9ca3af' }}>
                  {result.rowCount} record{result.rowCount !== 1 ? 's' : ''} &middot; {result.columns.length} fields
                  {resultSearch && totalRows !== result.rows.length && (
                    <span style={{ color: '#f59e0b', marginLeft: 6 }}>({totalRows} matched)</span>
                  )}
                </span>
                <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                  <svg width="13" height="13" viewBox="0 0 16 16" fill="none" style={{ position: 'absolute', left: 8, pointerEvents: 'none' }}>
                    <circle cx="6.5" cy="6.5" r="5" stroke="#9ca3af" strokeWidth="1.3"/><path d="M10.5 10.5L14 14" stroke="#9ca3af" strokeWidth="1.3" strokeLinecap="round"/>
                  </svg>
                  <input
                    className="soql-search-input"
                    placeholder="Search results..."
                    value={resultSearch}
                    onChange={e => { setResultSearch(e.target.value); setPage(1) }}
                    style={{ fontSize: 12, padding: '4px 28px 4px 26px', width: 200 }}
                  />
                  {resultSearch && (
                    <button
                      onClick={() => { setResultSearch(''); setPage(1) }}
                      style={{ position: 'absolute', right: 6, background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 14, lineHeight: 1, padding: 0 }}
                      title="Clear search"
                    >&times;</button>
                  )}
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center' }}>
                <button
                  onClick={() => setResultsMaximized(false)}
                  style={{
                    background: 'none', border: 'none', cursor: 'pointer',
                    fontSize: 20, color: '#6b7280', lineHeight: 1, padding: '4px 8px',
                  }}
                  title="Close"
                >&times;</button>
              </div>
            </div>
            <div style={{ flex: 1, overflow: 'auto', minHeight: 0 }}>
              <table className="results-table" style={{ width: 'max-content', minWidth: '100%', fontSize: 12 }}>
                <thead>
                  <tr>
                    <th style={{ position: 'sticky', top: 0, background: '#f9fafb', zIndex: 1, width: 28, textAlign: 'center', color: '#9ca3af' }}>#</th>
                    {result.columns.map(col => (
                      <th key={col} style={{ position: 'sticky', top: 0, background: '#f9fafb', zIndex: 1 }}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {visibleRows.map((row, i) => (
                    <tr key={startIdx + i}>
                      <td style={{ textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>{startIdx + i + 1}</td>
                      {result.columns.map(col => {
                        const val = row[col] ?? ''
                        const valStr = typeof val === 'object' && val !== null ? JSON.stringify(val) : String(val)
                        return <td key={col}>{valStr}</td>
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {paginationBar}
          </div>
        </div>
      )}

    </div>
  )
}
