import React, { useState, useRef } from 'react'

export default function ExcelToTextPanel({ API_BASE = '' }) {
  const [file, setFile] = useState(null)
  const [columns, setColumns] = useState([])
  const [rows, setRows] = useState([])
  const [textCol, setTextCol] = useState('')
  const [fileNameCol, setFileNameCol] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [generating, setGenerating] = useState(false)
  const [previewIdx, setPreviewIdx] = useState(null)
  const fileRef = useRef(null)

  const handleFileUpload = async (e) => {
    const f = e.target.files[0]
    if (!f) return
    setFile(f)
    setError('')
    setColumns([])
    setRows([])
    setTextCol('')
    setFileNameCol('')
    setPreviewIdx(null)
    setLoading(true)

    const formData = new FormData()
    formData.append('file', f)

    try {
      const res = await fetch(`${API_BASE}/api/excel-to-text/parse`, {
        method: 'POST',
        body: formData,
      })
      const data = await res.json()
      if (data.error) {
        setError(data.error)
      } else {
        setColumns(data.columns || [])
        setRows(data.rows || [])
        // Auto-select columns if obvious
        const cols = data.columns || []
        const textGuess = cols.find(c => /content|text|body|description|template/i.test(c))
        const nameGuess = cols.find(c => /file.?name|name|title|label|subject/i.test(c))
        if (textGuess) setTextCol(textGuess)
        if (nameGuess) setFileNameCol(nameGuess)
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  const handleGenerate = async () => {
    if (!textCol || !fileNameCol) return
    setGenerating(true)
    setError('')

    try {
      const res = await fetch(`${API_BASE}/api/excel-to-text/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ textColumn: textCol, fileNameColumn: fileNameCol, rows }),
      })
      if (!res.ok) {
        const data = await res.json()
        setError(data.error || 'Generation failed')
        return
      }
      // Download the zip
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = (file?.name || 'output').replace(/\.[^.]+$/, '') + '_files.zip'
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(url)
    } catch (err) {
      setError(err.message)
    } finally {
      setGenerating(false)
    }
  }

  const previewRow = previewIdx != null ? rows[previewIdx] : null

  return (
    <div style={{ padding: 24, maxWidth: 900, margin: '0 auto', overflowY: 'auto', flex: 1 }}>
      <h2 style={{ margin: '0 0 4px', fontSize: 20 }}>Excel to Text Files</h2>
      <p style={{ color: '#6b7280', fontSize: 13, marginBottom: 20 }}>
        Upload an Excel file, pick the text column and filename column, then download as individual text files.
      </p>

      {/* Upload */}
      <div style={{
        border: '2px dashed #d1d5db', borderRadius: 8, padding: '30px 20px',
        textAlign: 'center', marginBottom: 20, background: '#fafafa',
        cursor: 'pointer',
      }}
        onClick={() => fileRef.current?.click()}
      >
        <input
          ref={fileRef}
          type="file"
          accept=".xlsx,.xls,.csv"
          onChange={handleFileUpload}
          style={{ display: 'none' }}
        />
        {file ? (
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: '#374151' }}>{file.name}</div>
            <div style={{ fontSize: 12, color: '#6b7280', marginTop: 4 }}>
              {rows.length} rows, {columns.length} columns
            </div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>Click to change file</div>
          </div>
        ) : (
          <div>
            <div style={{ fontSize: 28, marginBottom: 8 }}>
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#9ca3af" strokeWidth="1.5">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 2v6h6M12 18v-6M9 15h6" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div style={{ fontSize: 14, color: '#6b7280' }}>Click to upload Excel or CSV file</div>
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4 }}>.xlsx, .xls, .csv</div>
          </div>
        )}
      </div>

      {loading && <div style={{ color: '#6366f1', fontSize: 13, marginBottom: 16 }}>Parsing file...</div>}
      {error && (
        <div style={{
          padding: '10px 14px', borderRadius: 6, marginBottom: 16,
          background: '#fef2f2', border: '1px solid #fecaca', color: '#991b1b', fontSize: 13,
        }}>{error}</div>
      )}

      {/* Column Selection */}
      {columns.length > 0 && (
        <div style={{
          border: '1px solid #e1e5eb', borderRadius: 8, padding: 16, marginBottom: 20,
          background: '#fff',
        }}>
          <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 12 }}>Map Columns</div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
                File Name Column
              </label>
              <select
                value={fileNameCol}
                onChange={e => setFileNameCol(e.target.value)}
                style={{
                  width: '100%', padding: '8px 12px', borderRadius: 6,
                  border: '1px solid #d1d5db', fontSize: 13,
                }}
              >
                <option value="">-- Select column --</option>
                {columns.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>
                Column containing the desired file name for each row
              </div>
            </div>
            <div>
              <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
                Text Content Column
              </label>
              <select
                value={textCol}
                onChange={e => setTextCol(e.target.value)}
                style={{
                  width: '100%', padding: '8px 12px', borderRadius: 6,
                  border: '1px solid #d1d5db', fontSize: 13,
                }}
              >
                <option value="">-- Select column --</option>
                {columns.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>
                Column containing the text to write to each file
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Preview Table */}
      {columns.length > 0 && textCol && fileNameCol && (
        <div style={{
          border: '1px solid #e1e5eb', borderRadius: 8, overflow: 'hidden', marginBottom: 20,
        }}>
          <div style={{
            padding: '10px 14px', background: '#f9fafb', borderBottom: '1px solid #e1e5eb',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Preview ({rows.length} files)</span>
            <button
              onClick={handleGenerate}
              disabled={generating}
              style={{
                padding: '6px 20px', borderRadius: 6, border: 'none',
                background: '#6366f1', color: '#fff', fontWeight: 600, fontSize: 13,
                cursor: generating ? 'default' : 'pointer',
                opacity: generating ? 0.6 : 1,
              }}
            >
              {generating ? 'Generating...' : 'Download as ZIP'}
            </button>
          </div>
          <div style={{ maxHeight: 300, overflowY: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
              <thead>
                <tr style={{ background: '#f3f4f6' }}>
                  <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600, width: 40 }}>#</th>
                  <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600 }}>File Name</th>
                  <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600 }}>Text Preview</th>
                  <th style={{ padding: '6px 10px', width: 60 }}></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => {
                  const fname = row[fileNameCol] || `row_${i + 1}`
                  const text = row[textCol] || ''
                  return (
                    <tr key={i} style={{
                      borderTop: '1px solid #e5e7eb',
                      background: previewIdx === i ? '#eff6ff' : 'transparent',
                    }}>
                      <td style={{ padding: '6px 10px', color: '#6b7280' }}>{i + 1}</td>
                      <td style={{ padding: '6px 10px', fontFamily: 'monospace', fontWeight: 500 }}>
                        {fname}
                      </td>
                      <td style={{
                        padding: '6px 10px', maxWidth: 400, overflow: 'hidden',
                        textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#374151',
                      }}>
                        {text.substring(0, 120)}{text.length > 120 ? '...' : ''}
                      </td>
                      <td style={{ padding: '6px 10px', textAlign: 'center' }}>
                        <button
                          onClick={() => setPreviewIdx(previewIdx === i ? null : i)}
                          style={{
                            padding: '2px 8px', borderRadius: 4, border: '1px solid #d1d5db',
                            background: '#fff', fontSize: 11, cursor: 'pointer', color: '#6366f1',
                          }}
                        >
                          {previewIdx === i ? 'Close' : 'View'}
                        </button>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Full text preview modal */}
      {previewRow && (
        <div
          onClick={() => setPreviewIdx(null)}
          style={{
            position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
            background: 'rgba(0,0,0,0.5)', zIndex: 1000,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            padding: 40,
          }}
        >
          <div
            onClick={e => e.stopPropagation()}
            style={{
              background: '#fff', borderRadius: 12, width: '100%', maxWidth: 720,
              maxHeight: '80vh', display: 'flex', flexDirection: 'column',
              boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
            }}
          >
            <div style={{
              padding: '12px 18px', background: '#e0e7ff', borderBottom: '1px solid #c7d2fe',
              fontWeight: 600, fontSize: 14, color: '#3730a3',
              display: 'flex', justifyContent: 'space-between', alignItems: 'center',
              borderRadius: '12px 12px 0 0',
            }}>
              <span>{previewRow[fileNameCol] || `row_${previewIdx + 1}`}</span>
              <button
                onClick={() => setPreviewIdx(null)}
                style={{
                  padding: '4px 12px', borderRadius: 4, border: '1px solid #a5b4fc',
                  background: '#fff', fontSize: 12, cursor: 'pointer', fontWeight: 500,
                }}
              >
                Close
              </button>
            </div>
            <pre style={{
              padding: 18, margin: 0, fontSize: 13, lineHeight: 1.6,
              whiteSpace: 'pre-wrap', wordBreak: 'break-word',
              overflowY: 'auto', flex: 1,
              color: '#1e293b', fontFamily: 'ui-monospace, monospace',
            }}>
{previewRow[textCol] || '(empty)'}
            </pre>
          </div>
        </div>
      )}
    </div>
  )
}
