import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react'

const PAGE_SIZE = 10

function formatDuration(startIso, endMs) {
  const start = new Date(startIso).getTime()
  const diff = Math.floor((endMs - start) / 1000)
  if (diff < 0) return '0s'
  if (diff < 60) return `${diff}s`
  const m = Math.floor(diff / 60)
  const s = diff % 60
  if (m < 60) return `${m}m ${s}s`
  const h = Math.floor(m / 60)
  return `${h}h ${m % 60}m ${s}s`
}

function formatDateCompact(isoStr) {
  if (!isoStr) return '-'
  const d = new Date(isoStr)
  const now = new Date()
  const isToday = d.toDateString() === now.toDateString()
  const yesterday = new Date(now); yesterday.setDate(yesterday.getDate() - 1)
  const isYesterday = d.toDateString() === yesterday.toDateString()

  const time = d.toLocaleString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true })
  if (isToday) return `Today ${time}`
  if (isYesterday) return `Yesterday ${time}`
  return d.toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })
}

function formatTimeWithZone(isoStr) {
  if (!isoStr) return ''
  return new Date(isoStr).toLocaleString(undefined, {
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true, timeZoneName: 'short',
  })
}

function getJobProgress(job) {
  if (job.type === 'SF Extract' && job.statuses) {
    const names = Object.keys(job.statuses)
    if (names.length === 0) return 0
    const total = names.reduce((sum, n) => sum + (job.progress?.[n] || 0), 0)
    return Math.round(total / names.length)
  }
  return job.progress || 0
}

function getJobStatus(job) {
  if (job.type === 'SF Extract' && job.statuses) {
    const vals = Object.values(job.statuses)
    if (vals.every(s => s === 'complete')) return 'complete'
    if (vals.some(s => s === 'error')) return 'error'
    if (vals.some(s => s === 'downloading')) return 'running'
    if (vals.some(s => s === 'pending')) return 'running'
    return 'complete'
  }
  if (job.status === 'complete') return 'complete'
  if (job.status === 'error') return 'error'
  if (job.status === 'cancelled') return 'cancelled'
  if (job.running) return 'running'
  return job.status || 'unknown'
}

function getJobMessage(job) {
  if (job.type === 'SF Extract' && job.statuses) {
    const names = Object.keys(job.statuses)
    const done = names.filter(n => job.statuses[n] === 'complete').length
    const errored = names.filter(n => job.statuses[n] === 'error').length
    const total = names.length
    if (done === total) return `Extracted ${total} object${total !== 1 ? 's' : ''}`
    if (errored > 0) return `${done}/${total} complete, ${errored} error${errored !== 1 ? 's' : ''}`
    return `${done}/${total} objects complete`
  }
  return job.message || ''
}

function getStatusColor(status) {
  if (status === 'complete') return '#10b981'
  if (status === 'error') return '#ef4444'
  if (status === 'cancelled') return '#f59e0b'
  if (status === 'running') return '#3b82f6'
  return '#9ca3af'
}

function getStatusBadge(status) {
  switch (status) {
    case 'complete': return { bg: '#ecfdf5', color: '#065f46', border: '#a7f3d0', label: 'Complete' }
    case 'error': return { bg: '#fef2f2', color: '#991b1b', border: '#fecaca', label: 'Error' }
    case 'cancelled': return { bg: '#fffbeb', color: '#92400e', border: '#fde68a', label: 'Cancelled' }
    case 'running': return { bg: '#eff6ff', color: '#1e40af', border: '#bfdbfe', label: 'Running' }
    default: return { bg: '#f3f4f6', color: '#374151', border: '#e5e7eb', label: status }
  }
}

function getTypeBadgeStyle(type) {
  switch (type) {
    case 'SF Extract':
      return { background: '#eff6ff', color: '#1d4ed8', border: '1px solid #bfdbfe' }
    case 'SOQL Import':
      return { background: '#f0fdf4', color: '#166534', border: '1px solid #bbf7d0' }
    case 'SQL Import': case 'Athena Import': case 'MySQL Import': case 'Redshift Import': case 'PostgreSQL Import':
      return { background: '#faf5ff', color: '#6b21a8', border: '1px solid #e9d5ff' }
    case 'CSV Import':
      return { background: '#fffbeb', color: '#92400e', border: '1px solid #fde68a' }
    case 'SF Upload': case 'Quick Load':
      return { background: '#ecfdf5', color: '#065f46', border: '1px solid #a7f3d0' }
    case 'File Download':
      return { background: '#fff7ed', color: '#c2410c', border: '1px solid #fed7aa' }
    case 'File Upload':
      return { background: '#fdf2f8', color: '#be185d', border: '1px solid #fbcfe8' }
    default:
      return { background: '#f3f4f6', color: '#374151', border: '1px solid #e5e7eb' }
  }
}

function getSourceLabel(job) {
  const parts = []
  if (job.source_name) parts.push(job.source_name)
  if (job.source_database) parts.push(job.source_database)
  const tbl = job.type === 'SF Upload' ? job.table_name : (job.source_object || '')
  if (tbl) parts.push(tbl)
  return parts.join(' / ') || '-'
}

function getTargetLabel(job) {
  const parts = []
  if (job.target_name) parts.push(job.target_name)
  const isUpload = job.type === 'SF Upload'
  if (!isUpload && job.target_database) parts.push(job.target_database)
  const tbl = isUpload ? job.object_name : job.table_name
  if (tbl) parts.push(tbl)
  return parts.join(' / ') || '-'
}

function getEndMs(job, now, frozenTimes) {
  if (job.running) return now
  if (job.finished_at || job.finishedAt) return new Date(job.finished_at || job.finishedAt).getTime()
  return frozenTimes[job.id] || now
}

// ── Sort arrow icon ─────────────────────────────────────────────────

function SortIcon({ active, dir }) {
  return (
    <svg width="10" height="10" viewBox="0 0 10 10" style={{ marginLeft: 2, opacity: active ? 1 : 0.25 }}>
      <path d="M5 1L8.5 4.5H1.5L5 1Z" fill={active && dir === 'asc' ? '#4f46e5' : '#9ca3af'} />
      <path d="M5 9L1.5 5.5H8.5L5 9Z" fill={active && dir === 'desc' ? '#4f46e5' : '#9ca3af'} />
    </svg>
  )
}

function SortHeader({ label, field, sortCol, sortDir, onSort, style }) {
  const active = sortCol === field
  return (
    <th
      onClick={() => onSort(field)}
      style={{
        padding: '10px 12px', textAlign: 'left', fontSize: 11, fontWeight: 600,
        color: active ? '#4f46e5' : '#64748b', cursor: 'pointer', userSelect: 'none',
        whiteSpace: 'nowrap', borderBottom: '1px solid #e2e8f0',
        background: 'linear-gradient(to bottom, #f8fafc, #f1f5f9)',
        letterSpacing: '0.03em', textTransform: 'uppercase',
        ...style,
      }}
    >
      <span style={{ display: 'inline-flex', alignItems: 'center', gap: 2 }}>
        {label}
        <SortIcon active={active} dir={sortDir} />
      </span>
    </th>
  )
}

// ── Main component ──────────────────────────────────────────────────

export default function JobsPanel({ onNavigateToDb }) {
  const [jobs, setJobs] = useState([])
  const [expandedId, setExpandedId] = useState(null)
  const [now, setNow] = useState(Date.now())
  const [sortCol, setSortCol] = useState('started_at')
  const [sortDir, setSortDir] = useState('desc')
  const [page, setPage] = useState(0)
  const timerRef = useRef(null)
  const frozenTimesRef = useRef({})

  const fetchJobs = useCallback(() => {
    fetch('/api/jobs')
      .then(r => r.json())
      .then(data => {
        const list = data.jobs || []
        const frozen = frozenTimesRef.current
        list.forEach(j => {
          if (!j.running && !(j.finished_at || j.finishedAt) && !frozen[j.id]) {
            frozen[j.id] = Date.now()
          }
        })
        setJobs(list)
      })
      .catch(() => {})
  }, [])

  useEffect(() => {
    fetchJobs()
    const hasRunning = jobs.some(j => j.running)
    const interval = hasRunning ? 2000 : 5000
    timerRef.current = setInterval(() => {
      fetchJobs()
      setNow(Date.now())
    }, interval)
    return () => clearInterval(timerRef.current)
  }, [fetchJobs, jobs.some(j => j.running)])

  const handleSort = useCallback((field) => {
    setSortCol(prev => {
      if (prev === field) {
        setSortDir(d => d === 'asc' ? 'desc' : 'asc')
        return field
      }
      setSortDir('desc')
      return field
    })
    setPage(0)
  }, [])

  const sortedJobs = useMemo(() => {
    const list = [...jobs]
    const dir = sortDir === 'asc' ? 1 : -1
    list.sort((a, b) => {
      let va, vb
      switch (sortCol) {
        case 'type': va = a.type || ''; vb = b.type || ''; break
        case 'source': va = getSourceLabel(a); vb = getSourceLabel(b); break
        case 'target': va = getTargetLabel(a); vb = getTargetLabel(b); break
        case 'status': va = getJobStatus(a); vb = getJobStatus(b); break
        case 'started_at': va = a.started_at || ''; vb = b.started_at || ''; break
        case 'ended_at': va = a.finished_at || a.finishedAt || ''; vb = b.finished_at || b.finishedAt || ''; break
        case 'duration': {
          const ea = getEndMs(a, now, frozenTimesRef.current)
          const eb = getEndMs(b, now, frozenTimesRef.current)
          va = a.started_at ? ea - new Date(a.started_at).getTime() : 0
          vb = b.started_at ? eb - new Date(b.started_at).getTime() : 0
          return (va - vb) * dir
        }
        default: va = ''; vb = ''
      }
      if (typeof va === 'string') return va.localeCompare(vb) * dir
      return (va - vb) * dir
    })
    return list
  }, [jobs, sortCol, sortDir, now])

  const totalPages = Math.max(1, Math.ceil(sortedJobs.length / PAGE_SIZE))
  const safePage = Math.min(page, totalPages - 1)
  const pageJobs = sortedJobs.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE)
  const runningCount = jobs.filter(j => j.running).length

  if (jobs.length === 0) {
    return (
      <div style={{
        display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
        padding: '80px 20px', color: '#94a3b8',
      }}>
        <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <path d="M3 9h18"/>
          <path d="M9 21V9"/>
        </svg>
        <div style={{ marginTop: 16, fontSize: 15, fontWeight: 500 }}>No jobs yet</div>
        <div style={{ marginTop: 4, fontSize: 13 }}>
          Start an extract, import, or upload to see progress here
        </div>
      </div>
    )
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {/* Header bar */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ fontSize: 13, fontWeight: 600, color: '#1e293b' }}>
            {jobs.length} job{jobs.length !== 1 ? 's' : ''}
          </span>
          {runningCount > 0 && (
            <span style={{
              fontSize: 11, fontWeight: 600, color: '#1e40af',
              background: '#dbeafe', padding: '2px 8px', borderRadius: 10,
              display: 'inline-flex', alignItems: 'center', gap: 4,
            }}>
              <span style={{
                width: 6, height: 6, borderRadius: '50%', background: '#3b82f6',
                animation: 'pulse 1.5s infinite',
              }} />
              {runningCount} running
            </span>
          )}
        </div>
        {totalPages > 1 && (
          <span style={{ fontSize: 11, color: '#94a3b8' }}>
            Showing {safePage * PAGE_SIZE + 1}-{Math.min((safePage + 1) * PAGE_SIZE, sortedJobs.length)} of {sortedJobs.length}
          </span>
        )}
      </div>

      {/* Table */}
      <div style={{
        border: '1px solid #e2e8f0', borderRadius: 10, overflow: 'hidden',
        boxShadow: '0 1px 3px rgba(0,0,0,0.04), 0 1px 2px rgba(0,0,0,0.02)',
      }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr>
                <SortHeader label="Type" field="type" sortCol={sortCol} sortDir={sortDir} onSort={handleSort} style={{ width: 90 }} />
                <SortHeader label="Source" field="source" sortCol={sortCol} sortDir={sortDir} onSort={handleSort} />
                <SortHeader label="Target" field="target" sortCol={sortCol} sortDir={sortDir} onSort={handleSort} />
                <SortHeader label="Status" field="status" sortCol={sortCol} sortDir={sortDir} onSort={handleSort} style={{ width: 110 }} />
                <SortHeader label="Started" field="started_at" sortCol={sortCol} sortDir={sortDir} onSort={handleSort} style={{ width: 140 }} />
                <SortHeader label="Ended" field="ended_at" sortCol={sortCol} sortDir={sortDir} onSort={handleSort} style={{ width: 140 }} />
                <SortHeader label="Duration" field="duration" sortCol={sortCol} sortDir={sortDir} onSort={handleSort} style={{ width: 90 }} />
                <th style={{
                  padding: '10px 12px', fontSize: 11, fontWeight: 600, color: '#64748b',
                  borderBottom: '1px solid #e2e8f0',
                  background: 'linear-gradient(to bottom, #f8fafc, #f1f5f9)',
                  width: 44, textAlign: 'center', letterSpacing: '0.03em', textTransform: 'uppercase',
                }} />
              </tr>
            </thead>
            <tbody>
              {pageJobs.map((job, idx) => {
                const status = getJobStatus(job)
                const progress = getJobProgress(job)
                const statusBadge = getStatusBadge(status)
                const typeBadge = getTypeBadgeStyle(job.type)
                const isExpanded = expandedId === job.id
                const endMs = getEndMs(job, now, frozenTimesRef.current)
                const clickable = job.type !== 'SF Upload' && job.target_conn_id
                const isEven = idx % 2 === 0

                return (
                  <React.Fragment key={job.id}>
                    <tr
                      onClick={() => setExpandedId(isExpanded ? null : job.id)}
                      className="jobs-row"
                      style={{
                        cursor: 'pointer',
                        borderBottom: isExpanded ? 'none' : '1px solid #f1f5f9',
                        background: isExpanded ? '#f8fafc' : isEven ? '#fff' : '#fafbfd',
                      }}
                    >
                      {/* Type */}
                      <td style={{ padding: '10px 12px' }}>
                        <span style={{
                          ...typeBadge, fontSize: 10, fontWeight: 600, padding: '3px 8px',
                          borderRadius: 5, whiteSpace: 'nowrap', display: 'inline-block',
                          letterSpacing: '0.02em',
                        }}>
                          {job.type || 'Job'}
                        </span>
                      </td>

                      {/* Source */}
                      <td style={{
                        padding: '10px 12px', color: '#334155', fontWeight: 400,
                        maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      }} title={getSourceLabel(job)}>
                        {renderSourceTarget(job, 'source')}
                      </td>

                      {/* Target */}
                      <td style={{
                        padding: '10px 12px', maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                      }}>
                        <span
                          onClick={(e) => {
                            if (clickable && onNavigateToDb) {
                              e.stopPropagation()
                              onNavigateToDb(job.target_conn_id, job.target_database, job.table_name)
                            }
                          }}
                          style={{
                            color: clickable ? '#4f46e5' : '#334155',
                            cursor: clickable ? 'pointer' : 'default',
                          }}
                          title={clickable ? 'Open in Transform tab' : getTargetLabel(job)}
                        >
                          {renderSourceTarget(job, 'target')}
                        </span>
                      </td>

                      {/* Status */}
                      <td style={{ padding: '10px 12px' }}>
                        <span style={{
                          display: 'inline-flex', alignItems: 'center', gap: 5,
                          fontSize: 11, fontWeight: 600, padding: '3px 9px', borderRadius: 5,
                          background: statusBadge.bg, color: statusBadge.color,
                          border: `1px solid ${statusBadge.border}`,
                        }}>
                          <span style={{
                            width: 6, height: 6, borderRadius: '50%',
                            background: getStatusColor(status), flexShrink: 0,
                            animation: status === 'running' ? 'pulse 1.5s infinite' : 'none',
                          }} />
                          {statusBadge.label}
                          {status === 'running' && progress > 0 && (
                            <span style={{ fontWeight: 400, opacity: 0.8 }}>{progress}%</span>
                          )}
                        </span>
                      </td>

                      {/* Started */}
                      <td style={{ padding: '10px 12px', fontSize: 12, color: '#64748b', whiteSpace: 'nowrap' }}>
                        {formatDateCompact(job.started_at)}
                      </td>

                      {/* Ended */}
                      <td style={{ padding: '10px 12px', fontSize: 12, color: '#64748b', whiteSpace: 'nowrap' }}>
                        {job.running ? (
                          <span style={{ color: '#94a3b8', fontStyle: 'italic' }}>In progress</span>
                        ) : formatDateCompact(job.finished_at || job.finishedAt)}
                      </td>

                      {/* Duration */}
                      <td style={{ padding: '10px 12px', whiteSpace: 'nowrap' }}>
                        {job.started_at ? (
                          <span style={{
                            fontSize: 12, fontWeight: 600,
                            fontFamily: 'ui-monospace, SFMono-Regular, monospace',
                            color: status === 'complete' ? '#059669'
                              : status === 'error' ? '#dc2626'
                              : status === 'running' ? '#2563eb'
                              : '#64748b',
                          }}>
                            {formatDuration(job.started_at, endMs)}
                          </span>
                        ) : '-'}
                      </td>

                      {/* Expand chevron */}
                      <td style={{ padding: '10px 8px', textAlign: 'center' }}>
                        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4 }}>
                          {job.running && (
                            <button
                              title="Cancel job"
                              onClick={(e) => {
                                e.stopPropagation()
                                if (confirm('Cancel this job?')) {
                                  fetch(`/api/jobs/${job.id}/cancel`, { method: 'POST' })
                                    .then(() => fetchJobs())
                                    .catch(() => {})
                                }
                              }}
                              style={{
                                background: 'none', border: '1px solid #fca5a5', borderRadius: 4,
                                padding: '2px 5px', cursor: 'pointer', color: '#ef4444', fontSize: 10,
                                fontWeight: 500, lineHeight: 1.2, transition: 'all 0.15s',
                              }}
                              onMouseEnter={e => { e.currentTarget.style.background = '#fef2f2' }}
                              onMouseLeave={e => { e.currentTarget.style.background = 'none' }}
                            >
                              <svg width="12" height="12" viewBox="0 0 16 16" fill="none">
                                <rect x="3" y="3" width="10" height="10" rx="2" stroke="currentColor" strokeWidth="1.5"/>
                              </svg>
                            </button>
                          )}
                          <svg
                            width="14" height="14" viewBox="0 0 14 14" fill="none"
                            style={{
                              transform: isExpanded ? 'rotate(180deg)' : 'rotate(0)',
                              transition: 'transform 0.2s ease',
                            }}
                          >
                            <path d="M3.5 5.5l3.5 3.5 3.5-3.5" stroke="#94a3b8" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                          </svg>
                        </div>
                      </td>
                    </tr>

                    {/* Expanded detail row */}
                    {isExpanded && (
                      <tr>
                        <td colSpan={8} style={{ padding: 0, borderBottom: '1px solid #e2e8f0' }}>
                          <ExpandedDetail job={job} status={status} endMs={endMs} />
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                )
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4,
          padding: '4px 0', fontSize: 12,
        }}>
          <PaginationBtn onClick={() => setPage(0)} disabled={safePage === 0} label={'\u00AB'} title="First" />
          <PaginationBtn onClick={() => setPage(p => Math.max(0, p - 1))} disabled={safePage === 0} label={'\u2039 Prev'} />

          {/* Page numbers */}
          {(() => {
            const pages = []
            const start = Math.max(0, safePage - 2)
            const end = Math.min(totalPages - 1, safePage + 2)
            for (let i = start; i <= end; i++) {
              pages.push(
                <button
                  key={i}
                  onClick={() => setPage(i)}
                  style={{
                    background: i === safePage ? '#4f46e5' : 'transparent',
                    color: i === safePage ? '#fff' : '#64748b',
                    border: i === safePage ? '1px solid #4f46e5' : '1px solid transparent',
                    borderRadius: 6, padding: '4px 10px', cursor: 'pointer',
                    fontSize: 12, fontWeight: i === safePage ? 600 : 400,
                    minWidth: 32, transition: 'all 0.15s',
                  }}
                >
                  {i + 1}
                </button>
              )
            }
            return pages
          })()}

          <PaginationBtn onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))} disabled={safePage >= totalPages - 1} label={'Next \u203A'} />
          <PaginationBtn onClick={() => setPage(totalPages - 1)} disabled={safePage >= totalPages - 1} label={'\u00BB'} title="Last" />
        </div>
      )}

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.4; }
        }
        .jobs-row:hover {
          background: #f1f5f9 !important;
        }
      `}</style>
    </div>
  )
}

function PaginationBtn({ onClick, disabled, label, title }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      title={title}
      style={{
        background: disabled ? 'transparent' : 'transparent',
        border: '1px solid transparent',
        borderRadius: 6,
        padding: '4px 10px',
        cursor: disabled ? 'default' : 'pointer',
        color: disabled ? '#cbd5e1' : '#64748b',
        fontSize: 12, fontWeight: 500,
        transition: 'all 0.15s',
      }}
    >
      {label}
    </button>
  )
}

function renderSourceTarget(job, which) {
  const isUpload = job.type === 'SF Upload'
  let connName, dbName, tableName

  if (which === 'source') {
    connName = job.source_name
    dbName = job.source_database
    tableName = isUpload ? job.table_name : (job.source_object || '')
  } else {
    connName = job.target_name
    dbName = isUpload ? '' : job.target_database
    tableName = isUpload ? job.object_name : job.table_name
  }

  if (!connName && !dbName && !tableName) return <span style={{ color: '#cbd5e1' }}>-</span>

  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12 }}>
      {connName && <span style={{ color: '#64748b' }}>{connName}</span>}
      {connName && (dbName || tableName) && <span style={{ color: '#cbd5e1' }}>/</span>}
      {dbName && <span style={{ color: '#64748b' }}>{dbName}</span>}
      {dbName && tableName && <span style={{ color: '#cbd5e1' }}>/</span>}
      {tableName && <span style={{ fontWeight: 600, color: '#334155' }}>{tableName}</span>}
    </span>
  )
}

// ── Expanded detail ─────────────────────────────────────────────────

function ExpandedDetail({ job, status, endMs }) {
  const message = getJobMessage(job)
  const totalDuration = job.started_at ? formatDuration(job.started_at, endMs) : ''

  return (
    <div style={{
      padding: '14px 20px', background: '#f8fafc', fontSize: 12, color: '#475569',
      display: 'flex', flexDirection: 'column', gap: 8,
      borderTop: '1px dashed #e2e8f0',
    }}>
      {/* Info grid */}
      <div style={{
        display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))',
        gap: '6px 24px',
      }}>
        <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Job ID</span><br/><span style={{ fontFamily: 'monospace', fontSize: 11 }}>{job.id}</span></div>
        <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Status</span><br/><span style={{ textTransform: 'capitalize', fontWeight: 500 }}>{status}</span></div>
        {job.started_at && (
          <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Started</span><br/>{formatTimeWithZone(job.started_at)}</div>
        )}
        {!job.running && (job.finished_at || job.finishedAt) && (
          <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Completed</span><br/>{formatTimeWithZone(job.finished_at || job.finishedAt)}</div>
        )}
        {job.started_at && (
          <div>
            <span style={{ color: '#94a3b8', fontSize: 11 }}>Duration</span><br/>
            <span style={{
              fontWeight: 700, fontFamily: 'ui-monospace, SFMono-Regular, monospace',
              color: status === 'complete' ? '#059669' : status === 'error' ? '#dc2626' : '#2563eb',
            }}>
              {totalDuration}
            </span>
          </div>
        )}
        {job.record_count != null && (
          <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Records</span><br/>{job.record_count.toLocaleString()}</div>
        )}
        {job.type === 'SF Upload' && (
          <>
            <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Operation</span><br/>{job.operation || '-'}</div>
            {job.total_records != null && <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Records</span><br/>{job.total_records.toLocaleString()}</div>}
            <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Success</span><br/><span style={{ color: '#059669', fontWeight: 500 }}>{job.success_count ?? 0}</span></div>
            <div><span style={{ color: '#94a3b8', fontSize: 11 }}>Errors</span><br/><span style={{ color: job.error_count ? '#dc2626' : '#94a3b8', fontWeight: 500 }}>{job.error_count ?? 0}</span></div>
          </>
        )}
      </div>

      {/* Message */}
      {message && (
        <div style={{
          padding: '6px 10px', borderRadius: 6,
          background: status === 'error' ? '#fef2f2' : '#f0fdf4',
          color: status === 'error' ? '#991b1b' : '#166534',
          fontSize: 12, fontWeight: 500,
        }}>
          {message}
        </div>
      )}

      {/* SF Extract per-object breakdown */}
      {job.type === 'SF Extract' && job.statuses && (
        <div style={{
          display: 'flex', flexDirection: 'column', gap: 5, marginTop: 4,
          background: '#fff', borderRadius: 8, border: '1px solid #e2e8f0', padding: '10px 12px',
        }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#64748b', marginBottom: 2 }}>Object Breakdown</div>
          {Object.entries(job.statuses).map(([objName, objStatus]) => {
            const objStatusNorm = objStatus === 'complete' ? 'complete' : objStatus === 'error' ? 'error' : 'running'
            return (
              <div key={objName} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <span style={{
                  width: 7, height: 7, borderRadius: '50%', flexShrink: 0,
                  background: getStatusColor(objStatusNorm),
                  animation: objStatusNorm === 'running' ? 'pulse 1.5s infinite' : 'none',
                }} />
                <span style={{ width: 150, fontWeight: 500, fontSize: 12, color: '#334155' }}>{objName}</span>
                <div style={{
                  width: 100, height: 5, background: '#e2e8f0', borderRadius: 3, overflow: 'hidden',
                }}>
                  <div style={{
                    width: `${job.progress?.[objName] || 0}%`, height: '100%', borderRadius: 3,
                    background: getStatusColor(objStatusNorm), transition: 'width 0.3s ease',
                  }} />
                </div>
                <span style={{ fontSize: 11, color: '#94a3b8' }}>{job.messages?.[objName] || objStatus}</span>
                {job.errors?.[objName] && (
                  <span style={{ color: '#dc2626', fontSize: 11 }}>{job.errors[objName]}</span>
                )}
              </div>
            )
          })}
        </div>
      )}

      {/* File Download/Upload details */}
      {(job.type === 'File Download' || job.type === 'File Upload') && (
        <div style={{ display: 'flex', gap: 24, flexWrap: 'wrap' }}>
          <span><strong>Object Type:</strong> {job.object_type || '-'}</span>
          {job.total_files > 0 && <span><strong>Files:</strong> {job.completed_files || 0}/{job.total_files}</span>}
          {job.output_dir && <span><strong>Output:</strong> <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{job.output_dir}</span></span>}
          {job.source_dir && <span><strong>Source:</strong> <span style={{ fontFamily: 'monospace', fontSize: 11 }}>{job.source_dir}</span></span>}
          {job.type === 'File Upload' && (
            <>
              <span><strong>Success:</strong> {job.success_count ?? 0}</span>
              <span><strong>Errors:</strong> {job.error_count ?? 0}</span>
            </>
          )}
        </div>
      )}

      {/* Upload errors */}
      {job.type === 'SF Upload' && job.errors?.length > 0 && (
        <div>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#dc2626', marginBottom: 4 }}>Errors</div>
          <div style={{
            maxHeight: 120, overflow: 'auto',
            background: '#fff', border: '1px solid #fecaca', borderRadius: 6, padding: 10,
            fontSize: 11, fontFamily: 'ui-monospace, SFMono-Regular, monospace', color: '#991b1b',
          }}>
            {job.errors.slice(0, 20).map((err, i) => (
              <div key={i} style={{ padding: '2px 0' }}>{typeof err === 'string' ? err : JSON.stringify(err)}</div>
            ))}
            {job.errors.length > 20 && <div style={{ color: '#94a3b8', marginTop: 4 }}>...and {job.errors.length - 20} more</div>}
          </div>
        </div>
      )}
    </div>
  )
}
