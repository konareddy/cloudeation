import React, { useState, useEffect, useRef, useCallback } from 'react'
import ConnectionSelect from './ConnectionSelect.jsx'

function formatBytes(n) {
  if (n == null) return ''
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  if (n < 1024 * 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`
  return `${(n / (1024 * 1024 * 1024)).toFixed(1)} GB`
}

export default function AttachmentPanel({ sfConnections = [], sfConnectionId, onSetActiveSfId, sfRefreshKey }) {
  // Mode: download or upload
  const [mode, setMode] = useState('download')
  // SF connection
  const [selectedSfId, setSelectedSfId] = useState(sfConnectionId || '')
  // Object type
  const [objectType, setObjectType] = useState('Attachment')

  // Download state
  const [whereClause, setWhereClause] = useState('')
  const [outputDir, setOutputDir] = useState('')
  const [previewCount, setPreviewCount] = useState(null)
  const [loadingCount, setLoadingCount] = useState(false)
  const [countError, setCountError] = useState('')

  // Upload state
  const [sourceDir, setSourceDir] = useState('')
  const [defaultParentId, setDefaultParentId] = useState('')
  const [linkToRecordId, setLinkToRecordId] = useState('')
  const [folders, setFolders] = useState([])
  const [showFolderPicker, setShowFolderPicker] = useState(false)

  // Job state (shared for download and upload)
  const [jobState, setJobState] = useState(null)
  const [jobId, setJobId] = useState(null)
  const [fileResults, setFileResults] = useState([])
  const [loadingResults, setLoadingResults] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const pollRef = useRef(null)

  // Sync with parent sfConnectionId
  useEffect(() => {
    if (sfConnectionId) setSelectedSfId(sfConnectionId)
  }, [sfConnectionId])

  const handleSfChange = (id) => {
    setSelectedSfId(id)
    if (onSetActiveSfId) onSetActiveSfId(id)
    setPreviewCount(null)
    setCountError('')
  }

  // Load folders for upload mode
  const loadFolders = useCallback(() => {
    fetch('/api/attachments/folders')
      .then(r => r.json())
      .then(data => setFolders(data.folders || []))
      .catch(() => {})
  }, [])

  useEffect(() => {
    if (mode === 'upload') loadFolders()
  }, [mode, loadFolders])

  // Preview count
  const handlePreviewCount = () => {
    if (!selectedSfId) return
    setLoadingCount(true)
    setCountError('')
    setPreviewCount(null)
    fetch('/api/attachments/count', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sfConnectionId: selectedSfId,
        objectType,
        whereClause: whereClause || undefined,
      }),
    })
      .then(r => r.json())
      .then(data => {
        if (data.error) setCountError(data.error)
        else setPreviewCount(data.count)
      })
      .catch(e => setCountError(e.message))
      .finally(() => setLoadingCount(false))
  }

  // Start download
  const handleDownload = () => {
    if (!selectedSfId) return
    setJobState({ running: true, status: 'starting', progress: 0, message: 'Starting...' })
    setFileResults([])
    setShowResults(true)
    fetch('/api/attachments/download', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sfConnectionId: selectedSfId,
        objectType,
        whereClause: whereClause || undefined,
        outputDir: outputDir || undefined,
      }),
    })
      .then(r => r.json())
      .then(({ jobId: jid }) => {
        setJobId(jid)
        startPolling(jid, 'download')
      })
      .catch(e => {
        setJobState({ running: false, status: 'error', progress: 0, message: e.message })
      })
  }

  // Start upload
  const handleUpload = () => {
    if (!selectedSfId || !sourceDir) return
    setJobState({ running: true, status: 'starting', progress: 0, message: 'Starting...' })
    setFileResults([])
    setShowResults(true)
    fetch('/api/attachments/upload', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sfConnectionId: selectedSfId,
        objectType,
        sourceDir,
        defaultParentId: defaultParentId || undefined,
        linkToRecordId: linkToRecordId || undefined,
      }),
    })
      .then(r => r.json())
      .then(({ jobId: jid }) => {
        setJobId(jid)
        startPolling(jid, 'upload')
      })
      .catch(e => {
        setJobState({ running: false, status: 'error', progress: 0, message: e.message })
      })
  }

  // Cancel job
  const handleCancel = () => {
    if (!jobId) return
    fetch(`/api/attachments/${jobId}/cancel`, { method: 'POST' })
      .then(r => r.json())
      .catch(() => {})
  }

  const startPolling = (jid, jobMode) => {
    if (pollRef.current) clearInterval(pollRef.current)
    pollRef.current = setInterval(() => {
      fetch(`/api/attachments/${jobMode}/${jid}/status`)
        .then(r => r.json())
        .then(s => {
          setJobState(s)
          if (!s.running) {
            clearInterval(pollRef.current)
            pollRef.current = null
            // Fetch file results
            if (s.has_file_results) {
              setLoadingResults(true)
              fetch(`/api/attachments/${jobMode}/${jid}/results`)
                .then(r => r.json())
                .then(data => setFileResults(data.file_results || []))
                .finally(() => setLoadingResults(false))
            }
          }
        })
        .catch(() => {})
    }, 1500)
  }

  useEffect(() => {
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [])

  const isRunning = jobState?.running
  const statusColor = jobState?.status === 'complete' ? '#10b981'
    : jobState?.status === 'error' ? '#ef4444'
    : jobState?.status === 'cancelled' ? '#d97706'
    : '#3b82f6'

  const folderPickerRef = useRef(null)
  useEffect(() => {
    const handler = (e) => {
      if (folderPickerRef.current && !folderPickerRef.current.contains(e.target)) setShowFolderPicker(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      {/* Toolbar */}
      <div style={{
        padding: '12px 16px',
        borderBottom: '1px solid #e5e7eb',
        display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap',
        background: '#fff',
      }}>
        {/* Mode toggle */}
        <div style={{ display: 'flex', borderRadius: 6, overflow: 'hidden', border: '1px solid #d1d5db' }}>
          {['download', 'upload'].map(m => (
            <button
              key={m}
              onClick={() => { setMode(m); setJobState(null); setFileResults([]); setShowResults(false) }}
              disabled={isRunning}
              style={{
                padding: '5px 14px', fontSize: 12, fontWeight: 500, border: 'none', cursor: 'pointer',
                background: mode === m ? '#3b82f6' : '#fff',
                color: mode === m ? '#fff' : '#374151',
                transition: 'all 0.15s',
              }}
            >
              {m === 'download' ? 'Download' : 'Upload'}
            </button>
          ))}
        </div>

        {/* SF Connection */}
        <div style={{ minWidth: 200 }}>
          <ConnectionSelect
            connections={sfConnections}
            value={selectedSfId}
            onChange={handleSfChange}
            placeholder="Select SF connection..."
          />
        </div>

        {/* Object type toggle */}
        <div style={{ display: 'flex', borderRadius: 6, overflow: 'hidden', border: '1px solid #d1d5db' }}>
          {[
            { value: 'Attachment', label: 'Attachment' },
            { value: 'ContentVersion', label: 'ContentVersion' },
          ].map(opt => (
            <button
              key={opt.value}
              onClick={() => { setObjectType(opt.value); setPreviewCount(null); setCountError('') }}
              disabled={isRunning}
              style={{
                padding: '5px 12px', fontSize: 11, fontWeight: 500, border: 'none', cursor: 'pointer',
                background: objectType === opt.value ? '#6366f1' : '#fff',
                color: objectType === opt.value ? '#fff' : '#374151',
                transition: 'all 0.15s',
              }}
            >
              {opt.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main content */}
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Left panel — configuration */}
        <div style={{
          width: 380, minWidth: 320, borderRight: '1px solid #e5e7eb',
          overflow: 'auto', padding: 16, display: 'flex', flexDirection: 'column', gap: 16,
          background: '#fafbfc',
        }}>
          {mode === 'download' ? (
            <>
              {/* WHERE clause */}
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
                  WHERE clause <span style={{ fontWeight: 400, color: '#9ca3af' }}>(optional)</span>
                </label>
                <textarea
                  value={whereClause}
                  onChange={e => { setWhereClause(e.target.value); setPreviewCount(null); setCountError('') }}
                  disabled={isRunning}
                  placeholder={objectType === 'Attachment'
                    ? "e.g. ParentId = '001...'"
                    : "e.g. ContentDocumentId = '069...'"
                  }
                  style={{
                    width: '100%', minHeight: 60, padding: 8, fontSize: 12,
                    fontFamily: 'monospace', border: '1px solid #d1d5db', borderRadius: 6,
                    resize: 'vertical', background: '#fff',
                  }}
                />
              </div>

              {/* Output directory */}
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
                  Download to <span style={{ fontWeight: 400, color: '#9ca3af' }}>(optional — defaults to ~/sfdc-loader/attachments/&lt;job-id&gt;)</span>
                </label>
                <input
                  type="text"
                  value={outputDir}
                  onChange={e => setOutputDir(e.target.value)}
                  disabled={isRunning}
                  placeholder="e.g. /Users/you/Downloads/sf-files"
                  style={{
                    width: '100%', padding: 8, fontSize: 12, fontFamily: 'monospace',
                    border: '1px solid #d1d5db', borderRadius: 6, background: '#fff',
                  }}
                />
              </div>

              {/* Preview count */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <button
                  onClick={handlePreviewCount}
                  disabled={!selectedSfId || loadingCount || isRunning}
                  style={{
                    padding: '6px 14px', fontSize: 12, fontWeight: 500,
                    background: '#fff', border: '1px solid #d1d5db', borderRadius: 6,
                    cursor: 'pointer', color: '#374151',
                  }}
                >
                  {loadingCount ? 'Counting...' : 'Preview Count'}
                </button>
                {previewCount != null && (
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#1d4ed8' }}>
                    {previewCount.toLocaleString()} file(s)
                  </span>
                )}
                {countError && (
                  <span style={{ fontSize: 12, color: '#dc2626' }}>{countError}</span>
                )}
              </div>

              {/* Download button */}
              <button
                onClick={handleDownload}
                disabled={!selectedSfId || isRunning}
                style={{
                  padding: '10px 20px', fontSize: 13, fontWeight: 600,
                  background: isRunning ? '#9ca3af' : '#3b82f6',
                  color: '#fff', border: 'none', borderRadius: 8,
                  cursor: isRunning ? 'default' : 'pointer',
                  transition: 'background 0.15s',
                }}
              >
                {isRunning ? 'Downloading...' : 'Download Files'}
              </button>
            </>
          ) : (
            <>
              {/* Source directory */}
              <div>
                <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
                  Source Directory
                </label>
                <div style={{ position: 'relative' }} ref={folderPickerRef}>
                  <input
                    type="text"
                    value={sourceDir}
                    onChange={e => setSourceDir(e.target.value)}
                    disabled={isRunning}
                    placeholder="Path to folder with files..."
                    style={{
                      width: '100%', padding: '8px 32px 8px 8px', fontSize: 12,
                      fontFamily: 'monospace', border: '1px solid #d1d5db', borderRadius: 6,
                      background: '#fff',
                    }}
                  />
                  {folders.length > 0 && (
                    <button
                      onClick={() => setShowFolderPicker(!showFolderPicker)}
                      style={{
                        position: 'absolute', right: 4, top: '50%', transform: 'translateY(-50%)',
                        background: 'none', border: 'none', cursor: 'pointer', padding: '2px 4px',
                        color: '#6b7280', fontSize: 14,
                      }}
                      title="Pick from previous downloads"
                    >
                      {showFolderPicker ? '\u25B4' : '\u25BE'}
                    </button>
                  )}
                  {showFolderPicker && folders.length > 0 && (
                    <div style={{
                      position: 'absolute', top: '100%', left: 0, right: 0, zIndex: 10,
                      background: '#fff', border: '1px solid #d1d5db', borderRadius: 6,
                      boxShadow: '0 4px 12px rgba(0,0,0,0.1)', maxHeight: 200, overflow: 'auto',
                    }}>
                      {folders.map(f => (
                        <div
                          key={f.path}
                          onClick={() => { setSourceDir(f.path); setShowFolderPicker(false) }}
                          style={{
                            padding: '8px 10px', fontSize: 12, cursor: 'pointer',
                            borderBottom: '1px solid #f3f4f6',
                            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                          }}
                          onMouseEnter={e => e.currentTarget.style.background = '#f0f4ff'}
                          onMouseLeave={e => e.currentTarget.style.background = '#fff'}
                        >
                          <span style={{ fontFamily: 'monospace', fontWeight: 500 }}>{f.name}</span>
                          <span style={{ color: '#9ca3af', fontSize: 11 }}>
                            {f.file_count} files &bull; {f.total_size_display}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Default ParentId (for Attachment) */}
              {objectType === 'Attachment' && (
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
                    Default Parent ID <span style={{ fontWeight: 400, color: '#9ca3af' }}>(for Attachment)</span>
                  </label>
                  <input
                    type="text"
                    value={defaultParentId}
                    onChange={e => setDefaultParentId(e.target.value)}
                    disabled={isRunning}
                    placeholder="e.g. 001..."
                    style={{
                      width: '100%', padding: 8, fontSize: 12, fontFamily: 'monospace',
                      border: '1px solid #d1d5db', borderRadius: 6, background: '#fff',
                    }}
                  />
                  <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>
                    Used when metadata.csv doesn't provide a ParentId
                  </div>
                </div>
              )}

              {/* Link to Record ID (for ContentVersion) */}
              {objectType === 'ContentVersion' && (
                <div>
                  <label style={{ fontSize: 12, fontWeight: 600, color: '#374151', display: 'block', marginBottom: 4 }}>
                    Link to Record ID <span style={{ fontWeight: 400, color: '#9ca3af' }}>(optional)</span>
                  </label>
                  <input
                    type="text"
                    value={linkToRecordId}
                    onChange={e => setLinkToRecordId(e.target.value)}
                    disabled={isRunning}
                    placeholder="e.g. 001..."
                    style={{
                      width: '100%', padding: 8, fontSize: 12, fontFamily: 'monospace',
                      border: '1px solid #d1d5db', borderRadius: 6, background: '#fff',
                    }}
                  />
                  <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 2 }}>
                    Creates a ContentDocumentLink to this record after upload
                  </div>
                </div>
              )}

              {/* Upload button */}
              <button
                onClick={handleUpload}
                disabled={!selectedSfId || !sourceDir || isRunning}
                style={{
                  padding: '10px 20px', fontSize: 13, fontWeight: 600,
                  background: isRunning ? '#9ca3af' : '#10b981',
                  color: '#fff', border: 'none', borderRadius: 8,
                  cursor: isRunning ? 'default' : 'pointer',
                  transition: 'background 0.15s',
                }}
              >
                {isRunning ? 'Uploading...' : 'Upload Files'}
              </button>
            </>
          )}
        </div>

        {/* Right panel — progress & results */}
        <div style={{
          flex: 1, overflow: 'auto', padding: 16,
          display: 'flex', flexDirection: 'column', gap: 12,
        }}>
          {!jobState && !showResults && (
            <div style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
              padding: '60px 20px', color: '#9ca3af',
            }}>
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                <polyline points="14 2 14 8 20 8"/>
                <line x1="16" y1="13" x2="8" y2="13"/>
                <line x1="16" y1="17" x2="8" y2="17"/>
              </svg>
              <div style={{ marginTop: 12, fontSize: 14, fontWeight: 500 }}>
                {mode === 'download' ? 'Download files from Salesforce' : 'Upload files to Salesforce'}
              </div>
              <div style={{ marginTop: 4, fontSize: 12 }}>
                {mode === 'download'
                  ? 'Select a connection, choose object type, and click Download'
                  : 'Select a source folder and click Upload'
                }
              </div>
            </div>
          )}

          {jobState && (
            <>
              {/* Progress section */}
              <div style={{
                background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, padding: 16,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>
                    {jobState.type || (mode === 'download' ? 'File Download' : 'File Upload')}
                  </span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    {isRunning && (
                      <button
                        onClick={handleCancel}
                        style={{
                          padding: '3px 12px', fontSize: 11, fontWeight: 600,
                          background: '#fff', color: '#dc2626', border: '1px solid #fca5a5',
                          borderRadius: 4, cursor: 'pointer', transition: 'all 0.15s',
                        }}
                        onMouseEnter={e => { e.currentTarget.style.background = '#fef2f2' }}
                        onMouseLeave={e => { e.currentTarget.style.background = '#fff' }}
                      >
                        Cancel
                      </button>
                    )}
                    <span style={{
                      fontSize: 11, fontWeight: 600, padding: '2px 8px', borderRadius: 4,
                      background: jobState.status === 'complete' ? '#ecfdf5' : jobState.status === 'cancelled' ? '#fffbeb' : jobState.status === 'error' ? '#fef2f2' : '#eff6ff',
                      color: jobState.status === 'cancelled' ? '#d97706' : statusColor,
                    }}>
                      {jobState.status || 'pending'}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div style={{
                  width: '100%', height: 8, background: '#e5e7eb', borderRadius: 4, overflow: 'hidden',
                  marginBottom: 8,
                }}>
                  <div style={{
                    width: `${jobState.progress || 0}%`, height: '100%', borderRadius: 4,
                    background: statusColor,
                    transition: 'width 0.3s ease',
                  }} />
                </div>

                {/* Stats */}
                <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap', fontSize: 12, color: '#6b7280' }}>
                  <span>{jobState.progress || 0}%</span>
                  {jobState.total_files > 0 && (
                    <span>{jobState.completed_files || 0} / {jobState.total_files} files</span>
                  )}
                  {jobState.total_bytes > 0 && (
                    <span>{formatBytes(mode === 'download' ? jobState.downloaded_bytes : jobState.uploaded_bytes)} / {formatBytes(jobState.total_bytes)}</span>
                  )}
                  {jobState.success_count > 0 && (
                    <span style={{ color: '#10b981' }}>{jobState.success_count} succeeded</span>
                  )}
                  {jobState.error_count > 0 && (
                    <span style={{ color: '#ef4444' }}>{jobState.error_count} failed</span>
                  )}
                </div>

                {/* Message */}
                {jobState.message && (
                  <div style={{ marginTop: 8, fontSize: 12, color: '#374151' }}>
                    {jobState.message}
                  </div>
                )}

                {/* Output dir */}
                {jobState.output_dir && (
                  <div style={{ marginTop: 6, fontSize: 11, color: '#9ca3af', fontFamily: 'monospace' }}>
                    {jobState.output_dir}
                  </div>
                )}
              </div>

              {/* Errors */}
              {jobState.errors?.length > 0 && (
                <div style={{
                  background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8, padding: 12,
                }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: '#dc2626', marginBottom: 6 }}>
                    Errors ({jobState.errors.length})
                  </div>
                  <div style={{ maxHeight: 120, overflow: 'auto', fontSize: 11, fontFamily: 'monospace' }}>
                    {jobState.errors.slice(0, 20).map((err, i) => (
                      <div key={i} style={{ padding: '2px 0', color: '#991b1b' }}>
                        {typeof err === 'string' ? err : `${err.file}: ${err.error}`}
                      </div>
                    ))}
                    {jobState.errors.length > 20 && (
                      <div style={{ color: '#9ca3af' }}>...and {jobState.errors.length - 20} more</div>
                    )}
                  </div>
                </div>
              )}

              {/* Per-file results table */}
              {!isRunning && fileResults.length > 0 && (
                <div style={{
                  background: '#fff', border: '1px solid #e5e7eb', borderRadius: 8, overflow: 'hidden',
                }}>
                  <div
                    onClick={() => setShowResults(!showResults)}
                    style={{
                      padding: '10px 14px', cursor: 'pointer', fontSize: 12, fontWeight: 600,
                      color: '#374151', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                      background: '#fafbfc', borderBottom: showResults ? '1px solid #e5e7eb' : 'none',
                    }}
                  >
                    <span>File Results ({fileResults.length})</span>
                    <svg
                      width="14" height="14" viewBox="0 0 14 14" fill="none"
                      style={{ transform: showResults ? 'rotate(180deg)' : 'rotate(0)', transition: 'transform 0.15s' }}
                    >
                      <path d="M3 5l4 4 4-4" stroke="#9ca3af" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  {showResults && (
                    <div style={{ maxHeight: 400, overflow: 'auto' }}>
                      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
                        <thead>
                          <tr style={{ background: '#f9fafb', borderBottom: '1px solid #e5e7eb' }}>
                            <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600 }}>#</th>
                            <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600 }}>
                              {mode === 'download' ? 'Name' : 'File'}
                            </th>
                            <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600 }}>Status</th>
                            <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600 }}>
                              {mode === 'download' ? 'Size' : 'SF ID'}
                            </th>
                            <th style={{ padding: '6px 10px', textAlign: 'left', fontWeight: 600 }}>Detail</th>
                          </tr>
                        </thead>
                        <tbody>
                          {fileResults.map((fr, i) => (
                            <tr key={i} style={{ borderBottom: '1px solid #f3f4f6' }}>
                              <td style={{ padding: '5px 10px', color: '#9ca3af' }}>{i + 1}</td>
                              <td style={{ padding: '5px 10px', fontFamily: 'monospace', maxWidth: 200, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                {fr.name || fr.file}
                              </td>
                              <td style={{ padding: '5px 10px' }}>
                                <span style={{
                                  display: 'inline-block', width: 6, height: 6, borderRadius: '50%',
                                  background: fr.success ? '#10b981' : '#ef4444', marginRight: 4,
                                }} />
                                {fr.success ? 'OK' : 'Error'}
                              </td>
                              <td style={{ padding: '5px 10px', fontFamily: 'monospace', fontSize: 10 }}>
                                {mode === 'download' ? formatBytes(fr.size) : (fr.sf_id || '-')}
                              </td>
                              <td style={{ padding: '5px 10px', color: fr.error ? '#dc2626' : '#9ca3af', maxWidth: 250, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                {fr.error || (mode === 'download' ? (fr.id || '') : '')}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
              {loadingResults && (
                <div style={{ fontSize: 12, color: '#9ca3af', textAlign: 'center', padding: 12 }}>
                  Loading file results...
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  )
}
