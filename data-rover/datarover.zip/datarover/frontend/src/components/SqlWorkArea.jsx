import React, { useState, useEffect, useRef } from 'react'
import ResizablePanel from './ResizablePanel.jsx'
import { ResizablePanelV } from './ResizablePanel.jsx'
import { connectionDisplayName } from './ConnectionModal.jsx'
import ConnectionSelect, { DatabaseSelect, DbIcon, getConnectionIcon } from './ConnectionSelect.jsx'

// Color for the type-indicator bullet shown next to each field
const FIELD_TYPE_COLORS = {
  string: '#6366f1', phone: '#6366f1', email: '#6366f1', url: '#6366f1',
  encryptedstring: '#6366f1', combobox: '#6366f1',
  picklist: '#8b5cf6', multipicklist: '#8b5cf6',
  textarea: '#818cf8',
  id: '#3b82f6', reference: '#3b82f6',
  'double': '#22c55e', currency: '#22c55e', percent: '#22c55e', 'int': '#22c55e',
  'long': '#22c55e',
  boolean: '#f59e0b',
  date: '#f97316', datetime: '#f97316', time: '#f97316',
  address: '#9ca3af', location: '#9ca3af',
  // common SQL types
  varchar: '#6366f1', char: '#6366f1', text: '#818cf8', nvarchar: '#6366f1',
  integer: '#22c55e', bigint: '#22c55e', smallint: '#22c55e', numeric: '#22c55e',
  decimal: '#22c55e', float: '#22c55e', real: '#22c55e',
  timestamp: '#f97316', 'timestamp without time zone': '#f97316',
  'timestamp with time zone': '#f97316',
  'character varying': '#6366f1',
}
function fieldTypeColor(type) {
  return FIELD_TYPE_COLORS[(type || '').toLowerCase()] || '#d1d5db'
}

// Extract all table names from SQL query (FROM clause)
function parseTablesFromSql(sql) {
  const match = sql.match(/\bFROM\s+([\s\S]+?)(?:\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
  if (!match) return []
  return match[1]
    .split(',')
    .map(part => part.trim().split(/\s+/)[0])
    .filter(name => name && /^\w+$/.test(name))
}

function parseTableFromSql(sql) {
  return parseTablesFromSql(sql)[0] || null
}

// Parse alias → table name mapping from FROM clause
function parseAliasesFromSql(sql) {
  const match = sql.match(/\bFROM\s+([\s\S]+?)(?:\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
  if (!match) return {}
  const aliases = {}
  match[1].split(',').forEach(part => {
    const tokens = part.trim().split(/\s+/)
    if (tokens.length >= 2 && /^\w+$/.test(tokens[0]) && /^\w+$/.test(tokens[1])) {
      aliases[tokens[1].toLowerCase()] = tokens[0]
    }
    if (tokens[0] && /^\w+$/.test(tokens[0])) {
      aliases[tokens[0].toLowerCase()] = tokens[0]
    }
  })
  return aliases
}

export default function SqlWorkArea({ dbConnectionId, dbConnections = [], targetDbConnections = [], activeDbId = '', onSetActiveDbId, onOpenModal, onEditConn, navigateToTable, navigateToDatabase, onNavigateHandled }) {
  // Multi-tab query state
  const queryTabCounterRef = useRef(1)
  const [queryTabs, setQueryTabs] = useState([
    { id: 1, name: 'Query 1', sql: 'SELECT * FROM  LIMIT 25', result: null, error: null }
  ])
  const [activeQueryTabId, setActiveQueryTabId] = useState(1)

  const activeQTab = queryTabs.find(t => t.id === activeQueryTabId) || queryTabs[0]
  const sql = activeQTab?.sql || ''
  const result = activeQTab?.result || null
  const error = activeQTab?.error || null

  const setSql = (valOrFn) => {
    setQueryTabs(prev => prev.map(t => t.id === activeQueryTabId
      ? { ...t, sql: typeof valOrFn === 'function' ? valOrFn(t.sql) : valOrFn }
      : t
    ))
  }
  const setResult = (val) => {
    setQueryTabs(prev => prev.map(t => t.id === activeQueryTabId ? { ...t, result: val } : t))
  }
  const setError = (val) => {
    setQueryTabs(prev => prev.map(t => t.id === activeQueryTabId ? { ...t, error: val } : t))
  }

  const addQueryTab = () => {
    queryTabCounterRef.current++
    const newTab = { id: queryTabCounterRef.current, name: `Query ${queryTabCounterRef.current}`, sql: '', result: null, error: null }
    setQueryTabs(prev => [...prev, newTab])
    setActiveQueryTabId(newTab.id)
    setBottomTab('fields')
  }

  const closeQueryTab = (tabId) => {
    setQueryTabs(prev => {
      if (prev.length <= 1) return prev
      const next = prev.filter(t => t.id !== tabId)
      if (activeQueryTabId === tabId) setActiveQueryTabId(next[next.length - 1].id)
      return next
    })
  }

  // Column resize state
  const [columnWidths, setColumnWidths] = useState({})
  const colResizing = useRef(null)

  const handleColResizeStart = (col, e) => {
    e.preventDefault()
    e.stopPropagation()
    const startX = e.clientX
    const th = e.target.closest('th')
    const startWidth = th ? th.offsetWidth : 150
    colResizing.current = { col, startX, startWidth }

    const onMouseMove = (ev) => {
      if (!colResizing.current) return
      const diff = ev.clientX - colResizing.current.startX
      const minChars = Math.max(10, colResizing.current.col.length)
      const minWidth = minChars * 8 + 20 // ~8px per char + padding
      const newWidth = Math.max(minWidth, colResizing.current.startWidth + diff)
      setColumnWidths(prev => ({ ...prev, [colResizing.current.col]: newWidth }))
    }
    const onMouseUp = () => {
      colResizing.current = null
      document.removeEventListener('mousemove', onMouseMove)
      document.removeEventListener('mouseup', onMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }
    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'
    document.addEventListener('mousemove', onMouseMove)
    document.addEventListener('mouseup', onMouseUp)
  }

  const [running, setRunning] = useState(false)
  const [tables, setTables] = useState([])
  const [tableComments, setTableComments] = useState({})
  const [tableSearch, setTableSearch] = useState('')
  const [databases, setDatabases] = useState([])
  const [selectedDb, setSelectedDb] = useState('')

  // Fields state
  const [fields, setFields] = useState([])
  const [fieldsLoading, setFieldsLoading] = useState(false)
  const [fieldSearch, setFieldSearch] = useState('')
  const [detectedTable, setDetectedTable] = useState(null)
  const [detectedTables, setDetectedTables] = useState([])
  const [fieldsObjectFilter, setFieldsObjectFilter] = useState('')

  // Bottom panel tab
  const [bottomTab, setBottomTab] = useState('fields')

  // History
  const [history, setHistory] = useState([])
  const [showHistory, setShowHistory] = useState(false)

  // Pagination
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(100)

  // Results search
  const [resultSearch, setResultSearch] = useState('')

  // Import to DB state
  const [showImportModal, setShowImportModal] = useState(false)
  const [importTableName, setImportTableName] = useState('')
  const [importSoql, setImportSoql] = useState('')
  const [importJob, setImportJob] = useState(null)
  const importPollRef = useRef(null)
  const [importTargetDbId, setImportTargetDbId] = useState(null)
  const [importTargetSelectedDb, setImportTargetSelectedDb] = useState('')

  // Import icon popovers
  const [showDbPopover, setShowDbPopover] = useState(false)
  const [showResultsDbPopover, setShowResultsDbPopover] = useState(false)
  const [importConnDatabases, setImportConnDatabases] = useState({})
  const [expandedImportConn, setExpandedImportConn] = useState(null)
  const [createDbInput, setCreateDbInput] = useState({ connId: null, name: '', loading: false, error: '' })

  // Save as Step (checkbox in import modal)
  const [saveAsStep, setSaveAsStep] = useState(false)
  const [saveStepName, setSaveStepName] = useState('')
  const [stepSaved, setStepSaved] = useState(false)

  const saveAsStepRef = useRef({ saveAsStep: false, saveStepName: '' })
  useEffect(() => { saveAsStepRef.current = { saveAsStep, saveStepName } }, [saveAsStep, saveStepName])
  const prevImportStatusRef = useRef(null)
  useEffect(() => {
    if (importJob?.status === 'complete' && prevImportStatusRef.current !== 'complete' && saveAsStepRef.current.saveAsStep && saveAsStepRef.current.saveStepName.trim()) {
      const name = saveAsStepRef.current.saveStepName.trim()
      const effectiveTargetDbId = importTargetDbId || dbConnectionId
      const cfg = {
        sourceDbConnectionId: activeDbId || dbConnectionId,
        targetDbConnectionId: effectiveTargetDbId,
        sourceDatabase: selectedDb || '',
        targetDatabase: importTargetSelectedDb || selectedDb || '',
        sql: importSoql || sql,
        tableName: importTableName || detectedTable || 'transform_result',
      }
      fetch('/api/saved-steps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, type: 'transform', config: cfg }),
      }).then(() => setStepSaved(true)).catch(() => {})
    }
    prevImportStatusRef.current = importJob?.status || null
  }, [importJob?.status])

  // Textarea cell popup
  const [textCellPopup, setTextCellPopup] = useState(null) // { column, value }

  // Sidebar item import popover
  const [sidebarImportItem, setSidebarImportItem] = useState(null)
  const [sidebarImportPos, setSidebarImportPos] = useState({ top: 0, left: 0 })

  // AI Assistant state
  const [showAiPanel, setShowAiPanel] = useState(false)
  const [aiPrompt, setAiPrompt] = useState('')
  const [aiLoading, setAiLoading] = useState(false)
  const [aiResult, setAiResult] = useState(null) // { sql, explanation }
  const [aiError, setAiError] = useState('')

  const handleAiGenerate = async () => {
    if (!aiPrompt.trim() || aiLoading) return
    setAiLoading(true)
    setAiResult(null)
    setAiError('')

    // Gather schema: fetch columns for all known tables
    const dbParam = selectedDb ? `?database=${encodeURIComponent(selectedDb)}` : ''
    let tableSchemas = []
    try {
      const colPromises = tables.map(async (tName) => {
        try {
          const res = await fetch(`/api/database/${dbConnectionId}/tables/${tName}/columns${dbParam}`)
          const data = await res.json()
          return { name: tName, columns: data.columns || [] }
        } catch { return { name: tName, columns: [] } }
      })
      tableSchemas = await Promise.all(colPromises)
    } catch { /* ignore */ }

    const conn = dbConnections.find(c => c.id === dbConnectionId)
    try {
      const res = await fetch('/api/ai/generate-sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: aiPrompt.trim(),
          tables: tableSchemas,
          database: selectedDb || '',
          dbType: conn?.dbType || '',
        }),
      })
      const data = await res.json()
      if (data.error) {
        setAiError(data.error)
      } else {
        setAiResult(data)
      }
    } catch (err) {
      setAiError('Failed to connect to AI service: ' + err.message)
    } finally {
      setAiLoading(false)
    }
  }

  // Autocomplete state
  const [autoComplete, setAutoComplete] = useState({ show: false, items: [], selectedIdx: 0 })
  const [acPosition, setAcPosition] = useState({ top: 0, left: 0 })
  const textareaRef = useRef(null)
  const lineNumberRef = useRef(null)

  // Saved scripts state
  const [savedScripts, setSavedScripts] = useState([])
  const [showScriptsModal, setShowScriptsModal] = useState(false)
  const [showSaveScriptModal, setShowSaveScriptModal] = useState(false)
  const [saveScriptName, setSaveScriptName] = useState('')

  // Fetch saved scripts on mount
  useEffect(() => {
    fetch('/api/saved-steps')
      .then(r => r.json())
      .then(data => setSavedScripts((data.steps || []).filter(s => s.type === 'script')))
      .catch(() => {})
  }, [])

  const handleSaveScript = () => {
    if (!saveScriptName.trim() || !sql.trim()) return
    const script = {
      id: String(Date.now()),
      name: saveScriptName.trim(),
      type: 'script',
      config: {
        sql: sql,
        dbConnectionId: activeDbId || dbConnectionId,
        database: selectedDb || '',
      },
      savedAt: new Date().toISOString(),
    }
    fetch('/api/saved-steps', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(script),
    })
      .then(r => r.json())
      .then(saved => {
        setSavedScripts(prev => [saved, ...prev.filter(s => s.id !== saved.id)])
        setShowSaveScriptModal(false)
        setSaveScriptName('')
      })
      .catch(() => {})
  }

  const handleDeleteScript = (scriptId) => {
    fetch(`/api/saved-steps/${scriptId}`, { method: 'DELETE' })
      .then(() => setSavedScripts(prev => prev.filter(s => s.id !== scriptId)))
      .catch(() => {})
  }

  const handleLoadScript = (script) => {
    setSql(script.config?.sql || '')
    setShowScriptsModal(false)
  }

  // Fetch list of databases when connection changes
  useEffect(() => {
    if (!dbConnectionId) { setDatabases([]); setSelectedDb(''); setTables([]); return }
    fetch(`/api/database/${dbConnectionId}/databases`)
      .then(r => r.json())
      .then(data => {
        if (!data.error) {
          const dbs = data.databases || []
          setDatabases(dbs)
          setSelectedDb('')
          setTables([])
          if (dbs.length === 1) setSelectedDb(dbs[0])
        }
      })
      .catch(() => {})
  }, [dbConnectionId])

  // Fetch tables when a database is selected
  const refreshTables = () => {
    if (!dbConnectionId || !selectedDb) { setTables([]); setTableComments({}); return }
    fetch(`/api/database/${dbConnectionId}/tables?database=${encodeURIComponent(selectedDb)}`)
      .then(r => r.json())
      .then(data => {
        if (!data.error) {
          setTables(data.tables || [])
          setTableComments(data.tableComments || {})
        }
      })
      .catch(() => {})
  }
  useEffect(refreshTables, [dbConnectionId, selectedDb])

  // Auto-detect tables from query and load columns
  useEffect(() => {
    const allTables = parseTablesFromSql(sql)
    const tableName = allTables[0] || null
    const listKey = allTables.join(',')
    const prevListKey = detectedTables.join(',')

    if (allTables.length > 0 && listKey !== prevListKey) {
      setDetectedTable(tableName)
      setDetectedTables(allTables)
      setFieldsLoading(true)
      setFieldSearch('')
      setFieldsObjectFilter('')
      const dbParam = selectedDb ? `?database=${encodeURIComponent(selectedDb)}` : ''
      const fetches = allTables.map(name =>
        fetch(`/api/database/${dbConnectionId}/tables/${name}/columns${dbParam}`)
          .then(r => r.json())
          .then(data => ({ name, columns: data.columns || [] }))
          .catch(() => ({ name, columns: [] }))
      )
      Promise.all(fetches).then(results => {
        let merged = []
        if (allTables.length === 1) {
          merged = results[0].columns.map(c => ({ name: c.name, type: c.type, label: c.type }))
        } else {
          results.forEach(r => {
            r.columns.forEach(c => {
              merged.push({ name: `${r.name}.${c.name}`, type: c.type, label: c.type, _objectName: r.name })
            })
          })
        }
        setFields(merged)
      }).finally(() => setFieldsLoading(false))
    } else if (allTables.length === 0) {
      setDetectedTable(null)
      setDetectedTables([])
      setFieldsObjectFilter('')
      setFields([])
    }
  }, [sql, dbConnectionId, selectedDb])

  useEffect(() => {
    return () => { if (importPollRef.current) clearInterval(importPollRef.current) }
  }, [])

  useEffect(() => { setPage(1); setResultSearch('') }, [result])

  // Parse fields already in the SELECT clause
  const selectedFieldNames = (() => {
    const upper = sql.toUpperCase()
    const selectIdx = upper.indexOf('SELECT ')
    const fromIdx = upper.indexOf(' FROM ')
    if (selectIdx < 0 || fromIdx < 0) return new Set()
    const fieldsPart = sql.substring(selectIdx + 7, fromIdx)
    return new Set(fieldsPart.split(',').map(f => f.trim().toLowerCase()).filter(Boolean))
  })()

  const filteredFields = fields
    .filter(f => !fieldsObjectFilter || f._objectName === fieldsObjectFilter)
    .filter(f => !selectedFieldNames.has(f.name.toLowerCase()))
    .filter(f => !fieldSearch ||
      f.name.toLowerCase().includes(fieldSearch.toLowerCase()) ||
      f.label.toLowerCase().includes(fieldSearch.toLowerCase())
    )

  const filteredTables = tableSearch
    ? tables.filter(t => t.toLowerCase().includes(tableSearch.toLowerCase()))
    : tables

  const handleSelectTable = (tableName) => {
    setFieldSearch('')
    setResult(null)
    setError(null)
    setBottomTab('fields')
    setSql(prev => {
      const trimmed = prev.trim()
      if (!trimmed) return `SELECT * FROM ${tableName} LIMIT 25`
      const upper = trimmed.toUpperCase()
      const fromIdx = upper.indexOf(' FROM ')
      if (fromIdx < 0) return trimmed + ` FROM ${tableName} LIMIT 25`
      const afterFrom = trimmed.substring(fromIdx + 6)
      const endMatch = afterFrom.match(/^[\s\S]+?(?=\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
      const beforeFrom = trimmed.substring(0, fromIdx + 6)
      const rest = endMatch ? afterFrom.substring(endMatch[0].length) : ''
      return beforeFrom + tableName + rest
    })
  }

  // Navigate to a specific database when triggered from outside (e.g. Jobs panel)
  useEffect(() => {
    if (navigateToDatabase && databases.length > 0) {
      const match = databases.find(d => d.toLowerCase() === navigateToDatabase.toLowerCase())
      if (match && match !== selectedDb) {
        setSelectedDb(match)
      }
    }
  }, [navigateToDatabase, databases])

  // Navigate to a specific table when triggered from outside (e.g. Jobs panel)
  useEffect(() => {
    if (navigateToTable && tables.length > 0) {
      const match = tables.find(t => t.toLowerCase() === navigateToTable.toLowerCase())
      if (match) {
        handleSelectTable(match)
      }
      if (onNavigateHandled) onNavigateHandled()
    }
  }, [navigateToTable, tables])

  const handleFieldClick = (fieldName) => {
    setSql(prev => {
      // If field has a table prefix (multi-table mode), resolve to alias
      let insertName = fieldName
      const dotPos = fieldName.indexOf('.')
      if (dotPos >= 0) {
        const tablePart = fieldName.substring(0, dotPos)
        const colPart = fieldName.substring(dotPos + 1)
        // Build reverse map: table → alias (prefer short alias over table name itself)
        const fromMatch = prev.match(/\bFROM\s+([\s\S]+?)(?:\s+(?:WHERE|LIMIT|ORDER|GROUP|HAVING)\b|$)/i)
        if (fromMatch) {
          let bestAlias = tablePart
          fromMatch[1].split(',').forEach(part => {
            const tokens = part.trim().split(/\s+/)
            if (tokens[0] && tokens[0].toLowerCase() === tablePart.toLowerCase() && tokens.length >= 2 && /^\w+$/.test(tokens[1])) {
              bestAlias = tokens[1]
            }
          })
          insertName = bestAlias + '.' + colPart
        }
      }

      const upper = prev.toUpperCase()
      const fromIdx = upper.indexOf(' FROM ')
      if (fromIdx > 0) {
        const beforeFrom = prev.substring(0, fromIdx).trimEnd()
        const afterFrom = prev.substring(fromIdx)
        const selectIdx = upper.indexOf('SELECT ')
        const between = beforeFrom.substring(selectIdx + 7).trim()
        if (!between || between === '*') {
          return prev.substring(0, selectIdx + 7) + insertName + afterFrom
        }
        return beforeFrom + ', ' + insertName + afterFrom
      }
      return prev + ' ' + insertName
    })
  }

  const handleSelectAllFields = () => {
    if (!detectedTable || fields.length === 0) return
    const fieldNames = fields.map(f => f.name).join(', ')
    setSql(`SELECT ${fieldNames} FROM ${detectedTable} LIMIT 25`)
  }

  const handleRun = () => {
    if (!dbConnectionId || !sql.trim()) return
    setRunning(true)
    setResult(null)
    setError(null)
    setBottomTab('results')
    const startTime = Date.now()
    fetch(`/api/database/${dbConnectionId}/query`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sql: sql.trim(), database: selectedDb || undefined }),
    })
      .then(r => r.json())
      .then(data => {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1)
        if (data.error) {
          setError(data.error)
        } else {
          setResult({ ...data, elapsed })
          const conn = dbConnections.find(c => c.id === dbConnectionId)
          setHistory(prev => [{
            sql: sql.trim(),
            time: new Date().toLocaleTimeString(),
            rows: data.rowCount,
            elapsed,
            connection: conn ? connectionDisplayName(conn) : dbConnectionId,
            database: selectedDb || '',
            table: detectedTable || '',
          }, ...prev].slice(0, 50))
        }
      })
      .catch(err => setError(err.message))
      .finally(() => setRunning(false))
  }

  // Autocomplete helpers
  const getAutocompleteContext = (text, cursorPos) => {
    const upper = text.toUpperCase()
    const selectIdx = upper.indexOf('SELECT ')
    if (selectIdx < 0) return null
    const fromIdx = upper.indexOf(' FROM ')

    // Find word boundary at cursor (include dots for tablename.field tokens)
    let wordStart = cursorPos
    while (wordStart > 0) {
      const ch = text[wordStart - 1]
      if (ch === ',' || ch === ' ' || ch === '\n' || ch === '\t') break
      wordStart--
    }
    while (wordStart < cursorPos && (text[wordStart] === ' ' || text[wordStart] === '\t')) wordStart++

    const partial = text.substring(wordStart, cursorPos)

    // Check for tablename.partial pattern (works anywhere in the query)
    const dotIdx = partial.indexOf('.')
    if (dotIdx >= 0) {
      const tableName = partial.substring(0, dotIdx)
      const fieldPartial = partial.substring(dotIdx + 1)
      if (tableName.length > 0) {
        return { type: 'dotfield', partial: fieldPartial, tableName, wordStart: wordStart + dotIdx + 1 }
      }
    }

    // After FROM: suggest table names (only within FROM clause)
    if (fromIdx >= 0 && cursorPos > fromIdx + 6) {
      const afterFrom = upper.substring(fromIdx + 6)
      const clauseEnd = afterFrom.match(/\b(WHERE|LIMIT|ORDER|GROUP|HAVING)\b/)
      const clauseEndPos = clauseEnd ? fromIdx + 6 + clauseEnd.index : text.length
      if (cursorPos <= clauseEndPos) {
        return { type: 'table', partial, wordStart }
      }
    }

    // After WHERE / other clauses: suggest table names as column qualifiers
    if (fromIdx >= 0 && cursorPos > fromIdx) {
      const afterFrom = upper.substring(fromIdx + 6)
      const whereMatch = afterFrom.match(/\b(WHERE|ORDER|GROUP|HAVING)\b/)
      if (whereMatch) {
        const clauseStartPos = fromIdx + 6 + whereMatch.index + whereMatch[0].length
        if (cursorPos > clauseStartPos && partial.length > 0) {
          return { type: 'table_ref', partial, wordStart }
        }
      }
      return null
    }

    // Between SELECT and FROM: suggest fields
    if (cursorPos <= selectIdx + 7) return null
    return { type: 'field', partial, wordStart }
  }

  const computeCursorPosition = (textarea, cursorPos) => {
    const text = textarea.value.substring(0, cursorPos)
    const lines = text.split('\n')
    const lineNumber = lines.length - 1
    const colNumber = lines[lines.length - 1].length
    const style = window.getComputedStyle(textarea)
    const lineHeight = parseFloat(style.lineHeight) || parseFloat(style.fontSize) * 1.5
    const fontSize = parseFloat(style.fontSize)
    const charWidth = fontSize * 0.6
    const paddingTop = parseFloat(style.paddingTop) || 0
    const paddingLeft = parseFloat(style.paddingLeft) || 0
    const top = paddingTop + (lineNumber + 1) * lineHeight - textarea.scrollTop
    const left = paddingLeft + colNumber * charWidth
    return { top: Math.max(0, top), left: Math.min(left, textarea.offsetWidth - 240) }
  }

  // --- Command dropdown state for "connect" / "use" ---
  const [commandDropdown, setCommandDropdown] = useState({ show: false, type: '', items: [], selectedIdx: 0 })
  const [cmdDropdownPos, setCmdDropdownPos] = useState({ top: 0, left: 0 })

  const showCommandDropdown = (type, textarea, cursorPos, extra) => {
    setCmdDropdownPos(computeCursorPosition(textarea, cursorPos))
    if (type === 'connect') {
      const items = dbConnections.map(c => ({
        id: c.id,
        name: connectionDisplayName(c),
        type: (c.dbType || 'postgres'),
        icon: c,
        isActive: c.id === dbConnectionId,
      }))
      setCommandDropdown({ show: true, type: 'connect', items, selectedIdx: 0 })
    } else if (type === 'use') {
      if (!dbConnectionId) return
      fetch(`/api/database/${dbConnectionId}/databases`)
        .then(r => r.json())
        .then(data => {
          const dbs = data.databases || []
          if (dbs.length > 0) {
            const items = dbs.map(db => ({ id: db, name: db, isActive: db === selectedDb }))
            setCommandDropdown({ show: true, type: 'use', items, selectedIdx: 0 })
          }
        })
        .catch(() => {})
    } else if (type === 'import-table') {
      if (tables.length === 0) return
      const items = tables.map(t => ({ id: t, name: t, type: 'table' }))
      setCommandDropdown({ show: true, type: 'import-table', items, selectedIdx: 0 })
    } else if (type === 'import-conn') {
      if (targetDbConnections.length === 0) return
      const items = targetDbConnections.map(c => ({
        id: c.id, name: connectionDisplayName(c), rawName: c.name, type: (c.dbType || 'postgres'), icon: c,
      }))
      setCommandDropdown({ show: true, type: 'import-conn', items, selectedIdx: 0, _importTable: extra?.table })
    } else if (type === 'import-db') {
      const connId = extra?.connId
      if (!connId) return
      fetch(`/api/database/${connId}/databases`)
        .then(r => r.json())
        .then(data => {
          const dbs = data.databases || []
          if (dbs.length > 0) {
            const items = dbs.map(db => ({ id: db, name: db }))
            setCommandDropdown({ show: true, type: 'import-db', items, selectedIdx: 0, _importTable: extra?.table, _importConnId: connId, _importConnName: extra?.connName })
          }
        })
        .catch(() => {})
    }
  }

  const selectCommandItem = (item) => {
    if (commandDropdown.type === 'connect') {
      handleConnChange(item.id)
      setSql('')
    } else if (commandDropdown.type === 'use') {
      handleDbChange(item.id)
      setSql('')
    } else if (commandDropdown.type === 'import-table') {
      setSql(`import ${item.name} to `)
      setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
      return
    } else if (commandDropdown.type === 'import-conn') {
      const table = commandDropdown._importTable || ''
      setSql(`import ${table} to ${item.rawName || item.name}.`)
      setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
      return
    } else if (commandDropdown.type === 'import-db') {
      const table = commandDropdown._importTable || ''
      const connId = commandDropdown._importConnId
      handleImportTableToDb(table, connId, item.name)
      setSql('')
    }
    setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
  }

  const handleSqlChange = (e) => {
    const newVal = e.target.value
    setSql(newVal)

    // Detect commands typed in query editor: connect, use, import
    const trimmedCmd = newVal.trim().toLowerCase()
    if (trimmedCmd === 'connect' || trimmedCmd === 'use') {
      if (textareaRef.current) showCommandDropdown(trimmedCmd, textareaRef.current, e.target.selectionStart)
      return
    }
    if (trimmedCmd === 'import') {
      if (textareaRef.current) showCommandDropdown('import-table', textareaRef.current, e.target.selectionStart)
      return
    }
    const importToMatch = newVal.trim().match(/^import\s+(\S+)\s+to\s*$/i)
    if (importToMatch) {
      if (textareaRef.current) showCommandDropdown('import-conn', textareaRef.current, e.target.selectionStart, { table: importToMatch[1] })
      return
    }
    const importDotMatch = newVal.trim().match(/^import\s+(\S+)\s+to\s+(.+)\.$/i)
    if (importDotMatch) {
      const table = importDotMatch[1]
      const connName = importDotMatch[2].trim()
      const matchedConn = targetDbConnections.find(c => c.name.toLowerCase() === connName.toLowerCase())
      if (matchedConn && textareaRef.current) {
        showCommandDropdown('import-db', textareaRef.current, e.target.selectionStart, { table, connId: matchedConn.id, connName })
      }
      return
    }
    if (commandDropdown.show) {
      setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
    }

    const cursorPos = e.target.selectionStart
    const ctx = getAutocompleteContext(newVal, cursorPos)

    if (!ctx || ctx.partial.length < 1) {
      // For table mode, show all tables even with empty partial (right after FROM)
      if (ctx && ctx.type === 'table' && ctx.partial.length === 0) {
        if (tables.length > 0) {
          const matches = tables.slice(0, 20).map(t => ({ name: t, type: 'table' }))
          if (textareaRef.current) setAcPosition(computeCursorPosition(textareaRef.current, cursorPos))
          setAutoComplete({ show: true, items: matches, selectedIdx: 0, mode: 'table' })
          return
        }
      }
      // For dotfield mode, show all fields for that table when partial is empty (right after '.')
      if (ctx && ctx.type === 'dotfield' && ctx.partial.length === 0) {
        const aliasMap = parseAliasesFromSql(newVal)
        const resolvedTable = aliasMap[ctx.tableName.toLowerCase()] || ctx.tableName
        const tbl = resolvedTable.toLowerCase()
        const tableFields = fields.filter(f => {
          if (f._objectName) return f._objectName.toLowerCase() === tbl
          return detectedTable && detectedTable.toLowerCase() === tbl
        })
        const matches = tableFields.slice(0, 20).map(f => {
          const baseName = f._objectName ? f.name.split('.').pop() : f.name
          return { name: baseName, type: f.type }
        })
        if (matches.length > 0) {
          if (textareaRef.current) setAcPosition(computeCursorPosition(textareaRef.current, cursorPos))
          setAutoComplete({ show: true, items: matches, selectedIdx: 0, mode: 'dotfield' })
          return
        }
      }
      if (autoComplete.show) setAutoComplete({ show: false, items: [], selectedIdx: 0 })
      return
    }

    const lowerPartial = ctx.partial.toLowerCase()
    let matches = []

    if (ctx.type === 'table' || ctx.type === 'table_ref') {
      matches = tables
        .filter(t => t.toLowerCase().startsWith(lowerPartial))
        .slice(0, 20)
        .map(t => ({ name: t, type: 'table' }))
    } else if (ctx.type === 'dotfield') {
      const aliasMap = parseAliasesFromSql(newVal)
      const resolvedTable = aliasMap[ctx.tableName.toLowerCase()] || ctx.tableName
      const tbl = resolvedTable.toLowerCase()
      const tableFields = fields.filter(f => {
        if (f._objectName) return f._objectName.toLowerCase() === tbl
        return detectedTable && detectedTable.toLowerCase() === tbl
      })
      matches = tableFields
        .filter(f => {
          const baseName = f._objectName ? f.name.split('.').pop() : f.name
          return baseName.toLowerCase().includes(lowerPartial)
        })
        .slice(0, 20)
        .map(f => {
          const baseName = f._objectName ? f.name.split('.').pop() : f.name
          return { name: baseName, type: f.type }
        })
    } else {
      if (fields.length === 0) {
        if (autoComplete.show) setAutoComplete({ show: false, items: [], selectedIdx: 0 })
        return
      }
      matches = fields.filter(f => f.name.toLowerCase().startsWith(lowerPartial)).slice(0, 20)
    }

    if (matches.length > 0 && !(matches.length === 1 && matches[0].name.toLowerCase() === lowerPartial)) {
      if (textareaRef.current) setAcPosition(computeCursorPosition(textareaRef.current, cursorPos))
      setAutoComplete({ show: true, items: matches, selectedIdx: 0, mode: ctx.type })
    } else {
      setAutoComplete({ show: false, items: [], selectedIdx: 0 })
    }
  }

  const insertAutoCompleteField = (fieldName) => {
    if (!textareaRef.current) return
    const textarea = textareaRef.current
    const cursorPos = textarea.selectionStart
    const ctx = getAutocompleteContext(sql, cursorPos)
    if (!ctx) return

    const before = sql.substring(0, ctx.wordStart)
    const after = sql.substring(cursorPos)
    let newSql, newPos

    // Determine if cursor is in the SELECT field list or elsewhere
    const upperSql = sql.toUpperCase()
    const fromPos = upperSql.indexOf(' FROM ')
    const inSelectClause = ctx.type === 'field' || (fromPos >= 0 && ctx.wordStart < fromPos)

    if (ctx.type === 'table_ref') {
      // In WHERE/ORDER/etc: table is a column qualifier, append dot
      newSql = before + fieldName + '.' + after
      newPos = ctx.wordStart + fieldName.length + 1
    } else if (ctx.type === 'table') {
      // In FROM clause: add a space after
      newSql = before + fieldName + ' ' + after
      newPos = ctx.wordStart + fieldName.length + 1
    } else if (inSelectClause) {
      // In SELECT clause: add comma + space after
      newSql = before + fieldName + ', ' + after
      newPos = ctx.wordStart + fieldName.length + 2
    } else {
      // In WHERE / ORDER BY / etc: just add a space after
      newSql = before + fieldName + ' ' + after
      newPos = ctx.wordStart + fieldName.length + 1
    }

    setSql(newSql)
    setAutoComplete({ show: false, items: [], selectedIdx: 0 })
    requestAnimationFrame(() => {
      textarea.focus()
      textarea.setSelectionRange(newPos, newPos)
    })
  }

  const handleKeyDown = (e) => {
    // Command dropdown keyboard navigation
    if (commandDropdown.show) {
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setCommandDropdown(prev => ({ ...prev, selectedIdx: Math.min(prev.selectedIdx + 1, prev.items.length - 1) }))
        return
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault()
        setCommandDropdown(prev => ({ ...prev, selectedIdx: Math.max(prev.selectedIdx - 1, 0) }))
        return
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        if (commandDropdown.items.length > 0) {
          e.preventDefault()
          selectCommandItem(commandDropdown.items[commandDropdown.selectedIdx])
          return
        }
      }
      if (e.key === 'Escape') {
        e.preventDefault()
        setCommandDropdown({ show: false, type: '', items: [], selectedIdx: 0 })
        return
      }
    }
    if (autoComplete.show) {
      if (e.key === 'ArrowDown') {
        e.preventDefault()
        setAutoComplete(prev => ({ ...prev, selectedIdx: Math.min(prev.selectedIdx + 1, prev.items.length - 1) }))
        return
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault()
        setAutoComplete(prev => ({ ...prev, selectedIdx: Math.max(prev.selectedIdx - 1, 0) }))
        return
      }
      if (e.key === 'Tab' || e.key === 'Enter') {
        if (autoComplete.items.length > 0) {
          e.preventDefault()
          insertAutoCompleteField(autoComplete.items[autoComplete.selectedIdx].name)
          return
        }
      }
      if (e.key === 'Escape') {
        e.preventDefault()
        setAutoComplete({ show: false, items: [], selectedIdx: 0 })
        return
      }
    }
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault()
      handleRun()
    }
  }

  const exportResultsCsv = () => {
    if (!result || !result.columns.length) return
    const header = result.columns.join(',')
    const rows = result.rows.map(row =>
      result.columns.map(col => {
        const val = row[col] ?? ''
        return val.includes(',') || val.includes('"') || val.includes('\n')
          ? `"${val.replace(/"/g, '""')}"` : val
      }).join(',')
    )
    const csv = [header, ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    const tableName = parseTableFromSql(sql) || 'sql_results'
    a.href = url; a.download = `${tableName}.csv`; a.click()
    URL.revokeObjectURL(url)
  }

  const exportResultsExcel = () => {
    if (!result || !result.columns.length) return
    const escXml = s => (s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    const tableName = parseTableFromSql(sql) || 'sql_results'
    let xml = '<?xml version="1.0"?>\n<?mso-application progid="Excel.Sheet"?>\n'
    xml += '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">\n'
    xml += `<Worksheet ss:Name="${escXml(tableName)}"><Table>\n`
    xml += '<Row>'
    result.columns.forEach(col => { xml += `<Cell><Data ss:Type="String">${escXml(col)}</Data></Cell>` })
    xml += '</Row>\n'
    result.rows.forEach(row => {
      xml += '<Row>'
      result.columns.forEach(col => {
        const val = row[col] ?? ''
        const isNum = val && !isNaN(val) && String(val).trim() !== ''
        xml += `<Cell><Data ss:Type="${isNum ? 'Number' : 'String'}">${escXml(String(val))}</Data></Cell>`
      })
      xml += '</Row>\n'
    })
    xml += '</Table></Worksheet></Workbook>'
    const blob = new Blob([xml], { type: 'application/vnd.ms-excel' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url; a.download = `${tableName}.xls`; a.click()
    URL.revokeObjectURL(url)
  }

  // Import helpers
  const fetchImportConnDatabases = (connId) => {
    if (importConnDatabases[connId]) return
    fetch(`/api/database/${connId}/databases`)
      .then(r => r.json())
      .then(data => {
        if (!data.error) setImportConnDatabases(prev => ({ ...prev, [connId]: data.databases || [] }))
      })
      .catch(() => {})
  }

  const handleExpandImportConn = (connId) => {
    if (expandedImportConn === connId) {
      setExpandedImportConn(null)
    } else {
      setExpandedImportConn(connId)
      fetchImportConnDatabases(connId)
    }
  }

  const handleCreateDatabase = (connId) => {
    const name = createDbInput.name.trim()
    if (!name) return
    setCreateDbInput(prev => ({ ...prev, loading: true, error: '' }))
    fetch(`/api/database/${connId}/create-database`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name }),
    })
      .then(r => {
        if (!r.ok) return r.text().then(t => { throw new Error(t.startsWith('<') ? `Server error (${r.status})` : JSON.parse(t).error || `Error ${r.status}`) })
        return r.json()
      })
      .then(data => {
        if (data.error) {
          setCreateDbInput(prev => ({ ...prev, loading: false, error: data.error }))
        } else {
          setCreateDbInput({ connId: null, name: '', loading: false, error: '' })
          setImportConnDatabases(prev => ({
            ...prev,
            [connId]: [...(prev[connId] || []), data.database].sort(),
          }))
        }
      })
      .catch(err => {
        setCreateDbInput(prev => ({ ...prev, loading: false, error: err.message }))
      })
  }

  const handleImportTableToDb = (tableName, targetDbId, targetDatabase) => {
    setImportTableName(tableName.toLowerCase())
    setImportSoql(`SELECT * FROM ${tableName}`)
    setImportTargetDbId(targetDbId || dbConnectionId)
    setImportTargetSelectedDb(targetDatabase || '')
    setShowImportModal(true)
  }

  const handleImportSqlToDb = (targetDbId, targetDatabase) => {
    const tbl = parseTableFromSql(sql)
    setImportTableName(tbl ? tbl.toLowerCase() : 'sql_import')
    setImportSoql(sql.trim())
    setImportTargetDbId(targetDbId || dbConnectionId)
    setImportTargetSelectedDb(targetDatabase || '')
    setShowImportModal(true)
  }

  const [tableExistsWarning, setTableExistsWarning] = useState(null)

  const handleStartImport = () => {
    const effectiveDbId = importTargetDbId || dbConnectionId
    if (!dbConnectionId || !effectiveDbId || !importTableName.trim()) return
    const dbParam = importTargetSelectedDb ? `?database=${encodeURIComponent(importTargetSelectedDb)}` : ''
    fetch(`/api/database/${effectiveDbId}/table-exists/${encodeURIComponent(importTableName.trim())}${dbParam}`)
      .then(r => r.json())
      .then(data => {
        if (data.exists) {
          setShowImportModal(false)
          setTableExistsWarning({ tableName: importTableName.trim() })
        } else {
          _doStartImport()
        }
      })
      .catch(() => _doStartImport())
  }

  const _doStartImport = () => {
    setTableExistsWarning(null)
    const effectiveDbId = importTargetDbId || dbConnectionId
    setShowImportModal(false)
    if (!dbConnectionId || !effectiveDbId) return
    const srcConn = dbConnections.find(c => c.id === dbConnectionId)
    const sourceInfo = { type: 'Database', connection: srcConn?.name || dbConnectionId, database: selectedDb || '' }
    setImportJob({ status: 'starting', progress: 0, message: 'Starting SQL import...' })
    fetch('/api/import-sql', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sourceDbConnectionId: dbConnectionId,
        targetDbConnectionId: effectiveDbId,
        sql: importSoql,
        tableName: importTableName,
        sourceDatabase: selectedDb,
        targetDatabase: importTargetSelectedDb,
        sourceInfo,
      }),
    })
      .then(r => r.json())
      .then(({ jobId }) => {
        importPollRef.current = setInterval(() => {
          fetch(`/api/import-sql/${jobId}/status`).then(r => r.json()).then(s => {
            setImportJob(s)
            if (!s.running) { clearInterval(importPollRef.current); importPollRef.current = null }
          }).catch(() => {})
        }, 1000)
      })
      .catch(err => setImportJob({ status: 'error', progress: 0, message: err.message }))
  }

  // Connection selector
  const [selectedConnId, setSelectedConnId] = useState(activeDbId || '')

  useEffect(() => {
    if (activeDbId) setSelectedConnId(activeDbId)
  }, [activeDbId])

  const handleConnChange = (id) => {
    setSelectedConnId(id)
    onSetActiveDbId && onSetActiveDbId(id)
  }

  const selectedConn = dbConnections.find(c => c.id === selectedConnId)

  const dbSelector = (
    <div style={{ padding: '8px 8px 6px', borderBottom: '1px solid #e5e7eb' }}>
      <div style={{ fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 4 }}>Connections</div>
      <div style={{ display: 'flex', gap: 4, alignItems: 'center' }}>
        <ConnectionSelect
          connections={dbConnections}
          value={selectedConnId}
          onChange={handleConnChange}
          placeholder="Select connection..."
        />
        {onOpenModal && (
          <button className="btn-inline-add" style={{ width: 24, height: 24, fontSize: 13 }} onClick={onOpenModal} title="Add connection">+</button>
        )}
        {selectedConn && onEditConn && (
          <button className="btn-inline-edit" style={{ width: 24, height: 24, fontSize: 12 }} onClick={() => onEditConn(selectedConn)} title="Edit connection">&#9998;</button>
        )}
      </div>
    </div>
  )

  if (!dbConnectionId) {
    return (
      <div className="work-area" style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <div style={{ width: 260, background: '#fafbfc', borderRight: '1px solid #e5e7eb', display: 'flex', flexDirection: 'column' }}>
          {dbSelector}
          <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>
            Select a database connection to load tables
          </div>
        </div>
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 13 }}>
          Select a database connection to begin
        </div>
      </div>
    )
  }

  const handleDbChange = (db) => {
    setSelectedDb(db)
    setDetectedTable(null)
    setResult(null)
    setError(null)
  }

  // Search-filtered rows
  const searchFilteredRows = (() => {
    if (!result?.rows) return []
    if (!resultSearch.trim()) return result.rows
    const term = resultSearch.toLowerCase()
    return result.rows.filter(row =>
      result.columns.some(col => String(row[col] ?? '').toLowerCase().includes(term))
    )
  })()

  // Detect complex/long-text columns from field metadata (DB types)
  const expandableDbTypes = new Set(['text', 'longtext', 'mediumtext', 'tinytext', 'clob', 'nclob', 'ntext', 'blob', 'mediumblob', 'longblob', 'json', 'jsonb', 'xml'])
  const expandableColumns = new Set(
    fields.filter(f => expandableDbTypes.has((f.type || '').toLowerCase())).map(f => f.name)
  )

  // Pagination (over filtered rows)
  const totalRows = searchFilteredRows.length
  const totalPages = Math.max(1, Math.ceil(totalRows / pageSize))
  const startIdx = (page - 1) * pageSize
  const endIdx = Math.min(startIdx + pageSize, totalRows)
  const visibleRows = searchFilteredRows.slice(startIdx, endIdx)

  // Import popover renderer (shared between toolbar and results)
  const renderImportPopover = (show, setShow, onSelect) => show && (
    <>
      <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99 }} onClick={() => { setShow(false); setExpandedImportConn(null) }} />
      <div className="export-db-popover">
        <div style={{ padding: '6px 10px', fontSize: 10, fontWeight: 600, color: '#6b7280', borderBottom: '1px solid #f3f4f6' }}>Import to Database</div>
        {targetDbConnections.map(c => {
          const dbs = importConnDatabases[c.id] || []
          const isExpanded = expandedImportConn === c.id
          return (
            <div key={c.id}>
              <div
                className="export-db-item"
                onClick={() => {
                  if (dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) {
                    handleExpandImportConn(c.id)
                  } else {
                    setShow(false); setExpandedImportConn(null)
                    onSelect(c.id, dbs[0] || '')
                  }
                }}
              >
                {getConnectionIcon(c)}
                <span style={{ flex: 1 }}>{connectionDisplayName(c)}</span>
                {(dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) && (
                  <span style={{ fontSize: 9, color: '#9ca3af' }}>{isExpanded ? '\u25B4' : '\u25BE'}</span>
                )}
              </div>
              {isExpanded && (
                <>
                  {dbs.length > 0 && dbs.map(db => (
                    <div
                      key={db}
                      className="export-db-item"
                      style={{ paddingLeft: 28, fontSize: 11 }}
                      onClick={() => { setShow(false); setExpandedImportConn(null); onSelect(c.id, db) }}
                    >
                      <DbIcon size={12} color="#6366f1" />
                      <span>{db}</span>
                    </div>
                  ))}
                  {createDbInput.connId === c.id ? (
                    <div style={{ paddingLeft: 28, padding: '4px 8px 4px 28px', display: 'flex', alignItems: 'center', gap: 4 }}>
                      <input
                        autoFocus
                        value={createDbInput.name}
                        onChange={e => setCreateDbInput(prev => ({ ...prev, name: e.target.value, error: '' }))}
                        onKeyDown={e => { if (e.key === 'Enter') handleCreateDatabase(c.id); if (e.key === 'Escape') setCreateDbInput({ connId: null, name: '', loading: false, error: '' }) }}
                        onClick={e => e.stopPropagation()}
                        placeholder="Database name"
                        style={{ fontSize: 11, padding: '2px 6px', border: '1px solid #d1d5db', borderRadius: 4, width: 120, outline: 'none' }}
                        disabled={createDbInput.loading}
                      />
                      <button onClick={(e) => { e.stopPropagation(); handleCreateDatabase(c.id) }} disabled={createDbInput.loading || !createDbInput.name.trim()} style={{ fontSize: 10, padding: '2px 6px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
                        {createDbInput.loading ? '...' : 'Create'}
                      </button>
                      {createDbInput.error && <span style={{ fontSize: 9, color: '#dc2626' }}>{createDbInput.error}</span>}
                    </div>
                  ) : (
                    <div
                      className="export-db-item"
                      style={{ paddingLeft: 28, fontSize: 11, color: '#2563eb' }}
                      onClick={(e) => { e.stopPropagation(); setCreateDbInput({ connId: c.id, name: '', loading: false, error: '' }) }}
                    >
                      <span style={{ fontSize: 13, lineHeight: 1 }}>+</span>
                      <span>Create database</span>
                    </div>
                  )}
                </>
              )}
            </div>
          )
        })}
      </div>
    </>
  )

  // Sidebar
  const sidebar = (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#fafbfc' }}>
      {dbSelector}
      {databases.length > 0 && (
        <div style={{ padding: '6px 8px', borderBottom: '1px solid #e5e7eb' }}>
          <div style={{ fontSize: 11, fontWeight: 600, color: '#374151', marginBottom: 4 }}>Database</div>
          <DatabaseSelect
            databases={databases}
            value={selectedDb}
            onChange={handleDbChange}
          />
        </div>
      )}
      <div style={{ padding: '6px 8px', borderBottom: '1px solid #e5e7eb', display: 'flex', gap: 4, alignItems: 'center' }}>
        <input className="soql-search-input" placeholder="Search tables..." value={tableSearch} onChange={e => setTableSearch(e.target.value)} style={{ flex: 1 }} />
        <button
          onClick={refreshTables}
          title="Refresh table list"
          style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', padding: '2px 4px', fontSize: 14, lineHeight: 1, flexShrink: 0 }}
          onMouseEnter={e => e.target.style.color = '#6366f1'}
          onMouseLeave={e => e.target.style.color = '#9ca3af'}
        >&#8635;</button>
      </div>
      <div style={{ flex: 1, overflow: 'auto' }}>
        {databases.length > 1 && !selectedDb ? (
          <div style={{ padding: 12, fontSize: 11, color: '#9ca3af' }}>Select a database above</div>
        ) : filteredTables.length === 0 ? (
          <div style={{ padding: 12, fontSize: 11, color: '#d1d5db' }}>No tables found</div>
        ) : (
          filteredTables.map(t => {
            let sourceLabel = null
            try {
              const meta = tableComments[t] ? JSON.parse(tableComments[t]) : null
              if (meta?.type) sourceLabel = meta.type === 'Salesforce' ? `SF: ${meta.connection}` : meta.type === 'CSV' ? `CSV: ${meta.file}` : `DB: ${meta.connection}`
            } catch {}
            return (
            <div key={t} className={`soql-item ${detectedTables.includes(t) ? 'soql-item-active' : ''}`}>
              <div style={{ flex: 1, overflow: 'hidden' }} onClick={() => handleSelectTable(t)} title={sourceLabel ? `Source: ${sourceLabel}` : `${t} — click to generate SELECT query`}>
                <span className="soql-item-name">{t}</span>
                {sourceLabel && <span style={{ display: 'block', fontSize: 9, color: '#9ca3af', lineHeight: 1.2, marginTop: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{sourceLabel}</span>}
              </div>
              {targetDbConnections.length > 0 && (
                <button
                  className="sidebar-import-btn"
                  onClick={e => {
                    e.stopPropagation()
                    const rect = e.currentTarget.getBoundingClientRect()
                    setSidebarImportPos({ top: rect.bottom + 2, left: rect.left })
                    setSidebarImportItem(sidebarImportItem === t ? null : t)
                    setExpandedImportConn(null)
                  }}
                  title="Import to database"
                >
                  <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M6 2v6M3.5 5.5L6 8l2.5-2.5" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 9.5h8" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round"/></svg>
                </button>
              )}
            </div>
          )})
        )}
      </div>

      {/* Sidebar import popover (fixed positioned) */}
      {sidebarImportItem && (
        <>
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, zIndex: 99 }} onClick={() => { setSidebarImportItem(null); setExpandedImportConn(null) }} />
          <div className="export-db-popover" style={{ position: 'fixed', top: sidebarImportPos.top, left: sidebarImportPos.left, zIndex: 100 }}>
            <div style={{ padding: '6px 10px', fontSize: 10, fontWeight: 600, color: '#6b7280', borderBottom: '1px solid #f3f4f6' }}>Import to Database</div>
            {targetDbConnections.map(c => {
              const dbs = importConnDatabases[c.id] || []
              const isExpanded = expandedImportConn === c.id
              return (
                <div key={c.id}>
                  <div
                    className="export-db-item"
                    onClick={() => {
                      if (dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) {
                        handleExpandImportConn(c.id)
                      } else {
                        setSidebarImportItem(null); setExpandedImportConn(null)
                        handleImportTableToDb(sidebarImportItem, c.id, dbs[0] || '')
                      }
                    }}
                  >
                    {getConnectionIcon(c)}
                    <span style={{ flex: 1 }}>{connectionDisplayName(c)}</span>
                    {(dbs.length > 1 || (!dbs.length && !importConnDatabases[c.id])) && (
                      <span style={{ fontSize: 9, color: '#9ca3af' }}>{isExpanded ? '\u25B4' : '\u25BE'}</span>
                    )}
                  </div>
                  {isExpanded && (
                    <>
                      {dbs.length > 0 && dbs.map(db => (
                        <div
                          key={db}
                          className="export-db-item"
                          style={{ paddingLeft: 28, fontSize: 11 }}
                          onClick={() => { setSidebarImportItem(null); setExpandedImportConn(null); handleImportTableToDb(sidebarImportItem, c.id, db) }}
                        >
                          <DbIcon size={12} color="#6366f1" />
                          <span>{db}</span>
                        </div>
                      ))}
                      {createDbInput.connId === c.id ? (
                        <div style={{ paddingLeft: 28, padding: '4px 8px 4px 28px', display: 'flex', alignItems: 'center', gap: 4 }}>
                          <input
                            autoFocus
                            value={createDbInput.name}
                            onChange={e => setCreateDbInput(prev => ({ ...prev, name: e.target.value, error: '' }))}
                            onKeyDown={e => { if (e.key === 'Enter') handleCreateDatabase(c.id); if (e.key === 'Escape') setCreateDbInput({ connId: null, name: '', loading: false, error: '' }) }}
                            onClick={e => e.stopPropagation()}
                            placeholder="Database name"
                            style={{ fontSize: 11, padding: '2px 6px', border: '1px solid #d1d5db', borderRadius: 4, width: 120, outline: 'none' }}
                            disabled={createDbInput.loading}
                          />
                          <button onClick={(e) => { e.stopPropagation(); handleCreateDatabase(c.id) }} disabled={createDbInput.loading || !createDbInput.name.trim()} style={{ fontSize: 10, padding: '2px 6px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer' }}>
                            {createDbInput.loading ? '...' : 'Create'}
                          </button>
                          {createDbInput.error && <span style={{ fontSize: 9, color: '#dc2626' }}>{createDbInput.error}</span>}
                        </div>
                      ) : (
                        <div
                          className="export-db-item"
                          style={{ paddingLeft: 28, fontSize: 11, color: '#2563eb' }}
                          onClick={(e) => { e.stopPropagation(); setCreateDbInput({ connId: c.id, name: '', loading: false, error: '' }) }}
                        >
                          <span style={{ fontSize: 13, lineHeight: 1 }}>+</span>
                          <span>Create database</span>
                        </div>
                      )}
                    </>
                  )}
                </div>
              )
            })}
          </div>
        </>
      )}
    </div>
  )

  // Pagination controls
  const paginationBar = totalRows > 0 ? (
    <div style={{ padding: '4px 8px', borderTop: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0, background: '#f9fafb', fontSize: 11, color: '#6b7280' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <span>Rows per page:</span>
        <select value={pageSize} onChange={e => { setPageSize(Number(e.target.value)); setPage(1) }} style={{ border: '1px solid #d1d5db', borderRadius: 4, padding: '1px 4px', fontSize: 11, background: 'white' }}>
          {[25, 50, 100, 250, 500].map(n => <option key={n} value={n}>{n}</option>)}
        </select>
      </div>
      <span>{startIdx + 1}–{endIdx} of {totalRows} records</span>
      <div style={{ display: 'flex', gap: 4 }}>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page <= 1} onClick={() => setPage(1)}>First</button>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page <= 1} onClick={() => setPage(p => p - 1)}>Prev</button>
        <span style={{ padding: '2px 6px', fontSize: 11 }}>Page {page} / {totalPages}</span>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page >= totalPages} onClick={() => setPage(p => p + 1)}>Next</button>
        <button className="btn btn-secondary" style={{ padding: '1px 8px', fontSize: 10 }} disabled={page >= totalPages} onClick={() => setPage(totalPages)}>Last</button>
      </div>
    </div>
  ) : null

  const editorAndResults = (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <ResizablePanelV
        storageKey="sql-editor-height"
        initialTopHeight={180}
        minTop={100}
        minBottom={80}
        top={
          <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
            {/* Query tabs */}
            <div style={{ display: 'flex', alignItems: 'center', borderBottom: '1px solid #e5e7eb', background: '#f9fafb', flexShrink: 0, overflow: 'auto' }}>
              {queryTabs.map(tab => (
                <div
                  key={tab.id}
                  onClick={() => setActiveQueryTabId(tab.id)}
                  style={{
                    padding: '4px 12px', fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6,
                    borderRight: '1px solid #e5e7eb', whiteSpace: 'nowrap', flexShrink: 0,
                    background: tab.id === activeQueryTabId ? 'white' : 'transparent',
                    color: tab.id === activeQueryTabId ? '#1f2937' : '#9ca3af',
                    fontWeight: tab.id === activeQueryTabId ? 600 : 400,
                    borderBottom: tab.id === activeQueryTabId ? '2px solid #3b82f6' : '2px solid transparent',
                  }}
                >
                  <span>{tab.name}</span>
                  {tab.result && <span style={{ fontSize: 9, color: '#10b981' }}>&#9679;</span>}
                  {queryTabs.length > 1 && (
                    <span
                      onClick={e => { e.stopPropagation(); closeQueryTab(tab.id) }}
                      style={{ fontSize: 13, color: '#d1d5db', cursor: 'pointer', lineHeight: 1 }}
                      title="Close tab"
                    >&times;</span>
                  )}
                </div>
              ))}
              <button
                onClick={addQueryTab}
                style={{
                  padding: '4px 10px', fontSize: 14, cursor: 'pointer', background: 'none', border: 'none',
                  color: '#9ca3af', fontWeight: 600, flexShrink: 0,
                }}
                title="New query tab"
              >+</button>
            </div>

            {/* Toolbar */}
            <div style={{ padding: '4px 8px', display: 'flex', alignItems: 'center', borderBottom: '1px solid #e5e7eb', gap: 6 }}>
              <button className="btn btn-primary" style={{ padding: '3px 12px', fontSize: 12, flexShrink: 0 }} onClick={handleRun} disabled={running || !sql.trim()}>
                {running ? 'Running...' : 'Run'}
              </button>
              <button
                data-tour="ai-button"
                onClick={() => { setShowAiPanel(prev => !prev); setAiError(''); }}
                style={{
                  padding: '3px 10px', fontSize: 12, flexShrink: 0, cursor: 'pointer',
                  background: showAiPanel ? '#7c3aed' : '#f3f0ff', color: showAiPanel ? '#fff' : '#7c3aed',
                  border: '1px solid ' + (showAiPanel ? '#7c3aed' : '#c4b5fd'), borderRadius: 4,
                  fontWeight: 600, display: 'flex', alignItems: 'center', gap: 4,
                }}
                title="AI SQL Assistant"
              >
                <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5">
                  <path d="M8 1v3M8 12v3M1 8h3M12 8h3M3.05 3.05l2.12 2.12M10.83 10.83l2.12 2.12M3.05 12.95l2.12-2.12M10.83 5.17l2.12-2.12"/>
                </svg>
                AI
              </button>
              <button
                onClick={() => { setSaveScriptName(''); setShowSaveScriptModal(true) }}
                disabled={!sql.trim()}
                style={{ background: 'none', border: 'none', cursor: sql.trim() ? 'pointer' : 'default', fontSize: 11, color: sql.trim() ? '#059669' : '#d1d5db', padding: '2px 6px', flexShrink: 0, fontWeight: 500 }}
                title="Save current query as a script"
              >
                Save Script
              </button>
              <button
                onClick={() => setShowScriptsModal(true)}
                style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 11, color: '#6b7280', padding: '2px 6px', flexShrink: 0, textDecoration: 'underline' }}
                title="Saved Scripts"
              >
                Scripts{savedScripts.length > 0 ? ` (${savedScripts.length})` : ''}
              </button>
              {history.length > 0 && (
                <button
                  onClick={() => setShowHistory(true)}
                  style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 11, color: '#6b7280', padding: '2px 6px', flexShrink: 0, textDecoration: 'underline' }}
                  title="Query History"
                >
                  History ({history.length})
                </button>
              )}
              <span style={{ fontSize: 11, color: '#9ca3af', whiteSpace: 'nowrap' }}>
                {detectedTables.length > 0 && (
                  <span style={{ fontWeight: 500 }}>
                    {detectedTables.map((name, idx) => (
                      <React.Fragment key={name}>
                        {idx > 0 && <span style={{ color: '#9ca3af' }}>, </span>}
                        <span
                          style={{ color: '#2563eb', cursor: 'pointer', textDecoration: 'underline', textDecorationStyle: 'dotted', textUnderlineOffset: 2 }}
                          onClick={() => { setBottomTab('fields'); setFieldsObjectFilter(detectedTables.length > 1 ? name : '') }}
                          title={`View ${name} fields`}
                        >{name}</span>
                      </React.Fragment>
                    ))}
                  </span>
                )}
              </span>
              <div style={{ display: 'flex', gap: 4, alignItems: 'center', flexShrink: 0, marginLeft: 'auto' }}>
                {detectedTable && targetDbConnections.length > 0 && (
                  <div style={{ display: 'flex', gap: 3, alignItems: 'center' }}>
                    <span style={{ fontSize: 10, color: '#6b7280', whiteSpace: 'nowrap', marginRight: 2 }}>Import:</span>
                    <div style={{ position: 'relative' }}>
                      <button
                        className="export-icon-btn export-icon-db"
                        onClick={() => setShowDbPopover(prev => !prev)}
                        disabled={targetDbConnections.length === 0}
                        title="Import all table data to another database"
                      >
                        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><ellipse cx="8" cy="4" rx="6" ry="2.5" stroke="currentColor" strokeWidth="1.2"/><path d="M2 4v8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5V4" stroke="currentColor" strokeWidth="1.2"/><path d="M2 8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5" stroke="currentColor" strokeWidth="1.2"/></svg>
                      </button>
                      {renderImportPopover(showDbPopover, setShowDbPopover, (connId, db) => handleImportTableToDb(detectedTable, connId, db))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* AI Assistant Panel */}
            {showAiPanel && (
              <div style={{
                borderBottom: '1px solid #e5e7eb', padding: '8px 10px', background: '#faf8ff',
                display: 'flex', flexDirection: 'column', gap: 6,
              }}>
                <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                  <input
                    type="text"
                    value={aiPrompt}
                    onChange={e => setAiPrompt(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleAiGenerate() } }}
                    placeholder="Ask about your data... (e.g. 'show all customers with orders > $100')"
                    style={{
                      flex: 1, padding: '6px 10px', fontSize: 12, border: '1px solid #c4b5fd',
                      borderRadius: 4, outline: 'none', background: '#fff',
                    }}
                    disabled={aiLoading}
                  />
                  <button
                    onClick={handleAiGenerate}
                    disabled={aiLoading || !aiPrompt.trim()}
                    style={{
                      padding: '6px 14px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                      background: '#7c3aed', color: '#fff', border: 'none', borderRadius: 4,
                      opacity: (aiLoading || !aiPrompt.trim()) ? 0.5 : 1,
                    }}
                  >
                    {aiLoading ? 'Generating...' : 'Generate'}
                  </button>
                  <button
                    onClick={() => { setShowAiPanel(false); setAiResult(null); setAiError(''); setAiPrompt('') }}
                    style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 16, color: '#9ca3af', padding: '0 4px', lineHeight: 1 }}
                    title="Close AI panel"
                  >&times;</button>
                </div>
                {aiError && (
                  <div style={{ fontSize: 12, color: '#dc2626', background: '#fef2f2', padding: '6px 10px', borderRadius: 4 }}>
                    {aiError}
                  </div>
                )}
                {aiLoading && (
                  <div style={{ fontSize: 12, color: '#7c3aed', padding: '4px 0' }}>
                    <span style={{ display: 'inline-block', animation: 'spin 1s linear infinite', marginRight: 6 }}>&#9696;</span>
                    Thinking...
                  </div>
                )}
                {aiResult && (
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                    <pre style={{
                      background: '#1e1b2e', color: '#e2e8f0', padding: '8px 10px', borderRadius: 4,
                      fontSize: 12, fontFamily: 'SF Mono, Fira Code, monospace', overflow: 'auto',
                      maxHeight: 120, margin: 0, whiteSpace: 'pre-wrap',
                    }}>{aiResult.sql}</pre>
                    {aiResult.explanation && (
                      <div style={{ fontSize: 11, color: '#6b7280', fontStyle: 'italic' }}>
                        {aiResult.explanation}
                      </div>
                    )}
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button
                        onClick={() => { setSql(aiResult.sql); setShowAiPanel(false); setAiResult(null); setAiPrompt('') }}
                        style={{
                          padding: '4px 12px', fontSize: 12, fontWeight: 600, cursor: 'pointer',
                          background: '#10b981', color: '#fff', border: 'none', borderRadius: 4,
                        }}
                      >Use Query</button>
                      <button
                        onClick={() => { setSql(prev => prev ? prev + '\n' + aiResult.sql : aiResult.sql) }}
                        style={{
                          padding: '4px 12px', fontSize: 12, cursor: 'pointer',
                          background: '#fff', color: '#374151', border: '1px solid #d1d5db', borderRadius: 4,
                        }}
                      >Append</button>
                    </div>
                  </div>
                )}
                {!tables.length && !aiResult && !aiError && !aiLoading && (
                  <div style={{ fontSize: 11, color: '#9ca3af' }}>
                    Select a database first to get schema-aware SQL suggestions.
                  </div>
                )}
              </div>
            )}

            {/* Query textarea with line numbers */}
            <div style={{ flex: 1, minHeight: 0, position: 'relative', display: 'flex' }}>
              <div
                ref={lineNumberRef}
                style={{
                  width: 40, minWidth: 40, background: '#f0f1f3', borderRight: '1px solid #e5e7eb',
                  fontFamily: "'SF Mono', 'Fira Code', 'Cascadia Code', monospace",
                  fontSize: 'var(--editor-font-size, 13px)', lineHeight: 1.5, padding: '12px 0',
                  color: '#9ca3af', textAlign: 'right', userSelect: 'none', overflow: 'hidden',
                  whiteSpace: 'pre-wrap', boxSizing: 'border-box',
                }}
              >
                {sql.split('\n').map((_, i) => (
                  <div key={i} style={{ paddingRight: 8 }}>{i + 1}</div>
                ))}
              </div>
              <div style={{ flex: 1, position: 'relative', minWidth: 0 }}>
                <textarea
                  ref={textareaRef}
                  className="sql-editor"
                  style={{ width: '100%', height: '100%', minHeight: 0 }}
                  value={sql}
                  onChange={handleSqlChange}
                  onKeyDown={handleKeyDown}
                  onScroll={e => { if (lineNumberRef.current) lineNumberRef.current.scrollTop = e.target.scrollTop }}
                  onBlur={() => { setTimeout(() => { setAutoComplete(prev => ({ ...prev, show: false })); setCommandDropdown(prev => ({ ...prev, show: false })) }, 150) }}
                  placeholder="Enter SQL query..."
                  spellCheck={false}
                />
                {autoComplete.show && autoComplete.items.length > 0 && (
                  <div className="autocomplete-popup" style={{ top: acPosition.top, left: acPosition.left }}>
                    {autoComplete.items.slice(0, 8).map((f, i) => (
                      <div
                        key={f.name}
                        className={`autocomplete-item ${i === autoComplete.selectedIdx ? 'autocomplete-item-active' : ''}`}
                        onMouseDown={e => { e.preventDefault(); insertAutoCompleteField(f.name) }}
                        onMouseEnter={() => setAutoComplete(prev => ({ ...prev, selectedIdx: i }))}
                      >
                        <span className="autocomplete-field-name">{f.name}</span>
                        <span className="autocomplete-field-type">{f.type}</span>
                      </div>
                    ))}
                  </div>
                )}
                {commandDropdown.show && commandDropdown.items.length > 0 && (
                  <div className="autocomplete-popup" style={{ top: cmdDropdownPos.top, left: cmdDropdownPos.left, minWidth: 280 }}>
                    <div style={{ padding: '4px 10px', fontSize: 10, fontWeight: 600, color: '#9ca3af', textTransform: 'uppercase', letterSpacing: 0.5 }}>
                      {{ connect: 'Select Connection', use: 'Select Database', 'import-table': 'Select Table to Import', 'import-conn': 'Import To Connection', 'import-db': 'Select Database' }[commandDropdown.type] || 'Select'}
                    </div>
                    {commandDropdown.items.map((item, i) => (
                      <div
                        key={item.id}
                        className={`autocomplete-item ${i === commandDropdown.selectedIdx ? 'autocomplete-item-active' : ''}`}
                        onMouseDown={e => { e.preventDefault(); selectCommandItem(item) }}
                        onMouseEnter={() => setCommandDropdown(prev => ({ ...prev, selectedIdx: i }))}
                        style={{ display: 'flex', alignItems: 'center', gap: 8 }}
                      >
                        {(commandDropdown.type === 'connect' || commandDropdown.type === 'import-conn') ? (
                          <>
                            <span style={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
                              {item.isActive ? <span style={{ color: '#22c55e', fontWeight: 700, fontSize: 14 }}>&#10003;</span> : getConnectionIcon(item.icon)}
                            </span>
                            <span className="autocomplete-field-name" style={{ flex: 1 }}>{item.name}</span>
                            <span className="autocomplete-field-type">{item.type}</span>
                          </>
                        ) : (commandDropdown.type === 'use' || commandDropdown.type === 'import-db') ? (
                          <>
                            <span style={{ flexShrink: 0, display: 'flex', alignItems: 'center' }}>
                              {item.isActive ? <span style={{ color: '#22c55e', fontWeight: 700, fontSize: 14 }}>&#10003;</span> : <DbIcon size={14} color="#6366f1" />}
                            </span>
                            <span className="autocomplete-field-name" style={{ flex: 1 }}>{item.name}</span>
                          </>
                        ) : (
                          <span className="autocomplete-field-name" style={{ flex: 1 }}>{item.name}</span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        }
        bottom={
          <div style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden' }}>
            {/* Tabs: Fields / Results */}
            <div style={{ display: 'flex', borderBottom: '2px solid #e5e7eb', flexShrink: 0, background: '#fafbfc' }}>
              <button
                onClick={() => setBottomTab('fields')}
                style={{
                  padding: '5px 16px', fontSize: 11, fontWeight: 600, cursor: 'pointer', border: 'none', background: 'none',
                  color: bottomTab === 'fields' ? '#3b82f6' : '#9ca3af',
                  borderBottom: bottomTab === 'fields' ? '2px solid #3b82f6' : '2px solid transparent',
                  marginBottom: -2,
                }}
              >
                Fields {detectedTable && fields.length > 0 ? `(${fields.length})` : ''}
              </button>
              <button
                onClick={() => setBottomTab('results')}
                style={{
                  padding: '5px 16px', fontSize: 11, fontWeight: 600, cursor: 'pointer', border: 'none', background: 'none',
                  color: bottomTab === 'results' ? '#3b82f6' : '#9ca3af',
                  borderBottom: bottomTab === 'results' ? '2px solid #3b82f6' : '2px solid transparent',
                  marginBottom: -2,
                }}
              >
                Results {result ? `(${result.rowCount})` : ''}
              </button>
            </div>

            {/* Fields tab */}
            {bottomTab === 'fields' && (
              detectedTable && (fieldsLoading || fields.length > 0) ? (
                <div style={{ flex: 1, overflow: 'auto', padding: 12 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, gap: 8 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexShrink: 0 }}>
                      {detectedTables.length > 1 ? (
                        <>
                          <button
                            onClick={() => setFieldsObjectFilter('')}
                            style={{
                              padding: '2px 8px', fontSize: 11, fontWeight: 600, border: '1px solid', borderRadius: 12, cursor: 'pointer',
                              background: !fieldsObjectFilter ? '#2563eb' : '#fff',
                              color: !fieldsObjectFilter ? '#fff' : '#6b7280',
                              borderColor: !fieldsObjectFilter ? '#2563eb' : '#d1d5db',
                            }}
                          >All ({fields.length})</button>
                          {detectedTables.map(name => {
                            const count = fields.filter(f => f._objectName === name).length
                            const active = fieldsObjectFilter === name
                            return (
                              <button
                                key={name}
                                onClick={() => setFieldsObjectFilter(active ? '' : name)}
                                style={{
                                  padding: '2px 8px', fontSize: 11, fontWeight: 600, border: '1px solid', borderRadius: 12, cursor: 'pointer',
                                  background: active ? '#2563eb' : '#fff',
                                  color: active ? '#fff' : '#374151',
                                  borderColor: active ? '#2563eb' : '#d1d5db',
                                }}
                              >{name} ({count})</button>
                            )
                          })}
                        </>
                      ) : (
                        <div style={{ fontSize: 12, fontWeight: 600, color: '#374151' }}>
                          {detectedTables.join(', ')} <span style={{ fontWeight: 400, color: '#9ca3af' }}>({fields.length} columns)</span>
                        </div>
                      )}
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
                      {fields.length > 0 && (
                        <a href="#" className="field-link-action" onClick={e => { e.preventDefault(); handleSelectAllFields() }}>SELECT *</a>
                      )}
                      <div style={{ width: 200 }}>
                        <input
                          className="soql-search-input"
                          placeholder="Search fields..."
                          value={fieldSearch}
                          onChange={e => setFieldSearch(e.target.value)}
                          style={{ fontSize: 11, padding: '3px 8px', width: '100%' }}
                        />
                      </div>
                    </div>
                  </div>
                  {fieldsLoading ? (
                    <div style={{ padding: 20, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>Loading fields...</div>
                  ) : (
                    <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                      <thead>
                        <tr style={{ borderBottom: '2px solid #e5e7eb' }}>
                          <th style={{ textAlign: 'left', padding: '4px 8px', color: '#6b7280', fontWeight: 600, width: 40 }}>#</th>
                          <th style={{ textAlign: 'left', padding: '4px 8px', color: '#6b7280', fontWeight: 600 }}>Column</th>
                          <th style={{ textAlign: 'left', padding: '4px 8px', color: '#6b7280', fontWeight: 600, width: 140 }}>Type</th>
                        </tr>
                      </thead>
                      <tbody>
                        {(() => {
                          let counter = 0
                          let lastObj = null
                          return filteredFields.map((f) => {
                            counter++
                            const showHeader = detectedTables.length > 1 && f._objectName && f._objectName !== lastObj
                            lastObj = f._objectName || lastObj
                            const objFieldCount = showHeader ? fields.filter(x => x._objectName === f._objectName).length : 0
                            return (
                              <React.Fragment key={f.name}>
                                {showHeader && (
                                  <tr style={{ background: '#f0f4ff', borderBottom: '1px solid #e5e7eb' }}>
                                    <td colSpan={3} style={{ padding: '4px 8px', fontSize: 11, fontWeight: 600, color: '#2563eb' }}>
                                      {f._objectName} <span style={{ fontWeight: 400, color: '#9ca3af' }}>({objFieldCount} columns)</span>
                                    </td>
                                  </tr>
                                )}
                                <tr style={{ borderBottom: '1px solid #f3f4f6' }} className="field-row-hover">
                                  <td style={{ padding: '3px 8px', color: '#9ca3af', fontSize: 11 }}>{counter}</td>
                                  <td style={{ padding: '3px 8px', color: '#1e40af', cursor: 'pointer' }} onClick={() => handleFieldClick(f.name)} title="Click to add to query">
                                    <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: 2, background: fieldTypeColor(f.type), marginRight: 6, verticalAlign: 'middle' }} />
                                    {f.name}
                                  </td>
                                  <td style={{ padding: '3px 8px', color: '#9ca3af' }}>{f.type}</td>
                                </tr>
                              </React.Fragment>
                            )
                          })
                        })()}
                      </tbody>
                    </table>
                  )}
                </div>
              ) : (
                <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 12 }}>
                  Select a table to see its columns
                </div>
              )
            )}

            {/* Results tab */}
            {bottomTab === 'results' && (
              <>
                {error && <div className="test-result test-error" style={{ margin: 8 }}>{error}</div>}
                {result && result.message && <div className="test-result test-success" style={{ margin: 8 }}>{result.message}</div>}
                {result && result.columns && result.columns.length > 0 && (
                  <>
                    <div style={{ padding: '4px 8px', fontSize: 11, color: '#6b7280', borderBottom: '1px solid #e5e7eb', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
                      <span>
                        {result.rowCount} record{result.rowCount !== 1 ? 's' : ''} &middot; {result.elapsed}s &middot; {result.columns.length} columns
                        {resultSearch && totalRows !== result.rows.length && (
                          <span style={{ color: '#f59e0b', marginLeft: 6 }}>({totalRows} matched)</span>
                        )}
                      </span>
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
                          <svg width="13" height="13" viewBox="0 0 16 16" fill="none" style={{ position: 'absolute', left: 6, pointerEvents: 'none' }}>
                            <circle cx="6.5" cy="6.5" r="5" stroke="#9ca3af" strokeWidth="1.3"/><path d="M10.5 10.5L14 14" stroke="#9ca3af" strokeWidth="1.3" strokeLinecap="round"/>
                          </svg>
                          <input
                            className="soql-search-input"
                            placeholder="Search results..."
                            value={resultSearch}
                            onChange={e => { setResultSearch(e.target.value); setPage(1) }}
                            style={{ fontSize: 11, padding: '2px 8px 2px 22px', width: 160 }}
                          />
                          {resultSearch && (
                            <button
                              onClick={() => { setResultSearch(''); setPage(1) }}
                              style={{ position: 'absolute', right: 4, background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 13, lineHeight: 1, padding: 0 }}
                              title="Clear search"
                            >&times;</button>
                          )}
                        </div>
                        <span style={{ fontSize: 10, color: '#9ca3af', marginRight: 2 }}>Export ({totalRows}):</span>
                        <button
                          className="export-icon-btn"
                          onClick={exportResultsCsv}
                          title="Export results as CSV"
                        >
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.2"/><text x="8" y="11" textAnchor="middle" fontSize="6" fontWeight="700" fill="currentColor">CSV</text></svg>
                        </button>
                        <button
                          className="export-icon-btn export-icon-excel"
                          onClick={exportResultsExcel}
                          title="Export results as Excel"
                        >
                          <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="1" y="1" width="14" height="14" rx="2" stroke="currentColor" strokeWidth="1.2"/><text x="8" y="11" textAnchor="middle" fontSize="6" fontWeight="700" fill="currentColor">XLS</text></svg>
                        </button>
                        {targetDbConnections.length > 0 && (
                          <div style={{ position: 'relative' }}>
                            <button
                              className="export-icon-btn export-icon-db"
                              onClick={() => setShowResultsDbPopover(prev => !prev)}
                              title="Import query results to another database"
                            >
                              <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><ellipse cx="8" cy="4" rx="6" ry="2.5" stroke="currentColor" strokeWidth="1.2"/><path d="M2 4v8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5V4" stroke="currentColor" strokeWidth="1.2"/><path d="M2 8c0 1.38 2.69 2.5 6 2.5s6-1.12 6-2.5" stroke="currentColor" strokeWidth="1.2"/></svg>
                            </button>
                            {renderImportPopover(showResultsDbPopover, setShowResultsDbPopover, (connId, db) => handleImportSqlToDb(connId, db))}
                          </div>
                        )}
                      </div>
                    </div>
                    <div style={{ flex: 1, overflow: 'auto' }}>
                      <table className="results-table" style={{ width: 'max-content', minWidth: '100%' }}>
                        <thead><tr>
                          <th style={{ width: 28, minWidth: 28, textAlign: 'center', color: '#9ca3af' }}>#</th>
                          {result.columns.map(col => {
                            const minW = Math.max(10, col.length) * 8 + 20
                            return (
                              <th key={col} style={{ width: columnWidths[col] || undefined, minWidth: minW }}>
                                {col}
                                <div className="col-resize-handle" onMouseDown={e => handleColResizeStart(col, e)} />
                              </th>
                            )
                          })}
                        </tr></thead>
                        <tbody>
                          {visibleRows.map((row, i) => (
                            <tr key={startIdx + i}>
                              <td style={{ textAlign: 'center', color: '#9ca3af', fontSize: 10 }}>{startIdx + i + 1}</td>
                              {result.columns.map(col => {
                                const val = row[col] ?? ''
                                const valStr = typeof val === 'object' && val !== null ? JSON.stringify(val, null, 2) : String(val)
                                const isExpandable = expandableColumns.has(col) || (typeof val === 'object' && val !== null) || (valStr.length > 100 && (valStr.startsWith('OrderedDict') || valStr.startsWith('{') || valStr.startsWith('[')))
                                if (isExpandable && val) {
                                  const preview = valStr.length > 30 ? valStr.slice(0, 30) : valStr
                                  return <td key={col} style={{ cursor: 'pointer' }} onClick={() => setTextCellPopup({ column: col, value: valStr })}>{preview}<span style={{ color: '#6366f1', fontWeight: 600 }}>...</span></td>
                                }
                                return <td key={col} title={valStr || ''}>{valStr}</td>
                              })}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                    {paginationBar}
                  </>
                )}
                {!error && !result && (
                  <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#d1d5db', fontSize: 12 }}>
                    Run a query to see results
                  </div>
                )}
              </>
            )}
          </div>
        }
      />
    </div>
  )

  return (
    <div className="work-area">
      <ResizablePanel storageKey="sql-sidebar-width" left={sidebar} right={editorAndResults} initialLeftWidth={260} minLeft={200} minRight={300} />

      {/* Save Script modal */}
      {showSaveScriptModal && (
        <div className="modal-overlay" onClick={() => setShowSaveScriptModal(false)}>
          <div className="modal" style={{ width: 400 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Save Script</h2>
              <button className="btn-close" onClick={() => setShowSaveScriptModal(false)}>&times;</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label>Script Name</label>
                <input
                  className="form-input"
                  value={saveScriptName}
                  onChange={e => setSaveScriptName(e.target.value)}
                  placeholder="e.g. Product2 Transform"
                  autoFocus
                  onKeyDown={e => { if (e.key === 'Enter') handleSaveScript() }}
                />
              </div>
              <div className="form-group">
                <label>SQL Preview</label>
                <div style={{ fontSize: 12, color: '#6b7280', background: '#f9fafb', padding: 8, borderRadius: 6, fontFamily: 'monospace', maxHeight: 120, overflow: 'auto', whiteSpace: 'pre-wrap' }}>
                  {sql}
                </div>
              </div>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-secondary" onClick={() => setShowSaveScriptModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleSaveScript} disabled={!saveScriptName.trim()}>Save</button>
            </div>
          </div>
        </div>
      )}

      {/* Saved Scripts modal */}
      {showScriptsModal && (
        <div className="modal-overlay" onClick={() => setShowScriptsModal(false)}>
          <div className="modal" style={{ width: 650, maxHeight: '70vh' }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Saved Scripts</h2>
              <button className="btn-close" onClick={() => setShowScriptsModal(false)}>&times;</button>
            </div>
            <div className="modal-body" style={{ maxHeight: '55vh', overflow: 'auto', padding: 0 }}>
              {savedScripts.length === 0 ? (
                <div style={{ padding: 24, textAlign: 'center', color: '#9ca3af', fontSize: 13 }}>
                  No saved scripts yet. Use "Save Script" to store your transformation queries.
                </div>
              ) : (
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                  <thead>
                    <tr style={{ borderBottom: '2px solid #e5e7eb', position: 'sticky', top: 0, background: 'white' }}>
                      <th style={{ textAlign: 'left', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>Name</th>
                      <th style={{ textAlign: 'left', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>SQL</th>
                      <th style={{ textAlign: 'left', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>Saved</th>
                      <th style={{ textAlign: 'center', padding: '6px 10px', color: '#6b7280', fontWeight: 600, width: 60 }}></th>
                    </tr>
                  </thead>
                  <tbody>
                    {savedScripts.map(s => (
                      <tr
                        key={s.id}
                        style={{ borderBottom: '1px solid #f3f4f6', cursor: 'pointer' }}
                        className="field-row-hover"
                        onClick={() => handleLoadScript(s)}
                        title="Click to load this script"
                      >
                        <td style={{ padding: '5px 10px', fontWeight: 500, color: '#1f2937', whiteSpace: 'nowrap' }}>{s.name}</td>
                        <td style={{ padding: '5px 10px', fontFamily: 'monospace', fontSize: 11, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#6b7280' }}>{s.config?.sql}</td>
                        <td style={{ padding: '5px 10px', color: '#9ca3af', whiteSpace: 'nowrap', fontSize: 11 }}>{s.savedAt ? new Date(s.savedAt).toLocaleDateString() : ''}</td>
                        <td style={{ padding: '5px 10px', textAlign: 'center' }}>
                          <button
                            onClick={e => { e.stopPropagation(); handleDeleteScript(s.id) }}
                            style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#ef4444', fontSize: 13, padding: '2px 6px' }}
                            title="Delete script"
                          >&times;</button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}

      {/* History modal */}
      {showHistory && (
        <div className="modal-overlay" onClick={() => setShowHistory(false)}>
          <div className="modal" style={{ width: 600, maxHeight: '70vh' }} onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Query History</h2>
              <button className="btn-close" onClick={() => setShowHistory(false)}>&times;</button>
            </div>
            <div className="modal-body" style={{ maxHeight: '55vh', overflow: 'auto', padding: 0 }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 12 }}>
                <thead>
                  <tr style={{ borderBottom: '2px solid #e5e7eb', position: 'sticky', top: 0, background: 'white' }}>
                    <th style={{ textAlign: 'left', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>Time</th>
                    <th style={{ textAlign: 'left', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>SQL</th>
                    <th style={{ textAlign: 'right', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>Rows</th>
                    <th style={{ textAlign: 'right', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>Time(s)</th>
                    <th style={{ textAlign: 'left', padding: '6px 10px', color: '#6b7280', fontWeight: 600 }}>Connection</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((h, i) => (
                    <tr
                      key={i}
                      style={{ borderBottom: '1px solid #f3f4f6', cursor: 'pointer' }}
                      className="field-row-hover"
                      onClick={() => { setSql(h.sql); setShowHistory(false) }}
                      title="Click to restore this query"
                    >
                      <td style={{ padding: '5px 10px', color: '#9ca3af', whiteSpace: 'nowrap', fontSize: 11 }}>{h.time}</td>
                      <td style={{ padding: '5px 10px', fontFamily: 'monospace', fontSize: 11, maxWidth: 300, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#1f2937' }}>{h.sql}</td>
                      <td style={{ padding: '5px 10px', textAlign: 'right', color: '#374151' }}>{h.rows?.toLocaleString()}</td>
                      <td style={{ padding: '5px 10px', textAlign: 'right', color: '#9ca3af' }}>{h.elapsed}s</td>
                      <td style={{ padding: '5px 10px', color: '#6b7280', fontSize: 11, whiteSpace: 'nowrap' }}>
                        {h.connection}{h.database ? ` / ${h.database}` : ''}{h.table ? ` / ${h.table}` : ''}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Import modal */}
      {showImportModal && (
        <div className="modal-overlay" onClick={() => setShowImportModal(false)}>
          <div className="modal" style={{ width: 400 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header"><h2>Import to Database</h2><button className="btn-close" onClick={() => setShowImportModal(false)}>&times;</button></div>
            <div className="modal-body">
              {(() => {
                const targetConn = targetDbConnections.find(c => c.id === importTargetDbId)
                return targetConn ? (
                  <div className="form-group">
                    <label>Target Connection</label>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: '#374151', background: '#f9fafb', padding: 8, borderRadius: 6 }}>
                      {getConnectionIcon(targetConn)}
                      <span style={{ fontWeight: 500 }}>{connectionDisplayName(targetConn)}</span>
                      {importTargetSelectedDb && (
                        <span style={{ display: 'flex', alignItems: 'center', gap: 4, color: '#6366f1' }}>
                          <DbIcon size={12} color="#6366f1" /> {importTargetSelectedDb}
                        </span>
                      )}
                    </div>
                  </div>
                ) : null
              })()}
              <div className="form-group">
                <label>Target Table Name</label>
                <input className="form-input" value={importTableName} onChange={e => setImportTableName(e.target.value)} placeholder="e.g. my_data" />
                <span className="field-hint">Table will be created or replaced in the target database.</span>
              </div>
              <div className="form-group">
                <label>Source SQL</label>
                <div style={{ fontSize: 12, color: '#6b7280', background: '#f9fafb', padding: 8, borderRadius: 6, fontFamily: 'monospace', maxHeight: 80, overflow: 'auto', whiteSpace: 'pre-wrap' }}>
                  {importSoql}
                </div>
              </div>
              <div style={{ marginTop: 4, padding: '10px 12px', background: '#f8fafc', borderRadius: 8, border: '1px solid #e2e8f0' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 12, fontWeight: 500, color: '#374151' }}>
                  <input type="checkbox" checked={saveAsStep} onChange={e => { setSaveAsStep(e.target.checked); setStepSaved(false) }} style={{ accentColor: '#8b5cf6' }} />
                  Save as reusable step in Orchestrator
                </label>
                {saveAsStep && (
                  <input
                    value={saveStepName} onChange={e => setSaveStepName(e.target.value)}
                    placeholder="Step name, e.g. Transform Contacts"
                    style={{ marginTop: 8, width: '100%', padding: '7px 10px', fontSize: 12, border: '1.5px solid #d1d5db', borderRadius: 6, outline: 'none' }}
                    onFocus={e => e.target.style.borderColor = '#8b5cf6'} onBlur={e => e.target.style.borderColor = '#d1d5db'}
                  />
                )}
              </div>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-secondary" onClick={() => setShowImportModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={handleStartImport} disabled={!importTableName.trim() || !importTargetDbId || (saveAsStep && !saveStepName.trim())}>Start Import</button>
            </div>
          </div>
        </div>
      )}

      {tableExistsWarning && (
        <div className="modal-overlay" onClick={() => setTableExistsWarning(null)}>
          <div className="modal" style={{ width: 400 }} onClick={e => e.stopPropagation()}>
            <div className="modal-header" style={{ background: '#fef3c7', borderBottom: '1px solid #fde68a' }}>
              <h2 style={{ color: '#92400e', display: 'flex', alignItems: 'center', gap: 8 }}>
                <svg width="18" height="18" viewBox="0 0 20 20" fill="none"><path d="M10 2L1 18h18L10 2z" stroke="#d97706" strokeWidth="1.5" fill="#fef3c7"/><path d="M10 8v4M10 14v1" stroke="#d97706" strokeWidth="1.5" strokeLinecap="round"/></svg>
                Table Already Exists
              </h2>
              <button className="btn-close" onClick={() => setTableExistsWarning(null)}>&times;</button>
            </div>
            <div className="modal-body">
              <p style={{ fontSize: 13, color: '#374151', lineHeight: 1.5 }}>
                The table <strong style={{ fontFamily: 'monospace', background: '#f3f4f6', padding: '1px 6px', borderRadius: 3 }}>{tableExistsWarning.tableName}</strong> already exists and will be <strong>dropped and recreated</strong>.
              </p>
              <p style={{ fontSize: 12, color: '#6b7280', marginTop: 8 }}>All existing data in this table will be lost.</p>
            </div>
            <div className="modal-footer" style={{ justifyContent: 'flex-end' }}>
              <button className="btn btn-secondary" onClick={() => setTableExistsWarning(null)}>Cancel</button>
              <button className="btn btn-primary" style={{ background: '#d97706' }} onClick={_doStartImport}>Replace Table</button>
            </div>
          </div>
        </div>
      )}

      {/* Import job toast */}
      {importJob && (
        <div style={{ position: 'fixed', bottom: 20, right: 20, zIndex: 200, background: 'white', borderRadius: 10, boxShadow: '0 4px 20px rgba(0,0,0,0.15)', border: '1px solid #e5e7eb', padding: '12px 16px', width: 320 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>
              {importJob.status === 'complete' ? 'Import Complete' : importJob.status === 'error' ? 'Import Failed' : 'Importing to Database...'}
            </span>
            <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 16 }} onClick={() => setImportJob(null)}>&times;</button>
          </div>
          <div className="progress-bar-container" style={{ width: '100%', height: 6, marginBottom: 6 }}>
            <div className={`progress-bar ${importJob.status === 'complete' ? 'complete' : importJob.status === 'error' ? 'error' : 'downloading'}`} style={{ width: `${importJob.progress || 0}%` }} />
          </div>
          <div style={{ fontSize: 11, color: '#6b7280' }}>{importJob.message || importJob.status}</div>
          {importJob.status === 'complete' && stepSaved && (
            <div style={{ marginTop: 6, fontSize: 11, color: '#059669', fontWeight: 500 }}>Step saved to Orchestrator</div>
          )}
        </div>
      )}

      {/* Textarea cell popup */}
      {textCellPopup && (
        <>
          <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.3)', zIndex: 300 }} onClick={() => setTextCellPopup(null)} />
          <div style={{ position: 'fixed', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 301, background: 'white', borderRadius: 10, boxShadow: '0 8px 32px rgba(0,0,0,0.2)', border: '1px solid #e5e7eb', width: '60%', maxWidth: 700, maxHeight: '70vh', display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 16px', borderBottom: '1px solid #f3f4f6' }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: '#374151' }}>{textCellPopup.column}</span>
              <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 18 }} onClick={() => setTextCellPopup(null)}>&times;</button>
            </div>
            <div style={{ padding: 16, overflow: 'auto', flex: 1, fontSize: 13, color: '#374151', whiteSpace: 'pre-wrap', wordBreak: 'break-word', fontFamily: 'inherit', lineHeight: 1.6 }}>
              {textCellPopup.value}
            </div>
          </div>
        </>
      )}

    </div>
  )
}
