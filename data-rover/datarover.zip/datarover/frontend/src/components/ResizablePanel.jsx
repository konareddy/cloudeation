import React, { useState, useRef, useCallback } from 'react'

/**
 * A horizontal split panel with a draggable divider.
 * Props: left, right, initialLeftWidth (px), minLeft, minRight, storageKey
 */
export default function ResizablePanel({ left, right, initialLeftWidth = 250, minLeft = 120, minRight = 200, storageKey }) {
  const [leftWidth, setLeftWidth] = useState(() => {
    if (storageKey) {
      const saved = localStorage.getItem(storageKey)
      if (saved != null) {
        const parsed = Number(saved)
        if (!isNaN(parsed) && parsed >= minLeft) return parsed
      }
    }
    return initialLeftWidth
  })
  const dragging = useRef(false)
  const containerRef = useRef(null)

  const onMouseDown = useCallback((e) => {
    e.preventDefault()
    dragging.current = true

    const onMouseMove = (e) => {
      if (!dragging.current || !containerRef.current) return
      const rect = containerRef.current.getBoundingClientRect()
      let newWidth = e.clientX - rect.left
      const maxLeft = rect.width - minRight
      newWidth = Math.max(minLeft, Math.min(maxLeft, newWidth))
      setLeftWidth(newWidth)
    }

    const onMouseUp = () => {
      dragging.current = false
      if (storageKey) {
        // Read current width from state via DOM measurement
        if (containerRef.current) {
          const firstChild = containerRef.current.firstElementChild
          if (firstChild) {
            localStorage.setItem(storageKey, String(firstChild.offsetWidth))
          }
        }
      }
      document.removeEventListener('mousemove', onMouseMove)
      document.removeEventListener('mouseup', onMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }

    document.body.style.cursor = 'col-resize'
    document.body.style.userSelect = 'none'
    document.addEventListener('mousemove', onMouseMove)
    document.addEventListener('mouseup', onMouseUp)
  }, [minLeft, minRight, storageKey])

  return (
    <div ref={containerRef} style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
      <div style={{ width: leftWidth, minWidth: minLeft, overflow: 'auto', flexShrink: 0 }}>
        {left}
      </div>
      <div
        className="resize-handle"
        onMouseDown={onMouseDown}
      />
      <div style={{ flex: 1, minWidth: minRight, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {right}
      </div>
    </div>
  )
}

/**
 * A vertical split panel with a draggable divider.
 * Props: top, bottom, initialTopHeight (px), minTop, minBottom, storageKey
 */
export function ResizablePanelV({ top, bottom, initialTopHeight = 200, minTop = 80, minBottom = 80, storageKey }) {
  const [topHeight, setTopHeight] = useState(() => {
    if (storageKey) {
      const saved = localStorage.getItem(storageKey)
      if (saved != null) {
        const parsed = Number(saved)
        if (!isNaN(parsed) && parsed >= minTop) return parsed
      }
    }
    return initialTopHeight
  })
  const dragging = useRef(false)
  const containerRef = useRef(null)

  const onMouseDown = useCallback((e) => {
    e.preventDefault()
    dragging.current = true

    const onMouseMove = (e) => {
      if (!dragging.current || !containerRef.current) return
      const rect = containerRef.current.getBoundingClientRect()
      let newHeight = e.clientY - rect.top
      const maxTop = rect.height - minBottom
      newHeight = Math.max(minTop, Math.min(maxTop, newHeight))
      setTopHeight(newHeight)
    }

    const onMouseUp = () => {
      dragging.current = false
      if (storageKey) {
        if (containerRef.current) {
          const firstChild = containerRef.current.firstElementChild
          if (firstChild) {
            localStorage.setItem(storageKey, String(firstChild.offsetHeight))
          }
        }
      }
      document.removeEventListener('mousemove', onMouseMove)
      document.removeEventListener('mouseup', onMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }

    document.body.style.cursor = 'row-resize'
    document.body.style.userSelect = 'none'
    document.addEventListener('mousemove', onMouseMove)
    document.addEventListener('mouseup', onMouseUp)
  }, [minTop, minBottom, storageKey])

  return (
    <div ref={containerRef} style={{ display: 'flex', flexDirection: 'column', flex: 1, overflow: 'hidden' }}>
      <div style={{ height: topHeight, minHeight: minTop, overflow: 'auto', flexShrink: 0 }}>
        {top}
      </div>
      <div
        className="resize-handle-v"
        onMouseDown={onMouseDown}
      />
      <div style={{ flex: 1, minHeight: minBottom, overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {bottom}
      </div>
    </div>
  )
}
