import React, { useState, useEffect, useCallback, useRef } from 'react'
import ConnectionSelect, { DatabaseSelect } from './ConnectionSelect.jsx'
import { connectionDisplayName } from './ConnectionModal.jsx'

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const api = (path, opts) => fetch(path, opts).then(r => {
  if (!r.ok) return r.text().then(t => { throw new Error(`${r.status}: ${t}`) })
  return r.json()
})
const genId = (prefix) => `${prefix}_${Date.now()}`

const WIZARD_PAGES = [
  { key: 'extract',   label: 'Extract',   desc: 'Source data', color: '#3b82f6' },
  { key: 'transform', label: 'Transform', desc: 'SQL query',   color: '#8b5cf6' },
  { key: 'load',      label: 'Load',      desc: 'To target',   color: '#10b981' },
  { key: 'schedule',  label: 'Schedule',  desc: 'Timing',      color: '#f59e0b' },
]

const SCHEDULE_PRESETS = [
  { label: 'Hourly', cron: '0 * * * *' },
  { label: 'Daily 6 AM', cron: '0 6 * * *' },
  { label: 'Daily 12 AM', cron: '0 0 * * *' },
  { label: 'Weekly Mon 6 AM', cron: '0 6 * * 1' },
]

const STATUS_COLORS = {
  complete: '#10b981',
  error: '#ef4444',
  running: '#3b82f6',
  pending: '#9ca3af',
}

function StatusDot({ status, size = 8 }) {
  return (
    <span style={{
      display: 'inline-block', width: size, height: size, borderRadius: '50%',
      background: STATUS_COLORS[status] || '#9ca3af', flexShrink: 0,
    }} />
  )
}

// ---------------------------------------------------------------------------
// Step Config Sub-Components
// ---------------------------------------------------------------------------

function ObjectSearchPicker({ sfObjects, selected, onAdd, onRemove }) {
  const [search, setSearch] = useState('')
  const [focused, setFocused] = useState(false)
  const wrapRef = useRef(null)

  useEffect(() => {
    const handler = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setFocused(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const filtered = search
    ? sfObjects.filter(o =>
        !selected.includes(o.apiName) &&
        (`${o.name} ${o.apiName}`.toLowerCase().includes(search.toLowerCase()))
      ).slice(0, 15)
    : []

  return (
    <div ref={wrapRef} className="pip-obj-picker">
      {/* Selected chips */}
      {selected.length > 0 && (
        <div className="pip-obj-chips">
          {selected.map(api => {
            const obj = sfObjects.find(o => o.apiName === api)
            return (
              <span key={api} className="pip-obj-chip">
                {obj ? obj.name : api}
                <button onClick={() => onRemove(api)}>&times;</button>
              </span>
            )
          })}
        </div>
      )}
      {/* Search input */}
      <div style={{ position: 'relative' }}>
        <input
          className="pip-obj-search"
          value={search}
          onChange={e => setSearch(e.target.value)}
          onFocus={() => setFocused(true)}
          placeholder={selected.length ? 'Search to add more objects...' : 'Type to search SF objects...'}
        />
        {focused && search && filtered.length > 0 && (
          <div className="pip-obj-dropdown">
            {filtered.map(o => (
              <div
                key={o.apiName}
                className="pip-obj-dropdown-item"
                onClick={() => { onAdd(o.apiName); setSearch('') }}
              >
                <span style={{ fontWeight: 500 }}>{o.name}</span>
                <span style={{ color: '#9ca3af', fontSize: 11, marginLeft: 6 }}>{o.apiName}</span>
              </div>
            ))}
          </div>
        )}
        {focused && search && filtered.length === 0 && (
          <div className="pip-obj-dropdown">
            <div style={{ padding: '8px 12px', color: '#9ca3af', fontSize: 12 }}>No matching objects</div>
          </div>
        )}
      </div>
    </div>
  )
}

function TableNameAutocomplete({ value, onChange, existingTables, placeholder }) {
  const [focused, setFocused] = useState(false)
  const wrapRef = useRef(null)

  useEffect(() => {
    const handler = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setFocused(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  const filtered = value
    ? existingTables.filter(t => t.toLowerCase().includes(value.toLowerCase()) && t !== value).slice(0, 10)
    : existingTables.slice(0, 10)

  return (
    <div ref={wrapRef} style={{ position: 'relative' }}>
      <input
        className="pip-obj-table-input"
        value={value}
        onChange={e => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        placeholder={placeholder}
      />
      {focused && filtered.length > 0 && (
        <div className="pip-table-dropdown">
          {filtered.map(t => (
            <div
              key={t}
              className="pip-table-dropdown-item"
              onMouseDown={e => { e.preventDefault(); onChange(t); setFocused(false) }}
            >
              {t}
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

function suggestPkChunkSize(recordCount) {
  if (!recordCount || recordCount <= 10000) return null // no PK chunking needed
  if (recordCount <= 100000) return 25000
  if (recordCount <= 500000) return 50000
  if (recordCount <= 2000000) return 100000
  if (recordCount <= 5000000) return 250000
  return 250000
}

function ExtractStepConfig({ step, onChange, sfConnections, dbConnections }) {
  // Build a unified list: all connections with a "kind" tag
  const allSourceConnections = [
    ...sfConnections.map(c => ({ ...c, _kind: 'salesforce' })),
    ...dbConnections.map(c => ({ ...c, _kind: 'database' })),
  ]

  // Determine which source connection is selected & its type
  const sourceConnId = step.sourceConnectionId || ''
  const sourceConn = allSourceConnections.find(c => c.id === sourceConnId)
  const sourceType = sourceConn?._kind || ''
  const isSF = sourceType === 'salesforce'
  const isDB = sourceType === 'database'
  const srcDbType = isDB ? (sourceConn?.dbType || '').toLowerCase() : ''

  const [sfObjects, setSfObjects] = useState([])
  const dbId = step.dbConnectionId || ''
  const [databases, setDatabases] = useState([])
  const [srcDatabases, setSrcDatabases] = useState([])
  const [tableExistence, setTableExistence] = useState({})
  const [existingTables, setExistingTables] = useState([])
  const [recordCounts, setRecordCounts] = useState({}) // { Account: 1886145 }
  const [deltaAnalysis, setDeltaAnalysis] = useState({}) // { Account: { sfCount, dbCount, deltaCount, ... } }
  const [deltaLoading, setDeltaLoading] = useState({})  // { Account: true }


  // Preview state: keyed by object name
  const [previewData, setPreviewData] = useState({})   // { Account: { columns, rows, rowCount } }
  const [previewLoading, setPreviewLoading] = useState({}) // { Account: true }
  const [previewError, setPreviewError] = useState({})  // { Account: 'error msg' }
  const [previewOpen, setPreviewOpen] = useState({})    // { Account: true } — which preview panels are open

  // SF objects
  useEffect(() => {
    if (isSF && sourceConnId) {
      api(`/api/salesforce/${sourceConnId}/objects`).then(d => {
        const list = Array.isArray(d) ? d : (d.objects || [])
        setSfObjects(list)
      }).catch(() => {})
    } else { setSfObjects([]) }
  }, [sourceConnId, isSF])

  // Target DB databases
  const fetchTargetDatabases = useCallback(() => {
    if (dbId) {
      api(`/api/database/${dbId}/databases`).then(d => setDatabases(d.databases || [])).catch(() => setDatabases([]))
    } else { setDatabases([]) }
  }, [dbId])
  useEffect(() => { fetchTargetDatabases() }, [fetchTargetDatabases])

  // Source DB databases (for database source)
  useEffect(() => {
    if (isDB && sourceConnId) {
      api(`/api/database/${sourceConnId}/databases`).then(d => setSrcDatabases(d.databases || [])).catch(() => {})
    } else { setSrcDatabases([]) }
  }, [sourceConnId, isDB])

  const objects = step.objects || []
  const tableNames = step.tableNames || {}
  const importModes = step.importModes || {}
  const pkChunkSizes = step.pkChunkSizes || {}
  const targetDb = step.targetDatabase || ''

  // Fetch record counts for selected SF objects
  useEffect(() => {
    if (!isSF || !sourceConnId || objects.length === 0) return
    objects.forEach(obj => {
      if (recordCounts[obj] !== undefined) return
      api(`/api/salesforce/${sourceConnId}/recordcount/${obj}`)
        .then(d => {
          if (d.count != null) {
            setRecordCounts(prev => ({ ...prev, [obj]: d.count }))
          }
        })
        .catch(() => {})
    })
  }, [isSF, sourceConnId, objects.join(',')])

  // Auto-suggest PK chunk sizes when record counts arrive
  useEffect(() => {
    if (!isSF) return
    const newSizes = { ...pkChunkSizes }
    let changed = false
    objects.forEach(obj => {
      const count = recordCounts[obj]
      if (count != null && !newSizes[obj]) {
        const suggested = suggestPkChunkSize(count)
        if (suggested) {
          newSizes[obj] = suggested
          changed = true
        }
      }
    })
    if (changed) {
      onChange({ ...step, pkChunkSizes: newSizes })
    }
  }, [JSON.stringify(recordCounts)])

  // Fetch delta analysis when user picks "Append Delta" + a target table
  const fetchDeltaAnalysis = useCallback((obj, tbl) => {
    if (!sourceConnId || !dbId || !tbl) return
    setDeltaLoading(prev => ({ ...prev, [obj]: true }))
    api('/api/delta-analysis', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sfConnectionId: sourceConnId,
        dbConnectionId: dbId,
        objectName: obj,
        tableName: tbl,
        targetDatabase: targetDb,
      }),
    })
      .then(d => setDeltaAnalysis(prev => ({ ...prev, [obj]: d })))
      .catch(() => {})
      .finally(() => setDeltaLoading(prev => ({ ...prev, [obj]: false })))
  }, [sourceConnId, dbId, targetDb])

  // Track which table each delta analysis was run against
  const deltaAnalyzedTable = useRef({})

  // Auto-trigger delta analysis when mode=delta and table is selected (or changed)
  useEffect(() => {
    if (!isSF) return
    objects.forEach(obj => {
      const mode = importModes[obj] || 'full'
      const tbl = tableNames[obj]
      if (mode !== 'delta' || !tbl) return
      // Re-fetch if table changed or no analysis yet
      const prev = deltaAnalyzedTable.current[obj]
      if (prev !== tbl || (!deltaAnalysis[obj] && !deltaLoading[obj])) {
        deltaAnalyzedTable.current[obj] = tbl
        setDeltaAnalysis(da => { const n = {...da}; delete n[obj]; return n })
        fetchDeltaAnalysis(obj, tbl)
      }
    })
  }, [isSF, objects.join(','), JSON.stringify(importModes), JSON.stringify(tableNames)])

  // Fetch existing tables for delta mode dropdown
  useEffect(() => {
    if (!dbId) { setExistingTables([]); return }
    const dbParam = targetDb ? `?database=${encodeURIComponent(targetDb)}` : ''
    api(`/api/database/${dbId}/tables${dbParam}`)
      .then(d => setExistingTables((d.tables || []).map(t => typeof t === 'string' ? t : t.name || t)))
      .catch(() => setExistingTables([]))
  }, [dbId, targetDb])

  useEffect(() => {
    if (!dbId || objects.length === 0) { setTableExistence({}); return }
    const dbParam = targetDb ? `?database=${encodeURIComponent(targetDb)}` : ''
    const checks = {}
    Promise.all(
      objects.map(obj => {
        const tbl = tableNames[obj] || obj
        return api(`/api/database/${dbId}/table-exists/${tbl}${dbParam}`)
          .then(d => { checks[obj] = d.exists })
          .catch(() => { checks[obj] = false })
      })
    ).then(() => setTableExistence(checks))
  }, [dbId, targetDb, objects.join(','), JSON.stringify(tableNames)])

  const addObject = (apiName) => {
    if (!objects.includes(apiName)) {
      onChange({ ...step, objects: [...objects, apiName] })
    }
  }

  const removeObject = (apiName) => {
    const nextTbl = { ...tableNames }; delete nextTbl[apiName]
    const nextModes = { ...importModes }; delete nextModes[apiName]
    onChange({ ...step, objects: objects.filter(o => o !== apiName), tableNames: nextTbl, importModes: nextModes })
  }

  const fetchPreview = async (objectName) => {
    if (!sourceConnId) return
    setPreviewLoading(p => ({ ...p, [objectName]: true }))
    setPreviewError(p => ({ ...p, [objectName]: '' }))
    setPreviewOpen(p => ({ ...p, [objectName]: true }))
    try {
      if (isSF) {
        const data = await api(`/api/salesforce/${sourceConnId}/preview/${objectName}?limit=10`)
        setPreviewData(p => ({ ...p, [objectName]: data }))
      } else if (isDB) {
        // For DB source, run a LIMIT 10 query on the source
        const sql = `SELECT * FROM ${objectName} LIMIT 10`
        const data = await api(`/api/database/${sourceConnId}/query`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sql, database: step.sourceDatabase || undefined }),
        })
        setPreviewData(p => ({ ...p, [objectName]: data }))
      }
    } catch (e) {
      setPreviewError(p => ({ ...p, [objectName]: e.message || 'Preview failed' }))
    } finally {
      setPreviewLoading(p => ({ ...p, [objectName]: false }))
    }
  }

  const togglePreview = (objectName) => {
    if (previewOpen[objectName]) {
      setPreviewOpen(p => ({ ...p, [objectName]: false }))
    } else if (previewData[objectName]) {
      setPreviewOpen(p => ({ ...p, [objectName]: true }))
    } else {
      fetchPreview(objectName)
    }
  }

  const handleSourceChange = (connId) => {
    const conn = allSourceConnections.find(c => c.id === connId)
    const kind = conn?._kind || ''
    // Clear objects, tables, modes, delta state when switching any source connection
    setRecordCounts({})
    setDeltaAnalysis({})
    setDeltaLoading({})
    setPreviewOpen({})
    setPreviewData({})
    setPreviewError({})
    deltaAnalyzedTable.current = {}
    if (kind === 'salesforce') {
      onChange({ ...step, sourceConnectionId: connId, sfConnectionId: connId, sourceType: 'salesforce', sourceDbConnectionId: '', sourceDatabase: '', sql: '', objects: [], tableNames: {}, importModes: {}, pkChunkSizes: {} })
    } else {
      onChange({ ...step, sourceConnectionId: connId, sourceDbConnectionId: connId, sourceType: 'database', sfConnectionId: '', objects: [], tableNames: {}, importModes: {}, pkChunkSizes: {} })
    }
  }

  return (
    <div className="pip-step-fields">
      {/* Source (left) and Target (right) side by side */}
      <div className="pip-two-col">
        <div className="pip-col">
          <div className="pip-col-header">Source{isSF ? ' (Salesforce)' : isDB ? ` (${srcDbType || 'Database'})` : ''}</div>
          <div className="pip-field-row">
            <label>Connection</label>
            <select
              value={sourceConnId}
              onChange={e => handleSourceChange(e.target.value)}
              style={{ width: '100%' }}
            >
              <option value="">Select source connection...</option>
              {sfConnections.length > 0 && (
                <optgroup label="Salesforce">
                  {sfConnections.map(c => (
                    <option key={c.id} value={c.id}>{connectionDisplayName(c)}</option>
                  ))}
                </optgroup>
              )}
              {dbConnections.length > 0 && (
                <optgroup label="Database">
                  {dbConnections.map(c => (
                    <option key={c.id} value={c.id}>{connectionDisplayName(c)}</option>
                  ))}
                </optgroup>
              )}
            </select>
          </div>

          {isSF && (
            <div className="pip-field-row">
              <label>Objects to Extract</label>
              <ObjectSearchPicker
                sfObjects={sfObjects}
                selected={objects}
                onAdd={addObject}
                onRemove={removeObject}
              />
            </div>
          )}

          {isDB && (
            <>
              {srcDatabases.length > 0 && (
                <div className="pip-field-row">
                  <label>Database</label>
                  <DatabaseSelect
                    databases={srcDatabases}
                    value={step.sourceDatabase || ''}
                    onChange={v => onChange({ ...step, sourceDatabase: v })}
                  />
                </div>
              )}
              <div className="pip-field-row">
                <label>SQL Query</label>
                <textarea
                  value={step.sql || ''}
                  onChange={e => onChange({ ...step, sql: e.target.value })}
                  rows={5} style={{ width: '100%', fontFamily: 'monospace', fontSize: 12 }}
                  placeholder="SELECT * FROM my_table WHERE ..."
                />
              </div>
            </>
          )}
        </div>

        {/* Arrow between columns */}
        <div className="pip-col-arrow">
          <div style={{
            width: 32, height: 32, borderRadius: '50%', background: '#f1f5f9',
            border: '1px solid #e2e8f0',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7"/>
            </svg>
          </div>
        </div>

        <div className="pip-col">
          <div className="pip-col-header">Target</div>
          <div className="pip-field-row">
            <label>DB Connection</label>
            <ConnectionSelect
              connections={dbConnections}
              value={dbId}
              onChange={v => onChange({ ...step, dbConnectionId: v, targetDatabase: '' })}
              placeholder="Select target DB connection..."
            />
          </div>
          {dbId && (
            <div className="pip-field-row">
              <label>Database</label>
              <div style={{ display: 'flex', gap: 6, alignItems: 'center', flex: 1 }}>
                <div style={{ flex: 1 }}>
                  <DatabaseSelect
                    databases={databases}
                    value={targetDb}
                    onChange={v => onChange({ ...step, targetDatabase: v })}
                  />
                </div>
                <button type="button" title="Refresh databases" onClick={() => { setDatabases([]); fetchTargetDatabases() }}
                  style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 6, padding: '4px 7px', cursor: 'pointer', color: '#6b7280', fontSize: 14, lineHeight: 1, display: 'flex', alignItems: 'center' }}>
                  ↻
                </button>
              </div>
            </div>
          )}
          {isDB && (
            <div className="pip-field-row">
              <label>Target Table Name</label>
              <input
                value={step.tableName || ''}
                onChange={e => onChange({ ...step, tableName: e.target.value })}
                placeholder="e.g. imported_data"
                style={{ width: '100%' }}
              />
            </div>
          )}
        </div>
      </div>

      {/* Object mapping table (only for Salesforce source) */}
      {isSF && objects.length > 0 && (
        <div className="pip-obj-table-wrap">
          <table className="pip-obj-table">
            <thead>
              <tr>
                <th style={{ width: '25%' }}>Source Object</th>
                <th style={{ width: 90 }}>Records</th>
                <th style={{ width: '18%' }}>Import Mode</th>
                <th>Target Table</th>
                <th style={{ width: 120 }}>PK Chunk Size</th>
                <th style={{ width: 40 }}></th>
              </tr>
            </thead>
            <tbody>
              {objects.map(obj => {
                const sfObj = sfObjects.find(o => o.apiName === obj)
                const tbl = tableNames[obj] || obj
                const exists = tableExistence[obj]
                const mode = importModes[obj] || 'full'
                const count = recordCounts[obj]
                const suggested = suggestPkChunkSize(count)
                const chunkSize = pkChunkSizes[obj] || ''
                const statusMsg = mode === 'delta' && tbl
                  ? { text: `Append to "${tbl}"`, color: '#059669', bg: '#ecfdf5' }
                  : mode === 'delta' && !tbl && dbId
                  ? { text: 'Select a table', color: '#d97706', bg: '#fffbeb' }
                  : exists && mode === 'full' && tbl
                  ? { text: `Drop & recreate "${tbl}"`, color: '#d97706', bg: '#fffbeb' }
                  : !exists && mode === 'full' && tbl && dbId
                  ? { text: `Create "${tbl}"`, color: '#6b7280', bg: 'transparent' }
                  : null
                const pLoading = previewLoading[obj]
                const isOpen = previewOpen[obj]
                const da = deltaAnalysis[obj]
                const dLoading = deltaLoading[obj]
                const showDelta = mode === 'delta' && !!tableNames[obj]
                return (
                  <React.Fragment key={obj}>
                    <tr>
                      <td>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                          <div>
                            <div style={{ fontWeight: 600, fontSize: 13 }}>{sfObj ? sfObj.name : obj}</div>
                            <div style={{ fontSize: 10, color: '#9ca3af' }}>{obj}</div>
                          </div>
                          <button
                            className={`pip-preview-btn${isOpen ? ' active' : ''}`}
                            title="Preview sample data"
                            onClick={() => togglePreview(obj)}
                            disabled={pLoading}
                            style={{ marginLeft: 4, flexShrink: 0 }}
                          >
                            {pLoading ? (
                              <span className="spinner-sm" style={{ width: 11, height: 11, borderColor: 'rgba(139,92,246,0.3)', borderTopColor: '#8b5cf6' }} />
                            ) : (
                              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                <circle cx="12" cy="12" r="3"/>
                              </svg>
                            )}
                          </button>
                        </div>
                      </td>
                      <td>
                        {count != null ? (
                          <span style={{
                            fontSize: 12, fontWeight: 500, fontFamily: 'ui-monospace, monospace',
                            color: count > 1000000 ? '#dc2626' : count > 100000 ? '#d97706' : '#059669',
                          }}>
                            {count.toLocaleString()}
                          </span>
                        ) : (
                          <span style={{ fontSize: 11, color: '#d1d5db' }}>loading...</span>
                        )}
                      </td>
                      <td>
                        <select
                          value={mode}
                          onChange={e => {
                            const newMode = e.target.value
                            const updates = { ...step, importModes: { ...importModes, [obj]: newMode } }
                            if (newMode !== mode) updates.tableNames = { ...tableNames, [obj]: '' }
                            onChange(updates)
                          }}
                          className="pip-obj-table-select"
                        >
                          <option value="full">Full Refresh</option>
                          <option value="delta">Append Delta</option>
                        </select>
                        {statusMsg && (
                          <div style={{ fontSize: 10, color: statusMsg.color, marginTop: 2 }}>{statusMsg.text}</div>
                        )}
                      </td>
                      <td>
                        <TableNameAutocomplete
                          value={obj in tableNames ? tableNames[obj] : (mode === 'delta' ? '' : obj)}
                          onChange={v => onChange({ ...step, tableNames: { ...tableNames, [obj]: v } })}
                          existingTables={existingTables}
                          placeholder={mode === 'delta' ? 'Select or type table...' : obj}
                        />
                      </td>
                      <td>
                        {suggested ? (
                          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                            <input
                              type="number"
                              value={chunkSize}
                              onChange={e => {
                                const val = parseInt(e.target.value) || ''
                                onChange({ ...step, pkChunkSizes: { ...pkChunkSizes, [obj]: val } })
                              }}
                              style={{
                                width: '100%', fontSize: 11, padding: '3px 6px',
                                fontFamily: 'ui-monospace, monospace',
                                border: '1px solid #e2e8f0', borderRadius: 4,
                              }}
                              min={10000} max={250000} step={10000}
                              title={`Suggested: ${suggested.toLocaleString()} based on ${count?.toLocaleString()} records`}
                            />
                            <div style={{ fontSize: 9, color: '#9ca3af' }}>
                              ~{count && chunkSize ? Math.ceil(count / chunkSize) : '?'} batches
                            </div>
                          </div>
                        ) : (
                          <span style={{ fontSize: 10, color: '#d1d5db' }}>N/A</span>
                        )}
                      </td>
                      <td>
                        <button
                          className="btn-icon btn-icon-danger"
                          title="Remove"
                          onClick={() => removeObject(obj)}
                          style={{ fontSize: 14 }}
                        >&times;</button>
                      </td>
                    </tr>
                    {/* Inline delta analysis row */}
                    {showDelta && (
                      <tr className="pip-delta-row">
                        <td colSpan={6} style={{ padding: 0 }}>
                          <div className="pip-delta-inline">
                            {dLoading && !da && (
                              <div className="pip-delta-loading">
                                <span className="spinner-sm" style={{ width: 10, height: 10, borderColor: 'rgba(59,130,246,0.3)', borderTopColor: '#3b82f6' }} />
                                Analyzing delta...
                              </div>
                            )}
                            {da && (
                              <div className="pip-delta-inline-stats">
                                <div className="pip-delta-stat">
                                  <span className="pip-delta-stat-label">Source</span>
                                  <span className="pip-delta-stat-value">{da.sfCount?.toLocaleString() ?? '?'}</span>
                                </div>
                                <div className="pip-delta-stat">
                                  <span className="pip-delta-stat-label">Target</span>
                                  <span className="pip-delta-stat-value">{da.dbCount?.toLocaleString() ?? '?'}</span>
                                </div>
                                <div className="pip-delta-stat">
                                  <span className="pip-delta-stat-label">To Sync</span>
                                  <span className="pip-delta-stat-value" style={{
                                    color: da.deltaCount === 0 ? '#059669' : da.deltaCount > 0 ? '#2563eb' : '#94a3b8',
                                  }}>
                                    {da.deltaCount != null ? da.deltaCount.toLocaleString() : '?'}
                                    {da.deltaCount === 0 && <small style={{ color: '#059669', fontWeight: 400, marginLeft: 4, fontSize: 10 }}>Up to date</small>}
                                  </span>
                                </div>
                                {da.lastModified && (
                                  <div className="pip-delta-stat">
                                    <span className="pip-delta-stat-label">Last Sync</span>
                                    <span style={{ fontSize: 11 }}>{new Date(da.lastModified).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true })}</span>
                                  </div>
                                )}
                                <div className="pip-delta-stat">
                                  <span className="pip-delta-stat-label">Org</span>
                                  {da.orgMatch === 'match' && <span style={{ color: '#059669', fontWeight: 600, fontSize: 11 }}>✓ Match</span>}
                                  {da.orgMatch === 'partial' && <span style={{ color: '#d97706', fontWeight: 600, fontSize: 11 }}>⚠ Partial</span>}
                                  {da.orgMatch === 'mismatch' && <span style={{ color: '#dc2626', fontWeight: 600, fontSize: 11 }}>✗ Mismatch</span>}
                                  {(da.orgMatch === 'unknown' || !da.orgMatch) && <span style={{ color: '#94a3b8', fontSize: 11 }}>—</span>}
                                </div>
                                <button
                                  onClick={() => { setDeltaAnalysis(prev => { const n = {...prev}; delete n[obj]; return n }); fetchDeltaAnalysis(obj, tbl) }}
                                  disabled={dLoading}
                                  className="pip-delta-refresh"
                                  title="Refresh"
                                >
                                  {dLoading ? (
                                    <span className="spinner-sm" style={{ width: 10, height: 10, borderColor: 'rgba(59,130,246,0.3)', borderTopColor: '#3b82f6' }} />
                                  ) : (
                                    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                                      <polyline points="23 4 23 10 17 10" /><path d="M20.49 15a9 9 0 11-2.12-9.36L23 10" />
                                    </svg>
                                  )}
                                </button>
                              </div>
                            )}
                            {da?.warnings?.length > 0 && (
                              <div className="pip-delta-inline-warnings">
                                {da.warnings.map((w, i) => (
                                  <span key={i} className={`pip-delta-warning-tag ${w.includes('DIFFERENT') || w.includes('mismatch') ? 'pip-delta-warning-tag--error' : ''}`}>
                                    ⚠ {w}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                )
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Preview panels — outside the table so they don't break layout */}
      {isSF && objects.map(obj => {
        const isOpen = previewOpen[obj]
        const pData = previewData[obj]
        const pLoading = previewLoading[obj]
        const pError = previewError[obj]
        if (!isOpen) return null
        return (
          <div key={`preview-${obj}`} className="pip-preview-panel">
            <div className="pip-preview-header">
              <span>Sample Records — {obj}</span>
              {pData && <span style={{ color: '#9ca3af', fontSize: 11 }}>{pData.rowCount} row{pData.rowCount !== 1 ? 's' : ''}</span>}
              <button onClick={() => fetchPreview(obj)} title="Refresh" disabled={pLoading}
                style={{ marginLeft: 'auto', background: 'none', border: 'none', cursor: 'pointer', color: '#6b7280', display: 'flex', alignItems: 'center' }}>
                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/>
                  <path d="M3.51 9a9 9 0 0114.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0020.49 15"/>
                </svg>
              </button>
              <button onClick={() => setPreviewOpen(p => ({ ...p, [obj]: false }))}
                style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#9ca3af', fontSize: 16, lineHeight: 1 }}>&times;</button>
            </div>
            {pLoading && !pData && (
              <div style={{ padding: '16px', textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>
                <span className="spinner-sm" style={{ borderColor: 'rgba(139,92,246,0.3)', borderTopColor: '#8b5cf6', marginRight: 8 }} />
                Loading sample records...
              </div>
            )}
            {pError && (
              <div style={{ padding: '8px 12px', fontSize: 12, color: '#dc2626', background: '#fef2f2', borderRadius: '0 0 6px 6px' }}>{pError}</div>
            )}
            {pData && (
              <div className="pip-preview-table-wrap">
                <table className="pip-query-table">
                  <thead>
                    <tr>
                      {(pData.columns || []).map(col => (
                        <th key={col}>{col}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {(pData.rows || []).map((row, i) => (
                      <tr key={i}>
                        {(pData.columns || []).map(col => (
                          <td key={col}>{row[col] != null ? String(row[col]) : <span style={{ color: '#d1d5db' }}>NULL</span>}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )
      })}



    </div>
  )
}

function TransformStepConfig({ step, onChange, dbConnections, extractStep }) {
  // Pre-fill from Extract step's target if transform fields are empty
  const extractDbId = extractStep?.dbConnectionId || ''
  const extractDb = extractStep?.targetDatabase || ''
  const extractSourceType = extractStep?.sourceType || ''
  const extractObjects = extractStep?.objects || []
  const extractTableNames = extractStep?.tableNames || {}
  const extractTables = extractSourceType === 'database'
    ? (extractStep?.tableName ? [extractStep.tableName] : [])
    : extractObjects.map(o => extractTableNames[o] || o)

  // Use extract's target as default, but allow override
  const dbId = step.sourceDbConnectionId || extractDbId
  const dbName = step.sourceDatabase || extractDb
  const [databases, setDatabases] = useState([])

  // Query execution state
  const [queryResult, setQueryResult] = useState(null)
  const [queryError, setQueryError] = useState('')
  const [queryRunning, setQueryRunning] = useState(false)
  const [queryTime, setQueryTime] = useState(null)

  const fetchTransformDatabases = useCallback(() => {
    if (dbId) {
      api(`/api/database/${dbId}/databases`).then(d => setDatabases(d.databases || [])).catch(() => setDatabases([]))
    } else { setDatabases([]) }
  }, [dbId])
  useEffect(() => { fetchTransformDatabases() }, [fetchTransformDatabases])

  // Auto-sync from extract when transform fields are empty
  useEffect(() => {
    if (!step.sourceDbConnectionId && extractDbId) {
      onChange({ ...step, sourceDbConnectionId: extractDbId, sourceDatabase: extractDb, targetDbConnectionId: extractDbId, targetDatabase: extractDb })
    }
  }, [extractDbId, extractDb])

  const runQuery = async () => {
    if (!dbId || !step.sql?.trim()) return
    setQueryRunning(true)
    setQueryError('')
    setQueryResult(null)
    setQueryTime(null)
    const t0 = Date.now()
    try {
      const res = await api(`/api/database/${dbId}/query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: step.sql, database: dbName || undefined }),
      })
      setQueryTime(Date.now() - t0)
      if (res.error) { setQueryError(res.error) }
      else { setQueryResult(res) }
    } catch (e) {
      setQueryTime(Date.now() - t0)
      setQueryError(e.message || 'Query failed')
    } finally { setQueryRunning(false) }
  }

  return (
    <div className="pip-step-fields">
      <div className="pip-field-row">
        <label>DB Connection</label>
        <ConnectionSelect
          connections={dbConnections}
          value={dbId}
          onChange={v => onChange({ ...step, sourceDbConnectionId: v, targetDbConnectionId: v, sourceDatabase: '', targetDatabase: '' })}
          placeholder="Select DB connection..."
        />
      </div>
      {dbId && (
        <div className="pip-field-row">
          <label>Database</label>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', flex: 1 }}>
            <div style={{ flex: 1 }}>
              <DatabaseSelect
                databases={databases}
                value={dbName}
                onChange={v => onChange({ ...step, sourceDatabase: v, targetDatabase: v })}
              />
            </div>
            <button type="button" title="Refresh databases" onClick={() => { setDatabases([]); fetchTransformDatabases() }}
              style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 6, padding: '4px 7px', cursor: 'pointer', color: '#6b7280', fontSize: 14, lineHeight: 1, display: 'flex', alignItems: 'center' }}>
              ↻
            </button>
          </div>
        </div>
      )}

      {/* Show tables from Extract step as reference */}
      {extractTables.length > 0 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap', padding: '6px 0' }}>
          <span style={{ fontSize: 11, color: '#6b7280', fontWeight: 600 }}>Available tables from Extract:</span>
          {extractTables.map(t => (
            <span key={t} style={{
              background: '#f5f3ff', padding: '2px 8px', borderRadius: 4,
              fontSize: 12, fontFamily: 'monospace', color: '#6d28d9',
            }}>{t}</span>
          ))}
        </div>
      )}

      <div className="pip-field-row">
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <label style={{ margin: 0 }}>SQL Query</label>
          <button
            className="btn btn-sm"
            onClick={runQuery}
            disabled={queryRunning || !dbId || !step.sql?.trim()}
            style={{
              background: queryRunning ? '#9ca3af' : '#8b5cf6', color: '#fff',
              border: 'none', padding: '4px 14px', borderRadius: 6, fontSize: 12,
              cursor: queryRunning ? 'not-allowed' : 'pointer', fontWeight: 600,
              display: 'flex', alignItems: 'center', gap: 6,
            }}
          >
            {queryRunning ? (
              <><span className="spinner-sm" /> Running...</>
            ) : (
              <><svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M4 2l10 6-10 6V2z"/></svg> Run Query</>
            )}
          </button>
        </div>
        <textarea
          value={step.sql || ''}
          onChange={e => onChange({ ...step, sql: e.target.value })}
          rows={6} style={{ width: '100%', fontFamily: 'monospace', fontSize: 12 }}
          placeholder={extractTables.length > 0
            ? `SELECT * FROM ${extractTables[0] || 'table_name'} WHERE ...`
            : 'SELECT ... FROM ...'}
          onKeyDown={e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); runQuery() } }}
        />
      </div>

      {/* Query results / error */}
      {queryError && (
        <div style={{
          background: '#fef2f2', border: '1px solid #fecaca', borderRadius: 8,
          padding: '10px 14px', fontSize: 12, color: '#dc2626', marginTop: 4,
        }}>
          {queryError}
        </div>
      )}
      {queryResult && (
        <div className="pip-query-results" style={{ marginTop: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 600, color: '#374151' }}>
              {queryResult.rowCount != null ? `${queryResult.rowCount} rows` : 'Results'}
            </span>
            {queryTime != null && (
              <span style={{ fontSize: 11, color: '#9ca3af' }}>{(queryTime / 1000).toFixed(2)}s</span>
            )}
          </div>
          <div style={{ overflowX: 'auto', maxHeight: 300, border: '1px solid #e5e7eb', borderRadius: 8 }}>
            <table className="pip-query-table">
              <thead>
                <tr>
                  {(queryResult.columns || []).map(col => (
                    <th key={col}>{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {(queryResult.rows || []).slice(0, 100).map((row, i) => (
                  <tr key={i}>
                    {(queryResult.columns || []).map(col => (
                      <td key={col}>{row[col] != null ? String(row[col]) : <span style={{ color: '#d1d5db' }}>NULL</span>}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {queryResult.rowCount > 100 && (
            <div style={{ fontSize: 11, color: '#9ca3af', marginTop: 4, textAlign: 'center' }}>
              Showing first 100 of {queryResult.rowCount} rows
            </div>
          )}
        </div>
      )}

      <div className="pip-field-row" style={{ marginTop: 8 }}>
        <label>Result Table Name</label>
        <input value={step.tableName || ''} onChange={e => onChange({ ...step, tableName: e.target.value })}
          placeholder="e.g. filtered_accounts" />
        <span style={{ fontSize: 11, color: '#9ca3af' }}>
          Query results will be saved to this table in the same database
        </span>
      </div>
    </div>
  )
}

function LoadStepConfig({ step, onChange, sfConnections, dbConnections }) {
  const sfId = step.sfConnectionId || ''
  const dbId = step.dbConnectionId || ''
  const [databases, setDatabases] = useState([])
  const [sfObjects, setSfObjects] = useState([])
  const [sfFields, setSfFields] = useState([])
  const [dbColumns, setDbColumns] = useState([])

  const fetchLoadDatabases = useCallback(() => {
    if (dbId) api(`/api/database/${dbId}/databases`).then(d => setDatabases(d.databases || [])).catch(() => setDatabases([]))
    else setDatabases([])
  }, [dbId])
  useEffect(() => { fetchLoadDatabases() }, [fetchLoadDatabases])

  useEffect(() => {
    if (sfId) {
      api(`/api/salesforce/${sfId}/objects`).then(d => {
        const list = Array.isArray(d) ? d : (d.objects || [])
        setSfObjects(list)
      }).catch(() => {})
    } else setSfObjects([])
  }, [sfId])

  useEffect(() => {
    if (sfId && step.objectName) {
      api(`/api/salesforce/${sfId}/describe/${step.objectName}`)
        .then(d => setSfFields((d.fields || []).map(f => f.name)))
        .catch(() => {})
    } else { setSfFields([]) }
  }, [sfId, step.objectName])

  useEffect(() => {
    if (dbId && step.tableName) {
      const db = step.sourceDatabase ? `?database=${encodeURIComponent(step.sourceDatabase)}` : ''
      api(`/api/database/${dbId}/tables/${step.tableName}/columns${db}`)
        .then(d => setDbColumns((d.columns || []).map(c => c.name || c)))
        .catch(() => {})
    } else { setDbColumns([]) }
  }, [dbId, step.tableName, step.sourceDatabase])

  const mapping = step.columnMapping || {}

  return (
    <div className="pip-step-fields">
      <div className="pip-field-row">
        <label>Source DB Connection</label>
        <ConnectionSelect connections={dbConnections} value={dbId}
          onChange={v => onChange({ ...step, dbConnectionId: v, sourceDatabase: '' })} placeholder="Select source DB connection..." />
      </div>
      {dbId && (
        <div className="pip-field-row">
          <label>Source Database</label>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', flex: 1 }}>
            <div style={{ flex: 1 }}>
              <DatabaseSelect databases={databases} value={step.sourceDatabase || ''}
                onChange={v => onChange({ ...step, sourceDatabase: v })} />
            </div>
            <button type="button" title="Refresh databases" onClick={() => { setDatabases([]); fetchLoadDatabases() }}
              style={{ background: 'none', border: '1px solid #d1d5db', borderRadius: 6, padding: '4px 7px', cursor: 'pointer', color: '#6b7280', fontSize: 14, lineHeight: 1, display: 'flex', alignItems: 'center' }}>
              ↻
            </button>
          </div>
        </div>
      )}
      <div className="pip-field-row">
        <label>Source Table</label>
        <input value={step.tableName || ''} onChange={e => onChange({ ...step, tableName: e.target.value })}
          placeholder="e.g. filtered_accounts" />
      </div>
      <div className="pip-field-row">
        <label>Target SF Connection</label>
        <ConnectionSelect connections={sfConnections} value={sfId}
          onChange={v => onChange({ ...step, sfConnectionId: v })} placeholder="Select target SF connection..." />
      </div>
      <div className="pip-field-row">
        <label>Target SF Object</label>
        <select value={step.objectName || ''} onChange={e => onChange({ ...step, objectName: e.target.value })}>
          <option value="">Select object...</option>
          {sfObjects.map(o => <option key={o.apiName} value={o.apiName}>{o.name} ({o.apiName})</option>)}
        </select>
      </div>
      <div className="pip-field-row">
        <label>Operation</label>
        <select value={step.operation || 'insert'} onChange={e => onChange({ ...step, operation: e.target.value })}>
          <option value="insert">Insert</option>
          <option value="update">Update</option>
          <option value="upsert">Upsert</option>
        </select>
      </div>
      {(step.operation === 'upsert' || step.operation === 'update') && (
        <div className="pip-field-row">
          <label>External ID Field</label>
          <select value={step.externalIdField || ''} onChange={e => onChange({ ...step, externalIdField: e.target.value })}>
            <option value="">Select field...</option>
            {sfFields.map(f => <option key={f} value={f}>{f}</option>)}
          </select>
        </div>
      )}
      {dbColumns.length > 0 && sfFields.length > 0 && (
        <div className="pip-field-row">
          <label>Column Mapping</label>
          <div style={{ fontSize: 11, color: '#6b7280', marginBottom: 4 }}>Map DB columns to SF fields</div>
          {dbColumns.map(col => (
            <div key={col} style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 4 }}>
              <span style={{ fontSize: 12, minWidth: 100 }}>{col}</span>
              <select
                value={mapping[col] || ''}
                onChange={e => {
                  const next = { ...mapping }
                  if (e.target.value) next[col] = e.target.value
                  else delete next[col]
                  onChange({ ...step, columnMapping: next })
                }}
                style={{ flex: 1, fontSize: 12 }}
              >
                <option value="">-- skip --</option>
                {sfFields.map(f => <option key={f} value={f}>{f}</option>)}
              </select>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------------
// Default step factories
// ---------------------------------------------------------------------------
function makeStep(type) {
  const base = { id: genId('step'), type }
  if (type === 'extract') Object.assign(base, { sourceConnectionId: '', sourceType: '', sfConnectionId: '', dbConnectionId: '', objects: [], tableNames: {}, targetDatabase: '', sourceDbConnectionId: '', sourceDatabase: '', sql: '', tableName: '' })
  if (type === 'transform') Object.assign(base, { sourceDbConnectionId: '', targetDbConnectionId: '', sourceDatabase: '', targetDatabase: '', sql: '', tableName: '' })
  if (type === 'load') Object.assign(base, { dbConnectionId: '', sfConnectionId: '', sourceDatabase: '', tableName: '', objectName: '', operation: 'insert', externalIdField: '', columnMapping: {} })
  return base
}

function isStepEmpty(step) {
  if (!step) return true
  if (step.type === 'extract') {
    if (!step.sourceConnectionId) return true
    if (step.sourceType === 'database') return !step.sql
    return (step.objects || []).length === 0
  }
  if (step.type === 'transform') return !step.sql
  if (step.type === 'load') return !step.sfConnectionId && !step.tableName
  return true
}

// Extract the step of a given type from the steps array, or return a blank
function getStepByType(steps, type) {
  return steps.find(s => s.type === type) || null
}

// ---------------------------------------------------------------------------
// Main PipelinePanel
// ---------------------------------------------------------------------------
export default function PipelinePanel({ sfConnections = [], dbConnections = [] }) {
  const [pipelines, setPipelines] = useState([])
  const [selectedId, setSelectedId] = useState(null)
  const [draft, setDraft] = useState(null)
  const [saving, setSaving] = useState(false)
  const [runningId, setRunningId] = useState(null)
  const [runStatus, setRunStatus] = useState(null)
  const [schedules, setSchedules] = useState([])
  const [wizardPage, setWizardPage] = useState(0)
  const [sidebarSearch, setSidebarSearch] = useState('')
  const [sidebarPage, setSidebarPage] = useState(0)
  const [saveAsOpen, setSaveAsOpen] = useState(false)
  const [editingName, setEditingName] = useState(false)
  const [saveAsName, setSaveAsName] = useState('')
  const SIDEBAR_PAGE_SIZE = 15
  const pollRef = useRef(null)

  // Per-type draft steps (kept separate so skipping doesn't lose data)
  const [extractStep, setExtractStep] = useState(null)
  const [transformStep, setTransformStep] = useState(null)
  const [loadStep, setLoadStep] = useState(null)

  // Fetch pipelines
  const loadPipelines = useCallback(() => {
    api('/api/pipelines').then(d => setPipelines(d.pipelines || [])).catch(() => {})
    api('/api/pipelines/schedules').then(d => setSchedules(d.schedules || [])).catch(() => {})
  }, [])

  useEffect(() => { loadPipelines() }, [loadPipelines])

  // Select a pipeline → populate wizard steps
  const selectPipeline = (p) => {
    setSelectedId(p.id)
    const steps = p.steps || []
    setDraft({ ...p, schedule: { ...(p.schedule || { type: 'none', cron: '', runAt: null, timezone: 'UTC' }) } })
    setExtractStep(getStepByType(steps, 'extract') || makeStep('extract'))
    setTransformStep(getStepByType(steps, 'transform') || makeStep('transform'))
    setLoadStep(getStepByType(steps, 'load') || makeStep('load'))
    setWizardPage(0)
    setEditingName(false)
    setRunStatus(null)
  }

  // New pipeline
  const createNew = () => {
    const p = {
      id: genId('pip'),
      name: '',
      enabled: true,
      steps: [],
      schedule: { type: 'none', cron: '', runAt: null, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone },
      lastRuns: [],
    }
    setSelectedId(p.id)
    setDraft(p)
    setExtractStep(makeStep('extract'))
    setTransformStep(makeStep('transform'))
    setLoadStep(makeStep('load'))
    setWizardPage(0)
    setEditingName(true)
    setRunStatus(null)
  }

  // Build final steps array from wizard state (only include non-empty steps)
  const buildSteps = () => {
    const steps = []
    if (!isStepEmpty(extractStep)) steps.push(extractStep)
    if (!isStepEmpty(transformStep)) steps.push(transformStep)
    if (!isStepEmpty(loadStep)) steps.push(loadStep)
    return steps
  }

  // Save — returns the saved pipeline id, or null on failure
  const saveDraft = async () => {
    if (!draft) return null
    if (!draft.name || !draft.name.trim()) {
      alert('Please enter a pipeline name.')
      return null
    }
    setSaving(true)
    try {
      const payload = { ...draft, steps: buildSteps() }
      const saved = await api('/api/pipelines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      loadPipelines()
      setDraft({ ...saved, schedule: { ...(saved.schedule || {}) } })
      setSelectedId(saved.id)
      setSaving(false)
      return saved.id
    } catch (e) {
      console.error('Save failed:', e)
      setSaving(false)
      return null
    }
  }

  // Duplicate / Save As — opens modal
  const openSaveAs = () => {
    if (!draft) return
    setSaveAsName(`${draft.name} (copy)`)
    setSaveAsOpen(true)
  }
  const confirmSaveAs = async () => {
    if (!saveAsName.trim()) return
    setSaveAsOpen(false)
    setSaving(true)
    try {
      const payload = { ...draft, id: genId('pip'), name: saveAsName.trim(), steps: buildSteps(), lastRuns: [] }
      const saved = await api('/api/pipelines', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      loadPipelines()
      setDraft({ ...saved, schedule: { ...(saved.schedule || {}) } })
      setSelectedId(saved.id)
    } catch (e) {
      console.error('Save As failed:', e)
    }
    setSaving(false)
  }

  // Delete
  const deletePipeline = async () => {
    if (!draft) return
    if (!confirm(`Delete pipeline "${draft.name}"?`)) return
    await api(`/api/pipelines/${draft.id}`, { method: 'DELETE' })
    setDraft(null)
    setSelectedId(null)
    setExtractStep(null)
    setTransformStep(null)
    setLoadStep(null)
    loadPipelines()
  }

  // Run now
  const runNow = async () => {
    if (!draft) return
    const savedId = await saveDraft()
    if (!savedId) return
    try {
      const res = await api(`/api/pipelines/${savedId}/run`, { method: 'POST' })
      const runId = res.runId
      setRunningId(runId)
      setRunStatus({ status: 'running', stepResults: [] })

      if (pollRef.current) clearInterval(pollRef.current)
      pollRef.current = setInterval(async () => {
        const run = await api(`/api/pipelines/runs/${runId}`)
        setRunStatus(run)
        if (!run.running) {
          clearInterval(pollRef.current)
          pollRef.current = null
          setRunningId(null)
          loadPipelines()
        }
      }, 2000)
    } catch (e) { console.error(e) }
  }

  useEffect(() => () => { if (pollRef.current) clearInterval(pollRef.current) }, [])

  // Schedule helpers
  const updateSchedule = (patch) => {
    setDraft({ ...draft, schedule: { ...draft.schedule, ...patch } })
  }

  const nextRun = schedules.find(s => s.pipelineId === selectedId)
  const persisted = pipelines.find(p => p.id === selectedId)
  const lastRuns = persisted?.lastRuns || draft?.lastRuns || []

  const curPage = WIZARD_PAGES[wizardPage]
  const isLastPage = wizardPage === WIZARD_PAGES.length - 1
  const isFirstPage = wizardPage === 0

  return (
    <div className="pip-layout">
      {/* ---- Left Sidebar ---- */}
      <div className="pip-sidebar">
        <div className="pip-sidebar-header">
          <span style={{ fontWeight: 600, fontSize: 14 }}>Pipelines</span>
          <button className="btn btn-sm btn-primary" onClick={createNew}>+ New</button>
        </div>
        <div className="pip-sidebar-search">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/>
          </svg>
          <input
            value={sidebarSearch}
            onChange={e => { setSidebarSearch(e.target.value); setSidebarPage(0) }}
            placeholder="Search pipelines..."
          />
        </div>
        {(() => {
          const filtered = pipelines.filter(p =>
            !sidebarSearch || p.name.toLowerCase().includes(sidebarSearch.toLowerCase())
          )
          const totalPages = Math.ceil(filtered.length / SIDEBAR_PAGE_SIZE)
          const paged = filtered.slice(sidebarPage * SIDEBAR_PAGE_SIZE, (sidebarPage + 1) * SIDEBAR_PAGE_SIZE)
          return (
            <>
              <div className="pip-list">
                {filtered.length === 0 && (
                  <div style={{ padding: 16, textAlign: 'center', color: '#9ca3af', fontSize: 12 }}>
                    {pipelines.length === 0 ? 'No pipelines yet.' : 'No matches.'}
                  </div>
                )}
                {paged.map(p => {
                  const sched = p.schedule || {}
                  const lastRun = (p.lastRuns || [])[0]
                  const schedJob = schedules.find(s => s.pipelineId === p.id)
                  return (
                    <div
                      key={p.id}
                      className={`pip-list-item ${selectedId === p.id ? 'selected' : ''}`}
                      onClick={() => selectPipeline(p)}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        {lastRun && <StatusDot status={lastRun.status} />}
                        <span className="pip-list-name">{p.name}</span>
                        {!p.enabled && <span style={{ fontSize: 9, color: '#94a3b8', fontStyle: 'italic' }}>off</span>}
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 10, color: '#94a3b8', marginTop: 1 }}>
                        <span>{(p.steps || []).map(s => s.type).filter(Boolean).map(t => t.charAt(0).toUpperCase() + t.slice(1)).join(' → ') || 'No steps'}</span>
                        {sched.type === 'recurring' && <span className="pip-badge pip-badge-schedule">Recurring</span>}
                        {sched.type === 'once' && <span className="pip-badge pip-badge-once">Once</span>}
                      </div>
                    </div>
                  )
                })}
              </div>
              {totalPages > 1 && (
                <div className="pip-sidebar-pager">
                  <button disabled={sidebarPage === 0} onClick={() => setSidebarPage(p => p - 1)}>&lsaquo;</button>
                  <span>{sidebarPage + 1} / {totalPages}</span>
                  <button disabled={sidebarPage >= totalPages - 1} onClick={() => setSidebarPage(p => p + 1)}>&rsaquo;</button>
                </div>
              )}
              <div className="pip-sidebar-count">{filtered.length} pipeline{filtered.length !== 1 ? 's' : ''}</div>
            </>
          )
        })()}
      </div>

      {/* ---- Right Editor ---- */}
      <div className="pip-editor">
        {!draft ? (
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', flex: 1, color: '#9ca3af' }}>
            Select a pipeline or create a new one
          </div>
        ) : (
          <div className="pip-editor-inner">
            {/* Pipeline Name + Enabled */}
            <div className="pip-editor-header">
              <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: 8 }}>
                {editingName ? (
                  <input
                    className="pip-name-input"
                    value={draft.name}
                    autoFocus
                    onChange={e => { const v = e.target.value; setDraft(d => ({ ...d, name: v })) }}
                    onBlur={() => {
                      setEditingName(false)
                      setPipelines(prev => prev.map(p => p.id === draft.id ? { ...p, name: draft.name } : p))
                    }}
                    onKeyDown={e => { if (e.key === 'Enter') e.target.blur() }}
                    placeholder="Enter pipeline name..."
                  />
                ) : (
                  <div className="pip-name-display" onClick={() => setEditingName(true)}>
                    <span className="pip-name-text">{draft.name || 'Untitled Pipeline'}</span>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#6b7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ flexShrink: 0, cursor: 'pointer' }}>
                      <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>
                    </svg>
                  </div>
                )}
              </div>
              <label className="pip-toggle" title={draft.enabled ? 'Enabled' : 'Disabled'}>
                <input type="checkbox" checked={draft.enabled}
                  onChange={e => { const v = e.target.checked; setDraft(d => ({ ...d, enabled: v })) }} />
                <span style={{ fontSize: 12, color: draft.enabled ? '#10b981' : '#9ca3af' }}>
                  {draft.enabled ? 'Enabled' : 'Disabled'}
                </span>
              </label>
            </div>

            {/* Wizard Step Indicator with integrated nav */}
            <div className="pip-wizard-nav">
              <button
                className="pip-wizard-nav-btn pip-wizard-nav-btn--back"
                onClick={() => setWizardPage(wizardPage - 1)}
                disabled={isFirstPage}
                title="Previous step"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M15 18l-6-6 6-6"/></svg>
              </button>
              {WIZARD_PAGES.map((page, i) => {
                const active = i === wizardPage
                const done = i < wizardPage
                // Check if the step has data
                let hasData = false
                if (page.key === 'extract') hasData = !isStepEmpty(extractStep)
                else if (page.key === 'transform') hasData = !isStepEmpty(transformStep)
                else if (page.key === 'load') hasData = !isStepEmpty(loadStep)
                else if (page.key === 'schedule') hasData = draft.schedule?.type !== 'none'
                return (
                  <button
                    key={page.key}
                    className={`pip-wizard-step ${active ? 'active' : ''} ${done ? 'done' : ''}`}
                    onClick={() => setWizardPage(i)}
                    style={{ '--step-color': page.color }}
                  >
                    <span className="pip-wizard-dot" style={{ background: active || done || hasData ? page.color : '#d1d5db' }}>
                      {hasData && !active ? '\u2713' : i + 1}
                    </span>
                    <span className="pip-wizard-label">{page.label}</span>
                    <span className="pip-wizard-desc">{page.desc}</span>
                  </button>
                )
              })}
              <button
                className="pip-wizard-nav-btn pip-wizard-nav-btn--next"
                onClick={() => isLastPage ? saveDraft() : setWizardPage(wizardPage + 1)}
                disabled={isLastPage && saving}
              >
                {isLastPage ? (saving ? 'Saving...' : 'Save') : 'Next'}
                {!isLastPage && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M9 18l6-6-6-6"/></svg>}
              </button>
            </div>

            {/* Wizard Page Content */}
            <div className="pip-wizard-body">
              <div className="pip-wizard-page-header">
                <span className="pip-step-badge" style={{ background: curPage.color, fontSize: 12, padding: '3px 12px' }}>
                  {curPage.label}
                </span>
                {curPage.key !== 'schedule' && (
                  <span style={{ fontSize: 11, color: '#9ca3af', marginLeft: 'auto' }}>
                    Leave blank to skip this step
                  </span>
                )}
              </div>

              {curPage.key === 'extract' && (
                <ExtractStepConfig
                  key={selectedId}
                  step={extractStep}
                  onChange={setExtractStep}
                  sfConnections={sfConnections}
                  dbConnections={dbConnections}
                />
              )}

              {curPage.key === 'transform' && (
                <TransformStepConfig
                  key={selectedId}
                  step={transformStep}
                  onChange={setTransformStep}
                  dbConnections={dbConnections}
                  extractStep={extractStep}
                />
              )}

              {curPage.key === 'load' && (
                <LoadStepConfig
                  key={selectedId}
                  step={loadStep}
                  onChange={setLoadStep}
                  sfConnections={sfConnections}
                  dbConnections={dbConnections}
                />
              )}

              {curPage.key === 'schedule' && (
                <div className="pip-step-fields">
                  <div className="pip-field-row">
                    <label>Type</label>
                    <select value={draft.schedule.type || 'none'} onChange={e => updateSchedule({ type: e.target.value })}>
                      <option value="none">None (manual only)</option>
                      <option value="once">Run Once</option>
                      <option value="recurring">Recurring</option>
                    </select>
                  </div>
                  {draft.schedule.type === 'once' && (
                    <div className="pip-field-row">
                      <label>Run At</label>
                      <input
                        type="datetime-local"
                        value={draft.schedule.runAt ? draft.schedule.runAt.slice(0, 16) : ''}
                        onChange={e => updateSchedule({ runAt: e.target.value ? new Date(e.target.value).toISOString() : null })}
                      />
                    </div>
                  )}
                  {draft.schedule.type === 'recurring' && (
                    <>
                      <div className="pip-field-row">
                        <label>Presets</label>
                        <div style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>
                          {SCHEDULE_PRESETS.map(p => (
                            <button key={p.cron}
                              className={`btn btn-xs ${draft.schedule.cron === p.cron ? 'btn-primary' : 'btn-outline'}`}
                              onClick={() => updateSchedule({ cron: p.cron })}
                            >{p.label}</button>
                          ))}
                        </div>
                      </div>
                      <div className="pip-field-row">
                        <label>Cron Expression</label>
                        <input
                          value={draft.schedule.cron || ''}
                          onChange={e => updateSchedule({ cron: e.target.value })}
                          placeholder="min hour dom month dow"
                          style={{ fontFamily: 'monospace', fontSize: 12 }}
                        />
                      </div>
                    </>
                  )}
                  {draft.schedule.type !== 'none' && (
                    <div className="pip-field-row">
                      <label>Timezone</label>
                      <input value={draft.schedule.timezone || 'UTC'} onChange={e => updateSchedule({ timezone: e.target.value })}
                        placeholder="e.g. America/Los_Angeles" />
                    </div>
                  )}
                  {nextRun?.nextRunTime && (
                    <div style={{ fontSize: 12, color: '#6b7280', marginTop: 4 }}>
                      Next run: {new Date(nextRun.nextRunTime).toLocaleString()}
                    </div>
                  )}

                  {/* Summary of configured steps */}
                  <div style={{ marginTop: 12, borderTop: '1px solid #e5e7eb', paddingTop: 12 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: '#374151', marginBottom: 8 }}>Pipeline Summary</div>
                    {[
                      { label: 'Extract', step: extractStep, color: '#3b82f6' },
                      { label: 'Transform', step: transformStep, color: '#8b5cf6' },
                      { label: 'Load', step: loadStep, color: '#10b981' },
                    ].map(({ label, step, color }) => (
                      <div key={label} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '4px 0', fontSize: 12 }}>
                        <span className="pip-step-badge" style={{ background: isStepEmpty(step) ? '#d1d5db' : color, fontSize: 10 }}>
                          {label}
                        </span>
                        <span style={{ color: isStepEmpty(step) ? '#9ca3af' : '#374151' }}>
                          {isStepEmpty(step) ? 'Skipped' : stepSummary(step)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Run Status (live) */}
            {runStatus && (
              <div className="pip-section" style={{ marginTop: 0 }}>
                <div className="pip-section-header">
                  <span>Current Run</span>
                  <StatusDot status={runStatus.status} />
                </div>
                <div style={{ fontSize: 12, padding: '10px 14px' }}>
                  {(runStatus.stepResults || []).map((sr, i) => (
                    <div key={i} style={{ display: 'flex', gap: 8, alignItems: 'center', padding: '4px 0' }}>
                      <StatusDot status={sr.status} size={6} />
                      <span style={{ fontWeight: 500 }}>{sr.type}</span>
                      <span style={{ color: '#64748b' }}>{sr.message}</span>
                    </div>
                  ))}
                  {runStatus.status === 'running' && (
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6, color: '#3b82f6', marginTop: 6, paddingBottom: 2 }}>
                      <span className="spinner-sm" style={{ width: 12, height: 12, borderColor: 'rgba(59,130,246,0.3)', borderTopColor: '#3b82f6' }} />
                      Running...
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Pipeline Actions */}
            <div className="pip-actions-bar">
              <button className="btn btn-accent" onClick={runNow} disabled={!!runningId}>
                {runningId ? 'Running...' : 'Run Now'}
              </button>
              <button className="btn btn-outline btn-sm" onClick={saveDraft} disabled={saving}>
                {saving ? 'Saving...' : 'Save'}
              </button>
              <button className="btn btn-outline btn-sm" onClick={openSaveAs} disabled={saving} title="Duplicate this pipeline">
                Save As
              </button>
              <div style={{ flex: 1 }} />
              <button className="btn btn-danger btn-sm" onClick={deletePipeline}>Delete</button>
            </div>
          </div>
        )}
      </div>

      {/* Save As Modal */}
      {saveAsOpen && (
        <div className="pip-modal-overlay" onClick={() => setSaveAsOpen(false)}>
          <div className="pip-modal" onClick={e => e.stopPropagation()}>
            <div className="pip-modal-header">
              <span>Save Pipeline As</span>
              <button className="pip-modal-close" onClick={() => setSaveAsOpen(false)}>&times;</button>
            </div>
            <div className="pip-modal-body">
              <label className="pip-modal-label">Pipeline Name</label>
              <input
                className="pip-modal-input"
                value={saveAsName}
                onChange={e => setSaveAsName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && confirmSaveAs()}
                autoFocus
                placeholder="Enter pipeline name..."
              />
            </div>
            <div className="pip-modal-footer">
              <button className="btn btn-outline btn-sm" onClick={() => setSaveAsOpen(false)}>Cancel</button>
              <button className="btn btn-primary btn-sm" onClick={confirmSaveAs} disabled={!saveAsName.trim()}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ---------------------------------------------------------------------------
// Step summary text for the schedule review page
// ---------------------------------------------------------------------------
function stepSummary(step) {
  if (!step) return ''
  if (step.type === 'extract') {
    if (step.sourceType === 'database') {
      const sql = (step.sql || '').slice(0, 50)
      return sql ? `SQL: ${sql}${(step.sql || '').length > 50 ? '...' : ''}` : 'Configured'
    }
    const objs = (step.objects || []).join(', ')
    return objs ? `Objects: ${objs}` : 'Configured'
  }
  if (step.type === 'transform') {
    const sql = (step.sql || '').slice(0, 60)
    return sql ? `SQL: ${sql}${step.sql.length > 60 ? '...' : ''}` : 'Configured'
  }
  if (step.type === 'load') {
    return step.objectName ? `${step.operation || 'insert'} → ${step.objectName}` : 'Configured'
  }
  return ''
}

// ---------------------------------------------------------------------------
// RunHistoryItem
// ---------------------------------------------------------------------------
function RunHistoryItem({ run }) {
  const [expanded, setExpanded] = useState(false)
  return (
    <div className="pip-run-item">
      <div className="pip-run-item-header" onClick={() => setExpanded(!expanded)}>
        <StatusDot status={run.status} />
        <span style={{ fontWeight: 500, fontSize: 12 }}>{run.status}</span>
        <span style={{ fontSize: 11, color: '#6b7280' }}>{new Date(run.startedAt).toLocaleString()}</span>
        {run.finishedAt && (
          <span style={{ fontSize: 11, color: '#9ca3af' }}>
            ({Math.round((new Date(run.finishedAt) - new Date(run.startedAt)) / 1000)}s)
          </span>
        )}
        <span style={{ fontSize: 11, color: '#9ca3af', marginLeft: 'auto' }}>{expanded ? '\u25BC' : '\u25B6'}</span>
      </div>
      {expanded && (
        <div style={{ paddingLeft: 16, paddingTop: 4, paddingBottom: 4, fontSize: 12 }}>
          {(run.stepResults || []).map((sr, i) => (
            <div key={i} style={{ display: 'flex', gap: 6, alignItems: 'center', padding: '2px 0' }}>
              <StatusDot status={sr.status} size={6} />
              <span style={{ fontWeight: 500 }}>{sr.type}</span>
              <span style={{ color: '#6b7280' }}>{sr.message}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
