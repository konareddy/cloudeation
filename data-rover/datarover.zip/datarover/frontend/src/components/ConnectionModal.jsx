import React, { useState, useEffect, useRef } from 'react'

// PKCE helpers
function generateCodeVerifier() {
  const array = new Uint8Array(32)
  crypto.getRandomValues(array)
  return btoa(String.fromCharCode(...array))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

async function generateCodeChallenge(verifier) {
  const encoder = new TextEncoder()
  const data = encoder.encode(verifier)
  const digest = await crypto.subtle.digest('SHA-256', data)
  return btoa(String.fromCharCode(...new Uint8Array(digest)))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '')
}

const CONNECTION_TYPES = [
  { id: 'salesforce', label: 'Salesforce', icon: '\u2601' },
  { id: 'database', label: 'PostgreSQL', icon: '\uD83D\uDDC4' },
  { id: 'athena', label: 'Athena', icon: '\u26A1' },
  { id: 'redshift', label: 'Redshift', icon: '\uD83D\uDFE5' },
  { id: 'mysql', label: 'MySQL', icon: '\uD83D\uDDC3' },
  { id: 'duckdb', label: 'DuckDB (Local)', icon: '\uD83E\uDD86' },
]

const SF_ORG_TYPES = [
  { id: 'production', label: 'Production', loginUrl: 'https://login.salesforce.com' },
  { id: 'developer', label: 'Developer Edition', loginUrl: 'https://login.salesforce.com' },
  { id: 'sandbox', label: 'Sandbox', loginUrl: 'https://test.salesforce.com' },
]

const SF_COMMON_FIELDS = [
  { key: 'name', label: 'Connection Name', placeholder: 'e.g., Production' },
]

const SF_OAUTH_FIELDS = [
  { key: 'clientId', label: 'Connected App Client ID', placeholder: 'Consumer Key from Connected App', hint: 'Setup > App Manager > New Connected App' },
  { key: 'clientSecret', label: 'Connected App Client Secret', placeholder: 'Consumer Secret', type: 'password' },
]

const SF_PASSWORD_FIELDS = [
  { key: 'username', label: 'Username', placeholder: 'user@company.com' },
  { key: 'password', label: 'Password', placeholder: 'Password', type: 'password' },
  { key: 'securityToken', label: 'Security Token', placeholder: 'Security token (from email)', type: 'password', hint: 'Reset via: Settings > Reset My Security Token' },
]

const DB_FIELDS = [
  { key: 'name', label: 'Connection Name', placeholder: 'e.g., Local PostgreSQL' },
  { key: 'host', label: 'Host', placeholder: 'localhost' },
  { key: 'port', label: 'Port', placeholder: '5432' },
  { key: 'database', label: 'Database', placeholder: 'salesforce_data' },
  { key: 'username', label: 'Username', placeholder: 'postgres' },
  { key: 'password', label: 'Password', placeholder: 'Password', type: 'password' },
]

const AWS_REGIONS = [
  { value: 'us-east-1', label: 'US East (N. Virginia)' },
  { value: 'us-east-2', label: 'US East (Ohio)' },
  { value: 'us-west-1', label: 'US West (N. California)' },
  { value: 'us-west-2', label: 'US West (Oregon)' },
  { value: 'af-south-1', label: 'Africa (Cape Town)' },
  { value: 'ap-east-1', label: 'Asia Pacific (Hong Kong)' },
  { value: 'ap-south-1', label: 'Asia Pacific (Mumbai)' },
  { value: 'ap-south-2', label: 'Asia Pacific (Hyderabad)' },
  { value: 'ap-southeast-1', label: 'Asia Pacific (Singapore)' },
  { value: 'ap-southeast-2', label: 'Asia Pacific (Sydney)' },
  { value: 'ap-southeast-3', label: 'Asia Pacific (Jakarta)' },
  { value: 'ap-northeast-1', label: 'Asia Pacific (Tokyo)' },
  { value: 'ap-northeast-2', label: 'Asia Pacific (Seoul)' },
  { value: 'ap-northeast-3', label: 'Asia Pacific (Osaka)' },
  { value: 'ca-central-1', label: 'Canada (Central)' },
  { value: 'eu-central-1', label: 'Europe (Frankfurt)' },
  { value: 'eu-central-2', label: 'Europe (Zurich)' },
  { value: 'eu-west-1', label: 'Europe (Ireland)' },
  { value: 'eu-west-2', label: 'Europe (London)' },
  { value: 'eu-west-3', label: 'Europe (Paris)' },
  { value: 'eu-south-1', label: 'Europe (Milan)' },
  { value: 'eu-south-2', label: 'Europe (Spain)' },
  { value: 'eu-north-1', label: 'Europe (Stockholm)' },
  { value: 'il-central-1', label: 'Israel (Tel Aviv)' },
  { value: 'me-south-1', label: 'Middle East (Bahrain)' },
  { value: 'me-central-1', label: 'Middle East (UAE)' },
  { value: 'sa-east-1', label: 'South America (São Paulo)' },
]

const ATHENA_FIELDS = [
  { key: 'name', label: 'Connection Name', placeholder: 'e.g., Data Lake' },
  { key: 'region', label: 'AWS Region', type: 'select', options: AWS_REGIONS },
  { key: 'database', label: 'Database', placeholder: 'my_database' },
  { key: 's3OutputLocation', label: 'S3 Output Location', placeholder: 's3://my-bucket/athena-results/' },
  { key: 'accessKey', label: 'AWS Access Key', placeholder: 'AKIA...', type: 'password' },
  { key: 'secretKey', label: 'AWS Secret Key', placeholder: 'Secret key', type: 'password' },
]

const REDSHIFT_FIELDS = [
  { key: 'name', label: 'Connection Name', placeholder: 'e.g., Redshift DW' },
  { key: 'host', label: 'Cluster Endpoint', placeholder: 'my-cluster.xxxx.us-east-1.redshift.amazonaws.com' },
  { key: 'port', label: 'Port', placeholder: '5439' },
  { key: 'database', label: 'Database', placeholder: 'dev' },
  { key: 'username', label: 'Username', placeholder: 'awsuser' },
  { key: 'password', label: 'Password', placeholder: 'Password', type: 'password' },
]

const MYSQL_FIELDS = [
  { key: 'name', label: 'Connection Name', placeholder: 'e.g., MySQL Production' },
  { key: 'host', label: 'Host', placeholder: 'localhost' },
  { key: 'port', label: 'Port', placeholder: '3306' },
  { key: 'database', label: 'Database', placeholder: 'my_database' },
  { key: 'username', label: 'Username', placeholder: 'root' },
  { key: 'password', label: 'Password', placeholder: 'Password', type: 'password' },
]

const DUCKDB_FIELDS = [
  { key: 'name', label: 'Connection Name', placeholder: 'e.g., Local DuckDB' },
  { key: 'filepath', label: 'Data Directory', placeholder: '~/sfdc-loader/duckdb', hint: 'Directory where .duckdb files are stored' },
]

function PasswordInput({ field, value, onChange }) {
  const [visible, setVisible] = useState(false)
  return (
    <div className="input-with-toggle">
      <input
        className="form-input"
        type={visible ? 'text' : 'password'}
        placeholder={field.placeholder}
        value={value}
        onChange={onChange}
        required={field.key === 'name'}
      />
      <button
        type="button"
        className="toggle-visibility"
        onClick={() => setVisible(v => !v)}
        title={visible ? 'Hide' : 'Show'}
      >
        {visible ? '\uD83D\uDE48' : '\uD83D\uDC41'}
      </button>
    </div>
  )
}

export default function ConnectionModal({ type, connection, onSave, onClose }) {
  const [connType, setConnType] = useState(type || 'salesforce')
  const [form, setForm] = useState({})
  const [authMode, setAuthMode] = useState('oauth') // 'oauth' or 'password'
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState(null)
  const [oauthLoading, setOauthLoading] = useState(false)
  const [showOAuthFallback, setShowOAuthFallback] = useState(false)
  const [orgType, setOrgType] = useState('production')
  const popupRef = useRef(null)
  const pollRef = useRef(null)

  // Resolve the effective type for API calls (athena is stored as database with dbType)
  const effectiveApiType = (connType === 'athena' || connType === 'redshift' || connType === 'mysql' || connType === 'duckdb') ? 'database' : connType

  // Detect org type from loginUrl
  const detectOrgType = (loginUrl) => {
    if (!loginUrl) return 'production'
    if (loginUrl.includes('test.salesforce.com')) return 'sandbox'
    // Check stored orgType if available
    return 'production'
  }

  useEffect(() => {
    if (connection) {
      setForm({ ...connection })
      // Detect type from connection
      if (connection.dbType === 'athena') {
        setConnType('athena')
      } else if (connection.dbType === 'redshift') {
        setConnType('redshift')
      } else if (connection.dbType === 'mysql') {
        setConnType('mysql')
      } else if (connection.dbType === 'duckdb') {
        setConnType('duckdb')
      } else if (type === 'salesforce' || connection.loginUrl) {
        setConnType('salesforce')
      } else {
        setConnType(type || 'database')
      }
      // Detect org type from stored value or loginUrl
      if (connection.orgType) {
        setOrgType(connection.orgType)
      } else if (connection.loginUrl) {
        setOrgType(detectOrgType(connection.loginUrl))
      }
      // Detect auth mode from existing connection
      if (connection.username && !connection.clientId && (type === 'salesforce' || connection.loginUrl)) {
        setAuthMode('password')
      } else if (connection.username && connection.clientId && (type === 'salesforce' || connection.loginUrl)) {
        setAuthMode('password')
        setShowOAuthFallback(true)
      } else {
        setAuthMode('oauth')
      }
    } else {
      setConnType(type || 'salesforce')
      resetFormDefaults(type || 'salesforce')
    }
    setTestResult(null)
  }, [connection, type])

  const resetFormDefaults = (newType) => {
    if (newType === 'salesforce') {
      setOrgType('production')
      setForm({ name: '', loginUrl: 'https://login.salesforce.com' })
    } else if (newType === 'athena') {
      setForm({ name: '', region: 'us-east-1', database: '', s3OutputLocation: '', accessKey: '', secretKey: '', dbType: 'athena' })
    } else if (newType === 'redshift') {
      setForm({ name: '', host: '', port: '5439', database: 'dev', username: '', password: '', dbType: 'redshift' })
    } else if (newType === 'mysql') {
      setForm({ name: '', host: 'localhost', port: '3306', database: '', username: '', password: '', dbType: 'mysql' })
    } else if (newType === 'duckdb') {
      setForm({ name: 'Local DuckDB', filepath: '~/sfdc-loader/duckdb', dbType: 'duckdb' })
    } else {
      setForm({ name: '', host: 'localhost', port: '5432', database: '', username: '', password: '' })
    }
    setTestResult(null)
  }

  const handleTypeChange = (newType) => {
    if (newType === connType) return
    setConnType(newType)
    if (!connection) resetFormDefaults(newType)
  }

  // Cleanup popup poll on unmount
  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current)
    }
  }, [])

  const getFields = () => {
    if (connType === 'salesforce') {
      return [...SF_COMMON_FIELDS, ...(authMode === 'oauth' ? SF_OAUTH_FIELDS : SF_PASSWORD_FIELDS)]
    }
    if (connType === 'athena') return ATHENA_FIELDS
    if (connType === 'redshift') return REDSHIFT_FIELDS
    if (connType === 'mysql') return MYSQL_FIELDS
    if (connType === 'duckdb') return DUCKDB_FIELDS
    return DB_FIELDS
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    if (connType === 'salesforce') {
      if (authMode === 'oauth') {
        handleOAuthLogin()
      } else {
        handlePasswordSave()
      }
    } else {
      // Trim all string values to avoid whitespace issues with credentials
      const trimmed = {}
      for (const [k, v] of Object.entries(form)) {
        trimmed[k] = typeof v === 'string' ? v.trim() : v
      }
      const saveData = { ...trimmed, id: connection?.id || Date.now().toString() }
      if (connType === 'athena') saveData.dbType = 'athena'
      if (connType === 'redshift') saveData.dbType = 'redshift'
      if (connType === 'mysql') saveData.dbType = 'mysql'
      if (connType === 'duckdb') saveData.dbType = 'duckdb'
      onSave(saveData, effectiveApiType)
    }
  }

  // Derive loginUrl from orgType
  const getLoginUrl = () => {
    const ot = SF_ORG_TYPES.find(t => t.id === orgType)
    return ot ? ot.loginUrl : 'https://login.salesforce.com'
  }

  const handlePasswordSave = () => {
    if (!form.name) {
      setTestResult({ success: false, message: 'Connection Name is required' })
      return
    }
    onSave({ ...form, loginUrl: getLoginUrl(), orgType, id: connection?.id || Date.now().toString() }, 'salesforce')
  }

  const handleOAuthLogin = () => {
    const loginUrl = getLoginUrl()
    const clientId = form.clientId
    if (!clientId) {
      setTestResult({ success: false, message: 'Client ID is required' })
      return
    }
    if (!form.clientSecret) {
      setTestResult({ success: false, message: 'Client Secret is required' })
      return
    }

    setOauthLoading(true)
    setTestResult(null)

    localStorage.removeItem('oauth_result')

    const codeVerifier = generateCodeVerifier()
    generateCodeChallenge(codeVerifier).then(codeChallenge => {
      const redirectUri = `${window.location.origin}/oauth/callback`

      const params = new URLSearchParams({
        loginUrl,
        clientId,
        redirectUri,
        codeChallenge,
      })

      fetch(`/api/salesforce/oauth/authorize?${params}`)
        .then(r => r.json())
        .then(({ authorizeUrl, state }) => {
          localStorage.setItem('oauth_context', JSON.stringify({
            loginUrl,
            clientId,
            clientSecret: form.clientSecret,
            redirectUri,
            codeVerifier,
            connData: {
              id: connection?.id || Date.now().toString(),
              name: form.name || 'Salesforce',
              usage: connection?.usage,
              orgType,
            },
          }))
          localStorage.setItem('oauth_state', state)

        const w = 600, h = 700
        const left = window.screenX + (window.outerWidth - w) / 2
        const top = window.screenY + (window.outerHeight - h) / 2
        popupRef.current = window.open(
          authorizeUrl,
          'sf_oauth',
          `width=${w},height=${h},left=${left},top=${top},toolbar=no,menubar=no`
        )

        pollRef.current = setInterval(() => {
          if (popupRef.current && popupRef.current.closed) {
            clearInterval(pollRef.current)
            pollRef.current = null
            setOauthLoading(false)

            const resultStr = localStorage.getItem('oauth_result')
            localStorage.removeItem('oauth_result')
            localStorage.removeItem('oauth_state')
            localStorage.removeItem('oauth_context')

            if (resultStr) {
              try {
                const result = JSON.parse(resultStr)
                if (result.success) {
                  setTestResult({ success: true, message: 'Authenticated successfully' })
                  onSave(result.connection, 'salesforce')
                } else {
                  setTestResult({ success: false, message: result.error || 'OAuth failed' })
                }
              } catch {
                setTestResult({ success: false, message: 'Failed to parse OAuth result' })
              }
            } else {
              setTestResult({ success: false, message: 'OAuth flow was cancelled' })
            }
          }
        }, 500)
      })
      .catch(err => {
        setOauthLoading(false)
        setTestResult({ success: false, message: err.message })
      })
    })
  }

  const handleTest = () => {
    setTesting(true)
    setTestResult(null)
    const url = connType === 'salesforce' ? '/api/salesforce/test' : '/api/database/test'
    // Trim all values and include dbType for non-SF connections
    const trimmed = {}
    for (const [k, v] of Object.entries(form)) {
      trimmed[k] = typeof v === 'string' ? v.trim() : v
    }
    const body = { ...trimmed }
    if (connType === 'salesforce') body.loginUrl = getLoginUrl()
    else if (connType === 'athena') body.dbType = 'athena'
    else if (connType === 'redshift') body.dbType = 'redshift'
    else if (connType === 'mysql') body.dbType = 'mysql'
    else if (connType === 'duckdb') body.dbType = 'duckdb'
    fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
      .then(r => r.json())
      .then(result => {
        setTestResult(result)
        // Auto-reveal Client ID/Secret fields when SOAP is disabled
        if (!result.success && result.message && /SOAP.*disabled/i.test(result.message)) {
          setShowOAuthFallback(true)
        }
      })
      .catch(err => setTestResult({ success: false, message: err.message }))
      .finally(() => setTesting(false))
  }

  const typeLabel = CONNECTION_TYPES.find(t => t.id === connType)?.label || connType

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{connection ? 'Edit' : 'Add'} Connection</h2>
          <button className="btn-close" onClick={onClose}>&times;</button>
        </div>
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            {/* Connection type selector */}
            {!connection && (
              <div className="form-group">
                <label>Connection Type</label>
                <select
                  className="config-select"
                  value={connType}
                  onChange={e => handleTypeChange(e.target.value)}
                  style={{ fontSize: 13, padding: '8px 10px' }}
                >
                  {CONNECTION_TYPES.map(ct => (
                    <option key={ct.id} value={ct.id}>{ct.icon} {ct.label}</option>
                  ))}
                </select>
              </div>
            )}
            {connection && (
              <div style={{ fontSize: 12, color: '#6b7280', marginBottom: 8 }}>
                Type: <strong>{typeLabel}</strong>
              </div>
            )}

            {/* Org type selector for Salesforce */}
            {connType === 'salesforce' && (
              <div className="form-group">
                <label>Org Type</label>
                <div className="upload-radio-group">
                  {SF_ORG_TYPES.map(ot => (
                    <label key={ot.id} className={`upload-radio ${orgType === ot.id ? 'active' : ''}`}>
                      <input
                        type="radio" name="orgType" value={ot.id}
                        checked={orgType === ot.id}
                        onChange={() => {
                          setOrgType(ot.id)
                          setForm(f => ({ ...f, loginUrl: ot.loginUrl }))
                        }}
                        style={{ display: 'none' }}
                      />
                      {ot.label}
                    </label>
                  ))}
                </div>
                <span className="field-hint">{SF_ORG_TYPES.find(t => t.id === orgType)?.loginUrl}</span>
              </div>
            )}

            {/* Auth mode selector for Salesforce */}
            {connType === 'salesforce' && (
              <div className="form-group">
                <label>Authentication Method</label>
                <div className="upload-radio-group">
                  <label className={`upload-radio ${authMode === 'oauth' ? 'active' : ''}`}>
                    <input
                      type="radio" name="authMode" value="oauth"
                      checked={authMode === 'oauth'}
                      onChange={() => setAuthMode('oauth')}
                      style={{ display: 'none' }}
                    />
                    OAuth (Connected App)
                  </label>
                  <label className={`upload-radio ${authMode === 'password' ? 'active' : ''}`}>
                    <input
                      type="radio" name="authMode" value="password"
                      checked={authMode === 'password'}
                      onChange={() => setAuthMode('password')}
                      style={{ display: 'none' }}
                    />
                    Username / Password
                  </label>
                </div>
                {authMode === 'password' && (
                  <span className="field-hint">Uses SOAP API login. No Connected App needed. May be disabled in some orgs.</span>
                )}
              </div>
            )}

            {getFields().map(field => (
              <div className="form-group" key={field.key}>
                <label>{field.label}</label>
                {field.type === 'password' ? (
                  <PasswordInput
                    field={field}
                    value={form[field.key] || ''}
                    onChange={e => setForm({ ...form, [field.key]: e.target.value })}
                  />
                ) : field.type === 'select' ? (
                  <select
                    className="config-select"
                    value={form[field.key] || ''}
                    onChange={e => setForm({ ...form, [field.key]: e.target.value })}
                    style={{ fontSize: 13, padding: '8px 10px' }}
                  >
                    {field.options.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.value} — {opt.label}</option>
                    ))}
                  </select>
                ) : (
                  <input
                    className="form-input"
                    type="text"
                    placeholder={field.placeholder}
                    value={form[field.key] || ''}
                    onChange={e => setForm({ ...form, [field.key]: e.target.value })}
                    required={field.key === 'name'}
                  />
                )}
                {field.hint && <span className="field-hint">{field.hint}</span>}
              </div>
            ))}

            {/* OAuth fallback fields — shown when SOAP is disabled */}
            {connType === 'salesforce' && authMode === 'password' && showOAuthFallback && (
              <div style={{ marginTop: 8, padding: '12px 14px', background: '#fffbeb', border: '1px solid #fbbf24', borderRadius: 8 }}>
                <div style={{ fontSize: 12, fontWeight: 600, color: '#92400e', marginBottom: 8 }}>
                  SOAP API is disabled — provide Connected App credentials to connect:
                </div>
                <div className="form-group" style={{ marginBottom: 8 }}>
                  <label style={{ fontSize: 12 }}>Client ID</label>
                  <input
                    className="form-input"
                    type="text"
                    placeholder="Consumer Key from Connected App"
                    value={form.clientId || ''}
                    onChange={e => setForm({ ...form, clientId: e.target.value })}
                  />
                </div>
                <div className="form-group" style={{ marginBottom: 4 }}>
                  <label style={{ fontSize: 12 }}>Client Secret</label>
                  <PasswordInput
                    field={{ key: 'clientSecret', placeholder: 'Consumer Secret' }}
                    value={form.clientSecret || ''}
                    onChange={e => setForm({ ...form, clientSecret: e.target.value })}
                  />
                </div>
                <span className="field-hint">Setup &gt; App Manager &gt; New Connected App &gt; Enable OAuth &gt; add 'Full access' scope.</span>
              </div>
            )}

            {testResult && (
              <div className={`test-result ${testResult.success ? 'test-success' : 'test-error'}`}>
                {testResult.success ? testResult.message || 'Connected successfully' : testResult.message}
              </div>
            )}
          </div>
          <div className="modal-footer">
            {connType === 'salesforce' ? (
              authMode === 'oauth' ? (
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={oauthLoading}
                >
                  {oauthLoading ? 'Waiting for login...' : 'Login with Salesforce'}
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={handleTest}
                    disabled={testing}
                  >
                    {testing ? 'Testing...' : 'Test Connection'}
                  </button>
                  <div style={{ flex: 1 }} />
                  <button
                    type="submit"
                    className="btn btn-primary"
                    disabled={testing}
                  >
                    Save
                  </button>
                </>
              )
            ) : (
              <>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={handleTest}
                  disabled={testing}
                >
                  {testing ? 'Testing...' : 'Test Connection'}
                </button>
                <div style={{ flex: 1 }} />
                <button type="submit" className="btn btn-primary">
                  {connection ? 'Save Changes' : 'Add Connection'}
                </button>
              </>
            )}
            <div style={{ flex: 1 }} />
            <button type="button" className="btn btn-secondary" onClick={onClose}>Cancel</button>
          </div>
        </form>
      </div>
    </div>
  )
}

// Helper to get display name with type suffix
export function connectionDisplayName(conn) {
  if (!conn) return ''
  if (conn.loginUrl) return `${conn.name} (Salesforce)`
  if (conn.dbType === 'athena') return `${conn.name} (Athena)`
  if (conn.dbType === 'redshift') return `${conn.name} (Redshift)`
  if (conn.dbType === 'mysql') return `${conn.name} (MySQL)`
  if (conn.dbType === 'duckdb') return `${conn.name} (DuckDB)`
  return `${conn.name} (PostgreSQL)`
}
