import React, { useState, useEffect, useCallback, useRef } from 'react'

const FIELD_TYPE_GENERATORS = {
  string: (f) => {
    const len = Math.min(f.length || 20, 40)
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
    let s = ''
    for (let i = 0; i < Math.min(len, 10 + Math.floor(Math.random() * 10)); i++) s += chars[Math.floor(Math.random() * chars.length)]
    return s
  },
  textarea: (f) => {
    const words = ['Lorem', 'ipsum', 'dolor', 'sit', 'amet', 'consectetur', 'adipiscing', 'elit', 'sed', 'do']
    const count = 3 + Math.floor(Math.random() * 8)
    return Array.from({ length: count }, () => words[Math.floor(Math.random() * words.length)]).join(' ')
  },
  email: () => {
    const u = 'user' + Math.floor(Math.random() * 9999)
    const domains = ['test.com', 'example.org', 'sample.net']
    return `${u}@${domains[Math.floor(Math.random() * domains.length)]}`
  },
  phone: () => {
    const digits = () => Math.floor(Math.random() * 900 + 100)
    return `(${digits()}) ${digits()}-${Math.floor(Math.random() * 9000 + 1000)}`
  },
  url: () => `https://www.example${Math.floor(Math.random() * 999)}.com`,
  int: () => Math.floor(Math.random() * 10000),
  double: () => +(Math.random() * 10000).toFixed(2),
  currency: () => +(Math.random() * 10000).toFixed(2),
  percent: () => +(Math.random() * 100).toFixed(1),
  boolean: () => Math.random() > 0.5,
  date: () => {
    const d = new Date(Date.now() - Math.floor(Math.random() * 365 * 24 * 60 * 60 * 1000))
    return d.toISOString().split('T')[0]
  },
  datetime: () => {
    const d = new Date(Date.now() - Math.floor(Math.random() * 365 * 24 * 60 * 60 * 1000))
    return d.toISOString()
  },
  picklist: (f) => {
    const vals = (f.picklistValues || []).filter(v => v.active)
    return vals.length ? vals[Math.floor(Math.random() * vals.length)].value : ''
  },
  multipicklist: (f) => {
    const vals = (f.picklistValues || []).filter(v => v.active)
    if (!vals.length) return ''
    const count = 1 + Math.floor(Math.random() * Math.min(3, vals.length))
    const shuffled = [...vals].sort(() => Math.random() - 0.5)
    return shuffled.slice(0, count).map(v => v.value).join(';')
  },
}

function generateValue(field) {
  const t = field.type.toLowerCase()
  if (t === 'picklist') return FIELD_TYPE_GENERATORS.picklist(field)
  if (t === 'multipicklist') return FIELD_TYPE_GENERATORS.multipicklist(field)
  if (t === 'email') return FIELD_TYPE_GENERATORS.email()
  if (t === 'phone') return FIELD_TYPE_GENERATORS.phone()
  if (t === 'url') return FIELD_TYPE_GENERATORS.url()
  if (t === 'boolean') return FIELD_TYPE_GENERATORS.boolean()
  if (t === 'int' || t === 'integer') return FIELD_TYPE_GENERATORS.int()
  if (t === 'double' || t === 'long') return FIELD_TYPE_GENERATORS.double()
  if (t === 'currency') return FIELD_TYPE_GENERATORS.currency()
  if (t === 'percent') return FIELD_TYPE_GENERATORS.percent()
  if (t === 'date') return FIELD_TYPE_GENERATORS.date()
  if (t === 'datetime') return FIELD_TYPE_GENERATORS.datetime()
  if (t === 'textarea' || t === 'encryptedstring') return FIELD_TYPE_GENERATORS.textarea(field)
  if (t === 'string' || t === 'id' || t === 'combobox') return FIELD_TYPE_GENERATORS.string(field)
  return FIELD_TYPE_GENERATORS.string(field)
}

export default function SampleDataPanel({ sfConnections, sfRefreshKey }) {
  const [connId, setConnId] = useState('')
  const [objects, setObjects] = useState([])
  const [objectSearch, setObjectSearch] = useState('')
  const [selectedObject, setSelectedObject] = useState('')
  const [allFields, setAllFields] = useState([])
  const [selectedFieldNames, setSelectedFieldNames] = useState([])
  const [fieldSearch, setFieldSearch] = useState('')
  const [numRows, setNumRows] = useState(1)
  const [rows, setRows] = useState([])
  const [loadingObjects, setLoadingObjects] = useState(false)
  const [loadingFields, setLoadingFields] = useState(false)
  const [inserting, setInserting] = useState(false)
  const [insertResult, setInsertResult] = useState(null)
  const [error, setError] = useState('')

  // Auto-select first connection
  useEffect(() => {
    if (!connId && sfConnections.length) setConnId(sfConnections[0].id)
  }, [sfConnections, connId])

  // Load objects when connection changes
  useEffect(() => {
    if (!connId) return
    setLoadingObjects(true)
    setObjects([])
    setSelectedObject('')
    setAllFields([])
    setSelectedFieldNames([])
    setRows([])
    setInsertResult(null)
    fetch(`/api/salesforce/${connId}/objects`)
      .then(r => r.json())
      .then(data => {
        if (data.error) { setError(data.error); return }
        setObjects(Array.isArray(data) ? data : [])
      })
      .catch(e => setError(e.message))
      .finally(() => setLoadingObjects(false))
  }, [connId, sfRefreshKey])

  // Load fields when object changes
  useEffect(() => {
    if (!connId || !selectedObject) return
    setLoadingFields(true)
    setAllFields([])
    setSelectedFieldNames([])
    setRows([])
    setInsertResult(null)
    fetch(`/api/salesforce/${connId}/describe/${selectedObject}`)
      .then(r => r.json())
      .then(data => {
        if (data.error) { setError(data.error); return }
        const fields = (data.fields || []).filter(f => f.createable)
        setAllFields(fields)
        // Auto-select required fields
        const required = fields.filter(f => !f.nillable && !f.defaultedOnCreate).map(f => f.name)
        setSelectedFieldNames(required)
      })
      .catch(e => setError(e.message))
      .finally(() => setLoadingFields(false))
  }, [connId, selectedObject])

  const selectedFields = allFields.filter(f => selectedFieldNames.includes(f.name))

  const toggleField = (name) => {
    setSelectedFieldNames(prev =>
      prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]
    )
    setRows([])
    setInsertResult(null)
  }

  const selectAllFiltered = () => {
    const filtered = filteredFields.map(f => f.name)
    setSelectedFieldNames(prev => [...new Set([...prev, ...filtered])])
    setRows([])
    setInsertResult(null)
  }

  const deselectAllFiltered = () => {
    const filtered = new Set(filteredFields.map(f => f.name))
    setSelectedFieldNames(prev => prev.filter(n => !filtered.has(n)))
    setRows([])
    setInsertResult(null)
  }

  const handlePopulate = () => {
    if (!selectedFields.length) return
    const generated = []
    for (let i = 0; i < numRows; i++) {
      const row = {}
      for (const f of selectedFields) {
        row[f.name] = generateValue(f)
      }
      generated.push(row)
    }
    setRows(generated)
    setInsertResult(null)
  }

  const handleCellEdit = (rowIdx, fieldName, value) => {
    setRows(prev => {
      const next = [...prev]
      next[rowIdx] = { ...next[rowIdx], [fieldName]: value }
      return next
    })
  }

  const handleInsert = async () => {
    if (!rows.length || !connId || !selectedObject) return
    setInserting(true)
    setInsertResult(null)
    setError('')
    try {
      const resp = await fetch(`/api/salesforce/${connId}/sample-insert`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ object: selectedObject, records: rows }),
      })
      const data = await resp.json()
      if (data.error) {
        setError(data.error)
      } else {
        setInsertResult(data)
      }
    } catch (e) {
      setError(e.message)
    } finally {
      setInserting(false)
    }
  }

  const filteredObjects = objects.filter(o =>
    !objectSearch || o.name.toLowerCase().includes(objectSearch.toLowerCase()) || o.apiName.toLowerCase().includes(objectSearch.toLowerCase())
  )

  const filteredFields = allFields.filter(f =>
    !fieldSearch || f.name.toLowerCase().includes(fieldSearch.toLowerCase()) || f.label.toLowerCase().includes(fieldSearch.toLowerCase())
  )

  const connName = sfConnections.find(c => c.id === connId)?.name || ''

  return (
    <div className="sample-data-panel">
      {/* Top bar */}
      <div className="sample-data-toolbar">
        <label>Connection</label>
        <select value={connId} onChange={e => setConnId(e.target.value)} style={{ minWidth: 180 }}>
          {sfConnections.map(c => (
            <option key={c.id} value={c.id}>{c.name || c.id}</option>
          ))}
        </select>

        <label style={{ marginLeft: 16 }}>Rows</label>
        <input
          type="number" min={1} max={200} value={numRows}
          onChange={e => setNumRows(Math.max(1, Math.min(200, +e.target.value || 1)))}
          style={{ width: 64 }}
        />

        <button className="btn btn-primary" onClick={handlePopulate} disabled={!selectedFields.length} style={{ marginLeft: 16 }}>
          Populate Random Data
        </button>
        <button className="btn btn-success" onClick={handleInsert} disabled={!rows.length || inserting} style={{ marginLeft: 8 }}>
          {inserting ? 'Inserting...' : 'Insert to Salesforce'}
        </button>
      </div>

      {error && (
        <div className="sample-data-error">
          {error}
          <button onClick={() => setError('')} style={{ marginLeft: 8, background: 'none', border: 'none', cursor: 'pointer', fontWeight: 700 }}>×</button>
        </div>
      )}

      <div className="sample-data-body">
        {/* Left: object + field selection */}
        <div className="sample-data-sidebar">
          {/* Object picker */}
          <div className="sample-data-section">
            <div className="sample-data-section-title">Object</div>
            <input
              placeholder="Search objects..."
              value={objectSearch}
              onChange={e => setObjectSearch(e.target.value)}
              className="sample-data-search"
            />
            <div className="sample-data-list" style={{ maxHeight: 180 }}>
              {loadingObjects ? <div className="sample-data-empty">Loading...</div> :
                filteredObjects.length === 0 ? <div className="sample-data-empty">No objects</div> :
                filteredObjects.map(o => (
                  <div
                    key={o.apiName}
                    className={`sample-data-list-item ${selectedObject === o.apiName ? 'active' : ''}`}
                    onClick={() => setSelectedObject(o.apiName)}
                  >
                    <span className="sample-data-item-name">{o.apiName}</span>
                    <span className="sample-data-item-label">{o.name}</span>
                  </div>
                ))
              }
            </div>
          </div>

          {/* Field picker */}
          {selectedObject && (
            <div className="sample-data-section" style={{ flex: 1, minHeight: 0 }}>
              <div className="sample-data-section-title">
                Fields
                <span style={{ fontSize: 11, opacity: 0.6, marginLeft: 8 }}>
                  {selectedFieldNames.length} selected
                </span>
              </div>
              <input
                placeholder="Search fields..."
                value={fieldSearch}
                onChange={e => setFieldSearch(e.target.value)}
                className="sample-data-search"
              />
              <div style={{ display: 'flex', gap: 4, marginBottom: 4 }}>
                <button className="btn-mini" onClick={selectAllFiltered}>Select All</button>
                <button className="btn-mini" onClick={deselectAllFiltered}>Deselect All</button>
              </div>
              <div className="sample-data-list" style={{ flex: 1, minHeight: 0 }}>
                {loadingFields ? <div className="sample-data-empty">Loading...</div> :
                  filteredFields.length === 0 ? <div className="sample-data-empty">No createable fields</div> :
                  filteredFields.map(f => {
                    const isRequired = !f.nillable && !f.defaultedOnCreate
                    return (
                      <label key={f.name} className="sample-data-field-item">
                        <input
                          type="checkbox"
                          checked={selectedFieldNames.includes(f.name)}
                          onChange={() => toggleField(f.name)}
                        />
                        <span className="sample-data-field-name">{f.name}</span>
                        <span className="sample-data-field-type">{f.type}</span>
                        {isRequired && <span className="sample-data-field-req">req</span>}
                      </label>
                    )
                  })
                }
              </div>
            </div>
          )}
        </div>

        {/* Right: data preview + results */}
        <div className="sample-data-main">
          {rows.length === 0 && !insertResult && (
            <div className="sample-data-placeholder">
              Select an object and fields, then click <b>Populate Random Data</b> to generate sample records.
            </div>
          )}

          {rows.length > 0 && (
            <div className="sample-data-table-wrap">
              <table className="sample-data-table">
                <thead>
                  <tr>
                    <th>#</th>
                    {selectedFields.map(f => (
                      <th key={f.name} title={`${f.label} (${f.type})`}>{f.name}</th>
                    ))}
                    {insertResult && <th>Result</th>}
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row, i) => {
                    const result = insertResult?.results?.[i]
                    return (
                      <tr key={i}>
                        <td className="sample-data-rownum">{i + 1}</td>
                        {selectedFields.map(f => (
                          <td key={f.name}>
                            <input
                              className="sample-data-cell-input"
                              value={row[f.name] == null ? '' : String(row[f.name])}
                              onChange={e => handleCellEdit(i, f.name, e.target.value)}
                              disabled={inserting}
                            />
                          </td>
                        ))}
                        {insertResult && (
                          <td>
                            {result?.success ? (
                              <span className="sample-data-success-id" title={result.id}>
                                {result.id}
                              </span>
                            ) : (
                              <span className="sample-data-error-msg" title={result?.message || 'Error'}>
                                {result?.message || 'Error'}
                              </span>
                            )}
                          </td>
                        )}
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}

          {insertResult && (
            <div className="sample-data-summary">
              <span className="sample-data-summary-ok">{insertResult.successCount} inserted</span>
              {insertResult.errorCount > 0 && (
                <span className="sample-data-summary-err">{insertResult.errorCount} failed</span>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
