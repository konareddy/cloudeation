import React, { useState, useCallback, useRef, useEffect } from 'react'
import SqlWorkArea from './components/SqlWorkArea.jsx'
import SoqlWorkArea from './components/SoqlWorkArea.jsx'
import UploadPanel from './components/UploadPanel.jsx'
import AttachmentPanel from './components/AttachmentPanel.jsx'
import JobsPanel from './components/JobsPanel.jsx'
import ConnectionsPanel from './components/ConnectionsPanel.jsx'

import ConnectionModal, { connectionDisplayName } from './components/ConnectionModal.jsx'
import { getUsage } from './components/ConnectionsPanel.jsx'
import { useSettings } from './components/SettingsPanel.jsx'
import GuidedTour from './components/GuidedTour.jsx'
import QuickLoadPanel from './components/QuickLoadPanel.jsx'
import SandboxSeedingPanel from './components/SandboxSeedingPanel.jsx'
import PipelinePanel from './components/PipelinePanel.jsx'
import ScriptPanel from './components/ScriptPanel.jsx'
import ExcelToTextPanel from './components/ExcelToTextPanel.jsx'
import DataComparePanel from './components/DataComparePanel.jsx'
import SampleDataPanel from './components/SampleDataPanel.jsx'
import TerminalPanel from './components/TerminalPanel.jsx'
import { ResizablePanelV } from './components/ResizablePanel.jsx'

// OAuth callback handler — runs in the popup window
function OAuthCallback() {
  const [status, setStatus] = useState('Completing login...')
  const calledRef = useRef(false)

  const tryClose = () => {
    try { window.close() } catch {}
    try { self.close() } catch {}
    setTimeout(() => { try { window.close() } catch {} }, 500)
  }

  useEffect(() => {
    // Prevent StrictMode double-execution (auth codes are single-use)
    if (calledRef.current) return
    calledRef.current = true

    const params = new URLSearchParams(window.location.search)
    const code = params.get('code')
    const state = params.get('state')
    const error = params.get('error')

    if (error) {
      const desc = params.get('error_description') || error
      localStorage.setItem('oauth_result', JSON.stringify({ success: false, error: desc }))
      setStatus(`Error: ${desc}`)
      tryClose()
      return
    }

    if (!code || !state) {
      localStorage.setItem('oauth_result', JSON.stringify({ success: false, error: 'Missing code or state' }))
      setStatus('Error: Missing authorization code')
      tryClose()
      return
    }

    // Retrieve OAuth context stored by the parent window
    const oauthContext = JSON.parse(localStorage.getItem('oauth_context') || '{}')

    // Exchange code for tokens via backend (stateless — send everything)
    fetch('/api/salesforce/oauth/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code,
        state,
        loginUrl: oauthContext.loginUrl,
        clientId: oauthContext.clientId,
        clientSecret: oauthContext.clientSecret,
        redirectUri: oauthContext.redirectUri,
        codeVerifier: oauthContext.codeVerifier,
        connData: oauthContext.connData,
      }),
    })
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          localStorage.setItem('oauth_result', JSON.stringify({
            success: true,
            connection: data.connection,
          }))
          setStatus('Login successful! You can close this window.')
        } else {
          localStorage.setItem('oauth_result', JSON.stringify({
            success: false,
            error: data.error || 'Token exchange failed',
          }))
          setStatus(`Error: ${data.error || 'Token exchange failed'}`)
        }
        tryClose()
      })
      .catch(err => {
        localStorage.setItem('oauth_result', JSON.stringify({
          success: false,
          error: err.message,
        }))
        setStatus(`Error: ${err.message}`)
        tryClose()
      })
  }, [])

  return (
    <div style={{
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      height: '100vh', fontFamily: 'sans-serif', fontSize: '16px', color: '#333',
    }}>
      <p>{status}</p>
    </div>
  )
}

/**
 * Resizable bottom terminal panel with drag handle.
 */
function TerminalBottomPanel(props) {
  const STORAGE_KEY = 'dr-terminal-height'
  const [height, setHeight] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY)
    return saved ? Math.max(120, parseInt(saved)) : 200
  })
  const dragging = useRef(false)
  const startY = useRef(0)
  const startH = useRef(0)

  const onMouseDown = useCallback((e) => {
    e.preventDefault()
    dragging.current = true
    startY.current = e.clientY
    startH.current = height

    const onMouseMove = (e) => {
      if (!dragging.current) return
      const delta = startY.current - e.clientY
      const newH = Math.max(150, Math.min(600, startH.current + delta))
      setHeight(newH)
    }

    const onMouseUp = () => {
      dragging.current = false
      localStorage.setItem(STORAGE_KEY, String(height))
      document.removeEventListener('mousemove', onMouseMove)
      document.removeEventListener('mouseup', onMouseUp)
      document.body.style.cursor = ''
      document.body.style.userSelect = ''
    }

    document.body.style.cursor = 'row-resize'
    document.body.style.userSelect = 'none'
    document.addEventListener('mousemove', onMouseMove)
    document.addEventListener('mouseup', onMouseUp)
  }, [height])

  // Persist on height change
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, String(height))
  }, [height])

  return (
    <>
      <div className="resize-handle-v" onMouseDown={onMouseDown} style={{ flexShrink: 0 }} />
      <div style={{ height, minHeight: 120, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <TerminalPanel {...props} />
      </div>
    </>
  )
}

export default function App() {
  // Detect OAuth callback path
  if (window.location.pathname === '/oauth/callback') {
    return <OAuthCallback />
  }

  return <MainApp />
}

function MainApp() {
  // Settings
  const [settings, updateSettings] = useSettings()
  // Connections
  const [sfConnections, setSfConnections] = useState([])
  const [dbConnections, setDbConnections] = useState([])
  const [activeSfId, setActiveSfId] = useState('')
  const [activeDbId, setActiveDbId] = useState('')

  // Tabs
  const [activeTab, setActiveTab] = useState('salesforce')
  const sandboxRef = useRef(null)
  const compareRef = useRef(null)

  const switchTab = useCallback((tabId) => {
    // Guard leaving sandbox tab with unsaved changes
    if (activeTab === 'sandbox' && tabId !== 'sandbox' && sandboxRef.current?.isDirty?.()) {
      sandboxRef.current.guardUnsaved(() => setActiveTab(tabId))
      return
    }
    // Guard leaving compare tab with unsaved changes
    if (activeTab === 'compare' && tabId !== 'compare' && compareRef.current?.isDirty?.()) {
      compareRef.current.guardUnsaved(() => setActiveTab(tabId))
      return
    }
    setActiveTab(tabId)
  }, [activeTab])

  // Running jobs count for badge on Jobs tab
  const [runningJobsCount, setRunningJobsCount] = useState(0)
  useEffect(() => {
    const poll = () => {
      fetch('/api/jobs').then(r => r.json()).then(data => {
        setRunningJobsCount((data.jobs || []).filter(j => j.running).length)
      }).catch(() => {})
    }
    poll()
    const id = setInterval(poll, 5000)
    return () => clearInterval(id)
  }, [])

  // Navigate-to-table state (set from Jobs panel, consumed by SqlWorkArea)
  const [navToTable, setNavToTable] = useState(null)
  const [navToDatabase, setNavToDatabase] = useState(null)

  // Refresh key — incremented when a SF connection is re-saved (e.g. after OAuth re-login)
  const [sfRefreshKey, setSfRefreshKey] = useState(0)

  // Modal
  const [modal, setModal] = useState(null)

  // Terminal
  const [terminalOpen, setTerminalOpen] = useState(false)
  const [terminalFullScreen, setTerminalFullScreen] = useState(false)

  // Keyboard shortcut: Ctrl+` (backtick) to toggle terminal
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.ctrlKey && e.key === '`') {
        e.preventDefault()
        if (terminalFullScreen) {
          setTerminalFullScreen(false)
          setTerminalOpen(true)
          if (activeTab === 'terminal') switchTab('salesforce')
        } else {
          setTerminalOpen(v => !v)
        }
      }
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [terminalFullScreen, activeTab])

  // Guided tour
  const [showTour, setShowTour] = useState(false)

  // Migrate old usage format: 'load' → 'source'+'target', old strings → full array
  const migrateUsage = (conn) => {
    if (!Array.isArray(conn.usage)) return { ...conn, usage: ['extract', 'transform', 'source', 'target'] }
    const u = conn.usage
    // Migrate old 'load' to 'source' + 'target'
    if (u.includes('load')) {
      const next = u.filter(f => f !== 'load')
      if (!next.includes('source')) next.push('source')
      if (!next.includes('target')) next.push('target')
      return { ...conn, usage: next }
    }
    return conn
  }

  // Load connections on mount, migrate usage if needed
  const loadConnections = useCallback(() => {
    fetch('/api/connections')
      .then(r => r.json())
      .then(async (data) => {
        const sfRaw = data.salesforce_connections || []
        const dbRaw = data.database_connections || []
        const sfList = sfRaw.map(migrateUsage)
        const dbList = dbRaw.map(migrateUsage)

        // Persist migrations sequentially
        for (const conn of sfList) {
          const orig = sfRaw.find(c => c.id === conn.id)
          if (JSON.stringify(orig.usage) !== JSON.stringify(conn.usage)) {
            await fetch('/api/connections/salesforce', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(conn),
            }).catch(() => {})
          }
        }
        for (const conn of dbList) {
          const orig = dbRaw.find(c => c.id === conn.id)
          if (JSON.stringify(orig.usage) !== JSON.stringify(conn.usage)) {
            await fetch('/api/connections/database', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(conn),
            }).catch(() => {})
          }
        }

        setSfConnections(sfList)
        setDbConnections(dbList)
        if (sfList.length) setActiveSfId(prev => prev || sfList[0].id)
        if (dbList.length) setActiveDbId(prev => prev || dbList[0].id)
      })
      .catch(() => {})
  }, [])

  useEffect(() => { loadConnections() }, [loadConnections])

  // Unified connection save handler
  const handleSaveConnection = (conn, apiType) => {
    const endpoint = apiType === 'salesforce' ? '/api/connections/salesforce' : '/api/connections/database'
    fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(conn),
    })
      .then(r => r.json())
      .then(saved => {
        if (apiType === 'salesforce') {
          setSfConnections(prev => {
            const idx = prev.findIndex(c => c.id === saved.id)
            if (idx >= 0) { const next = [...prev]; next[idx] = saved; return next }
            return [...prev, saved]
          })
          setActiveSfId(saved.id)
          setSfRefreshKey(k => k + 1)
        } else {
          setDbConnections(prev => {
            const idx = prev.findIndex(c => c.id === saved.id)
            if (idx >= 0) { const next = [...prev]; next[idx] = saved; return next }
            return [...prev, saved]
          })
          if (!activeDbId) setActiveDbId(saved.id)
        }
        setModal(null)
      })
  }

  const handleDeleteSf = (id) => {
    fetch(`/api/connections/salesforce/${id}`, { method: 'DELETE' })
      .then(() => {
        setSfConnections(prev => prev.filter(c => c.id !== id))
        if (activeSfId === id) setActiveSfId(sfConnections.find(c => c.id !== id)?.id || '')
      })
  }

  const handleDeleteDb = (id) => {
    fetch(`/api/connections/database/${id}`, { method: 'DELETE' })
      .then(() => {
        setDbConnections(prev => prev.filter(c => c.id !== id))
        if (activeDbId === id) setActiveDbId(dbConnections.find(c => c.id !== id)?.id || '')
      })
  }

  const activeSfConn = sfConnections.find(c => c.id === activeSfId)
  const activeDbConn = dbConnections.find(c => c.id === activeDbId)

  const handleEditConn = (conn) => {
    const type = conn.loginUrl ? 'salesforce' : 'database'
    setModal({ type, connection: conn })
  }

  // Update a connection's usage (extract / transform / both)
  const handleUpdateConnectionUsage = (conn, usage) => {
    const updated = { ...conn, usage }
    const isSf = !!conn.loginUrl
    const endpoint = isSf ? '/api/connections/salesforce' : '/api/connections/database'
    // Optimistic local update
    if (isSf) {
      setSfConnections(prev => prev.map(c => c.id === conn.id ? { ...c, usage } : c))
    } else {
      setDbConnections(prev => prev.map(c => c.id === conn.id ? { ...c, usage } : c))
    }
    // Persist
    fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).then(r => r.json()).then(saved => {
      if (isSf) {
        setSfConnections(prev => prev.map(c => c.id === saved.id ? saved : c))
      } else {
        setDbConnections(prev => prev.map(c => c.id === saved.id ? saved : c))
      }
    }).catch(err => {
      console.error('Failed to save usage:', err)
      // Revert optimistic update on failure
      if (isSf) {
        setSfConnections(prev => prev.map(c => c.id === conn.id ? conn : c))
      } else {
        setDbConnections(prev => prev.map(c => c.id === conn.id ? conn : c))
      }
    })
  }

  // Update a connection's table prefix (for extract import)
  const handleUpdateTablePrefix = (conn, tablePrefix) => {
    const updated = { ...conn, tablePrefix }
    const isSf = !!conn.loginUrl
    const endpoint = isSf ? '/api/connections/salesforce' : '/api/connections/database'
    // Optimistic local update
    if (isSf) {
      setSfConnections(prev => prev.map(c => c.id === conn.id ? { ...c, tablePrefix } : c))
    } else {
      setDbConnections(prev => prev.map(c => c.id === conn.id ? { ...c, tablePrefix } : c))
    }
    // Persist
    fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).then(r => r.json()).then(saved => {
      if (isSf) {
        setSfConnections(prev => prev.map(c => c.id === saved.id ? saved : c))
      } else {
        setDbConnections(prev => prev.map(c => c.id === saved.id ? saved : c))
      }
    }).catch(err => {
      console.error('Failed to save table prefix:', err)
    })
  }

  // Filter helpers — usage is an array; missing defaults to all
  const forExtract = (c) => getUsage(c).includes('extract')
  const forTransform = (c) => getUsage(c).includes('transform')
  const forSource = (c) => getUsage(c).includes('source')
  const forTarget = (c) => getUsage(c).includes('target')

  return (
    <div className="app">
      <header className="header" data-tour="header">
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{
            width: 40, height: 40, borderRadius: 10,
            background: '#fff',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
            flexShrink: 0,
          }}>
            <img src="/logo.png" alt="Data Rover" style={{ height: 32, width: 32, objectFit: 'contain' }} />
          </div>
          <div>
            <h1 style={{ display: 'flex', alignItems: 'center', gap: 0, margin: 0, lineHeight: 1.1 }}>
              <span style={{ fontWeight: 700, fontSize: 20, letterSpacing: '-0.3px' }}>Data</span>
              <span style={{ fontWeight: 300, opacity: 0.6, margin: '0 6px', fontSize: 20 }}>|</span>
              <span style={{ fontWeight: 600, fontSize: 17, letterSpacing: '0.02em', opacity: 0.9 }}>Rover</span>
            </h1>
            <div style={{ fontSize: 9, fontWeight: 400, opacity: 0.55, letterSpacing: '0.08em', textTransform: 'uppercase', marginTop: 1 }}>
              by Cloudeation
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            className="btn-help"
            data-tour="help-button"
            onClick={() => setShowTour(true)}
            title="Take a guided tour"
          >
            ?
          </button>
        </div>
      </header>

      <div className="layout-full">
        <main className="main-content">
          <div className="tabs etl-tabs" data-tour="tabs">
            {[
              { id: 'salesforce', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1v8M4 6.5L7 9.5l3-3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 11.5h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>, colorClass: 'etl-e', label: 'Extract', sub: '' },
              { id: 'database', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M1.5 3.5h11M5 7h4M3 10.5h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><path d="M9.5 2v3M4.5 9v3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>, colorClass: 'etl-t', label: 'Transform', sub: 'Data' },
              { id: 'upload', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 9V1M4 3.5L7 1l3 2.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/><path d="M2 11.5h10" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/></svg>, colorClass: 'etl-l', label: 'Load', sub: 'to Salesforce' },
              { id: 'pipeline', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 3h3v2H2zM5.5 4h3M9 3h3v2H9zM5 7.5h4v2H5z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M3.5 5v1.5H7M10.5 5v1.5H7M7 6.5v1" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M7 9.5v2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>, colorClass: 'etl-p', label: 'Pipeline', sub: 'ETL Jobs' },
              { id: 'script', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M4 2h6a1 1 0 011 1v8a1 1 0 01-1 1H4a1 1 0 01-1-1V3a1 1 0 011-1z" stroke="currentColor" strokeWidth="1.3"/><path d="M5 5l2 2-2 2M8 9h2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>, colorClass: 'etl-sc', label: 'Script', sub: 'Runner' },
              { id: 'sandbox', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1v3M5 3.5l2 1 2-1" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M3 6.5c0 0 1-1 4-1s4 1 4 1v4c0 1-1.5 2.5-4 2.5S3 11.5 3 10.5v-4z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>, colorClass: 'etl-s', label: 'Sandbox', sub: 'Seeding' },
              { id: 'quickload', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M8 1H4a1 1 0 00-1 1v10a1 1 0 001 1h6a1 1 0 001-1V4L8 1z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M8 1v3h3M7 7v4M5 9h4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>, colorClass: 'etl-q', label: 'Quick Load', sub: 'to SF' },
              { id: 'attachments', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M10.5 6.5l-4 4a2.12 2.12 0 01-3-3l4.5-4.5a1.41 1.41 0 012 2L5.5 9.5a.71.71 0 01-1-1l4-4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>, colorClass: 'etl-a', label: 'Files', sub: 'Attachments' },
              { id: 'excel2text', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M8 1H4a1 1 0 00-1 1v10a1 1 0 001 1h6a1 1 0 001-1V4L8 1z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M8 1v3h3" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M5 7l4 4M9 7l-4 4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>, colorClass: 'etl-x', label: 'Excel', sub: 'to Files' },
              { id: 'compare', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M2 4h4v6H2zM8 4h4v6H8z" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/><path d="M6 7h2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>, colorClass: 'etl-cmp', label: 'Compare', sub: 'Data' },
              { id: 'sampledata', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 2h8a1 1 0 011 1v8a1 1 0 01-1 1H3a1 1 0 01-1-1V3a1 1 0 011-1z" stroke="currentColor" strokeWidth="1.3"/><path d="M2 5h10M5 5v7M9 5v7" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/></svg>, colorClass: 'etl-sd', label: 'Sample', sub: 'Data' },
              { id: 'jobs', icon: <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1v4M7 9v4M1 7h4M9 7h4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"/><circle cx="7" cy="7" r="2" stroke="currentColor" strokeWidth="1.5"/></svg>, colorClass: 'etl-j', label: 'Jobs', sub: 'History', badge: runningJobsCount },
            ].map(tab => (
              <button
                key={tab.id}
                className={`tab etl-tab ${activeTab === tab.id ? 'tab-active' : ''}`}
                onClick={() => switchTab(tab.id)}
                style={{ position: 'relative' }}
              >
                <span className={`etl-letter ${tab.colorClass}`} style={{ width: 24, height: 24 }}>{tab.icon}</span>
                <span className="etl-label">{tab.label}</span>
                <span className="etl-sub">{tab.sub}</span>
                {tab.badge > 0 && (
                  <span style={{
                    position: 'absolute', top: 4, right: 6,
                    width: 8, height: 8, borderRadius: '50%',
                    background: '#3b82f6', border: '2px solid #fff',
                    animation: 'pulse 1.5s infinite',
                  }} />
                )}
              </button>
            ))}
            <div style={{ flex: 1 }} />
            <button
              data-tour="config-tab"
              className={`tab etl-tab ${activeTab === 'connections' ? 'tab-active' : ''}`}
              onClick={() => switchTab('connections')}
              style={{ position: 'relative' }}
            >
              <span className="etl-letter etl-c" style={{ width: 24, height: 24 }}><svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 1.5v2M7 10.5v2M4.5 4.5L3 3M11 11l-1.5-1.5M1.5 7h2M10.5 7h2M4.5 9.5L3 11M11 3l-1.5 1.5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/><circle cx="7" cy="7" r="2.5" stroke="currentColor" strokeWidth="1.3"/></svg></span>
              <span className="etl-label">Configuration</span>
              <span className="etl-sub"></span>
            </button>
          </div>

          <div className="tab-content">
           {/* Terminal full-screen tab */}
           {terminalFullScreen && activeTab === 'terminal' && (
             <div style={{ display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
               <TerminalPanel
                 sfConnections={sfConnections}
                 dbConnections={dbConnections}
                 activeSfId={activeSfId}
                 activeDbId={activeDbId}
                 activeDatabase={activeDbConn?.database}
                 onSetActiveSfId={setActiveSfId}
                 onSetActiveDbId={setActiveDbId}
                 isFullScreen
                 onClose={() => { setTerminalFullScreen(false); setActiveTab('salesforce') }}
               />
             </div>
           )}
            <div style={{ display: activeTab === 'salesforce' ? 'flex' : 'none', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <SoqlWorkArea
                sfConnectionId={forExtract(activeSfConn || {}) ? activeSfId : ''}
                sfConnectionName={forExtract(activeSfConn || {}) ? (activeSfConn?.name || '') : ''}
                dbConnectionId={forExtract(activeDbConn || {}) ? activeDbId : ''}
                dbConnections={dbConnections.filter(forExtract)}
                targetDbConnections={dbConnections.filter(c => !['athena', 'redshift'].includes(c.dbType))}
                sfRefreshKey={sfRefreshKey}
                sfConnections={sfConnections.filter(forExtract)}
                activeSfId={forExtract(activeSfConn || {}) ? activeSfId : ''}
                onSetActiveSfId={setActiveSfId}
                onOpenModal={() => setModal({})}
                onEditConn={handleEditConn}
                onNavigateToJobs={() => setActiveTab('jobs')}
                tablePrefix={activeSfConn?.tablePrefix || ''}
              />
            </div>
            <div style={{ display: activeTab === 'database' ? 'flex' : 'none', flexDirection: 'column', flex: 1 }}>
              <SqlWorkArea
                dbConnectionId={forTransform(activeDbConn || {}) ? activeDbId : ''}
                dbConnections={dbConnections.filter(forTransform)}
                targetDbConnections={dbConnections.filter(c => !['athena', 'redshift'].includes(c.dbType) && forTransform(c))}
                activeDbId={forTransform(activeDbConn || {}) ? activeDbId : ''}
                onSetActiveDbId={setActiveDbId}
                onOpenModal={() => setModal({})}
                onEditConn={handleEditConn}
                navigateToTable={navToTable}
                navigateToDatabase={navToDatabase}
                onNavigateHandled={() => { setNavToTable(null); setNavToDatabase(null) }}
              />
            </div>
            <div style={{ display: activeTab === 'upload' ? 'flex' : 'none', flexDirection: 'column', flex: 1 }}>
              <UploadPanel
                sfConnectionId={forTarget(activeSfConn || {}) ? activeSfId : ''}
                sfRefreshKey={sfRefreshKey}
                dbConnectionId={activeDbId}
                sfConnection={forTarget(activeSfConn || {}) ? activeSfConn : null}
                sfConnections={sfConnections.filter(forTarget)}
                dbConnections={dbConnections}
                sourceConnections={[...dbConnections.filter(forSource), ...sfConnections.filter(forSource)]}
                targetConnections={[...sfConnections.filter(forTarget), ...dbConnections.filter(forTarget)]}
                onSetActiveSfId={setActiveSfId}
                onOpenSfModal={() => setModal({ type: 'salesforce' })}
                onEditSfConn={(conn) => setModal({ type: 'salesforce', connection: conn })}
              />
            </div>
            <div style={{ display: activeTab === 'quickload' ? 'flex' : 'none', flexDirection: 'column', flex: 1 }}>
              <QuickLoadPanel
                sfConnections={sfConnections.filter(forTarget)}
                sfRefreshKey={sfRefreshKey}
              />
            </div>
            <div style={{ display: activeTab === 'attachments' ? 'flex' : 'none', flexDirection: 'column', flex: 1 }}>
              <AttachmentPanel
                sfConnections={sfConnections}
                sfConnectionId={activeSfId}
                onSetActiveSfId={setActiveSfId}
                sfRefreshKey={sfRefreshKey}
              />
            </div>
            <div style={{ display: activeTab === 'sandbox' ? 'flex' : 'none', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <SandboxSeedingPanel ref={sandboxRef} sfConnections={sfConnections} />
            </div>
            <div style={{ display: activeTab === 'pipeline' ? 'flex' : 'none', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <PipelinePanel
                sfConnections={sfConnections}
                dbConnections={dbConnections}
              />
            </div>
            <div style={{ display: activeTab === 'script' ? 'flex' : 'none', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <ScriptPanel
                sfConnections={sfConnections}
                dbConnections={dbConnections}
                activeSfId={activeSfId}
                activeDbId={activeDbId}
                activeDatabase={activeDbConn?.database}
              />
            </div>
            <div style={{ display: activeTab === 'excel2text' ? 'flex' : 'none', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <ExcelToTextPanel />
            </div>
            <div style={{ display: activeTab === 'compare' ? 'flex' : 'none', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <DataComparePanel ref={compareRef} sfConnections={sfConnections} dbConnections={dbConnections} />
            </div>
            <div style={{ display: activeTab === 'sampledata' ? 'flex' : 'none', flexDirection: 'column', flex: 1, minHeight: 0, overflow: 'hidden' }}>
              <SampleDataPanel
                sfConnections={sfConnections}
                sfRefreshKey={sfRefreshKey}
              />
            </div>
            <div style={{ display: activeTab === 'jobs' ? 'flex' : 'none', flexDirection: 'column', flex: 1 }}>
              <JobsPanel onNavigateToDb={(connId, database, tableName) => {
                setActiveDbId(connId)
                setNavToDatabase(database || null)
                setNavToTable(tableName || null)
                setActiveTab('database')
              }} />
            </div>
            <div style={{ display: activeTab === 'connections' ? 'flex' : 'none', flexDirection: 'column', flex: 1 }}>
              <ConnectionsPanel
                sfConnections={sfConnections}
                dbConnections={dbConnections}
                onEdit={handleEditConn}
                onDeleteSf={handleDeleteSf}
                onDeleteDb={handleDeleteDb}
                onAdd={() => setModal({})}
                onUpdateUsage={handleUpdateConnectionUsage}
                onUpdateTablePrefix={handleUpdateTablePrefix}
                settings={settings}
                onUpdateSettings={updateSettings}
              />
            </div>
          </div>

          {/* Bottom terminal panel */}
          {terminalOpen && !terminalFullScreen && (
            <TerminalBottomPanel
              sfConnections={sfConnections}
              dbConnections={dbConnections}
              activeSfId={activeSfId}
              activeDbId={activeDbId}
              activeDatabase={activeDbConn?.database}
              onSetActiveSfId={setActiveSfId}
              onSetActiveDbId={setActiveDbId}
              onClose={() => setTerminalOpen(false)}
              onFullScreen={() => { setTerminalFullScreen(true); setTerminalOpen(false); switchTab('terminal') }}
            />
          )}
        </main>
      </div>

      <footer className="status-bar">
        <span>
          <span className={`status-dot ${activeSfConn ? 'connected' : 'disconnected'}`} />
          {activeSfConn ? connectionDisplayName(activeSfConn) : 'SF: Not connected'}
          &nbsp;&nbsp;&bull;&nbsp;&nbsp;
          <span className={`status-dot ${activeDbConn ? 'connected' : 'disconnected'}`} />
          {activeDbConn ? connectionDisplayName(activeDbConn) : 'DB: Not connected'}
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <button
            className="terminal-toggle"
            onClick={() => {
              if (terminalFullScreen) {
                setTerminalFullScreen(false)
                setTerminalOpen(true)
                if (activeTab === 'terminal') switchTab('salesforce')
              } else {
                setTerminalOpen(v => !v)
              }
            }}
            title={terminalOpen || terminalFullScreen ? 'Close Terminal (Ctrl+`)' : 'Open Terminal (Ctrl+`)'}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="4 17 10 11 4 5" /><line x1="12" y1="19" x2="20" y2="19" />
            </svg>
            Terminal
          </button>
          v1.0
        </span>
      </footer>

      {modal && (
        <ConnectionModal
          type={modal.type}
          connection={modal.connection}
          onSave={handleSaveConnection}
          onClose={() => setModal(null)}
        />
      )}

      <GuidedTour
        isOpen={showTour}
        onClose={() => setShowTour(false)}
        helpers={{ setActiveTab: switchTab }}
        activeTab={activeTab}
      />
    </div>
  )
}
