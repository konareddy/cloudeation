# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for Data Rover
# Build with:  pyinstaller datarover.spec

import os

block_cipher = None
ROOT = os.path.abspath('.')

a = Analysis(
    ['backend/app.py'],
    pathex=[os.path.join(ROOT, 'backend')],
    binaries=[],
    datas=[
        ('backend/static', 'static'),
    ],
    hiddenimports=[
        'config',
        'salesforce_client',
        'db_client',
        'downloader',
        'uploader',
        'simple_salesforce',
        'psycopg2',
        'pyathena',
        'mysql.connector',
        'cryptography',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='DataRover',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    icon=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='DataRover',
)
