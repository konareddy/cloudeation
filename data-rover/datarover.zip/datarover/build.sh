#!/bin/bash
set -e

# --------------------------------------------------
# Build script for Cloudeation Data Rover
# Creates a self-contained folder: dist/cloudeation/
# --------------------------------------------------

ROOT="$(cd "$(dirname "$0")" && pwd)"
DIST="$ROOT/dist/cloudeation"

echo "==> Cleaning previous build..."
rm -rf "$DIST"
mkdir -p "$DIST"

# 1. Build the frontend
echo "==> Building frontend..."
cd "$ROOT/frontend"
npm install --silent 2>/dev/null
npx vite build --outDir "$DIST/backend/static" 2>/dev/null
echo "    Frontend built -> backend/static/"

# 2. Copy backend source
echo "==> Copying backend..."
cp "$ROOT/backend/app.py"               "$DIST/backend/"
cp "$ROOT/backend/config.py"            "$DIST/backend/"
cp "$ROOT/backend/db_client.py"         "$DIST/backend/"
cp "$ROOT/backend/downloader.py"        "$DIST/backend/"
cp "$ROOT/backend/salesforce_client.py" "$DIST/backend/"
cp "$ROOT/backend/uploader.py"          "$DIST/backend/"
cp "$ROOT/backend/requirements.txt"     "$DIST/backend/"
mkdir -p "$DIST/backend/uploads"
mkdir -p "$DIST/backend/data"

# 3. Create a virtualenv inside the bundle
echo "==> Creating Python virtual environment..."
python3 -m venv "$DIST/venv"
"$DIST/venv/bin/pip" install --quiet --upgrade pip
"$DIST/venv/bin/pip" install --quiet -r "$DIST/backend/requirements.txt"
echo "    Dependencies installed."

# 4. Create launcher script
cat > "$DIST/start.sh" << 'LAUNCHER'
#!/bin/bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1

# Parse --port from args, or prompt the user
PORT=""
ARGS=()
for arg in "$@"; do
  if [[ "$arg" =~ ^--port=([0-9]+)$ ]]; then
    PORT="${BASH_REMATCH[1]}"
  fi
  ARGS+=("$arg")
done

if [ -z "$PORT" ]; then
  read -p "Enter port number [5001]: " PORT
  PORT="${PORT:-5001}"
  ARGS+=("--port=$PORT")
fi

echo ""
echo "Starting Cloudeation Data Rover..."
echo "  http://127.0.0.1:$PORT"
echo ""
exec "$DIR/venv/bin/python" "$DIR/backend/app.py" "${ARGS[@]}"
LAUNCHER
chmod +x "$DIST/start.sh"

# 5. Create a stop helper
cat > "$DIST/stop.sh" << 'STOPPER'
#!/bin/bash
pkill -f "backend/app.py" 2>/dev/null && echo "Stopped." || echo "Not running."
STOPPER
chmod +x "$DIST/stop.sh"

echo ""
echo "==> Build complete!"
echo "    Output: $DIST"
echo ""
echo "    To install elsewhere:"
echo "      cp -r $DIST /path/to/destination/"
echo ""
echo "    To run:"
echo "      cd /path/to/destination/cloudeation"
echo "      ./start.sh                  # prompts for port (default 5001)"
echo "      ./start.sh --port=8080      # use a specific port"
